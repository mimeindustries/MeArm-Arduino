var morphicVersion = "2014-December-05", modules = {}, useBlurredShadows = getBlurredShadowSupport(), standardSettings = {
    minimumFontHeight: getMinimumFontHeight(),
    globalFontFamily: "",
    menuFontName: "sans-serif",
    menuFontSize: 12,
    bubbleHelpFontSize: 10,
    prompterFontName: "sans-serif",
    prompterFontSize: 12,
    prompterSliderSize: 10,
    handleSize: 15,
    scrollBarSize: 12,
    mouseScrollAmount: 40,
    useSliderForInput: !1,
    useVirtualKeyboard: !0,
    isTouchDevice: !1,
    rasterizeSVGs: !1,
    isFlat: !1
}, touchScreenSettings = {
    minimumFontHeight: standardSettings.minimumFontHeight,
    globalFontFamily: "",
    menuFontName: "sans-serif",
    menuFontSize: 24,
    bubbleHelpFontSize: 18,
    prompterFontName: "sans-serif",
    prompterFontSize: 24,
    prompterSliderSize: 20,
    handleSize: 26,
    scrollBarSize: 24,
    mouseScrollAmount: 40,
    useSliderForInput: !0,
    useVirtualKeyboard: !0,
    isTouchDevice: !1,
    rasterizeSVGs: !1,
    isFlat: !1
}, MorphicPreferences = standardSettings;

function nop() {
    return null;
}

function localize(string) {
    return string;
}

function isNil(thing) {
    return void 0 === thing || null === thing;
}

function contains(list, element) {
    return list.some(function(any) {
        return any === element;
    });
}

function detect(list, predicate) {
    var i, size = list.length;
    for (i = 0; i < size; i += 1) if (predicate.call(null, list[i])) return list[i];
    return null;
}

function sizeOf(object) {
    var key, size = 0;
    for (key in object) Object.prototype.hasOwnProperty.call(object, key) && (size += 1);
    return size;
}

function isString(target) {
    return "string" == typeof target || target instanceof String;
}

function isObject(target) {
    return null !== target && ("object" == typeof target || target instanceof Object);
}

function radians(degrees) {
    return degrees * Math.PI / 180;
}

function degrees(radians) {
    return 180 * radians / Math.PI;
}

function fontHeight(height) {
    return 1.2 * Math.max(height, MorphicPreferences.minimumFontHeight);
}

function newCanvas(extentPoint) {
    var canvas, ext;
    return ext = extentPoint || {
        x: 0,
        y: 0
    }, (canvas = document.createElement("canvas")).width = ext.x, canvas.height = ext.y, 
    canvas;
}

function getMinimumFontHeight() {
    var ctx, maxX, x, y, canvas = document.createElement("canvas");
    for (canvas.width = 50, canvas.height = 50, (ctx = canvas.getContext("2d")).font = "1px serif", 
    maxX = ctx.measureText("I").width, ctx.fillStyle = "black", ctx.textBaseline = "bottom", 
    ctx.fillText("I", 0, 50), y = 0; y < 50; y += 1) for (x = 0; x < maxX; x += 1) if (0 !== ctx.getImageData(x, y, 1, 1).data[3]) return 50 - y + 1;
    return 0;
}

function getBlurredShadowSupport() {
    var source, target, ctx;
    return (source = document.createElement("canvas")).width = 10, source.height = 10, 
    (ctx = source.getContext("2d")).fillStyle = "rgb(255, 0, 0)", ctx.beginPath(), ctx.arc(5, 5, 5, 0, 2 * Math.PI, !0), 
    ctx.closePath(), ctx.fill(), (target = document.createElement("canvas")).width = 10, 
    target.height = 10, (ctx = target.getContext("2d")).shadowBlur = 10, ctx.shadowColor = "rgba(0, 0, 255, 1)", 
    ctx.drawImage(source, 0, 0), !!ctx.getImageData(0, 0, 1, 1).data[3];
}

function getDocumentPositionOf(aDOMelement) {
    var pos, offsetParent;
    if (null === aDOMelement) return {
        x: 0,
        y: 0
    };
    for (pos = {
        x: aDOMelement.offsetLeft,
        y: aDOMelement.offsetTop
    }, offsetParent = aDOMelement.offsetParent; null !== offsetParent; ) pos.x += offsetParent.offsetLeft, 
    pos.y += offsetParent.offsetTop, offsetParent !== document.body && offsetParent !== document.documentElement && (pos.x -= offsetParent.scrollLeft, 
    pos.y -= offsetParent.scrollTop), offsetParent = offsetParent.offsetParent;
    return pos;
}

function clone(target) {
    if ("object" == typeof target) {
        var Clone = function() {
            nop();
        };
        return Clone.prototype = target, new Clone();
    }
    return target;
}

function copy(target) {
    var value, c, property;
    if ("object" != typeof target) return target;
    if (target !== (value = target.valueOf())) return new target.constructor(value);
    if (target instanceof target.constructor && target.constructor !== Object) {
        c = clone(target.constructor.prototype);
        for (property in target) Object.prototype.hasOwnProperty.call(target, property) && (c[property] = target[property]);
    } else {
        c = {};
        for (property in target) c[property] || (c[property] = target[property]);
    }
    return c;
}

function Color(r, g, b, a) {
    this.r = r || 0, this.g = g || 0, this.b = b || 0, this.a = a || (0 === a ? 0 : 1);
}

Color.prototype.toString = function() {
    return "rgba(" + Math.round(this.r) + "," + Math.round(this.g) + "," + Math.round(this.b) + "," + this.a + ")";
}, Color.prototype.copy = function() {
    return new Color(this.r, this.g, this.b, this.a);
}, Color.prototype.eq = function(aColor) {
    return aColor && this.r === aColor.r && this.g === aColor.g && this.b === aColor.b;
}, Color.prototype.hsv = function() {
    var max, min, h, s, v, d, rr = this.r / 255, gg = this.g / 255, bb = this.b / 255;
    if (h = max = Math.max(rr, gg, bb), s = max, v = max, d = max - (min = Math.min(rr, gg, bb)), 
    s = 0 === max ? 0 : d / max, max === min) h = 0; else {
        switch (max) {
          case rr:
            h = (gg - bb) / d + (gg < bb ? 6 : 0);
            break;

          case gg:
            h = (bb - rr) / d + 2;
            break;

          case bb:
            h = (rr - gg) / d + 4;
        }
        h /= 6;
    }
    return [ h, s, v ];
}, Color.prototype.set_hsv = function(h, s, v) {
    var i, f, p, q, t;
    switch (p = v * (1 - s), q = v * (1 - (f = 6 * h - (i = Math.floor(6 * h))) * s), 
    t = v * (1 - (1 - f) * s), i % 6) {
      case 0:
        this.r = v, this.g = t, this.b = p;
        break;

      case 1:
        this.r = q, this.g = v, this.b = p;
        break;

      case 2:
        this.r = p, this.g = v, this.b = t;
        break;

      case 3:
        this.r = p, this.g = q, this.b = v;
        break;

      case 4:
        this.r = t, this.g = p, this.b = v;
        break;

      case 5:
        this.r = v, this.g = p, this.b = q;
    }
    this.r *= 255, this.g *= 255, this.b *= 255;
}, Color.prototype.mixed = function(proportion, otherColor) {
    var frac1 = Math.min(Math.max(proportion, 0), 1), frac2 = 1 - frac1;
    return new Color(this.r * frac1 + otherColor.r * frac2, this.g * frac1 + otherColor.g * frac2, this.b * frac1 + otherColor.b * frac2);
}, Color.prototype.darker = function(percent) {
    var fract = .8333;
    return percent && (fract = (100 - percent) / 100), this.mixed(fract, new Color(0, 0, 0));
}, Color.prototype.lighter = function(percent) {
    var fract = .8333;
    return percent && (fract = (100 - percent) / 100), this.mixed(fract, new Color(255, 255, 255));
}, Color.prototype.dansDarker = function() {
    var hsv = this.hsv(), result = new Color(), vv = Math.max(hsv[2] - .16, 0);
    return result.set_hsv(hsv[0], hsv[1], vv), result;
};

function Point(x, y) {
    this.x = x || 0, this.y = y || 0;
}

Point.prototype.toString = function() {
    return Math.round(this.x.toString()) + "@" + Math.round(this.y.toString());
}, Point.prototype.copy = function() {
    return new Point(this.x, this.y);
}, Point.prototype.eq = function(aPoint) {
    return this.x === aPoint.x && this.y === aPoint.y;
}, Point.prototype.lt = function(aPoint) {
    return this.x < aPoint.x && this.y < aPoint.y;
}, Point.prototype.gt = function(aPoint) {
    return this.x > aPoint.x && this.y > aPoint.y;
}, Point.prototype.ge = function(aPoint) {
    return this.x >= aPoint.x && this.y >= aPoint.y;
}, Point.prototype.le = function(aPoint) {
    return this.x <= aPoint.x && this.y <= aPoint.y;
}, Point.prototype.max = function(aPoint) {
    return new Point(Math.max(this.x, aPoint.x), Math.max(this.y, aPoint.y));
}, Point.prototype.min = function(aPoint) {
    return new Point(Math.min(this.x, aPoint.x), Math.min(this.y, aPoint.y));
}, Point.prototype.round = function() {
    return new Point(Math.round(this.x), Math.round(this.y));
}, Point.prototype.abs = function() {
    return new Point(Math.abs(this.x), Math.abs(this.y));
}, Point.prototype.neg = function() {
    return new Point(-this.x, -this.y);
}, Point.prototype.mirror = function() {
    return new Point(this.y, this.x);
}, Point.prototype.floor = function() {
    return new Point(Math.max(Math.floor(this.x), 0), Math.max(Math.floor(this.y), 0));
}, Point.prototype.ceil = function() {
    return new Point(Math.ceil(this.x), Math.ceil(this.y));
}, Point.prototype.add = function(other) {
    return other instanceof Point ? new Point(this.x + other.x, this.y + other.y) : new Point(this.x + other, this.y + other);
}, Point.prototype.subtract = function(other) {
    return other instanceof Point ? new Point(this.x - other.x, this.y - other.y) : new Point(this.x - other, this.y - other);
}, Point.prototype.multiplyBy = function(other) {
    return other instanceof Point ? new Point(this.x * other.x, this.y * other.y) : new Point(this.x * other, this.y * other);
}, Point.prototype.divideBy = function(other) {
    return other instanceof Point ? new Point(this.x / other.x, this.y / other.y) : new Point(this.x / other, this.y / other);
}, Point.prototype.floorDivideBy = function(other) {
    return other instanceof Point ? new Point(Math.floor(this.x / other.x), Math.floor(this.y / other.y)) : new Point(Math.floor(this.x / other), Math.floor(this.y / other));
}, Point.prototype.r = function() {
    var t = this.multiplyBy(this);
    return Math.sqrt(t.x + t.y);
}, Point.prototype.degrees = function() {
    var tan, theta;
    return 0 === this.x ? this.y >= 0 ? 90 : 270 : (tan = this.y / this.x, theta = Math.atan(tan), 
    this.x >= 0 ? this.y >= 0 ? degrees(theta) : 360 + degrees(theta) : 180 + degrees(theta));
}, Point.prototype.theta = function() {
    var tan, theta;
    return 0 === this.x ? this.y >= 0 ? radians(90) : radians(270) : (tan = this.y / this.x, 
    theta = Math.atan(tan), this.x >= 0 ? this.y >= 0 ? theta : radians(360) + theta : radians(180) + theta);
}, Point.prototype.crossProduct = function(aPoint) {
    return this.multiplyBy(aPoint.mirror());
}, Point.prototype.distanceTo = function(aPoint) {
    return aPoint.subtract(this).r();
}, Point.prototype.rotate = function(direction, center) {
    var offset = this.subtract(center);
    return "right" === direction ? new Point(-offset.y, offset.y).add(center) : "left" === direction ? new Point(offset.y, -offset.y).add(center) : center.subtract(offset);
}, Point.prototype.flip = function(direction, center) {
    return "vertical" === direction ? new Point(this.x, 2 * center.y - this.y) : new Point(2 * center.x - this.x, this.y);
}, Point.prototype.distanceAngle = function(dist, angle) {
    var x, y, deg = angle;
    return deg > 270 ? deg -= 360 : deg < -270 && (deg += 360), -90 <= deg && deg <= 90 ? (x = Math.sin(radians(deg)) * dist, 
    y = Math.sqrt(dist * dist - x * x), new Point(x + this.x, this.y - y)) : (x = Math.sin(radians(180 - deg)) * dist, 
    y = Math.sqrt(dist * dist - x * x), new Point(x + this.x, this.y + y));
}, Point.prototype.scaleBy = function(scalePoint) {
    return this.multiplyBy(scalePoint);
}, Point.prototype.translateBy = function(deltaPoint) {
    return this.add(deltaPoint);
}, Point.prototype.rotateBy = function(angle, centerPoint) {
    var center = centerPoint || new Point(0, 0), p = this.subtract(center), r = p.r(), theta = angle - p.theta();
    return new Point(center.x + r * Math.cos(theta), center.y - r * Math.sin(theta));
}, Point.prototype.asArray = function() {
    return [ this.x, this.y ];
};

function Rectangle(left, top, right, bottom) {
    this.init(new Point(left || 0, top || 0), new Point(right || 0, bottom || 0));
}

Rectangle.prototype.init = function(originPoint, cornerPoint) {
    this.origin = originPoint, this.corner = cornerPoint;
}, Rectangle.prototype.toString = function() {
    return "[" + this.origin.toString() + " | " + this.extent().toString() + "]";
}, Rectangle.prototype.copy = function() {
    return new Rectangle(this.left(), this.top(), this.right(), this.bottom());
}, Point.prototype.corner = function(cornerPoint) {
    return new Rectangle(this.x, this.y, cornerPoint.x, cornerPoint.y);
}, Point.prototype.rectangle = function(aPoint) {
    var org, crn;
    return org = this.min(aPoint), crn = this.max(aPoint), new Rectangle(org.x, org.y, crn.x, crn.y);
}, Point.prototype.extent = function(aPoint) {
    var crn = this.add(aPoint);
    return new Rectangle(this.x, this.y, crn.x, crn.y);
}, Rectangle.prototype.setTo = function(left, top, right, bottom) {
    this.origin = new Point(left || (0 === left ? 0 : this.left()), top || (0 === top ? 0 : this.top())), 
    this.corner = new Point(right || (0 === right ? 0 : this.right()), bottom || (0 === bottom ? 0 : this.bottom()));
}, Rectangle.prototype.area = function() {
    var w = this.width();
    return w < 0 ? 0 : Math.max(w * this.height(), 0);
}, Rectangle.prototype.bottom = function() {
    return this.corner.y;
}, Rectangle.prototype.bottomCenter = function() {
    return new Point(this.center().x, this.bottom());
}, Rectangle.prototype.bottomLeft = function() {
    return new Point(this.origin.x, this.corner.y);
}, Rectangle.prototype.bottomRight = function() {
    return this.corner.copy();
}, Rectangle.prototype.boundingBox = function() {
    return this;
}, Rectangle.prototype.center = function() {
    return this.origin.add(this.corner.subtract(this.origin).floorDivideBy(2));
}, Rectangle.prototype.corners = function() {
    return [ this.origin, this.bottomLeft(), this.corner, this.topRight() ];
}, Rectangle.prototype.extent = function() {
    return this.corner.subtract(this.origin);
}, Rectangle.prototype.height = function() {
    return this.corner.y - this.origin.y;
}, Rectangle.prototype.left = function() {
    return this.origin.x;
}, Rectangle.prototype.leftCenter = function() {
    return new Point(this.left(), this.center().y);
}, Rectangle.prototype.right = function() {
    return this.corner.x;
}, Rectangle.prototype.rightCenter = function() {
    return new Point(this.right(), this.center().y);
}, Rectangle.prototype.top = function() {
    return this.origin.y;
}, Rectangle.prototype.topCenter = function() {
    return new Point(this.center().x, this.top());
}, Rectangle.prototype.topLeft = function() {
    return this.origin;
}, Rectangle.prototype.topRight = function() {
    return new Point(this.corner.x, this.origin.y);
}, Rectangle.prototype.width = function() {
    return this.corner.x - this.origin.x;
}, Rectangle.prototype.position = function() {
    return this.origin;
}, Rectangle.prototype.eq = function(aRect) {
    return this.origin.eq(aRect.origin) && this.corner.eq(aRect.corner);
}, Rectangle.prototype.abs = function() {
    var newOrigin, newCorner;
    return newOrigin = this.origin.abs(), newCorner = this.corner.max(newOrigin), newOrigin.corner(newCorner);
}, Rectangle.prototype.insetBy = function(delta) {
    var result = new Rectangle();
    return result.origin = this.origin.add(delta), result.corner = this.corner.subtract(delta), 
    result;
}, Rectangle.prototype.expandBy = function(delta) {
    var result = new Rectangle();
    return result.origin = this.origin.subtract(delta), result.corner = this.corner.add(delta), 
    result;
}, Rectangle.prototype.growBy = function(delta) {
    var result = new Rectangle();
    return result.origin = this.origin.copy(), result.corner = this.corner.add(delta), 
    result;
}, Rectangle.prototype.intersect = function(aRect) {
    var result = new Rectangle();
    return result.origin = this.origin.max(aRect.origin), result.corner = this.corner.min(aRect.corner), 
    result;
}, Rectangle.prototype.merge = function(aRect) {
    var result = new Rectangle();
    return result.origin = this.origin.min(aRect.origin), result.corner = this.corner.max(aRect.corner), 
    result;
}, Rectangle.prototype.mergeWith = function(aRect) {
    this.origin = this.origin.min(aRect.origin), this.corner = this.corner.max(aRect.corner);
}, Rectangle.prototype.round = function() {
    return this.origin.round().corner(this.corner.round());
}, Rectangle.prototype.spread = function() {
    return this.origin.floor().corner(this.corner.ceil()).expandBy(1);
}, Rectangle.prototype.amountToTranslateWithin = function(aRect) {
    var dx = 0, dy = 0;
    return this.right() > aRect.right() && (dx = aRect.right() - this.right()), this.bottom() > aRect.bottom() && (dy = aRect.bottom() - this.bottom()), 
    this.left() + dx < aRect.left() && (dx = aRect.left() - this.left()), this.top() + dy < aRect.top() && (dy = aRect.top() - this.top()), 
    new Point(dx, dy);
}, Rectangle.prototype.containsPoint = function(aPoint) {
    return this.origin.le(aPoint) && aPoint.lt(this.corner);
}, Rectangle.prototype.containsRectangle = function(aRect) {
    return aRect.origin.gt(this.origin) && aRect.corner.lt(this.corner);
}, Rectangle.prototype.intersects = function(aRect) {
    var ro = aRect.origin, rc = aRect.corner;
    return rc.x >= this.origin.x && rc.y >= this.origin.y && ro.x <= this.corner.x && ro.y <= this.corner.y;
}, Rectangle.prototype.isNearTo = function(aRect, threshold) {
    var ro = aRect.origin, rc = aRect.corner, border = threshold || 0;
    return rc.x + border >= this.origin.x && rc.y + border >= this.origin.y && ro.x - border <= this.corner.x && ro.y - border <= this.corner.y;
}, Rectangle.prototype.scaleBy = function(scale) {
    var o = this.origin.multiplyBy(scale), c = this.corner.multiplyBy(scale);
    return new Rectangle(o.x, o.y, c.x, c.y);
}, Rectangle.prototype.translateBy = function(factor) {
    var o = this.origin.add(factor), c = this.corner.add(factor);
    return new Rectangle(o.x, o.y, c.x, c.y);
}, Rectangle.prototype.asArray = function() {
    return [ this.left(), this.top(), this.right(), this.bottom() ];
}, Rectangle.prototype.asArray_xywh = function() {
    return [ this.left(), this.top(), this.width(), this.height() ];
};

function Node(parent, childrenArray) {
    this.init(parent || null, childrenArray || []);
}

Node.prototype.init = function(parent, childrenArray) {
    this.parent = parent || null, this.children = childrenArray || [];
}, Node.prototype.toString = function() {
    return "a Node[" + this.children.length.toString() + "]";
}, Node.prototype.addChild = function(aNode) {
    this.children.push(aNode), aNode.parent = this;
}, Node.prototype.addChildFirst = function(aNode) {
    this.children.splice(0, null, aNode), aNode.parent = this;
}, Node.prototype.removeChild = function(aNode) {
    var idx = this.children.indexOf(aNode);
    -1 !== idx && this.children.splice(idx, 1);
}, Node.prototype.root = function() {
    return null === this.parent ? this : this.parent.root();
}, Node.prototype.depth = function() {
    return null === this.parent ? 0 : this.parent.depth() + 1;
}, Node.prototype.allChildren = function() {
    var result = [ this ];
    return this.children.forEach(function(child) {
        result = result.concat(child.allChildren());
    }), result;
}, Node.prototype.forAllChildren = function(aFunction) {
    this.children.length > 0 && this.children.forEach(function(child) {
        child.forAllChildren(aFunction);
    }), aFunction.call(null, this);
}, Node.prototype.allLeafs = function() {
    var result = [];
    return this.allChildren().forEach(function(element) {
        0 === element.children.length && result.push(element);
    }), result;
}, Node.prototype.allParents = function() {
    var result = [ this ];
    return null !== this.parent && (result = result.concat(this.parent.allParents())), 
    result;
}, Node.prototype.siblings = function() {
    var myself = this;
    return null === this.parent ? [] : this.parent.children.filter(function(child) {
        return child !== myself;
    });
}, Node.prototype.parentThatIsA = function(constructor) {
    return this instanceof constructor ? this : this.parent ? this.parent.parentThatIsA(constructor) : null;
}, Node.prototype.parentThatIsAnyOf = function(constructors) {
    var yup = !1, myself = this;
    return constructors.forEach(function(each) {
        myself.constructor !== each || (yup = !0);
    }), yup ? this : this.parent ? this.parent.parentThatIsAnyOf(constructors) : null;
};

var Morph, WorldMorph, HandMorph, ShadowMorph, FrameMorph, MenuMorph, HandleMorph, StringFieldMorph, ColorPickerMorph, SliderMorph, ScrollFrameMorph, InspectorMorph, StringMorph, TextMorph;

Morph.prototype = new Node(), Morph.prototype.constructor = Morph, Morph.uber = Node.prototype, 
Morph.prototype.trackChanges = !0, Morph.prototype.shadowBlur = 4;

function Morph() {
    this.init();
}

Morph.prototype.init = function() {
    Morph.uber.init.call(this), this.isMorph = !0, this.bounds = new Rectangle(0, 0, 50, 40), 
    this.color = new Color(80, 80, 80), this.texture = null, this.cachedTexture = null, 
    this.alpha = 1, this.isVisible = !0, this.isDraggable = !1, this.isTemplate = !1, 
    this.acceptsDrops = !1, this.noticesTransparentClick = !1, this.drawNew(), this.fps = 0, 
    this.customContextMenu = null, this.lastTime = Date.now(), this.onNextStep = null;
}, Morph.prototype.toString = function() {
    return "a " + (this.constructor.name || this.constructor.toString().split(" ")[1].split("(")[0]) + " " + this.children.length.toString() + " " + this.bounds;
}, Morph.prototype.destroy = function() {
    null !== this.parent && (this.fullChanged(), this.parent.removeChild(this));
}, Morph.prototype.stepFrame = function() {
    if (!this.step) return null;
    var current, elapsed, nxt;
    elapsed = (current = Date.now()) - this.lastTime, (this.fps > 0 ? 1e3 / this.fps - elapsed : 0) < 1 && (this.lastTime = current, 
    this.onNextStep && (nxt = this.onNextStep, this.onNextStep = null, nxt.call(this)), 
    this.step(), this.children.forEach(function(child) {
        child.stepFrame();
    }));
}, Morph.prototype.nextSteps = function(arrayOfFunctions) {
    var lst = arrayOfFunctions || [], nxt = lst.shift(), myself = this;
    nxt && (this.onNextStep = function() {
        nxt.call(myself), myself.nextSteps(lst);
    });
}, Morph.prototype.step = function() {
    nop();
}, Morph.prototype.left = function() {
    return this.bounds.left();
}, Morph.prototype.right = function() {
    return this.bounds.right();
}, Morph.prototype.top = function() {
    return this.bounds.top();
}, Morph.prototype.bottom = function() {
    return this.bounds.bottom();
}, Morph.prototype.center = function() {
    return this.bounds.center();
}, Morph.prototype.bottomCenter = function() {
    return this.bounds.bottomCenter();
}, Morph.prototype.bottomLeft = function() {
    return this.bounds.bottomLeft();
}, Morph.prototype.bottomRight = function() {
    return this.bounds.bottomRight();
}, Morph.prototype.boundingBox = function() {
    return this.bounds;
}, Morph.prototype.corners = function() {
    return this.bounds.corners();
}, Morph.prototype.leftCenter = function() {
    return this.bounds.leftCenter();
}, Morph.prototype.rightCenter = function() {
    return this.bounds.rightCenter();
}, Morph.prototype.topCenter = function() {
    return this.bounds.topCenter();
}, Morph.prototype.topLeft = function() {
    return this.bounds.topLeft();
}, Morph.prototype.topRight = function() {
    return this.bounds.topRight();
}, Morph.prototype.position = function() {
    return this.bounds.origin;
}, Morph.prototype.extent = function() {
    return this.bounds.extent();
}, Morph.prototype.width = function() {
    return this.bounds.width();
}, Morph.prototype.height = function() {
    return this.bounds.height();
}, Morph.prototype.fullBounds = function() {
    var result;
    return result = this.bounds, this.children.forEach(function(child) {
        child.isVisible && (result = result.merge(child.fullBounds()));
    }), result;
}, Morph.prototype.fullBoundsNoShadow = function() {
    var result;
    return result = this.bounds, this.children.forEach(function(child) {
        child instanceof ShadowMorph || !child.isVisible || (result = result.merge(child.fullBounds()));
    }), result;
}, Morph.prototype.visibleBounds = function() {
    var visible = this.bounds;
    return this.allParents().filter(function(p) {
        return p instanceof FrameMorph;
    }).forEach(function(f) {
        visible = visible.intersect(f.bounds);
    }), visible;
}, Morph.prototype.moveBy = function(delta) {
    this.changed(), this.bounds = this.bounds.translateBy(delta), this.children.forEach(function(child) {
        child.moveBy(delta);
    }), this.changed();
}, Morph.prototype.silentMoveBy = function(delta) {
    this.bounds = this.bounds.translateBy(delta), this.children.forEach(function(child) {
        child.silentMoveBy(delta);
    });
}, Morph.prototype.setPosition = function(aPoint) {
    var delta = aPoint.subtract(this.topLeft());
    0 === delta.x && 0 === delta.y || this.moveBy(delta);
}, Morph.prototype.silentSetPosition = function(aPoint) {
    var delta = aPoint.subtract(this.topLeft());
    0 === delta.x && 0 === delta.y || this.silentMoveBy(delta);
}, Morph.prototype.setLeft = function(x) {
    this.setPosition(new Point(x, this.top()));
}, Morph.prototype.setRight = function(x) {
    this.setPosition(new Point(x - this.width(), this.top()));
}, Morph.prototype.setTop = function(y) {
    this.setPosition(new Point(this.left(), y));
}, Morph.prototype.setBottom = function(y) {
    this.setPosition(new Point(this.left(), y - this.height()));
}, Morph.prototype.setCenter = function(aPoint) {
    this.setPosition(aPoint.subtract(this.extent().floorDivideBy(2)));
}, Morph.prototype.setFullCenter = function(aPoint) {
    this.setPosition(aPoint.subtract(this.fullBounds().extent().floorDivideBy(2)));
}, Morph.prototype.keepWithin = function(aMorph) {
    var leftOff, rightOff, topOff, bottomOff;
    (leftOff = this.fullBounds().left() - aMorph.left()) < 0 && this.moveBy(new Point(-leftOff, 0)), 
    (rightOff = this.fullBounds().right() - aMorph.right()) > 0 && this.moveBy(new Point(-rightOff, 0)), 
    (topOff = this.fullBounds().top() - aMorph.top()) < 0 && this.moveBy(new Point(0, -topOff)), 
    (bottomOff = this.fullBounds().bottom() - aMorph.bottom()) > 0 && this.moveBy(new Point(0, -bottomOff));
}, Morph.prototype.setExtent = function(aPoint) {
    aPoint.eq(this.extent()) || (this.changed(), this.silentSetExtent(aPoint), this.changed(), 
    this.drawNew());
}, Morph.prototype.silentSetExtent = function(aPoint) {
    var ext, newWidth, newHeight;
    ext = aPoint.round(), newWidth = Math.max(ext.x, 0), newHeight = Math.max(ext.y, 0), 
    this.bounds.corner = new Point(this.bounds.origin.x + newWidth, this.bounds.origin.y + newHeight);
}, Morph.prototype.setWidth = function(width) {
    this.setExtent(new Point(width || 0, this.height()));
}, Morph.prototype.silentSetWidth = function(width) {
    var w = Math.max(Math.round(width || 0), 0);
    this.bounds.corner = new Point(this.bounds.origin.x + w, this.bounds.corner.y);
}, Morph.prototype.setHeight = function(height) {
    this.setExtent(new Point(this.width(), height || 0));
}, Morph.prototype.silentSetHeight = function(height) {
    var h = Math.max(Math.round(height || 0), 0);
    this.bounds.corner = new Point(this.bounds.corner.x, this.bounds.origin.y + h);
}, Morph.prototype.setColor = function(aColor) {
    aColor && (this.color.eq(aColor) || (this.color = aColor, this.changed(), this.drawNew()));
}, Morph.prototype.drawNew = function() {
    this.image = newCanvas(this.extent());
    var context = this.image.getContext("2d");
    context.fillStyle = this.color.toString(), context.fillRect(0, 0, this.width(), this.height()), 
    this.cachedTexture ? this.drawCachedTexture() : this.texture && this.drawTexture(this.texture);
}, Morph.prototype.drawTexture = function(url) {
    var myself = this;
    this.cachedTexture = new Image(), this.cachedTexture.onload = function() {
        myself.drawCachedTexture();
    }, this.cachedTexture.src = this.texture = url;
}, Morph.prototype.drawCachedTexture = function() {
    var x, y, bg = this.cachedTexture, cols = Math.floor(this.image.width / bg.width), lines = Math.floor(this.image.height / bg.height), context = this.image.getContext("2d");
    for (y = 0; y <= lines; y += 1) for (x = 0; x <= cols; x += 1) context.drawImage(bg, x * bg.width, y * bg.height);
    this.changed();
}, Morph.prototype.drawOn = function(aCanvas, aRect) {
    var area, delta, src, context, w, h, sl, st;
    if (!this.isVisible) return null;
    if ((area = (aRect || this.bounds()).intersect(this.bounds).round()).extent().gt(new Point(0, 0))) {
        if (delta = this.position().neg(), src = area.copy().translateBy(delta).round(), 
        (context = aCanvas.getContext("2d")).globalAlpha = this.alpha, sl = src.left(), 
        st = src.top(), w = Math.min(src.width(), this.image.width - sl), h = Math.min(src.height(), this.image.height - st), 
        w < 1 || h < 1) return null;
        context.drawImage(this.image, src.left(), src.top(), w, h, area.left(), area.top(), w, h);
    }
}, Morph.prototype.fullDrawOn = function(aCanvas, aRect) {
    var rectangle;
    if (!this.isVisible) return null;
    rectangle = aRect || this.fullBounds(), this.drawOn(aCanvas, rectangle), this.children.forEach(function(child) {
        child.fullDrawOn(aCanvas, rectangle);
    });
}, Morph.prototype.hide = function() {
    this.isVisible = !1, this.changed(), this.children.forEach(function(child) {
        child.hide();
    });
}, Morph.prototype.show = function() {
    this.isVisible = !0, this.changed(), this.children.forEach(function(child) {
        child.show();
    });
}, Morph.prototype.toggleVisibility = function() {
    this.isVisible = !this.isVisible, this.changed(), this.children.forEach(function(child) {
        child.toggleVisibility();
    });
}, Morph.prototype.fullImageClassic = function() {
    var fb = this.fullBounds(), img = newCanvas(fb.extent());
    return img.getContext("2d").translate(-this.bounds.origin.x, -this.bounds.origin.y), 
    this.fullDrawOn(img, fb), img.globalAlpha = this.alpha, img;
}, Morph.prototype.fullImage = function() {
    var img, ctx, fb;
    return img = newCanvas(this.fullBounds().extent()), ctx = img.getContext("2d"), 
    fb = this.fullBounds(), this.allChildren().forEach(function(morph) {
        morph.isVisible && (ctx.globalAlpha = morph.alpha, morph.image.width && morph.image.height && ctx.drawImage(morph.image, morph.bounds.origin.x - fb.origin.x, morph.bounds.origin.y - fb.origin.y));
    }), img;
}, Morph.prototype.shadowImage = function(off, color) {
    var fb, img, outline, sha, ctx, offset = off || new Point(7, 7), clr = color || new Color(0, 0, 0);
    return fb = this.fullBounds().extent(), img = this.fullImage(), (ctx = (outline = newCanvas(fb)).getContext("2d")).drawImage(img, 0, 0), 
    ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, -offset.x, -offset.y), 
    (ctx = (sha = newCanvas(fb)).getContext("2d")).drawImage(outline, 0, 0), ctx.globalCompositeOperation = "source-atop", 
    ctx.fillStyle = clr.toString(), ctx.fillRect(0, 0, fb.x, fb.y), sha;
}, Morph.prototype.shadowImageBlurred = function(off, color) {
    var fb, img, sha, ctx, offset = off || new Point(7, 7), blur = this.shadowBlur, clr = color || new Color(0, 0, 0);
    return fb = this.fullBounds().extent().add(2 * blur), img = this.fullImage(), (ctx = (sha = newCanvas(fb)).getContext("2d")).shadowOffsetX = offset.x, 
    ctx.shadowOffsetY = offset.y, ctx.shadowBlur = blur, ctx.shadowColor = clr.toString(), 
    ctx.drawImage(img, blur - offset.x, blur - offset.y), ctx.shadowOffsetX = 0, ctx.shadowOffsetY = 0, 
    ctx.shadowBlur = 0, ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, blur - offset.x, blur - offset.y), 
    sha;
}, Morph.prototype.shadow = function(off, a, color) {
    var shadow = new ShadowMorph(), offset = off || new Point(7, 7), alpha = a || (0 === a ? 0 : .2), fb = this.fullBounds();
    return shadow.setExtent(fb.extent().add(2 * this.shadowBlur)), useBlurredShadows && !MorphicPreferences.isFlat ? (shadow.image = this.shadowImageBlurred(offset, color), 
    shadow.alpha = alpha, shadow.setPosition(fb.origin.add(offset).subtract(this.shadowBlur))) : (shadow.image = this.shadowImage(offset, color), 
    shadow.alpha = alpha, shadow.setPosition(fb.origin.add(offset))), shadow;
}, Morph.prototype.addShadow = function(off, a, color) {
    var shadow, offset = off || new Point(7, 7), alpha = a || (0 === a ? 0 : .2);
    return shadow = this.shadow(offset, alpha, color), this.addBack(shadow), this.fullChanged(), 
    shadow;
}, Morph.prototype.getShadow = function() {
    var shadows;
    return 0 !== (shadows = this.children.slice(0).reverse().filter(function(child) {
        return child instanceof ShadowMorph;
    })).length ? shadows[0] : null;
}, Morph.prototype.removeShadow = function() {
    var shadow = this.getShadow();
    null !== shadow && (this.fullChanged(), this.removeChild(shadow));
}, Morph.prototype.penTrails = function() {
    return this.image;
}, Morph.prototype.changed = function() {
    if (this.trackChanges) {
        var w = this.root();
        w instanceof WorldMorph && w.broken.push(this.visibleBounds().spread());
    }
    this.parent && this.parent.childChanged(this);
}, Morph.prototype.fullChanged = function() {
    if (this.trackChanges) {
        var w = this.root();
        w instanceof WorldMorph && w.broken.push(this.fullBounds().spread());
    }
}, Morph.prototype.childChanged = function() {
    this.parent && this.parent.childChanged(this);
}, Morph.prototype.world = function() {
    var root = this.root();
    return root instanceof WorldMorph ? root : root instanceof HandMorph ? root.world : null;
}, Morph.prototype.add = function(aMorph) {
    var owner = aMorph.parent;
    null !== owner && owner.removeChild(aMorph), this.addChild(aMorph);
}, Morph.prototype.addBack = function(aMorph) {
    var owner = aMorph.parent;
    null !== owner && owner.removeChild(aMorph), this.addChildFirst(aMorph);
}, Morph.prototype.topMorphSuchThat = function(predicate) {
    var next;
    return predicate.call(null, this) ? (next = detect(this.children.slice(0).reverse(), predicate)) ? next.topMorphSuchThat(predicate) : this : null;
}, Morph.prototype.morphAt = function(aPoint) {
    var result = null;
    return this.allChildren().slice(0).reverse().forEach(function(m) {
        m.fullBounds().containsPoint(aPoint) && null === result && (result = m);
    }), result;
}, Morph.prototype.overlappedMorphs = function() {
    var world = this.world(), fb = this.fullBounds(), myself = this, allParents = this.allParents(), allChildren = this.allChildren();
    return world.allChildren().filter(function(m) {
        return m.isVisible && m !== myself && m !== world && !contains(allParents, m) && !contains(allChildren, m) && m.fullBounds().intersects(fb);
    });
}, Morph.prototype.getPixelColor = function(aPoint) {
    var point, data;
    return point = aPoint.subtract(this.bounds.origin), new Color((data = this.image.getContext("2d").getImageData(point.x, point.y, 1, 1)).data[0], data.data[1], data.data[2], data.data[3]);
}, Morph.prototype.isTransparentAt = function(aPoint) {
    var point;
    return !!this.bounds.containsPoint(aPoint) && (!this.texture && (point = aPoint.subtract(this.bounds.origin), 
    0 === this.image.getContext("2d").getImageData(Math.floor(point.x), Math.floor(point.y), 1, 1).data[3]));
}, Morph.prototype.copy = function() {
    var c = copy(this);
    return c.parent = null, c.children = [], c.bounds = this.bounds.copy(), c;
}, Morph.prototype.fullCopy = function() {
    var c, dict = {};
    return (c = this.copyRecordingReferences(dict)).forAllChildren(function(m) {
        m.updateReferences(dict);
    }), c;
}, Morph.prototype.copyRecordingReferences = function(dict) {
    var c = this.copy();
    return dict[this] = c, this.children.forEach(function(m) {
        c.add(m.copyRecordingReferences(dict));
    }), c;
}, Morph.prototype.updateReferences = function(dict) {
    var property;
    for (property in this) this[property] && this[property].isMorph && dict[property] && (this[property] = dict[property]);
}, Morph.prototype.rootForGrab = function() {
    return this instanceof ShadowMorph ? this.parent.rootForGrab() : this.parent instanceof ScrollFrameMorph ? this.parent : null === this.parent || this.parent instanceof WorldMorph || this.parent instanceof FrameMorph || !0 === this.isDraggable ? this : this.parent.rootForGrab();
}, Morph.prototype.wantsDropOf = function(aMorph) {
    return !(aMorph instanceof HandleMorph || aMorph instanceof MenuMorph || aMorph instanceof InspectorMorph) && this.acceptsDrops;
}, Morph.prototype.pickUp = function(wrrld) {
    var world = wrrld || this.world();
    this.setPosition(world.hand.position().subtract(this.extent().floorDivideBy(2))), 
    world.hand.grab(this);
}, Morph.prototype.isPickedUp = function() {
    return null !== this.parentThatIsA(HandMorph);
}, Morph.prototype.situation = function() {
    return this.parent ? {
        origin: this.parent,
        position: this.position().subtract(this.parent.position())
    } : null;
}, Morph.prototype.slideBackTo = function(situation, inSteps) {
    var steps = inSteps || 5, pos = situation.origin.position().add(situation.position), xStep = -(this.left() - pos.x) / steps, yStep = -(this.top() - pos.y) / steps, stepCount = 0, oldStep = this.step, oldFps = this.fps, myself = this;
    this.fps = 0, this.step = function() {
        myself.fullChanged(), myself.silentMoveBy(new Point(xStep, yStep)), myself.fullChanged(), 
        (stepCount += 1) === steps && (situation.origin.add(myself), situation.origin.reactToDropOf && situation.origin.reactToDropOf(myself), 
        myself.step = oldStep, myself.fps = oldFps);
    };
}, Morph.prototype.nop = function() {
    nop();
}, Morph.prototype.resize = function() {
    this.world().activeHandle = new HandleMorph(this);
}, Morph.prototype.move = function() {
    this.world().activeHandle = new HandleMorph(this, null, null, null, null, "move");
}, Morph.prototype.hint = function(msg) {
    var m, text;
    text = msg, msg ? msg.toString && (text = msg.toString()) : text = "NULL", (m = new MenuMorph(this, text)).isDraggable = !0, 
    m.popUpCenteredAtHand(this.world());
}, Morph.prototype.inform = function(msg) {
    var m, text;
    text = msg, msg ? msg.toString && (text = msg.toString()) : text = "NULL", (m = new MenuMorph(this, text)).addItem("Ok"), 
    m.isDraggable = !0, m.popUpCenteredAtHand(this.world());
}, Morph.prototype.prompt = function(msg, callback, environment, defaultContents, width, floorNum, ceilingNum, isRounded) {
    var menu, entryField, slider, isNumeric;
    ceilingNum && (isNumeric = !0), menu = new MenuMorph(callback || null, msg || "", environment || null), 
    entryField = new StringFieldMorph(defaultContents || "", width || 100, MorphicPreferences.prompterFontSize, MorphicPreferences.prompterFontName, !1, !1, isNumeric), 
    menu.items.push(entryField), (ceilingNum || MorphicPreferences.useSliderForInput) && ((slider = new SliderMorph(floorNum || 0, ceilingNum, parseFloat(defaultContents), Math.floor((ceilingNum - floorNum) / 4), "horizontal")).alpha = 1, 
    slider.color = new Color(225, 225, 225), slider.button.color = menu.borderColor, 
    slider.button.highlightColor = slider.button.color.copy(), slider.button.highlightColor.b += 100, 
    slider.button.pressColor = slider.button.color.copy(), slider.button.pressColor.b += 150, 
    slider.setHeight(MorphicPreferences.prompterSliderSize), slider.action = isRounded ? function(num) {
        entryField.changed(), entryField.text.text = Math.round(num).toString(), entryField.text.drawNew(), 
        entryField.text.changed(), entryField.text.edit();
    } : function(num) {
        entryField.changed(), entryField.text.text = num.toString(), entryField.text.drawNew(), 
        entryField.text.changed();
    }, menu.items.push(slider)), menu.addLine(2), menu.addItem("Ok", function() {
        return entryField.string();
    }), menu.addItem("Cancel", function() {
        return null;
    }), menu.isDraggable = !0, menu.popUpAtHand(this.world()), entryField.text.edit();
}, Morph.prototype.pickColor = function(msg, callback, environment, defaultContents) {
    var menu, colorPicker;
    menu = new MenuMorph(callback || null, msg || "", environment || null), colorPicker = new ColorPickerMorph(defaultContents), 
    menu.items.push(colorPicker), menu.addLine(2), menu.addItem("Ok", function() {
        return colorPicker.getChoice();
    }), menu.addItem("Cancel", function() {
        return null;
    }), menu.isDraggable = !0, menu.popUpAtHand(this.world());
}, Morph.prototype.inspect = function(anotherObject) {
    var inspector, world = this.world instanceof Function ? this.world() : this.root() || this.world, inspectee = this;
    anotherObject && (inspectee = anotherObject), (inspector = new InspectorMorph(inspectee)).setPosition(world.hand.position()), 
    inspector.keepWithin(world), world.add(inspector), inspector.changed();
}, Morph.prototype.contextMenu = function() {
    var world;
    return this.customContextMenu ? this.customContextMenu : (world = this.world instanceof Function ? this.world() : this.world) && world.isDevMode ? this.parent === world ? this.developersMenu() : this.hierarchyMenu() : this.userMenu() || this.parent && this.parent.userMenu();
}, Morph.prototype.hierarchyMenu = function() {
    var parents = this.allParents(), world = this.world instanceof Function ? this.world() : this.world, menu = new MenuMorph(this, null);
    return parents.forEach(function(each) {
        each.developersMenu && each !== world && menu.addItem(each.toString().slice(0, 50), function() {
            each.developersMenu().popUpAtHand(world);
        });
    }), menu;
}, Morph.prototype.developersMenu = function() {
    var world = this.world instanceof Function ? this.world() : this.world, userMenu = this.userMenu() || this.parent && this.parent.userMenu(), menu = new MenuMorph(this, this.constructor.name || this.constructor.toString().split(" ")[1].split("(")[0]);
    return userMenu && (menu.addItem("user features...", function() {
        userMenu.popUpAtHand(world);
    }), menu.addLine()), menu.addItem("color...", function() {
        this.pickColor(menu.title + "\ncolor:", this.setColor, this, this.color);
    }, "choose another color \nfor this morph"), menu.addItem("transparency...", function() {
        this.prompt(menu.title + "\nalpha\nvalue:", this.setAlphaScaled, this, (100 * this.alpha).toString(), null, 1, 100, !0);
    }, "set this morph's\nalpha value"), menu.addItem("resize...", "resize", "show a handle\nwhich can be dragged\nto change this morph's extent"), 
    menu.addLine(), menu.addItem("duplicate", function() {
        this.fullCopy().pickUp(this.world());
    }, "make a copy\nand pick it up"), menu.addItem("pick up", "pickUp", "disattach and put \ninto the hand"), 
    menu.addItem("attach...", "attach", "stick this morph\nto another one"), menu.addItem("move...", "move", "show a handle\nwhich can be dragged\nto move this morph"), 
    menu.addItem("inspect...", "inspect", "open a window\non all properties"), menu.addItem("pic...", function() {
        window.open(this.fullImageClassic().toDataURL());
    }, "open a new window\nwith a picture of this morph"), menu.addLine(), this.isDraggable ? menu.addItem("lock", "toggleIsDraggable", "make this morph\nunmovable") : menu.addItem("unlock", "toggleIsDraggable", "make this morph\nmovable"), 
    menu.addItem("hide", "hide"), menu.addItem("delete", "destroy"), this instanceof WorldMorph || (menu.addLine(), 
    menu.addItem("World...", function() {
        world.contextMenu().popUpAtHand(world);
    }, "show the\nWorld's menu")), menu;
}, Morph.prototype.userMenu = function() {
    return null;
}, Morph.prototype.setAlphaScaled = function(alpha) {
    var newAlpha, unscaled;
    "number" == typeof alpha ? (unscaled = alpha / 100, this.alpha = Math.min(Math.max(unscaled, .1), 1)) : (newAlpha = parseFloat(alpha), 
    isNaN(newAlpha) || (unscaled = newAlpha / 100, this.alpha = Math.min(Math.max(unscaled, .1), 1))), 
    this.changed();
}, Morph.prototype.attach = function() {
    var choices = this.overlappedMorphs(), menu = new MenuMorph(this, "choose new parent:"), myself = this;
    choices.forEach(function(each) {
        menu.addItem(each.toString().slice(0, 50), function() {
            each.add(myself), myself.isDraggable = !1;
        });
    }), choices.length > 0 && menu.popUpAtHand(this.world());
}, Morph.prototype.toggleIsDraggable = function() {
    this.isDraggable = !this.isDraggable;
}, Morph.prototype.colorSetters = function() {
    return [ "color" ];
}, Morph.prototype.numericalSetters = function() {
    return [ "setLeft", "setTop", "setWidth", "setHeight", "setAlphaScaled" ];
}, Morph.prototype.allEntryFields = function() {
    return this.allChildren().filter(function(each) {
        return each.isEditable && (each instanceof StringMorph || each instanceof TextMorph);
    });
}, Morph.prototype.nextEntryField = function(current) {
    var fields = this.allEntryFields(), idx = fields.indexOf(current);
    return -1 !== idx && fields.length > idx + 1 ? fields[idx + 1] : fields[0];
}, Morph.prototype.previousEntryField = function(current) {
    var fields = this.allEntryFields(), idx = fields.indexOf(current);
    return -1 !== idx ? idx > 0 ? fields[idx - 1] : fields[fields.length - 1] : fields[0];
}, Morph.prototype.tab = function(editField) {
    this.nextTab ? this.nextTab(editField) : this.parent && this.parent.tab(editField);
}, Morph.prototype.backTab = function(editField) {
    this.previousTab ? this.previousTab(editField) : this.parent && this.parent.backTab(editField);
}, Morph.prototype.escalateEvent = function(functionName, arg) {
    for (var handler = this.parent; !handler[functionName] && null !== handler.parent; ) handler = handler.parent;
    handler[functionName] && handler[functionName](arg);
}, Morph.prototype.evaluateString = function(code) {
    var result;
    try {
        result = eval(code), this.drawNew(), this.changed();
    } catch (err) {
        this.inform(err);
    }
    return result;
}, Morph.prototype.isTouching = function(otherMorph) {
    var oImg = this.overlappingImage(otherMorph);
    return null !== detect(oImg.getContext("2d").getImageData(1, 1, oImg.width, oImg.height).data, function(each) {
        return 0 !== each;
    });
}, Morph.prototype.overlappingImage = function(otherMorph) {
    var fb = this.fullBounds(), otherFb = otherMorph.fullBounds(), oRect = fb.intersect(otherFb), oImg = newCanvas(oRect.extent()), ctx = oImg.getContext("2d");
    return oRect.width() < 1 || oRect.height() < 1 ? newCanvas(new Point(1, 1)) : (ctx.drawImage(this.fullImage(), oRect.origin.x - fb.origin.x, oRect.origin.y - fb.origin.y), 
    ctx.globalCompositeOperation = "source-in", ctx.drawImage(otherMorph.fullImage(), otherFb.origin.x - oRect.origin.x, otherFb.origin.y - oRect.origin.y), 
    oImg);
}, ShadowMorph.prototype = new Morph(), ShadowMorph.prototype.constructor = ShadowMorph, 
ShadowMorph.uber = Morph.prototype;

function ShadowMorph() {
    this.init();
}

HandleMorph.prototype = new Morph(), HandleMorph.prototype.constructor = HandleMorph, 
HandleMorph.uber = Morph.prototype;

function HandleMorph(target, minX, minY, insetX, insetY, type) {
    this.init(target, minX, minY, insetX, insetY, type);
}

HandleMorph.prototype.init = function(target, minX, minY, insetX, insetY, type) {
    var size = MorphicPreferences.handleSize;
    this.target = target || null, this.minExtent = new Point(minX || 0, minY || 0), 
    this.inset = new Point(insetX || 0, insetY || insetX || 0), this.type = type || "resize", 
    HandleMorph.uber.init.call(this), this.color = new Color(255, 255, 255), this.isDraggable = !1, 
    this.noticesTransparentClick = !0, this.setExtent(new Point(size, size));
}, HandleMorph.prototype.drawNew = function() {
    this.normalImage = newCanvas(this.extent()), this.highlightImage = newCanvas(this.extent()), 
    this.drawOnCanvas(this.normalImage, this.color, new Color(100, 100, 100)), this.drawOnCanvas(this.highlightImage, new Color(100, 100, 255), new Color(255, 255, 255)), 
    this.image = this.normalImage, this.target && (this.setPosition(this.target.bottomRight().subtract(this.extent().add(this.inset))), 
    this.target.add(this), this.target.changed());
}, HandleMorph.prototype.drawOnCanvas = function(aCanvas, color, shadowColor) {
    var p1, p11, p2, p22, i, context = aCanvas.getContext("2d");
    if (context.lineWidth = 1, context.lineCap = "round", context.strokeStyle = color.toString(), 
    "move" === this.type) for (p11 = (p1 = this.bottomLeft().subtract(this.position())).copy(), 
    p22 = (p2 = this.topRight().subtract(this.position())).copy(), i = 0; i <= this.height(); i += 6) p11.y = p1.y - i, 
    p22.y = p2.y - i, context.beginPath(), context.moveTo(p11.x, p11.y), context.lineTo(p22.x, p22.y), 
    context.closePath(), context.stroke();
    for (p11 = (p1 = this.bottomLeft().subtract(this.position())).copy(), p22 = (p2 = this.topRight().subtract(this.position())).copy(), 
    i = 0; i <= this.width(); i += 6) p11.x = p1.x + i, p22.x = p2.x + i, context.beginPath(), 
    context.moveTo(p11.x, p11.y), context.lineTo(p22.x, p22.y), context.closePath(), 
    context.stroke();
    if (context.strokeStyle = shadowColor.toString(), "move" === this.type) for (p11 = (p1 = this.bottomLeft().subtract(this.position())).copy(), 
    p22 = (p2 = this.topRight().subtract(this.position())).copy(), i = -2; i <= this.height(); i += 6) p11.y = p1.y - i, 
    p22.y = p2.y - i, context.beginPath(), context.moveTo(p11.x, p11.y), context.lineTo(p22.x, p22.y), 
    context.closePath(), context.stroke();
    for (p11 = (p1 = this.bottomLeft().subtract(this.position())).copy(), p22 = (p2 = this.topRight().subtract(this.position())).copy(), 
    i = 2; i <= this.width(); i += 6) p11.x = p1.x + i, p22.x = p2.x + i, context.beginPath(), 
    context.moveTo(p11.x, p11.y), context.lineTo(p22.x, p22.y), context.closePath(), 
    context.stroke();
}, HandleMorph.prototype.step = null, HandleMorph.prototype.mouseDownLeft = function(pos) {
    var world = this.root(), offset = pos.subtract(this.bounds.origin), myself = this;
    if (!this.target) return null;
    this.step = function() {
        var newPos, newExt;
        world.hand.mouseButton ? (newPos = world.hand.bounds.origin.copy().subtract(offset), 
        "resize" === this.type ? (newExt = (newExt = newPos.add(myself.extent().add(myself.inset)).subtract(myself.target.bounds.origin)).max(myself.minExtent), 
        myself.target.setExtent(newExt), myself.setPosition(myself.target.bottomRight().subtract(myself.extent().add(myself.inset)))) : myself.target.setPosition(newPos.subtract(this.target.extent()).add(this.extent()))) : this.step = null;
    }, this.target.step || (this.target.step = function() {
        nop();
    });
}, HandleMorph.prototype.rootForGrab = function() {
    return this;
}, HandleMorph.prototype.mouseEnter = function() {
    this.image = this.highlightImage, this.changed();
}, HandleMorph.prototype.mouseLeave = function() {
    this.image = this.normalImage, this.changed();
}, HandleMorph.prototype.copyRecordingReferences = function(dict) {
    var c = HandleMorph.uber.copyRecordingReferences.call(this, dict);
    return c.target && dict[this.target] && (c.target = dict[this.target]), c;
}, HandleMorph.prototype.attach = function() {
    var choices = this.overlappedMorphs(), menu = new MenuMorph(this, "choose target:"), myself = this;
    choices.forEach(function(each) {
        menu.addItem(each.toString().slice(0, 50), function() {
            myself.isDraggable = !1, myself.target = each, myself.drawNew(), myself.noticesTransparentClick = !0;
        });
    }), choices.length > 0 && menu.popUpAtHand(this.world());
};

var PenMorph;

PenMorph.prototype = new Morph(), PenMorph.prototype.constructor = PenMorph, PenMorph.uber = Morph.prototype;

function PenMorph() {
    this.init();
}

PenMorph.prototype.init = function() {
    var size = 4 * MorphicPreferences.handleSize;
    this.isWarped = !1, this.heading = 0, this.isDown = !0, this.size = 1, this.wantsRedraw = !1, 
    this.penPoint = "tip", this.penBounds = null, HandleMorph.uber.init.call(this), 
    this.setExtent(new Point(size, size));
}, PenMorph.prototype.changed = function() {
    if (!1 === this.isWarped) {
        var w = this.root();
        w instanceof WorldMorph && w.broken.push(this.visibleBounds().spread()), this.parent && this.parent.childChanged(this);
    }
}, PenMorph.prototype.drawNew = function(facing) {
    var context, start, dest, left, right, len, direction = facing || this.heading;
    this.isWarped ? this.wantsRedraw = !0 : (this.image = newCanvas(this.extent()), 
    context = this.image.getContext("2d"), len = this.width() / 2, start = this.center().subtract(this.bounds.origin), 
    "tip" === this.penPoint ? (dest = start.distanceAngle(.75 * len, direction - 180), 
    left = start.distanceAngle(len, direction + 195), right = start.distanceAngle(len, direction - 195)) : (dest = start.distanceAngle(.75 * len, direction), 
    left = start.distanceAngle(.33 * len, direction + 230), right = start.distanceAngle(.33 * len, direction - 230)), 
    this.penBounds = new Rectangle(Math.min(start.x, dest.x, left.x, right.x), Math.min(start.y, dest.y, left.y, right.y), Math.max(start.x, dest.x, left.x, right.x), Math.max(start.y, dest.y, left.y, right.y)), 
    context.fillStyle = this.color.toString(), context.beginPath(), context.moveTo(start.x, start.y), 
    context.lineTo(left.x, left.y), context.lineTo(dest.x, dest.y), context.lineTo(right.x, right.y), 
    context.closePath(), context.strokeStyle = "white", context.lineWidth = 3, context.stroke(), 
    context.strokeStyle = "black", context.lineWidth = 1, context.stroke(), context.fill());
}, PenMorph.prototype.setHeading = function(degrees) {
    this.heading = parseFloat(degrees) % 360, this.drawNew(), this.changed();
}, PenMorph.prototype.drawLine = function(start, dest) {
    var context = this.parent.penTrails().getContext("2d"), from = start.subtract(this.parent.bounds.origin), to = dest.subtract(this.parent.bounds.origin);
    this.isDown && (context.lineWidth = this.size, context.strokeStyle = this.color.toString(), 
    context.lineCap = "round", context.lineJoin = "round", context.beginPath(), context.moveTo(from.x, from.y), 
    context.lineTo(to.x, to.y), context.stroke(), !1 === this.isWarped && this.world().broken.push(start.rectangle(dest).expandBy(Math.max(this.size / 2, 1)).intersect(this.parent.visibleBounds()).spread()));
}, PenMorph.prototype.turn = function(degrees) {
    this.setHeading(this.heading + parseFloat(degrees));
}, PenMorph.prototype.forward = function(steps) {
    var dest, start = this.center(), dist = parseFloat(steps);
    dest = dist >= 0 ? this.position().distanceAngle(dist, this.heading) : this.position().distanceAngle(Math.abs(dist), this.heading - 180), 
    this.setPosition(dest), this.drawLine(start, this.center());
}, PenMorph.prototype.down = function() {
    this.isDown = !0;
}, PenMorph.prototype.up = function() {
    this.isDown = !1;
}, PenMorph.prototype.clear = function() {
    this.parent.drawNew(), this.parent.changed();
}, PenMorph.prototype.startWarp = function() {
    this.wantsRedraw = !1, this.isWarped = !0;
}, PenMorph.prototype.endWarp = function() {
    this.isWarped = !1, this.wantsRedraw && (this.drawNew(), this.wantsRedraw = !1), 
    this.parent.changed();
}, PenMorph.prototype.warp = function(fun) {
    this.startWarp(), fun.call(this), this.endWarp();
}, PenMorph.prototype.warpOp = function(selector, argsArray) {
    this.startWarp(), this[selector].apply(this, argsArray), this.endWarp();
}, PenMorph.prototype.warpSierpinski = function(length, min) {
    this.warpOp("sierpinski", [ length, min ]);
}, PenMorph.prototype.sierpinski = function(length, min) {
    var i;
    if (length > min) for (i = 0; i < 3; i += 1) this.sierpinski(.5 * length, min), 
    this.turn(120), this.forward(length);
}, PenMorph.prototype.warpTree = function(level, length, angle) {
    this.warpOp("tree", [ level, length, angle ]);
}, PenMorph.prototype.tree = function(level, length, angle) {
    level > 0 && (this.size = level, this.forward(length), this.turn(angle), this.tree(level - 1, .75 * length, angle), 
    this.turn(-2 * angle), this.tree(level - 1, .75 * length, angle), this.turn(angle), 
    this.forward(-length));
};

var ColorPaletteMorph;

ColorPaletteMorph.prototype = new Morph(), ColorPaletteMorph.prototype.constructor = ColorPaletteMorph, 
ColorPaletteMorph.uber = Morph.prototype;

function ColorPaletteMorph(target, sizePoint) {
    this.init(target || null, sizePoint || new Point(80, 50));
}

ColorPaletteMorph.prototype.init = function(target, size) {
    ColorPaletteMorph.uber.init.call(this), this.target = target, this.targetSetter = "color", 
    this.silentSetExtent(size), this.choice = null, this.drawNew();
}, ColorPaletteMorph.prototype.drawNew = function() {
    var context, ext, x, y, h, l;
    for (ext = this.extent(), this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 
    this.choice = new Color(), x = 0; x <= ext.x; x += 1) for (h = 360 * x / ext.x, 
    y = 0; y <= ext.y; y += 1) l = 100 - y / ext.y * 100, context.fillStyle = "hsl(" + h + ",100%," + l + "%)", 
    context.fillRect(x, y, 1, 1);
}, ColorPaletteMorph.prototype.mouseMove = function(pos) {
    this.choice = this.getPixelColor(pos), this.updateTarget();
}, ColorPaletteMorph.prototype.mouseDownLeft = function(pos) {
    this.choice = this.getPixelColor(pos), this.updateTarget();
}, ColorPaletteMorph.prototype.updateTarget = function() {
    this.target instanceof Morph && null !== this.choice && (this.target[this.targetSetter] instanceof Function ? this.target[this.targetSetter](this.choice) : (this.target[this.targetSetter] = this.choice, 
    this.target.drawNew(), this.target.changed()));
}, ColorPaletteMorph.prototype.copyRecordingReferences = function(dict) {
    var c = ColorPaletteMorph.uber.copyRecordingReferences.call(this, dict);
    return c.target && dict[this.target] && (c.target = dict[this.target]), c;
}, ColorPaletteMorph.prototype.developersMenu = function() {
    var menu = ColorPaletteMorph.uber.developersMenu.call(this);
    return menu.addLine(), menu.addItem("set target", "setTarget", "choose another morph\nwhose color property\n will be controlled by this one"), 
    menu;
}, ColorPaletteMorph.prototype.setTarget = function() {
    var choices = this.overlappedMorphs(), menu = new MenuMorph(this, "choose target:"), myself = this;
    choices.push(this.world()), choices.forEach(function(each) {
        menu.addItem(each.toString().slice(0, 50), function() {
            myself.target = each, myself.setTargetSetter();
        });
    }), 1 === choices.length ? (this.target = choices[0], this.setTargetSetter()) : choices.length > 0 && menu.popUpAtHand(this.world());
}, ColorPaletteMorph.prototype.setTargetSetter = function() {
    var choices = this.target.colorSetters(), menu = new MenuMorph(this, "choose target property:"), myself = this;
    choices.forEach(function(each) {
        menu.addItem(each, function() {
            myself.targetSetter = each;
        });
    }), 1 === choices.length ? this.targetSetter = choices[0] : choices.length > 0 && menu.popUpAtHand(this.world());
};

var GrayPaletteMorph;

GrayPaletteMorph.prototype = new ColorPaletteMorph(), GrayPaletteMorph.prototype.constructor = GrayPaletteMorph, 
GrayPaletteMorph.uber = ColorPaletteMorph.prototype;

function GrayPaletteMorph(target, sizePoint) {
    this.init(target || null, sizePoint || new Point(80, 10));
}

GrayPaletteMorph.prototype.drawNew = function() {
    var context, ext, gradient;
    ext = this.extent(), this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 
    this.choice = new Color(), (gradient = context.createLinearGradient(0, 0, ext.x, ext.y)).addColorStop(0, "black"), 
    gradient.addColorStop(1, "white"), context.fillStyle = gradient, context.fillRect(0, 0, ext.x, ext.y);
}, ColorPickerMorph.prototype = new Morph(), ColorPickerMorph.prototype.constructor = ColorPickerMorph, 
ColorPickerMorph.uber = Morph.prototype;

function ColorPickerMorph(defaultColor) {
    this.init(defaultColor || new Color(255, 255, 255));
}

ColorPickerMorph.prototype.init = function(defaultColor) {
    this.choice = defaultColor, ColorPickerMorph.uber.init.call(this), this.color = new Color(255, 255, 255), 
    this.silentSetExtent(new Point(80, 80)), this.drawNew();
}, ColorPickerMorph.prototype.drawNew = function() {
    ColorPickerMorph.uber.drawNew.call(this), this.buildSubmorphs();
}, ColorPickerMorph.prototype.buildSubmorphs = function() {
    var cpal, gpal, x, y;
    this.children.forEach(function(child) {
        child.destroy();
    }), this.children = [], this.feedback = new Morph(), this.feedback.color = this.choice, 
    this.feedback.setExtent(new Point(20, 20)), cpal = new ColorPaletteMorph(this.feedback, new Point(this.width(), 50)), 
    gpal = new GrayPaletteMorph(this.feedback, new Point(this.width(), 5)), cpal.setPosition(this.bounds.origin), 
    this.add(cpal), gpal.setPosition(cpal.bottomLeft()), this.add(gpal), x = gpal.left() + Math.floor((gpal.width() - this.feedback.width()) / 2), 
    y = gpal.bottom() + Math.floor((this.bottom() - gpal.bottom() - this.feedback.height()) / 2), 
    this.feedback.setPosition(new Point(x, y)), this.add(this.feedback);
}, ColorPickerMorph.prototype.getChoice = function() {
    return this.feedback.color;
}, ColorPickerMorph.prototype.rootForGrab = function() {
    return this;
};

var BlinkerMorph;

BlinkerMorph.prototype = new Morph(), BlinkerMorph.prototype.constructor = BlinkerMorph, 
BlinkerMorph.uber = Morph.prototype;

function BlinkerMorph(rate) {
    this.init(rate);
}

BlinkerMorph.prototype.init = function(rate) {
    BlinkerMorph.uber.init.call(this), this.color = new Color(0, 0, 0), this.fps = rate || 2, 
    this.drawNew();
}, BlinkerMorph.prototype.step = function() {
    this.toggleVisibility();
};

var CursorMorph;

CursorMorph.prototype = new BlinkerMorph(), CursorMorph.prototype.constructor = CursorMorph, 
CursorMorph.uber = BlinkerMorph.prototype, CursorMorph.prototype.viewPadding = 1;

function CursorMorph(aStringOrTextMorph) {
    this.init(aStringOrTextMorph);
}

CursorMorph.prototype.init = function(aStringOrTextMorph) {
    var ls;
    this.keyDownEventUsed = !1, this.target = aStringOrTextMorph, this.originalContents = this.target.text, 
    this.originalAlignment = this.target.alignment, this.slot = this.target.text.length, 
    CursorMorph.uber.init.call(this), ls = fontHeight(this.target.fontSize), this.setExtent(new Point(Math.max(Math.floor(ls / 20), 1), ls)), 
    this.drawNew(), this.image.getContext("2d").font = this.target.font(), this.target instanceof TextMorph && "left" !== this.target.alignment && this.target.setAlignmentToLeft(), 
    this.gotoSlot(this.slot);
}, CursorMorph.prototype.processKeyPress = function(event) {
    return this.keyDownEventUsed ? (this.keyDownEventUsed = !1, null) : 40 === event.keyCode || 40 === event.charCode ? (this.insert("("), 
    null) : 37 === event.keyCode || 37 === event.charCode ? (this.insert("%"), null) : (event.keyCode ? event.ctrlKey ? this.ctrl(event.keyCode, event.shiftKey) : event.metaKey ? this.cmd(event.keyCode, event.shiftKey) : this.insert(String.fromCharCode(event.keyCode), event.shiftKey) : event.charCode && (event.ctrlKey ? this.ctrl(event.charCode, event.shiftKey) : event.metaKey ? this.cmd(event.charCode, event.shiftKey) : this.insert(String.fromCharCode(event.charCode), event.shiftKey)), 
    void this.target.escalateEvent("reactToKeystroke", event));
}, CursorMorph.prototype.processKeyDown = function(event) {
    var shift = event.shiftKey;
    if (this.keyDownEventUsed = !1, event.ctrlKey) return this.ctrl(event.keyCode, event.shiftKey), 
    void this.target.escalateEvent("reactToKeystroke", event);
    if (event.metaKey) return this.cmd(event.keyCode, event.shiftKey), void this.target.escalateEvent("reactToKeystroke", event);
    switch (event.keyCode) {
      case 37:
        this.goLeft(shift), this.keyDownEventUsed = !0;
        break;

      case 39:
        this.goRight(shift), this.keyDownEventUsed = !0;
        break;

      case 38:
        this.goUp(shift), this.keyDownEventUsed = !0;
        break;

      case 40:
        this.goDown(shift), this.keyDownEventUsed = !0;
        break;

      case 36:
        this.goHome(shift), this.keyDownEventUsed = !0;
        break;

      case 35:
        this.goEnd(shift), this.keyDownEventUsed = !0;
        break;

      case 46:
        this.deleteRight(), this.keyDownEventUsed = !0;
        break;

      case 8:
        this.deleteLeft(), this.keyDownEventUsed = !0;
        break;

      case 13:
        this.target instanceof StringMorph ? this.accept() : this.insert("\n"), this.keyDownEventUsed = !0;
        break;

      case 27:
        this.cancel(), this.keyDownEventUsed = !0;
        break;

      default:
        nop();
    }
    this.target.escalateEvent("reactToKeystroke", event);
}, CursorMorph.prototype.gotoSlot = function(slot) {
    var right, left, length = this.target.text.length, pos = this.target.slotPosition(slot);
    this.slot = slot < 0 ? 0 : slot > length ? length : slot, this.parent && this.target.isScrollable && (right = this.parent.right() - this.viewPadding, 
    left = this.parent.left() + this.viewPadding, pos.x > right && (this.target.setLeft(this.target.left() + right - pos.x), 
    pos.x = right), pos.x < left && (left = Math.min(this.parent.left(), left), this.target.setLeft(this.target.left() + left - pos.x), 
    pos.x = left), this.target.right() < right && right - this.target.width() < left && (pos.x += right - this.target.right(), 
    this.target.setRight(right))), this.show(), this.setPosition(pos), this.parent && this.parent.parent instanceof ScrollFrameMorph && this.target.isScrollable && this.parent.parent.scrollCursorIntoView(this);
}, CursorMorph.prototype.goLeft = function(shift) {
    this.updateSelection(shift), this.gotoSlot(this.slot - 1), this.updateSelection(shift);
}, CursorMorph.prototype.goRight = function(shift, howMany) {
    this.updateSelection(shift), this.gotoSlot(this.slot + (howMany || 1)), this.updateSelection(shift);
}, CursorMorph.prototype.goUp = function(shift) {
    this.updateSelection(shift), this.gotoSlot(this.target.upFrom(this.slot)), this.updateSelection(shift);
}, CursorMorph.prototype.goDown = function(shift) {
    this.updateSelection(shift), this.gotoSlot(this.target.downFrom(this.slot)), this.updateSelection(shift);
}, CursorMorph.prototype.goHome = function(shift) {
    this.updateSelection(shift), this.gotoSlot(this.target.startOfLine(this.slot)), 
    this.updateSelection(shift);
}, CursorMorph.prototype.goEnd = function(shift) {
    this.updateSelection(shift), this.gotoSlot(this.target.endOfLine(this.slot)), this.updateSelection(shift);
}, CursorMorph.prototype.gotoPos = function(aPoint) {
    this.gotoSlot(this.target.slotAt(aPoint)), this.show();
}, CursorMorph.prototype.updateSelection = function(shift) {
    shift ? this.target.endMark || this.target.startMark ? this.target.endMark !== this.slot && (this.target.endMark = this.slot, 
    this.target.drawNew(), this.target.changed()) : (this.target.startMark = this.slot, 
    this.target.endMark = this.slot) : this.target.clearSelection();
}, CursorMorph.prototype.accept = function() {
    var world = this.root();
    world && world.stopEditing(), this.escalateEvent("accept", null);
}, CursorMorph.prototype.cancel = function() {
    var world = this.root();
    this.undo(), world && world.stopEditing(), this.escalateEvent("cancel", null);
}, CursorMorph.prototype.undo = function() {
    this.target.text = this.originalContents, this.target.changed(), this.target.drawNew(), 
    this.target.changed(), this.gotoSlot(0);
}, CursorMorph.prototype.insert = function(aChar, shiftKey) {
    var text;
    if ("\t" === aChar) return this.target.escalateEvent("reactToEdit", this.target), 
    shiftKey ? this.target.backTab(this.target) : this.target.tab(this.target);
    this.target.isNumeric && isNaN(parseFloat(aChar)) && !contains([ "-", "." ], aChar) || ("" !== this.target.selection() && (this.gotoSlot(this.target.selectionStartSlot()), 
    this.target.deleteSelection()), text = (text = this.target.text).slice(0, this.slot) + aChar + text.slice(this.slot), 
    this.target.text = text, this.target.drawNew(), this.target.changed(), this.goRight(!1, aChar.length));
}, CursorMorph.prototype.ctrl = function(aChar, shiftKey) {
    64 === aChar || 65 === aChar && shiftKey ? this.insert("@") : 65 === aChar ? this.target.selectAll() : 90 === aChar ? this.undo() : 123 === aChar ? this.insert("{") : 125 === aChar ? this.insert("}") : 91 === aChar ? this.insert("[") : 93 === aChar ? this.insert("]") : isNil(this.target.receiver) || (68 === aChar ? this.target.doIt() : 73 === aChar ? this.target.inspectIt() : 80 === aChar && this.target.showIt());
}, CursorMorph.prototype.cmd = function(aChar, shiftKey) {
    64 === aChar || 65 === aChar && shiftKey ? this.insert("@") : 65 === aChar ? this.target.selectAll() : 90 === aChar ? this.undo() : isNil(this.target.receiver) || (68 === aChar ? this.target.doIt() : 73 === aChar ? this.target.inspectIt() : 80 === aChar && this.target.showIt());
}, CursorMorph.prototype.deleteRight = function() {
    var text;
    "" !== this.target.selection() ? (this.gotoSlot(this.target.selectionStartSlot()), 
    this.target.deleteSelection()) : (text = this.target.text, this.target.changed(), 
    text = text.slice(0, this.slot) + text.slice(this.slot + 1), this.target.text = text, 
    this.target.drawNew());
}, CursorMorph.prototype.deleteLeft = function() {
    var text;
    if (this.target.selection()) return this.gotoSlot(this.target.selectionStartSlot()), 
    this.target.deleteSelection();
    text = this.target.text, this.target.changed(), this.target.text = text.substring(0, this.slot - 1) + text.substr(this.slot), 
    this.target.drawNew(), this.goLeft();
}, CursorMorph.prototype.destroy = function() {
    this.target.alignment !== this.originalAlignment && (this.target.alignment = this.originalAlignment, 
    this.target.drawNew(), this.target.changed()), CursorMorph.uber.destroy.call(this);
}, CursorMorph.prototype.inspectKeyEvent = function(event) {
    this.inform("Key pressed: " + String.fromCharCode(event.charCode) + "\n------------------------\ncharCode: " + event.charCode.toString() + "\nkeyCode: " + event.keyCode.toString() + "\nshiftKey: " + event.shiftKey.toString() + "\naltKey: " + event.altKey.toString() + "\nctrlKey: " + event.ctrlKey.toString() + "\ncmdKey: " + event.metaKey.toString());
};

var BoxMorph;

BoxMorph.prototype = new Morph(), BoxMorph.prototype.constructor = BoxMorph, BoxMorph.uber = Morph.prototype;

function BoxMorph(edge, border, borderColor) {
    this.init(edge, border, borderColor);
}

BoxMorph.prototype.init = function(edge, border, borderColor) {
    this.edge = edge || 4, this.border = border || (0 === border ? 0 : 2), this.borderColor = borderColor || new Color(), 
    BoxMorph.uber.init.call(this);
}, BoxMorph.prototype.drawNew = function() {
    var context;
    if (this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 
    0 === this.edge && 0 === this.border) return BoxMorph.uber.drawNew.call(this), null;
    context.fillStyle = this.color.toString(), context.beginPath(), this.outlinePath(context, Math.max(this.edge - this.border, 0), this.border), 
    context.closePath(), context.fill(), this.border > 0 && (context.lineWidth = this.border, 
    context.strokeStyle = this.borderColor.toString(), context.beginPath(), this.outlinePath(context, this.edge, this.border / 2), 
    context.closePath(), context.stroke());
}, BoxMorph.prototype.outlinePath = function(context, radius, inset) {
    var offset = radius + inset, w = this.width(), h = this.height();
    context.arc(offset, offset, radius, radians(-180), radians(-90), !1), context.arc(w - offset, offset, radius, radians(-90), radians(-0), !1), 
    context.arc(w - offset, h - offset, radius, radians(0), radians(90), !1), context.arc(offset, h - offset, radius, radians(90), radians(180), !1);
}, BoxMorph.prototype.developersMenu = function() {
    var menu = BoxMorph.uber.developersMenu.call(this);
    return menu.addLine(), menu.addItem("border width...", function() {
        this.prompt(menu.title + "\nborder\nwidth:", this.setBorderWidth, this, this.border.toString(), null, 0, 100, !0);
    }, "set the border's\nline size"), menu.addItem("border color...", function() {
        this.pickColor(menu.title + "\nborder color:", this.setBorderColor, this, this.borderColor);
    }, "set the border's\nline color"), menu.addItem("corner size...", function() {
        this.prompt(menu.title + "\ncorner\nsize:", this.setCornerSize, this, this.edge.toString(), null, 0, 100, !0);
    }, "set the corner's\nradius"), menu;
}, BoxMorph.prototype.setBorderWidth = function(size) {
    var newSize;
    "number" == typeof size ? this.border = Math.max(size, 0) : (newSize = parseFloat(size), 
    isNaN(newSize) || (this.border = Math.max(newSize, 0))), this.drawNew(), this.changed();
}, BoxMorph.prototype.setBorderColor = function(color) {
    color && (this.borderColor = color, this.drawNew(), this.changed());
}, BoxMorph.prototype.setCornerSize = function(size) {
    var newSize;
    "number" == typeof size ? this.edge = Math.max(size, 0) : (newSize = parseFloat(size), 
    isNaN(newSize) || (this.edge = Math.max(newSize, 0))), this.drawNew(), this.changed();
}, BoxMorph.prototype.colorSetters = function() {
    return [ "color", "borderColor" ];
}, BoxMorph.prototype.numericalSetters = function() {
    var list = BoxMorph.uber.numericalSetters.call(this);
    return list.push("setBorderWidth", "setCornerSize"), list;
};

var SpeechBubbleMorph;

SpeechBubbleMorph.prototype = new BoxMorph(), SpeechBubbleMorph.prototype.constructor = SpeechBubbleMorph, 
SpeechBubbleMorph.uber = BoxMorph.prototype;

function SpeechBubbleMorph(contents, color, edge, border, borderColor, padding, isThought) {
    this.init(contents, color, edge, border, borderColor, padding, isThought);
}

SpeechBubbleMorph.prototype.init = function(contents, color, edge, border, borderColor, padding, isThought) {
    this.isPointingRight = !0, this.contents = contents || "", this.padding = padding || 0, 
    this.isThought = isThought || !1, this.isClickable = !1, SpeechBubbleMorph.uber.init.call(this, edge || 6, border || (0 === border ? 0 : 1), borderColor || new Color(140, 140, 140)), 
    this.color = color || new Color(230, 230, 230), this.drawNew();
}, SpeechBubbleMorph.prototype.popUp = function(world, pos, isClickable) {
    this.drawNew(), this.setPosition(pos.subtract(new Point(0, this.height()))), this.addShadow(new Point(2, 2), 80), 
    this.keepWithin(world), world.add(this), this.fullChanged(), world.hand.destroyTemporaries(), 
    world.hand.temporaries.push(this), isClickable ? this.isClickable = !0 : this.mouseEnter = function() {
        this.destroy();
    };
}, SpeechBubbleMorph.prototype.drawNew = function() {
    this.contentsMorph && this.contentsMorph.destroy(), this.contents instanceof Morph ? this.contentsMorph = this.contents : isString(this.contents) ? this.contentsMorph = new TextMorph(this.contents, MorphicPreferences.bubbleHelpFontSize, null, !1, !0, "center") : this.contents instanceof HTMLCanvasElement ? (this.contentsMorph = new Morph(), 
    this.contentsMorph.silentSetWidth(this.contents.width), this.contentsMorph.silentSetHeight(this.contents.height), 
    this.contentsMorph.image = this.contents) : this.contentsMorph = new TextMorph(this.contents.toString(), MorphicPreferences.bubbleHelpFontSize, null, !1, !0, "center"), 
    this.add(this.contentsMorph), this.silentSetWidth(this.contentsMorph.width() + (this.padding ? 2 * this.padding : 2 * this.edge)), 
    this.silentSetHeight(this.contentsMorph.height() + this.edge + 2 * this.border + 2 * this.padding + 2), 
    SpeechBubbleMorph.uber.drawNew.call(this), this.contentsMorph.setPosition(this.position().add(new Point(this.padding || this.edge, this.border + this.padding + 1)));
}, SpeechBubbleMorph.prototype.outlinePath = function(context, radius, inset) {
    var rad, offset = radius + inset, w = this.width(), h = this.height();
    function circle(x, y, r) {
        context.moveTo(x + r, y), context.arc(x, y, r, radians(0), radians(360));
    }
    context.arc(offset, offset, radius, radians(-180), radians(-90), !1), context.arc(w - offset, offset, radius, radians(-90), radians(-0), !1), 
    context.arc(w - offset, h - offset - radius, radius, radians(0), radians(90), !1), 
    this.isThought || (this.isPointingRight ? (context.lineTo(offset + radius, h - offset), 
    context.lineTo(radius / 2 + inset, h - inset)) : (context.lineTo(w - (radius / 2 + inset), h - inset), 
    context.lineTo(w - (offset + radius), h - offset))), context.arc(offset, h - offset - radius, radius, radians(90), radians(180), !1), 
    this.isThought && (context.lineTo(inset, offset), this.isPointingRight ? (circle((rad = radius / 4) + inset, h - rad - inset, rad), 
    circle(2 * (rad = radius / 3.2) + inset, h - rad - 2 * inset, rad), circle(3 * (rad = radius / 2.8) + 2 * inset, h - rad - 4 * inset, rad)) : (circle(w - ((rad = radius / 4) + inset), h - rad - inset, rad), 
    circle(w - (2 * (rad = radius / 3.2) + inset), h - rad - 2 * inset, rad), circle(w - (3 * (rad = radius / 2.8) + 2 * inset), h - rad - 4 * inset, rad)));
}, SpeechBubbleMorph.prototype.shadowImage = function(off, color) {
    var fb, img, outline, sha, ctx, offset = off || new Point(7, 7), clr = color || new Color(0, 0, 0);
    return fb = this.extent(), img = this.image, (ctx = (outline = newCanvas(fb)).getContext("2d")).drawImage(img, 0, 0), 
    ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, -offset.x, -offset.y), 
    (ctx = (sha = newCanvas(fb)).getContext("2d")).drawImage(outline, 0, 0), ctx.globalCompositeOperation = "source-atop", 
    ctx.fillStyle = clr.toString(), ctx.fillRect(0, 0, fb.x, fb.y), sha;
}, SpeechBubbleMorph.prototype.shadowImageBlurred = function(off, color) {
    var fb, img, sha, ctx, offset = off || new Point(7, 7), blur = this.shadowBlur, clr = color || new Color(0, 0, 0);
    return fb = this.extent().add(2 * blur), img = this.image, (ctx = (sha = newCanvas(fb)).getContext("2d")).shadowOffsetX = offset.x, 
    ctx.shadowOffsetY = offset.y, ctx.shadowBlur = blur, ctx.shadowColor = clr.toString(), 
    ctx.drawImage(img, blur - offset.x, blur - offset.y), ctx.shadowOffsetX = 0, ctx.shadowOffsetY = 0, 
    ctx.shadowBlur = 0, ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, blur - offset.x, blur - offset.y), 
    sha;
}, SpeechBubbleMorph.prototype.fixLayout = function() {
    this.removeShadow(), this.drawNew(), this.addShadow(new Point(2, 2), 80);
};

var CircleBoxMorph;

CircleBoxMorph.prototype = new Morph(), CircleBoxMorph.prototype.constructor = CircleBoxMorph, 
CircleBoxMorph.uber = Morph.prototype;

function CircleBoxMorph(orientation) {
    this.init(orientation || "vertical");
}

CircleBoxMorph.prototype.init = function(orientation) {
    CircleBoxMorph.uber.init.call(this), this.orientation = orientation, this.autoOrient = !0, 
    this.setExtent(new Point(20, 100));
}, CircleBoxMorph.prototype.autoOrientation = function() {
    this.height() > this.width() ? this.orientation = "vertical" : this.orientation = "horizontal";
}, CircleBoxMorph.prototype.drawNew = function() {
    var radius, center1, center2, rect, x, y, context, ext, myself = this;
    this.autoOrient && this.autoOrientation(), this.image = newCanvas(this.extent()), 
    context = this.image.getContext("2d"), "vertical" === this.orientation ? (radius = this.width() / 2, 
    center1 = new Point(x = this.center().x, this.top() + radius), center2 = new Point(x, this.bottom() - radius), 
    rect = this.bounds.origin.add(new Point(0, radius)).corner(this.bounds.corner.subtract(new Point(0, radius)))) : (radius = this.height() / 2, 
    y = this.center().y, center1 = new Point(this.left() + radius, y), center2 = new Point(this.right() - radius, y), 
    rect = this.bounds.origin.add(new Point(radius, 0)).corner(this.bounds.corner.subtract(new Point(radius, 0)))), 
    [ center1.subtract(this.bounds.origin), center2.subtract(this.bounds.origin) ].forEach(function(center) {
        context.fillStyle = myself.color.toString(), context.beginPath(), context.arc(center.x, center.y, radius, 0, 2 * Math.PI, !1), 
        context.closePath(), context.fill();
    }), (ext = (rect = rect.translateBy(this.bounds.origin.neg())).extent()).x > 0 && ext.y > 0 && context.fillRect(rect.origin.x, rect.origin.y, rect.width(), rect.height());
}, CircleBoxMorph.prototype.developersMenu = function() {
    var menu = CircleBoxMorph.uber.developersMenu.call(this);
    return menu.addLine(), "vertical" === this.orientation ? menu.addItem("horizontal...", "toggleOrientation", "toggle the\norientation") : menu.addItem("vertical...", "toggleOrientation", "toggle the\norientation"), 
    menu;
}, CircleBoxMorph.prototype.toggleOrientation = function() {
    var center = this.center();
    this.changed(), "vertical" === this.orientation ? this.orientation = "horizontal" : this.orientation = "vertical", 
    this.silentSetExtent(new Point(this.height(), this.width())), this.setCenter(center), 
    this.drawNew(), this.changed();
};

var SliderButtonMorph;

SliderButtonMorph.prototype = new CircleBoxMorph(), SliderButtonMorph.prototype.constructor = SliderButtonMorph, 
SliderButtonMorph.uber = CircleBoxMorph.prototype;

function SliderButtonMorph(orientation) {
    this.init(orientation);
}

SliderButtonMorph.prototype.init = function(orientation) {
    this.color = new Color(80, 80, 80), this.highlightColor = new Color(90, 90, 140), 
    this.pressColor = new Color(80, 80, 160), this.is3D = !1, this.hasMiddleDip = !0, 
    SliderButtonMorph.uber.init.call(this, orientation);
}, SliderButtonMorph.prototype.autoOrientation = function() {
    nop();
}, SliderButtonMorph.prototype.drawNew = function() {
    var colorBak = this.color.copy();
    SliderButtonMorph.uber.drawNew.call(this), !this.is3D && MorphicPreferences.isFlat || this.drawEdges(), 
    this.normalImage = this.image, this.color = this.highlightColor.copy(), SliderButtonMorph.uber.drawNew.call(this), 
    !this.is3D && MorphicPreferences.isFlat || this.drawEdges(), this.highlightImage = this.image, 
    this.color = this.pressColor.copy(), SliderButtonMorph.uber.drawNew.call(this), 
    !this.is3D && MorphicPreferences.isFlat || this.drawEdges(), this.pressImage = this.image, 
    this.color = colorBak, this.image = this.normalImage;
}, SliderButtonMorph.prototype.drawEdges = function() {
    var gradient, radius, context = this.image.getContext("2d"), w = this.width(), h = this.height();
    context.lineJoin = "round", context.lineCap = "round", "vertical" === this.orientation ? (context.lineWidth = w / 3, 
    (gradient = context.createLinearGradient(0, 0, context.lineWidth, 0)).addColorStop(0, "white"), 
    gradient.addColorStop(1, this.color.toString()), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(.5 * context.lineWidth, w / 2), context.lineTo(.5 * context.lineWidth, h - w / 2), 
    context.stroke(), (gradient = context.createLinearGradient(w - context.lineWidth, 0, w, 0)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, "black"), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(w - .5 * context.lineWidth, w / 2), context.lineTo(w - .5 * context.lineWidth, h - w / 2), 
    context.stroke(), this.hasMiddleDip && (radius = w / 4, (gradient = context.createLinearGradient(context.lineWidth, 0, w - context.lineWidth, 0)).addColorStop(0, "black"), 
    gradient.addColorStop(.35, this.color.toString()), gradient.addColorStop(.65, this.color.toString()), 
    gradient.addColorStop(1, "white"), context.fillStyle = gradient, context.beginPath(), 
    context.arc(w / 2, h / 2, radius, radians(0), radians(360), !1), context.closePath(), 
    context.fill())) : "horizontal" === this.orientation && (context.lineWidth = h / 3, 
    (gradient = context.createLinearGradient(0, 0, 0, context.lineWidth)).addColorStop(0, "white"), 
    gradient.addColorStop(1, this.color.toString()), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(h / 2, .5 * context.lineWidth), context.lineTo(w - h / 2, .5 * context.lineWidth), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - context.lineWidth, 0, h)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, "black"), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(h / 2, h - .5 * context.lineWidth), context.lineTo(w - h / 2, h - .5 * context.lineWidth), 
    context.stroke(), this.hasMiddleDip && (radius = h / 4, (gradient = context.createLinearGradient(0, context.lineWidth, 0, h - context.lineWidth)).addColorStop(0, "black"), 
    gradient.addColorStop(.35, this.color.toString()), gradient.addColorStop(.65, this.color.toString()), 
    gradient.addColorStop(1, "white"), context.fillStyle = gradient, context.beginPath(), 
    context.arc(this.width() / 2, this.height() / 2, radius, radians(0), radians(360), !1), 
    context.closePath(), context.fill()));
}, SliderButtonMorph.prototype.mouseEnter = function() {
    this.image = this.highlightImage, this.changed();
}, SliderButtonMorph.prototype.mouseLeave = function() {
    this.image = this.normalImage, this.changed();
}, SliderButtonMorph.prototype.mouseDownLeft = function(pos) {
    this.image = this.pressImage, this.changed(), this.escalateEvent("mouseDownLeft", pos);
}, SliderButtonMorph.prototype.mouseClickLeft = function() {
    this.image = this.highlightImage, this.changed();
}, SliderButtonMorph.prototype.mouseMove = function() {
    nop();
}, SliderMorph.prototype = new CircleBoxMorph(), SliderMorph.prototype.constructor = SliderMorph, 
SliderMorph.uber = CircleBoxMorph.prototype;

function SliderMorph(start, stop, value, size, orientation, color) {
    this.init(start || 1, stop || 100, value || 50, size || 10, orientation || "vertical", color);
}

SliderMorph.prototype.init = function(start, stop, value, size, orientation, color) {
    this.target = null, this.action = null, this.start = start, this.stop = stop, this.value = value, 
    this.size = size, this.offset = null, this.button = new SliderButtonMorph(), this.button.isDraggable = !1, 
    this.button.color = new Color(200, 200, 200), this.button.highlightColor = new Color(210, 210, 255), 
    this.button.pressColor = new Color(180, 180, 255), SliderMorph.uber.init.call(this, orientation), 
    this.add(this.button), this.alpha = .3, this.color = color || new Color(0, 0, 0), 
    this.setExtent(new Point(20, 100));
}, SliderMorph.prototype.autoOrientation = function() {
    nop();
}, SliderMorph.prototype.rangeSize = function() {
    return this.stop - this.start;
}, SliderMorph.prototype.ratio = function() {
    return this.size / (this.rangeSize() + 1);
}, SliderMorph.prototype.unitSize = function() {
    return "vertical" === this.orientation ? (this.height() - this.button.height()) / this.rangeSize() : (this.width() - this.button.width()) / this.rangeSize();
}, SliderMorph.prototype.drawNew = function() {
    var bw, bh, posX, posY;
    SliderMorph.uber.drawNew.call(this), this.button.orientation = this.orientation, 
    "vertical" === this.orientation ? (bw = this.width() - 2, bh = Math.max(bw, Math.round(this.height() * this.ratio())), 
    this.button.silentSetExtent(new Point(bw, bh)), posX = 1, posY = Math.min(Math.round((this.value - this.start) * this.unitSize()), this.height() - this.button.height())) : (bh = this.height() - 2, 
    bw = Math.max(bh, Math.round(this.width() * this.ratio())), this.button.silentSetExtent(new Point(bw, bh)), 
    posY = 1, posX = Math.min(Math.round((this.value - this.start) * this.unitSize()), this.width() - this.button.width())), 
    this.button.setPosition(new Point(posX, posY).add(this.bounds.origin)), this.button.drawNew(), 
    this.button.changed();
}, SliderMorph.prototype.updateValue = function() {
    var relPos;
    relPos = "vertical" === this.orientation ? this.button.top() - this.top() : this.button.left() - this.left(), 
    this.value = Math.round(relPos / this.unitSize() + this.start), this.updateTarget();
}, SliderMorph.prototype.updateTarget = function() {
    this.action && ("function" == typeof this.action ? this.action.call(this.target, this.value) : this.target[this.action](this.value));
}, SliderMorph.prototype.copyRecordingReferences = function(dict) {
    var c = SliderMorph.uber.copyRecordingReferences.call(this, dict);
    return c.target && dict[this.target] && (c.target = dict[this.target]), c.button && dict[this.button] && (c.button = dict[this.button]), 
    c;
}, SliderMorph.prototype.developersMenu = function() {
    var menu = SliderMorph.uber.developersMenu.call(this);
    return menu.addItem("show value...", "showValue", "display a dialog box\nshowing the selected number"), 
    menu.addItem("floor...", function() {
        this.prompt(menu.title + "\nfloor:", this.setStart, this, this.start.toString(), null, 0, this.stop - this.size, !0);
    }, "set the minimum value\nwhich can be selected"), menu.addItem("ceiling...", function() {
        this.prompt(menu.title + "\nceiling:", this.setStop, this, this.stop.toString(), null, this.start + this.size, 100 * this.size, !0);
    }, "set the maximum value\nwhich can be selected"), menu.addItem("button size...", function() {
        this.prompt(menu.title + "\nbutton size:", this.setSize, this, this.size.toString(), null, 1, this.stop - this.start, !0);
    }, "set the range\ncovered by\nthe slider button"), menu.addLine(), menu.addItem("set target", "setTarget", "select another morph\nwhose numerical property\nwill be controlled by this one"), 
    menu;
}, SliderMorph.prototype.showValue = function() {
    this.inform(this.value);
}, SliderMorph.prototype.userSetStart = function(num) {
    this.start = Math.max(num, this.stop);
}, SliderMorph.prototype.setStart = function(num) {
    var newStart;
    "number" == typeof num ? this.start = Math.min(num, this.stop - this.size) : (newStart = parseFloat(num), 
    isNaN(newStart) || (this.start = Math.min(newStart, this.stop - this.size))), this.value = Math.max(this.value, this.start), 
    this.updateTarget(), this.drawNew(), this.changed();
}, SliderMorph.prototype.setStop = function(num) {
    var newStop;
    "number" == typeof num ? this.stop = Math.max(num, this.start + this.size) : (newStop = parseFloat(num), 
    isNaN(newStop) || (this.stop = Math.max(newStop, this.start + this.size))), this.value = Math.min(this.value, this.stop), 
    this.updateTarget(), this.drawNew(), this.changed();
}, SliderMorph.prototype.setSize = function(num) {
    var newSize;
    "number" == typeof num ? this.size = Math.min(Math.max(num, 1), this.stop - this.start) : (newSize = parseFloat(num), 
    isNaN(newSize) || (this.size = Math.min(Math.max(newSize, 1), this.stop - this.start))), 
    this.value = Math.min(this.value, this.stop - this.size), this.updateTarget(), this.drawNew(), 
    this.changed();
}, SliderMorph.prototype.setTarget = function() {
    var choices = this.overlappedMorphs(), menu = new MenuMorph(this, "choose target:"), myself = this;
    choices.push(this.world()), choices.forEach(function(each) {
        menu.addItem(each.toString().slice(0, 50), function() {
            myself.target = each, myself.setTargetSetter();
        });
    }), 1 === choices.length ? (this.target = choices[0], this.setTargetSetter()) : choices.length > 0 && menu.popUpAtHand(this.world());
}, SliderMorph.prototype.setTargetSetter = function() {
    var choices = this.target.numericalSetters(), menu = new MenuMorph(this, "choose target property:"), myself = this;
    choices.forEach(function(each) {
        menu.addItem(each, function() {
            myself.action = each;
        });
    }), 1 === choices.length ? this.action = choices[0] : choices.length > 0 && menu.popUpAtHand(this.world());
}, SliderMorph.prototype.numericalSetters = function() {
    var list = SliderMorph.uber.numericalSetters.call(this);
    return list.push("setStart", "setStop", "setSize"), list;
}, SliderMorph.prototype.step = null, SliderMorph.prototype.mouseDownLeft = function(pos) {
    var world, myself = this;
    this.button.bounds.containsPoint(pos) ? this.offset = pos.subtract(this.button.bounds.origin) : this.offset = new Point(), 
    world = this.root(), this.step = function() {
        var mousePos, newX, newY;
        world.hand.mouseButton ? (mousePos = world.hand.bounds.origin, "vertical" === myself.orientation ? (newX = myself.button.bounds.origin.x, 
        newY = Math.max(Math.min(mousePos.y - myself.offset.y, myself.bottom() - myself.button.height()), myself.top())) : (newY = myself.button.bounds.origin.y, 
        newX = Math.max(Math.min(mousePos.x - myself.offset.x, myself.right() - myself.button.width()), myself.left())), 
        myself.button.setPosition(new Point(newX, newY)), myself.updateValue()) : this.step = null;
    };
};

var MouseSensorMorph;

MouseSensorMorph.prototype = new BoxMorph(), MouseSensorMorph.prototype.constructor = MouseSensorMorph, 
MouseSensorMorph.uber = BoxMorph.prototype;

function MouseSensorMorph(edge, border, borderColor) {
    this.init(edge, border, borderColor);
}

MouseSensorMorph.prototype.init = function(edge, border, borderColor) {
    MouseSensorMorph.uber.init.call(this), this.edge = edge || 4, this.border = border || 2, 
    this.color = new Color(255, 255, 255), this.borderColor = borderColor || new Color(), 
    this.isTouched = !1, this.upStep = .05, this.downStep = .02, this.noticesTransparentClick = !1, 
    this.drawNew();
}, MouseSensorMorph.prototype.touch = function() {
    var myself = this;
    this.isTouched || (this.isTouched = !0, this.alpha = .6, this.step = function() {
        myself.isTouched ? myself.alpha < 1 && (myself.alpha = myself.alpha + myself.upStep) : myself.alpha > myself.downStep ? myself.alpha = myself.alpha - myself.downStep : (myself.alpha = 0, 
        myself.step = null), myself.changed();
    });
}, MouseSensorMorph.prototype.unTouch = function() {
    this.isTouched = !1;
}, MouseSensorMorph.prototype.mouseEnter = function() {
    this.touch();
}, MouseSensorMorph.prototype.mouseLeave = function() {
    this.unTouch();
}, MouseSensorMorph.prototype.mouseDownLeft = function() {
    this.touch();
}, MouseSensorMorph.prototype.mouseClickLeft = function() {
    this.unTouch();
};

var ListMorph, TriggerMorph;

InspectorMorph.prototype = new BoxMorph(), InspectorMorph.prototype.constructor = InspectorMorph, 
InspectorMorph.uber = BoxMorph.prototype;

function InspectorMorph(target) {
    this.init(target);
}

InspectorMorph.prototype.init = function(target) {
    this.target = target, this.currentProperty = null, this.showing = "attributes", 
    this.markOwnProperties = !1, this.hasUserEditedDetails = !1, InspectorMorph.uber.init.call(this), 
    this.silentSetExtent(new Point(20 * MorphicPreferences.handleSize, 20 * MorphicPreferences.handleSize * 2 / 3)), 
    this.isDraggable = !0, this.border = 1, this.edge = MorphicPreferences.isFlat ? 1 : 5, 
    this.color = new Color(60, 60, 60), this.borderColor = new Color(95, 95, 95), this.fps = 25, 
    this.drawNew(), this.label = null, this.list = null, this.detail = null, this.work = null, 
    this.buttonInspect = null, this.buttonClose = null, this.buttonSubset = null, this.buttonEdit = null, 
    this.resizer = null, this.target && this.buildPanes();
}, InspectorMorph.prototype.setTarget = function(target) {
    this.target = target, this.currentProperty = null, this.buildPanes();
}, InspectorMorph.prototype.updateCurrentSelection = function() {
    var val, txt, cnts, sel = this.list.selected, currentTxt = this.detail.contents.children[0], root = this.root();
    root && root.keyboardReceiver instanceof CursorMorph && root.keyboardReceiver.target === currentTxt ? this.hasUserEditedDetails = !0 : isNil(sel) || this.hasUserEditedDetails || (val = this.target[sel], 
    this.currentProperty = val, txt = isNil(val) ? "NULL" : isString(val) ? val : val.toString(), 
    currentTxt.text !== txt && ((cnts = new TextMorph(txt)).isEditable = !0, cnts.enableSelecting(), 
    cnts.setReceiver(this.target), this.detail.setContents(cnts)));
}, InspectorMorph.prototype.buildPanes = function() {
    var property, ctrl, ev, doubleClickAction, attribs = [], myself = this;
    this.children.forEach(function(m) {
        m !== this.work && m.destroy();
    }), this.children = [], this.label = new TextMorph(this.target.toString()), this.label.fontSize = MorphicPreferences.menuFontSize, 
    this.label.isBold = !0, this.label.color = new Color(255, 255, 255), this.label.drawNew(), 
    this.add(this.label);
    for (property in this.target) property && attribs.push(property);
    "attributes" === this.showing ? attribs = attribs.filter(function(prop) {
        return "function" != typeof myself.target[prop];
    }) : "methods" === this.showing && (attribs = attribs.filter(function(prop) {
        return "function" == typeof myself.target[prop];
    })), doubleClickAction = function() {
        var world, inspector;
        isObject(myself.currentProperty) && (world = myself.world(), (inspector = new InspectorMorph(myself.currentProperty)).setPosition(world.hand.position()), 
        inspector.keepWithin(world), world.add(inspector), inspector.changed());
    }, this.list = new ListMorph(this.target instanceof Array ? attribs : attribs.sort(), null, this.markOwnProperties ? [ [ new Color(0, 0, 180), function(element) {
        return Object.prototype.hasOwnProperty.call(myself.target, element);
    } ] ] : null, doubleClickAction), this.list.action = function() {
        myself.hasUserEditedDetails = !1, myself.updateCurrentSelection();
    }, this.list.hBar.alpha = .6, this.list.vBar.alpha = .6, this.list.contents.step = null, 
    this.add(this.list), this.detail = new ScrollFrameMorph(), this.detail.acceptsDrops = !1, 
    this.detail.contents.acceptsDrops = !1, this.detail.isTextLineWrapping = !0, this.detail.color = new Color(255, 255, 255), 
    this.detail.hBar.alpha = .6, this.detail.vBar.alpha = .6, (ctrl = new TextMorph("")).isEditable = !0, 
    ctrl.enableSelecting(), ctrl.setReceiver(this.target), this.detail.setContents(ctrl), 
    this.add(this.detail), null === this.work && (this.work = new ScrollFrameMorph(), 
    this.work.acceptsDrops = !1, this.work.contents.acceptsDrops = !1, this.work.isTextLineWrapping = !0, 
    this.work.color = new Color(255, 255, 255), this.work.hBar.alpha = .6, this.work.vBar.alpha = .6, 
    (ev = new TextMorph("")).isEditable = !0, ev.enableSelecting(), ev.setReceiver(this.target), 
    this.work.setContents(ev)), this.add(this.work), this.buttonSubset = new TriggerMorph(), 
    this.buttonSubset.labelString = "show...", this.buttonSubset.action = function() {
        var menu;
        (menu = new MenuMorph()).addItem("attributes", function() {
            myself.showing = "attributes", myself.buildPanes();
        }), menu.addItem("methods", function() {
            myself.showing = "methods", myself.buildPanes();
        }), menu.addItem("all", function() {
            myself.showing = "all", myself.buildPanes();
        }), menu.addLine(), menu.addItem(myself.markOwnProperties ? "un-mark own" : "mark own", function() {
            myself.markOwnProperties = !myself.markOwnProperties, myself.buildPanes();
        }, "highlight\n'own' properties"), menu.popUpAtHand(myself.world());
    }, this.add(this.buttonSubset), this.buttonInspect = new TriggerMorph(), this.buttonInspect.labelString = "inspect...", 
    this.buttonInspect.action = function() {
        var menu, world, inspector;
        isObject(myself.currentProperty) ? ((menu = new MenuMorph()).addItem("in new inspector...", function() {
            world = myself.world(), (inspector = new InspectorMorph(myself.currentProperty)).setPosition(world.hand.position()), 
            inspector.keepWithin(world), world.add(inspector), inspector.changed();
        }), menu.addItem("here...", function() {
            myself.setTarget(myself.currentProperty);
        }), menu.popUpAtHand(myself.world())) : myself.inform((null === myself.currentProperty ? "null" : typeof myself.currentProperty) + "\nis not inspectable");
    }, this.add(this.buttonInspect), this.buttonEdit = new TriggerMorph(), this.buttonEdit.labelString = "edit...", 
    this.buttonEdit.action = function() {
        var menu;
        (menu = new MenuMorph(myself)).addItem("save", "save", "accept changes"), menu.addLine(), 
        menu.addItem("add property...", "addProperty"), menu.addItem("rename...", "renameProperty"), 
        menu.addItem("remove...", "removeProperty"), menu.popUpAtHand(myself.world());
    }, this.add(this.buttonEdit), this.buttonClose = new TriggerMorph(), this.buttonClose.labelString = "close", 
    this.buttonClose.action = function() {
        myself.destroy();
    }, this.add(this.buttonClose), this.resizer = new HandleMorph(this, 150, 100, this.edge, this.edge), 
    this.fixLayout();
}, InspectorMorph.prototype.fixLayout = function() {
    var x, y, w, h;
    Morph.prototype.trackChanges = !1, x = this.left() + this.edge, y = this.top() + this.edge, 
    w = this.right() - this.edge - x, this.label.setPosition(new Point(x, y)), this.label.setWidth(w), 
    this.label.height() > this.height() - 50 && (this.silentSetHeight(this.label.height() + 50), 
    this.drawNew(), this.changed(), this.resizer.drawNew()), y = this.label.bottom() + 2, 
    w = Math.min(Math.floor(this.width() / 3), this.list.listContents.width()), w -= this.edge, 
    h = this.bottom() - 2 * this.edge - MorphicPreferences.handleSize - y, this.list.setPosition(new Point(x, y)), 
    this.list.setExtent(new Point(w, h)), x = this.list.right() + this.edge, w = this.right() - this.edge - x, 
    this.detail.setPosition(new Point(x, y)), this.detail.setExtent(new Point(w, 2 * h / 3 - this.edge)), 
    y = this.detail.bottom() + this.edge, this.work.setPosition(new Point(x, y)), this.work.setExtent(new Point(w, h / 3)), 
    x = this.list.left(), y = this.list.bottom() + this.edge, w = this.list.width(), 
    h = MorphicPreferences.handleSize, this.buttonSubset.setPosition(new Point(x, y)), 
    this.buttonSubset.setExtent(new Point(w, h)), x = this.detail.left(), w = (w = this.detail.width() - this.edge - MorphicPreferences.handleSize) / 3 - this.edge / 3, 
    this.buttonInspect.setPosition(new Point(x, y)), this.buttonInspect.setExtent(new Point(w, h)), 
    x = this.buttonInspect.right() + this.edge, this.buttonEdit.setPosition(new Point(x, y)), 
    this.buttonEdit.setExtent(new Point(w, h)), x = this.buttonEdit.right() + this.edge, 
    w = this.detail.right() - this.edge - MorphicPreferences.handleSize - x, this.buttonClose.setPosition(new Point(x, y)), 
    this.buttonClose.setExtent(new Point(w, h)), Morph.prototype.trackChanges = !0, 
    this.changed();
}, InspectorMorph.prototype.setExtent = function(aPoint) {
    InspectorMorph.uber.setExtent.call(this, aPoint), this.fixLayout();
}, InspectorMorph.prototype.save = function() {
    var txt = this.detail.contents.children[0].text.toString(), prop = this.list.selected;
    try {
        this.target.evaluateString("this." + prop + " = " + txt), this.hasUserEditedDetails = !1, 
        this.target.drawNew && (this.target.changed(), this.target.drawNew(), this.target.changed());
    } catch (err) {
        this.inform(err);
    }
}, InspectorMorph.prototype.addProperty = function() {
    var myself = this;
    this.prompt("new property name:", function(prop) {
        prop && (myself.target[prop] = null, myself.buildPanes(), myself.target.drawNew && (myself.target.changed(), 
        myself.target.drawNew(), myself.target.changed()));
    }, this, "property");
}, InspectorMorph.prototype.renameProperty = function() {
    var myself = this, propertyName = this.list.selected;
    this.prompt("property name:", function(prop) {
        try {
            delete myself.target[propertyName], myself.target[prop] = myself.currentProperty;
        } catch (err) {
            myself.inform(err);
        }
        myself.buildPanes(), myself.target.drawNew && (myself.target.changed(), myself.target.drawNew(), 
        myself.target.changed());
    }, this, propertyName);
}, InspectorMorph.prototype.removeProperty = function() {
    var prop = this.list.selected;
    try {
        delete this.target[prop], this.currentProperty = null, this.buildPanes(), this.target.drawNew && (this.target.changed(), 
        this.target.drawNew(), this.target.changed());
    } catch (err) {
        this.inform(err);
    }
}, InspectorMorph.prototype.step = function() {
    this.updateCurrentSelection();
    var lbl = this.target.toString();
    this.label.text !== lbl && (this.label.text = lbl, this.label.drawNew(), this.fixLayout());
};

var MenuItemMorph;

MenuMorph.prototype = new BoxMorph(), MenuMorph.prototype.constructor = MenuMorph, 
MenuMorph.uber = BoxMorph.prototype;

function MenuMorph(target, title, environment, fontSize) {
    this.init(target, title, environment, fontSize);
}

MenuMorph.prototype.init = function(target, title, environment, fontSize) {
    this.target = target, this.title = title || null, this.environment = environment || null, 
    this.fontSize = fontSize || null, this.items = [], this.label = null, this.world = null, 
    this.isListContents = !1, MenuMorph.uber.init.call(this), this.isDraggable = !1, 
    this.border = null, this.edge = null;
}, MenuMorph.prototype.addItem = function(labelString, action, hint, color, bold, italic, doubleClickAction) {
    this.items.push([ localize(labelString || "close"), action || nop, hint, color, bold || !1, italic || !1, doubleClickAction ]);
}, MenuMorph.prototype.addLine = function(width) {
    this.items.push([ 0, width || 1 ]);
}, MenuMorph.prototype.createLabel = function() {
    var text;
    null !== this.label && this.label.destroy(), (text = new TextMorph(localize(this.title), this.fontSize || MorphicPreferences.menuFontSize, MorphicPreferences.menuFontName, !0, !1, "center")).alignment = "center", 
    text.color = new Color(255, 255, 255), text.backgroundColor = this.borderColor, 
    text.drawNew(), this.label = new BoxMorph(3, 0), MorphicPreferences.isFlat && (this.label.edge = 0), 
    this.label.color = this.borderColor, this.label.borderColor = this.borderColor, 
    this.label.setExtent(text.extent().add(4)), this.label.drawNew(), this.label.add(text), 
    this.label.text = text;
}, MenuMorph.prototype.drawNew = function() {
    var item, fb, x, y, myself = this, isLine = !1;
    this.children.forEach(function(m) {
        m.destroy();
    }), this.children = [], this.isListContents || (this.edge = MorphicPreferences.isFlat ? 0 : 5, 
    this.border = MorphicPreferences.isFlat ? 1 : 2), this.color = new Color(255, 255, 255), 
    this.borderColor = new Color(60, 60, 60), this.silentSetExtent(new Point(0, 0)), 
    y = 2, x = this.left() + 4, this.isListContents || (this.title ? (this.createLabel(), 
    this.label.setPosition(this.bounds.origin.add(4)), this.add(this.label), y = this.label.bottom()) : y = this.top() + 4), 
    y += 1, this.items.forEach(function(tuple) {
        isLine = !1, tuple instanceof StringFieldMorph || tuple instanceof ColorPickerMorph || tuple instanceof SliderMorph ? item = tuple : 0 === tuple[0] ? (isLine = !0, 
        (item = new Morph()).color = myself.borderColor, item.setHeight(tuple[1])) : item = new MenuItemMorph(myself.target, tuple[1], tuple[0], myself.fontSize || MorphicPreferences.menuFontSize, MorphicPreferences.menuFontName, myself.environment, tuple[2], tuple[3], tuple[4], tuple[5], tuple[6]), 
        isLine && (y += 1), item.setPosition(new Point(x, y)), myself.add(item), y += item.height(), 
        isLine && (y += 1);
    }), fb = this.fullBounds(), this.silentSetExtent(fb.extent().add(4)), this.adjustWidths(), 
    MenuMorph.uber.drawNew.call(this);
}, MenuMorph.prototype.maxWidth = function() {
    var w = 0;
    return this.parent instanceof FrameMorph && this.parent.scrollFrame instanceof ScrollFrameMorph && (w = this.parent.scrollFrame.width()), 
    this.children.forEach(function(item) {
        item instanceof MenuItemMorph ? w = Math.max(w, item.children[0].width() + 8) : (item instanceof StringFieldMorph || item instanceof ColorPickerMorph || item instanceof SliderMorph) && (w = Math.max(w, item.width()));
    }), this.label && (w = Math.max(w, this.label.width())), w;
}, MenuMorph.prototype.adjustWidths = function() {
    var isSelected, w = this.maxWidth(), myself = this;
    this.children.forEach(function(item) {
        item.silentSetWidth(w), item instanceof MenuItemMorph ? (isSelected = item.image === item.pressImage, 
        item.createBackgrounds(), isSelected && (item.image = item.pressImage)) : (item.drawNew(), 
        item === myself.label && item.text.setPosition(item.center().subtract(item.text.extent().floorDivideBy(2))));
    });
}, MenuMorph.prototype.unselectAllItems = function() {
    this.children.forEach(function(item) {
        item instanceof MenuItemMorph && (item.image = item.normalImage);
    }), this.changed();
}, MenuMorph.prototype.popup = function(world, pos) {
    this.drawNew(), this.setPosition(pos), this.addShadow(new Point(2, 2), 80), this.keepWithin(world), 
    world.activeMenu && world.activeMenu.destroy(), this.items.length < 1 && !this.title || (world.add(this), 
    world.activeMenu = this, this.fullChanged());
}, MenuMorph.prototype.popUpAtHand = function(world) {
    var wrrld = world || this.world;
    this.popup(wrrld, wrrld.hand.position());
}, MenuMorph.prototype.popUpCenteredAtHand = function(world) {
    var wrrld = world || this.world;
    this.drawNew(), this.popup(wrrld, wrrld.hand.position().subtract(this.extent().floorDivideBy(2)));
}, MenuMorph.prototype.popUpCenteredInWorld = function(world) {
    var wrrld = world || this.world;
    this.drawNew(), this.popup(wrrld, wrrld.center().subtract(this.extent().floorDivideBy(2)));
}, StringMorph.prototype = new Morph(), StringMorph.prototype.constructor = StringMorph, 
StringMorph.uber = Morph.prototype;

function StringMorph(text, fontSize, fontStyle, bold, italic, isNumeric, shadowOffset, shadowColor, color, fontName) {
    this.init(text, fontSize, fontStyle, bold, italic, isNumeric, shadowOffset, shadowColor, color, fontName);
}

StringMorph.prototype.init = function(text, fontSize, fontStyle, bold, italic, isNumeric, shadowOffset, shadowColor, color, fontName) {
    this.text = text || ("" === text ? "" : "StringMorph"), this.fontSize = fontSize || 12, 
    this.fontName = fontName || MorphicPreferences.globalFontFamily, this.fontStyle = fontStyle || "sans-serif", 
    this.isBold = bold || !1, this.isItalic = italic || !1, this.isEditable = !1, this.isNumeric = isNumeric || !1, 
    this.isPassword = !1, this.shadowOffset = shadowOffset || new Point(0, 0), this.shadowColor = shadowColor || null, 
    this.isShowingBlanks = !1, this.blanksColor = new Color(180, 140, 140), this.isScrollable = !0, 
    this.currentlySelecting = !1, this.startMark = 0, this.endMark = 0, this.markedTextColor = new Color(255, 255, 255), 
    this.markedBackgoundColor = new Color(60, 60, 120), StringMorph.uber.init.call(this), 
    this.color = color || new Color(0, 0, 0), this.noticesTransparentClick = !0, this.drawNew();
}, StringMorph.prototype.toString = function() {
    return "a " + (this.constructor.name || this.constructor.toString().split(" ")[1].split("(")[0]) + '("' + this.text.slice(0, 30) + '...")';
}, StringMorph.prototype.password = function(letter, length) {
    var i, ans = "";
    for (i = 0; i < length; i += 1) ans += letter;
    return ans;
}, StringMorph.prototype.font = function() {
    var font = "";
    return this.isBold && (font += "bold "), this.isItalic && (font += "italic "), font + this.fontSize + "px " + (this.fontName ? this.fontName + ", " : "") + this.fontStyle;
}, StringMorph.prototype.drawNew = function() {
    var context, width, start, stop, i, p, c, x, y, shadowOffset = this.shadowOffset || new Point(), txt = this.isPassword ? this.password("*", this.text.length) : this.text;
    for (this.image = newCanvas(), (context = this.image.getContext("2d")).font = this.font(), 
    width = Math.max(context.measureText(txt).width + Math.abs(shadowOffset.x), 1), 
    this.bounds.corner = this.bounds.origin.add(new Point(width, fontHeight(this.fontSize) + Math.abs(shadowOffset.y))), 
    this.image.width = width, this.image.height = this.height(), context.font = this.font(), 
    context.textAlign = "left", context.textBaseline = "bottom", this.shadowColor && (x = Math.max(shadowOffset.x, 0), 
    y = Math.max(shadowOffset.y, 0), context.fillStyle = this.shadowColor.toString(), 
    context.fillText(txt, x, fontHeight(this.fontSize) + y)), x = Math.abs(Math.min(shadowOffset.x, 0)), 
    y = Math.abs(Math.min(shadowOffset.y, 0)), context.fillStyle = this.color.toString(), 
    this.isShowingBlanks ? this.renderWithBlanks(context, x, fontHeight(this.fontSize) + y) : context.fillText(txt, x, fontHeight(this.fontSize) + y), 
    start = Math.min(this.startMark, this.endMark), stop = Math.max(this.startMark, this.endMark), 
    i = start; i < stop; i += 1) p = this.slotPosition(i).subtract(this.position()), 
    c = txt.charAt(i), context.fillStyle = this.markedBackgoundColor.toString(), context.fillRect(p.x, p.y, context.measureText(c).width + 1 + x, fontHeight(this.fontSize) + y), 
    context.fillStyle = this.markedTextColor.toString(), context.fillText(c, p.x + x, fontHeight(this.fontSize) + y);
    this.parent && this.parent.fixLayout && this.parent.fixLayout();
}, StringMorph.prototype.renderWithBlanks = function(context, startX, y) {
    var space = context.measureText(" ").width, blank = newCanvas(new Point(space, this.height())), ctx = blank.getContext("2d"), words = this.text.split(" "), x = startX || 0, isFirst = !0;
    ctx.fillStyle = this.blanksColor.toString(), ctx.arc(space / 2, blank.height / 2, space / 2, radians(0), radians(360)), 
    ctx.fill();
    words.forEach(function(word) {
        isFirst || (context.drawImage(blank, x, 0), x += space), isFirst = !1, "" !== word && (context.fillText(word, x, y), 
        x += context.measureText(word).width);
    });
}, StringMorph.prototype.slotPosition = function(slot) {
    var xOffset, idx, txt = this.isPassword ? this.password("*", this.text.length) : this.text, dest = Math.min(Math.max(slot, 0), txt.length), context = this.image.getContext("2d");
    for (xOffset = 0, idx = 0; idx < dest; idx += 1) xOffset += context.measureText(txt[idx]).width;
    return this.pos = dest, new Point(this.left() + xOffset, this.top());
}, StringMorph.prototype.slotAt = function(aPoint) {
    for (var txt = this.isPassword ? this.password("*", this.text.length) : this.text, idx = 0, charX = 0, context = this.image.getContext("2d"); aPoint.x - this.left() > charX; ) if (charX += context.measureText(txt[idx]).width, 
    (idx += 1) === txt.length && context.measureText(txt).width - context.measureText(txt[idx - 1]).width / 2 < aPoint.x - this.left()) return idx;
    return idx - 1;
}, StringMorph.prototype.upFrom = function(slot) {
    return slot;
}, StringMorph.prototype.downFrom = function(slot) {
    return slot;
}, StringMorph.prototype.startOfLine = function() {
    return 0;
}, StringMorph.prototype.endOfLine = function() {
    return this.text.length;
}, StringMorph.prototype.rawHeight = function() {
    return this.height() / 1.2;
}, StringMorph.prototype.developersMenu = function() {
    var menu = StringMorph.uber.developersMenu.call(this);
    return menu.addLine(), menu.addItem("edit", "edit"), menu.addItem("font size...", function() {
        this.prompt(menu.title + "\nfont\nsize:", this.setFontSize, this, this.fontSize.toString(), null, 6, 500, !0);
    }, "set this String's\nfont point size"), "serif" !== this.fontStyle && menu.addItem("serif", "setSerif"), 
    "sans-serif" !== this.fontStyle && menu.addItem("sans-serif", "setSansSerif"), this.isBold ? menu.addItem("normal weight", "toggleWeight") : menu.addItem("bold", "toggleWeight"), 
    this.isItalic ? menu.addItem("normal style", "toggleItalic") : menu.addItem("italic", "toggleItalic"), 
    this.isShowingBlanks ? menu.addItem("hide blanks", "toggleShowBlanks") : menu.addItem("show blanks", "toggleShowBlanks"), 
    this.isPassword ? menu.addItem("show characters", "toggleIsPassword") : menu.addItem("hide characters", "toggleIsPassword"), 
    menu;
}, StringMorph.prototype.toggleIsDraggable = function() {
    this.isDraggable = !this.isDraggable, this.isDraggable ? this.disableSelecting() : this.enableSelecting();
}, StringMorph.prototype.toggleShowBlanks = function() {
    this.isShowingBlanks = !this.isShowingBlanks, this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.toggleWeight = function() {
    this.isBold = !this.isBold, this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.toggleItalic = function() {
    this.isItalic = !this.isItalic, this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.toggleIsPassword = function() {
    this.isPassword = !this.isPassword, this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.setSerif = function() {
    this.fontStyle = "serif", this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.setSansSerif = function() {
    this.fontStyle = "sans-serif", this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.setFontSize = function(size) {
    var newSize;
    "number" == typeof size ? this.fontSize = Math.round(Math.min(Math.max(size, 4), 500)) : (newSize = parseFloat(size), 
    isNaN(newSize) || (this.fontSize = Math.round(Math.min(Math.max(newSize, 4), 500)))), 
    this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.setText = function(size) {
    this.text = Math.round(size).toString(), this.changed(), this.drawNew(), this.changed();
}, StringMorph.prototype.numericalSetters = function() {
    return [ "setLeft", "setTop", "setAlphaScaled", "setFontSize", "setText" ];
}, StringMorph.prototype.edit = function() {
    this.root().edit(this);
}, StringMorph.prototype.selection = function() {
    var start, stop;
    return start = Math.min(this.startMark, this.endMark), stop = Math.max(this.startMark, this.endMark), 
    this.text.slice(start, stop);
}, StringMorph.prototype.selectionStartSlot = function() {
    return Math.min(this.startMark, this.endMark);
}, StringMorph.prototype.clearSelection = function() {
    this.currentlySelecting = !1, this.startMark = 0, this.endMark = 0, this.drawNew(), 
    this.changed();
}, StringMorph.prototype.deleteSelection = function() {
    var start, stop, text;
    text = this.text, start = Math.min(this.startMark, this.endMark), stop = Math.max(this.startMark, this.endMark), 
    this.text = text.slice(0, start) + text.slice(stop), this.changed(), this.clearSelection();
}, StringMorph.prototype.selectAll = function() {
    this.isEditable && (this.startMark = 0, this.endMark = this.text.length, this.drawNew(), 
    this.changed());
}, StringMorph.prototype.mouseDownLeft = function(pos) {
    this.isEditable ? this.clearSelection() : this.escalateEvent("mouseDownLeft", pos);
}, StringMorph.prototype.mouseClickLeft = function(pos) {
    var cursor;
    this.isEditable ? (this.currentlySelecting || this.edit(), (cursor = this.root().cursor) && cursor.gotoPos(pos), 
    this.currentlySelecting = !0) : this.escalateEvent("mouseClickLeft", pos);
}, StringMorph.prototype.enableSelecting = function() {
    this.mouseDownLeft = function(pos) {
        this.clearSelection(), this.isEditable && !this.isDraggable && (this.edit(), this.root().cursor.gotoPos(pos), 
        this.startMark = this.slotAt(pos), this.endMark = this.startMark, this.currentlySelecting = !0);
    }, this.mouseMove = function(pos) {
        if (this.isEditable && this.currentlySelecting && !this.isDraggable) {
            var newMark = this.slotAt(pos);
            newMark !== this.endMark && (this.endMark = newMark, this.drawNew(), this.changed());
        }
    };
}, StringMorph.prototype.disableSelecting = function() {
    this.mouseDownLeft = StringMorph.prototype.mouseDownLeft, delete this.mouseMove;
}, TextMorph.prototype = new Morph(), TextMorph.prototype.constructor = TextMorph, 
TextMorph.uber = Morph.prototype;

function TextMorph(text, fontSize, fontStyle, bold, italic, alignment, width, fontName, shadowOffset, shadowColor) {
    this.init(text, fontSize, fontStyle, bold, italic, alignment, width, fontName, shadowOffset, shadowColor);
}

TextMorph.prototype.init = function(text, fontSize, fontStyle, bold, italic, alignment, width, fontName, shadowOffset, shadowColor) {
    this.text = text || ("" === text ? text : "TextMorph"), this.words = [], this.lines = [], 
    this.lineSlots = [], this.fontSize = fontSize || 12, this.fontName = fontName || MorphicPreferences.globalFontFamily, 
    this.fontStyle = fontStyle || "sans-serif", this.isBold = bold || !1, this.isItalic = italic || !1, 
    this.alignment = alignment || "left", this.shadowOffset = shadowOffset || new Point(0, 0), 
    this.shadowColor = shadowColor || null, this.maxWidth = width || 0, this.maxLineWidth = 0, 
    this.backgroundColor = null, this.isEditable = !1, this.receiver = null, this.isScrollable = !0, 
    this.currentlySelecting = !1, this.startMark = 0, this.endMark = 0, this.markedTextColor = new Color(255, 255, 255), 
    this.markedBackgoundColor = new Color(60, 60, 120), TextMorph.uber.init.call(this), 
    this.color = new Color(0, 0, 0), this.noticesTransparentClick = !0, this.drawNew();
}, TextMorph.prototype.toString = function() {
    return 'a TextMorph("' + this.text.slice(0, 30) + '...")';
}, TextMorph.prototype.font = StringMorph.prototype.font, TextMorph.prototype.parse = function() {
    var newline, myself = this, paragraphs = this.text.split("\n"), context = newCanvas().getContext("2d"), oldline = "", slot = 0;
    context.font = this.font(), this.maxLineWidth = 0, this.lines = [], this.lineSlots = [ 0 ], 
    this.words = [], paragraphs.forEach(function(p) {
        myself.words = myself.words.concat(p.split(" ")), myself.words.push("\n");
    }), this.words.forEach(function(word) {
        "\n" === word ? (myself.lines.push(oldline), myself.lineSlots.push(slot), myself.maxLineWidth = Math.max(myself.maxLineWidth, context.measureText(oldline).width), 
        oldline = "") : (myself.maxWidth > 0 ? (newline = oldline + word + " ", context.measureText(newline).width > myself.maxWidth ? (myself.lines.push(oldline), 
        myself.lineSlots.push(slot), myself.maxLineWidth = Math.max(myself.maxLineWidth, context.measureText(oldline).width), 
        oldline = word + " ") : oldline = newline) : oldline = oldline + word + " ", slot += word.length + 1);
    });
}, TextMorph.prototype.drawNew = function() {
    var context, height, i, line, width, shadowHeight, shadowWidth, offx, offy, x, y, start, stop, p, c;
    if (this.image = newCanvas(), (context = this.image.getContext("2d")).font = this.font(), 
    this.parse(), shadowWidth = Math.abs(this.shadowOffset.x), shadowHeight = Math.abs(this.shadowOffset.y), 
    height = this.lines.length * (fontHeight(this.fontSize) + shadowHeight), 0 === this.maxWidth ? this.bounds = this.bounds.origin.extent(new Point(this.maxLineWidth + shadowWidth, height)) : this.bounds = this.bounds.origin.extent(new Point(this.maxWidth + shadowWidth, height)), 
    this.image.width = this.width(), this.image.height = this.height(), (context = this.image.getContext("2d")).font = this.font(), 
    context.textAlign = "left", context.textBaseline = "bottom", this.backgroundColor && (context.fillStyle = this.backgroundColor.toString(), 
    context.fillRect(0, 0, this.width(), this.height())), this.shadowColor) for (offx = Math.max(this.shadowOffset.x, 0), 
    offy = Math.max(this.shadowOffset.y, 0), context.fillStyle = this.shadowColor.toString(), 
    i = 0; i < this.lines.length; i += 1) line = this.lines[i], width = context.measureText(line).width + shadowWidth, 
    x = "right" === this.alignment ? this.width() - width : "center" === this.alignment ? (this.width() - width) / 2 : 0, 
    y = (i + 1) * (fontHeight(this.fontSize) + shadowHeight) - shadowHeight, context.fillText(line, x + offx, y + offy);
    for (offx = Math.abs(Math.min(this.shadowOffset.x, 0)), offy = Math.abs(Math.min(this.shadowOffset.y, 0)), 
    context.fillStyle = this.color.toString(), i = 0; i < this.lines.length; i += 1) line = this.lines[i], 
    width = context.measureText(line).width + shadowWidth, x = "right" === this.alignment ? this.width() - width : "center" === this.alignment ? (this.width() - width) / 2 : 0, 
    y = (i + 1) * (fontHeight(this.fontSize) + shadowHeight) - shadowHeight, context.fillText(line, x + offx, y + offy);
    for (start = Math.min(this.startMark, this.endMark), stop = Math.max(this.startMark, this.endMark), 
    i = start; i < stop; i += 1) p = this.slotPosition(i).subtract(this.position()), 
    c = this.text.charAt(i), context.fillStyle = this.markedBackgoundColor.toString(), 
    context.fillRect(p.x, p.y, context.measureText(c).width + 1, fontHeight(this.fontSize)), 
    context.fillStyle = this.markedTextColor.toString(), context.fillText(c, p.x, p.y + fontHeight(this.fontSize));
    this.parent && this.parent.layoutChanged && this.parent.layoutChanged();
}, TextMorph.prototype.setExtent = function(aPoint) {
    this.maxWidth = Math.max(aPoint.x, 0), this.changed(), this.drawNew();
}, TextMorph.prototype.columnRow = function(slot) {
    var row, col, idx = 0;
    for (row = 0; row < this.lines.length; row += 1) for (idx = this.lineSlots[row], 
    col = 0; col < this.lines[row].length; col += 1) {
        if (idx === slot) return new Point(col, row);
        idx += 1;
    }
    return new Point(this.lines[this.lines.length - 1].length - 1, this.lines.length - 1);
}, TextMorph.prototype.slotPosition = function(slot) {
    var yOffset, idx, colRow = this.columnRow(slot), context = this.image.getContext("2d"), shadowHeight = Math.abs(this.shadowOffset.y), xOffset = 0;
    for (yOffset = colRow.y * (fontHeight(this.fontSize) + shadowHeight), idx = 0; idx < colRow.x; idx += 1) xOffset += context.measureText(this.lines[colRow.y][idx]).width;
    return new Point(this.left() + xOffset, this.top() + yOffset);
}, TextMorph.prototype.slotAt = function(aPoint) {
    for (var charX = 0, row = 0, col = 0, shadowHeight = Math.abs(this.shadowOffset.y), context = this.image.getContext("2d"); aPoint.y - this.top() > (fontHeight(this.fontSize) + shadowHeight) * row; ) row += 1;
    for (row = Math.max(row, 1); aPoint.x - this.left() > charX; ) charX += context.measureText(this.lines[row - 1][col]).width, 
    col += 1;
    return this.lineSlots[Math.max(row - 1, 0)] + col - 1;
}, TextMorph.prototype.upFrom = function(slot) {
    var above, colRow = this.columnRow(slot);
    return colRow.y < 1 ? slot : (above = this.lines[colRow.y - 1]).length < colRow.x - 1 ? this.lineSlots[colRow.y - 1] + above.length : this.lineSlots[colRow.y - 1] + colRow.x;
}, TextMorph.prototype.downFrom = function(slot) {
    var below, colRow = this.columnRow(slot);
    return colRow.y > this.lines.length - 2 ? slot : (below = this.lines[colRow.y + 1]).length < colRow.x - 1 ? this.lineSlots[colRow.y + 1] + below.length : this.lineSlots[colRow.y + 1] + colRow.x;
}, TextMorph.prototype.startOfLine = function(slot) {
    return this.lineSlots[this.columnRow(slot).y];
}, TextMorph.prototype.endOfLine = function(slot) {
    return this.startOfLine(slot) + this.lines[this.columnRow(slot).y].length - 1;
}, TextMorph.prototype.edit = StringMorph.prototype.edit, TextMorph.prototype.selection = StringMorph.prototype.selection, 
TextMorph.prototype.selectionStartSlot = StringMorph.prototype.selectionStartSlot, 
TextMorph.prototype.clearSelection = StringMorph.prototype.clearSelection, TextMorph.prototype.deleteSelection = StringMorph.prototype.deleteSelection, 
TextMorph.prototype.selectAll = StringMorph.prototype.selectAll, TextMorph.prototype.mouseDownLeft = StringMorph.prototype.mouseDownLeft, 
TextMorph.prototype.mouseClickLeft = StringMorph.prototype.mouseClickLeft, TextMorph.prototype.enableSelecting = StringMorph.prototype.enableSelecting, 
TextMorph.prototype.disableSelecting = StringMorph.prototype.disableSelecting, TextMorph.prototype.selectAllAndEdit = function() {
    this.edit(), this.selectAll();
}, TextMorph.prototype.developersMenu = function() {
    var menu = TextMorph.uber.developersMenu.call(this);
    return menu.addLine(), menu.addItem("edit", "edit"), menu.addItem("font size...", function() {
        this.prompt(menu.title + "\nfont\nsize:", this.setFontSize, this, this.fontSize.toString(), null, 6, 100, !0);
    }, "set this Text's\nfont point size"), "left" !== this.alignment && menu.addItem("align left", "setAlignmentToLeft"), 
    "right" !== this.alignment && menu.addItem("align right", "setAlignmentToRight"), 
    "center" !== this.alignment && menu.addItem("align center", "setAlignmentToCenter"), 
    menu.addLine(), "serif" !== this.fontStyle && menu.addItem("serif", "setSerif"), 
    "sans-serif" !== this.fontStyle && menu.addItem("sans-serif", "setSansSerif"), this.isBold ? menu.addItem("normal weight", "toggleWeight") : menu.addItem("bold", "toggleWeight"), 
    this.isItalic ? menu.addItem("normal style", "toggleItalic") : menu.addItem("italic", "toggleItalic"), 
    menu;
}, TextMorph.prototype.setAlignmentToLeft = function() {
    this.alignment = "left", this.drawNew(), this.changed();
}, TextMorph.prototype.setAlignmentToRight = function() {
    this.alignment = "right", this.drawNew(), this.changed();
}, TextMorph.prototype.setAlignmentToCenter = function() {
    this.alignment = "center", this.drawNew(), this.changed();
}, TextMorph.prototype.toggleIsDraggable = StringMorph.prototype.toggleIsDraggable, 
TextMorph.prototype.toggleWeight = StringMorph.prototype.toggleWeight, TextMorph.prototype.toggleItalic = StringMorph.prototype.toggleItalic, 
TextMorph.prototype.setSerif = StringMorph.prototype.setSerif, TextMorph.prototype.setSansSerif = StringMorph.prototype.setSansSerif, 
TextMorph.prototype.setText = StringMorph.prototype.setText, TextMorph.prototype.setFontSize = StringMorph.prototype.setFontSize, 
TextMorph.prototype.numericalSetters = StringMorph.prototype.numericalSetters, TextMorph.prototype.evaluationMenu = function() {
    var menu = new MenuMorph(this, null);
    return menu.addItem("do it", "doIt", "evaluate the\nselected expression"), menu.addItem("show it", "showIt", "evaluate the\nselected expression\nand show the result"), 
    menu.addItem("inspect it", "inspectIt", "evaluate the\nselected expression\nand inspect the result"), 
    menu.addLine(), menu.addItem("select all", "selectAllAndEdit"), menu;
}, TextMorph.prototype.setReceiver = function(obj) {
    this.receiver = obj, this.customContextMenu = this.evaluationMenu();
}, TextMorph.prototype.doIt = function() {
    this.receiver.evaluateString(this.selection()), this.edit();
}, TextMorph.prototype.showIt = function() {
    var result = this.receiver.evaluateString(this.selection());
    null !== result && this.inform(result);
}, TextMorph.prototype.inspectIt = function() {
    var inspector, result = this.receiver.evaluateString(this.selection()), world = this.world();
    isObject(result) && ((inspector = new InspectorMorph(result)).setPosition(world.hand.position()), 
    inspector.keepWithin(world), world.add(inspector), inspector.changed());
}, TriggerMorph.prototype = new Morph(), TriggerMorph.prototype.constructor = TriggerMorph, 
TriggerMorph.uber = Morph.prototype;

function TriggerMorph(target, action, labelString, fontSize, fontStyle, environment, hint, labelColor, labelBold, labelItalic, doubleClickAction) {
    this.init(target, action, labelString, fontSize, fontStyle, environment, hint, labelColor, labelBold, labelItalic, doubleClickAction);
}

TriggerMorph.prototype.init = function(target, action, labelString, fontSize, fontStyle, environment, hint, labelColor, labelBold, labelItalic, doubleClickAction) {
    this.target = target || null, this.action = action || null, this.doubleClickAction = doubleClickAction || null, 
    this.environment = environment || null, this.labelString = labelString || null, 
    this.label = null, this.hint = hint || null, this.fontSize = fontSize || MorphicPreferences.menuFontSize, 
    this.fontStyle = fontStyle || "sans-serif", this.highlightColor = new Color(192, 192, 192), 
    this.pressColor = new Color(128, 128, 128), this.labelColor = labelColor || new Color(0, 0, 0), 
    this.labelBold = labelBold || !1, this.labelItalic = labelItalic || !1, TriggerMorph.uber.init.call(this), 
    this.color = new Color(255, 255, 255), this.drawNew();
}, TriggerMorph.prototype.drawNew = function() {
    this.createBackgrounds(), null !== this.labelString && this.createLabel();
}, TriggerMorph.prototype.createBackgrounds = function() {
    var context, ext = this.extent();
    this.normalImage = newCanvas(ext), (context = this.normalImage.getContext("2d")).fillStyle = this.color.toString(), 
    context.fillRect(0, 0, ext.x, ext.y), this.highlightImage = newCanvas(ext), (context = this.highlightImage.getContext("2d")).fillStyle = this.highlightColor.toString(), 
    context.fillRect(0, 0, ext.x, ext.y), this.pressImage = newCanvas(ext), (context = this.pressImage.getContext("2d")).fillStyle = this.pressColor.toString(), 
    context.fillRect(0, 0, ext.x, ext.y), this.image = this.normalImage;
}, TriggerMorph.prototype.createLabel = function() {
    null !== this.label && this.label.destroy(), this.label = new StringMorph(this.labelString, this.fontSize, this.fontStyle, this.labelBold, this.labelItalic, !1, null, null, this.labelColor), 
    this.label.setPosition(this.center().subtract(this.label.extent().floorDivideBy(2))), 
    this.add(this.label);
}, TriggerMorph.prototype.copyRecordingReferences = function(dict) {
    var c = TriggerMorph.uber.copyRecordingReferences.call(this, dict);
    return c.label && dict[this.label] && (c.label = dict[this.label]), c;
}, TriggerMorph.prototype.trigger = function() {
    "function" == typeof this.target ? "function" == typeof this.action ? this.target.call(this.environment, this.action.call(), this) : this.target.call(this.environment, this.action, this) : "function" == typeof this.action ? this.action.call(this.target) : this.target[this.action]();
}, TriggerMorph.prototype.triggerDoubleClick = function() {
    this.doubleClickAction && ("function" == typeof this.target ? "function" == typeof this.doubleClickAction ? this.target.call(this.environment, this.doubleClickAction.call(), this) : this.target.call(this.environment, this.doubleClickAction, this) : "function" == typeof this.doubleClickAction ? this.doubleClickAction.call(this.target) : this.target[this.doubleClickAction]());
}, TriggerMorph.prototype.mouseEnter = function() {
    this.image = this.highlightImage, this.changed(), this.hint && this.bubbleHelp(this.hint);
}, TriggerMorph.prototype.mouseLeave = function() {
    this.image = this.normalImage, this.changed(), this.hint && this.world().hand.destroyTemporaries();
}, TriggerMorph.prototype.mouseDownLeft = function() {
    this.image = this.pressImage, this.changed();
}, TriggerMorph.prototype.mouseClickLeft = function() {
    this.image = this.highlightImage, this.changed(), this.trigger();
}, TriggerMorph.prototype.mouseDoubleClick = function() {
    this.triggerDoubleClick();
}, TriggerMorph.prototype.rootForGrab = function() {
    return this.isDraggable ? TriggerMorph.uber.rootForGrab.call(this) : null;
}, TriggerMorph.prototype.bubbleHelp = function(contents) {
    var myself = this;
    this.fps = 2, this.step = function() {
        this.bounds.containsPoint(this.world().hand.position()) && myself.popUpbubbleHelp(contents), 
        myself.fps = 0, delete myself.step;
    };
}, TriggerMorph.prototype.popUpbubbleHelp = function(contents) {
    new SpeechBubbleMorph(localize(contents), null, null, 1).popUp(this.world(), this.rightCenter().add(new Point(-8, 0)));
};

var MenuItemMorph;

MenuItemMorph.prototype = new TriggerMorph(), MenuItemMorph.prototype.constructor = MenuItemMorph, 
MenuItemMorph.uber = TriggerMorph.prototype;

function MenuItemMorph(target, action, labelString, fontSize, fontStyle, environment, hint, color, bold, italic, doubleClickAction) {
    this.init(target, action, labelString, fontSize, fontStyle, environment, hint, color, bold, italic, doubleClickAction);
}

MenuItemMorph.prototype.createLabel = function() {
    var icon, lbl, np;
    null !== this.label && this.label.destroy(), isString(this.labelString) ? this.label = this.createLabelString(this.labelString) : this.labelString instanceof Array ? (this.label = new Morph(), 
    this.label.alpha = 0, icon = this.createIcon(this.labelString[0]), this.label.add(icon), 
    lbl = this.createLabelString(this.labelString[1]), this.label.add(lbl), lbl.setCenter(icon.center()), 
    lbl.setLeft(icon.right() + 4), this.label.bounds = icon.bounds.merge(lbl.bounds), 
    this.label.drawNew()) : this.label = this.createIcon(this.labelString), this.silentSetExtent(this.label.extent().add(new Point(8, 0))), 
    np = this.position().add(new Point(4, 0)), this.label.bounds = np.extent(this.label.extent()), 
    this.add(this.label);
}, MenuItemMorph.prototype.createIcon = function(source) {
    var src, icon = new Morph();
    return icon.image = source instanceof Morph ? source.fullImage() : source, source instanceof Morph && source.getShadow() && (src = icon.image, 
    icon.image = newCanvas(source.fullBounds().extent().subtract(this.shadowBlur * (useBlurredShadows ? 1 : 2))), 
    icon.image.getContext("2d").drawImage(src, 0, 0)), icon.silentSetWidth(icon.image.width), 
    icon.silentSetHeight(icon.image.height), icon;
}, MenuItemMorph.prototype.createLabelString = function(string) {
    var lbl = new TextMorph(string, this.fontSize, this.fontStyle, this.labelBold, this.labelItalic);
    return lbl.setColor(this.labelColor), lbl;
}, MenuItemMorph.prototype.mouseEnter = function() {
    this.isListItem() || (this.image = this.highlightImage, this.changed()), this.hint && this.bubbleHelp(this.hint);
}, MenuItemMorph.prototype.mouseLeave = function() {
    this.isListItem() || (this.image = this.normalImage, this.changed()), this.hint && this.world().hand.destroyTemporaries();
}, MenuItemMorph.prototype.mouseDownLeft = function(pos) {
    this.isListItem() && (this.parent.unselectAllItems(), this.escalateEvent("mouseDownLeft", pos)), 
    this.image = this.pressImage, this.changed();
}, MenuItemMorph.prototype.mouseMove = function() {
    this.isListItem() && this.escalateEvent("mouseMove");
}, MenuItemMorph.prototype.mouseClickLeft = function() {
    this.isListItem() || (this.parent.destroy(), this.root().activeMenu = null), this.trigger();
}, MenuItemMorph.prototype.isListItem = function() {
    return !!this.parent && this.parent.isListContents;
}, MenuItemMorph.prototype.isSelectedListItem = function() {
    return !!this.isListItem() && this.image === this.pressImage;
}, FrameMorph.prototype = new Morph(), FrameMorph.prototype.constructor = FrameMorph, 
FrameMorph.uber = Morph.prototype;

function FrameMorph(aScrollFrame) {
    this.init(aScrollFrame);
}

FrameMorph.prototype.init = function(aScrollFrame) {
    this.scrollFrame = aScrollFrame || null, FrameMorph.uber.init.call(this), this.color = new Color(255, 250, 245), 
    this.drawNew(), this.acceptsDrops = !0, this.scrollFrame && (this.isDraggable = !1, 
    this.noticesTransparentClick = !1, this.alpha = 0);
}, FrameMorph.prototype.fullBounds = function() {
    var shadow = this.getShadow();
    return null !== shadow ? this.bounds.merge(shadow.bounds) : this.bounds;
}, FrameMorph.prototype.fullImage = function() {
    return this.image;
}, FrameMorph.prototype.fullDrawOn = function(aCanvas, aRect) {
    var rectangle, dirty;
    return this.isVisible ? (rectangle = aRect || this.fullBounds(), (dirty = this.bounds.intersect(rectangle)).extent().gt(new Point(0, 0)) ? (this.drawOn(aCanvas, dirty), 
    void this.children.forEach(function(child) {
        child instanceof ShadowMorph ? child.fullDrawOn(aCanvas, rectangle) : child.fullDrawOn(aCanvas, dirty);
    })) : null) : null;
}, FrameMorph.prototype.moveBy = function(delta) {
    this.changed(), this.bounds = this.bounds.translateBy(delta), this.children.forEach(function(child) {
        child.silentMoveBy(delta);
    }), this.changed();
}, FrameMorph.prototype.submorphBounds = function() {
    var result = null;
    return this.children.length > 0 && (result = this.children[0].bounds, this.children.forEach(function(child) {
        result = result.merge(child.fullBounds());
    })), result;
}, FrameMorph.prototype.keepInScrollFrame = function() {
    if (null === this.scrollFrame) return null;
    this.left() > this.scrollFrame.left() && this.moveBy(new Point(this.scrollFrame.left() - this.left(), 0)), 
    this.right() < this.scrollFrame.right() && this.moveBy(new Point(this.scrollFrame.right() - this.right(), 0)), 
    this.top() > this.scrollFrame.top() && this.moveBy(new Point(0, this.scrollFrame.top() - this.top())), 
    this.bottom() < this.scrollFrame.bottom() && this.moveBy(0, new Point(this.scrollFrame.bottom() - this.bottom(), 0));
}, FrameMorph.prototype.adjustBounds = function() {
    var subBounds, newBounds, myself = this;
    if (null === this.scrollFrame) return null;
    newBounds = (subBounds = this.submorphBounds()) && !this.scrollFrame.isTextLineWrapping ? subBounds.expandBy(this.scrollFrame.padding).growBy(this.scrollFrame.growth).merge(this.scrollFrame.bounds) : this.scrollFrame.bounds.copy(), 
    this.bounds.eq(newBounds) || (this.bounds = newBounds, this.drawNew(), this.keepInScrollFrame()), 
    this.scrollFrame.isTextLineWrapping && this.children.forEach(function(morph) {
        morph instanceof TextMorph && (morph.setWidth(myself.width()), myself.setHeight(Math.max(morph.height(), myself.scrollFrame.height())));
    }), this.scrollFrame.adjustScrollBars();
}, FrameMorph.prototype.reactToDropOf = function() {
    this.adjustBounds();
}, FrameMorph.prototype.reactToGrabOf = function() {
    this.adjustBounds();
}, FrameMorph.prototype.copyRecordingReferences = function(dict) {
    var c = FrameMorph.uber.copyRecordingReferences.call(this, dict);
    return c.frame && dict[this.scrollFrame] && (c.frame = dict[this.scrollFrame]), 
    c;
}, FrameMorph.prototype.developersMenu = function() {
    var menu = FrameMorph.uber.developersMenu.call(this);
    return this.children.length > 0 && (menu.addLine(), menu.addItem("move all inside...", "keepAllSubmorphsWithin", "keep all submorphs\nwithin and visible")), 
    menu;
}, FrameMorph.prototype.keepAllSubmorphsWithin = function() {
    var myself = this;
    this.children.forEach(function(m) {
        m.keepWithin(myself);
    });
}, ScrollFrameMorph.prototype = new FrameMorph(), ScrollFrameMorph.prototype.constructor = ScrollFrameMorph, 
ScrollFrameMorph.uber = FrameMorph.prototype;

function ScrollFrameMorph(scroller, size, sliderColor) {
    this.init(scroller, size, sliderColor);
}

ScrollFrameMorph.prototype.init = function(scroller, size, sliderColor) {
    var myself = this;
    ScrollFrameMorph.uber.init.call(this), this.scrollBarSize = size || MorphicPreferences.scrollBarSize, 
    this.autoScrollTrigger = null, this.isScrollingByDragging = !0, this.hasVelocity = !0, 
    this.padding = 0, this.growth = 0, this.isTextLineWrapping = !1, this.contents = scroller || new FrameMorph(this), 
    this.add(this.contents), this.hBar = new SliderMorph(null, null, null, null, "horizontal", sliderColor), 
    this.hBar.setHeight(this.scrollBarSize), this.hBar.action = function(num) {
        myself.contents.setPosition(new Point(myself.left() - num, myself.contents.position().y));
    }, this.hBar.isDraggable = !1, this.add(this.hBar), this.vBar = new SliderMorph(null, null, null, null, "vertical", sliderColor), 
    this.vBar.setWidth(this.scrollBarSize), this.vBar.action = function(num) {
        myself.contents.setPosition(new Point(myself.contents.position().x, myself.top() - num));
    }, this.vBar.isDraggable = !1, this.add(this.vBar);
}, ScrollFrameMorph.prototype.adjustScrollBars = function() {
    var hWidth = this.width() - this.scrollBarSize, vHeight = this.height() - this.scrollBarSize;
    this.changed(), this.contents.width() > this.width() + MorphicPreferences.scrollBarSize ? (this.hBar.show(), 
    this.hBar.width() !== hWidth && this.hBar.setWidth(hWidth), this.hBar.setPosition(new Point(this.left(), this.bottom() - this.hBar.height())), 
    this.hBar.start = 0, this.hBar.stop = this.contents.width() - this.width(), this.hBar.size = this.width() / this.contents.width() * this.hBar.stop, 
    this.hBar.value = this.left() - this.contents.left(), this.hBar.drawNew()) : this.hBar.hide(), 
    this.contents.height() > this.height() + this.scrollBarSize ? (this.vBar.show(), 
    this.vBar.height() !== vHeight && this.vBar.setHeight(vHeight), this.vBar.setPosition(new Point(this.right() - this.vBar.width(), this.top())), 
    this.vBar.start = 0, this.vBar.stop = this.contents.height() - this.height(), this.vBar.size = this.height() / this.contents.height() * this.vBar.stop, 
    this.vBar.value = this.top() - this.contents.top(), this.vBar.drawNew()) : this.vBar.hide();
}, ScrollFrameMorph.prototype.addContents = function(aMorph) {
    this.contents.add(aMorph), this.contents.adjustBounds();
}, ScrollFrameMorph.prototype.setContents = function(aMorph) {
    this.contents.children.forEach(function(m) {
        m.destroy();
    }), this.contents.children = [], aMorph.setPosition(this.position().add(this.padding + 2)), 
    this.addContents(aMorph);
}, ScrollFrameMorph.prototype.setExtent = function(aPoint) {
    this.isTextLineWrapping && this.contents.setPosition(this.position().copy()), ScrollFrameMorph.uber.setExtent.call(this, aPoint), 
    this.contents.adjustBounds();
}, ScrollFrameMorph.prototype.scrollX = function(steps) {
    var newX, cl = this.contents.left(), l = this.left(), cw = this.contents.width(), r = this.right();
    (newX = cl + steps) + cw < r && (newX = r - cw), newX > l && (newX = l), newX !== cl && this.contents.setLeft(newX);
}, ScrollFrameMorph.prototype.scrollY = function(steps) {
    var newY, ct = this.contents.top(), t = this.top(), ch = this.contents.height(), b = this.bottom();
    (newY = ct + steps) + ch < b && (newY = b - ch), newY > t && (newY = t), newY !== ct && this.contents.setTop(newY);
}, ScrollFrameMorph.prototype.step = function() {
    nop();
}, ScrollFrameMorph.prototype.mouseDownLeft = function(pos) {
    if (!this.isScrollingByDragging) return null;
    var world = this.root(), oldPos = pos, myself = this, deltaX = 0, deltaY = 0;
    this.step = function() {
        var newPos;
        world.hand.mouseButton && 0 === world.hand.children.length && myself.bounds.containsPoint(world.hand.position()) ? (newPos = world.hand.bounds.origin, 
        0 !== (deltaX = newPos.x - oldPos.x) && myself.scrollX(deltaX), 0 !== (deltaY = newPos.y - oldPos.y) && myself.scrollY(deltaY), 
        oldPos = newPos) : myself.hasVelocity ? Math.abs(deltaX) < .5 && Math.abs(deltaY) < .5 ? myself.step = function() {
            nop();
        } : (deltaX *= .8, myself.scrollX(Math.round(deltaX)), deltaY *= .8, myself.scrollY(Math.round(deltaY))) : myself.step = function() {
            nop();
        }, this.adjustScrollBars();
    };
}, ScrollFrameMorph.prototype.startAutoScrolling = function() {
    var hand, inner, pos, myself = this, inset = 3 * MorphicPreferences.scrollBarSize, world = this.world();
    if (!world) return null;
    hand = world.hand, this.autoScrollTrigger || (this.autoScrollTrigger = Date.now()), 
    this.step = function() {
        pos = hand.bounds.origin, inner = myself.bounds.insetBy(inset), myself.bounds.containsPoint(pos) && !inner.containsPoint(pos) && hand.children.length > 0 ? myself.autoScroll(pos) : (myself.step = function() {
            nop();
        }, myself.autoScrollTrigger = null);
    };
}, ScrollFrameMorph.prototype.autoScroll = function(pos) {
    var inset;
    if (Date.now() - this.autoScrollTrigger < 500) return null;
    inset = 3 * MorphicPreferences.scrollBarSize, this.topLeft().extent(new Point(this.width(), inset)).containsPoint(pos) && this.scrollY(inset - (pos.y - this.top())), 
    this.topLeft().extent(new Point(inset, this.height())).containsPoint(pos) && this.scrollX(inset - (pos.x - this.left())), 
    new Point(this.right() - inset, this.top()).extent(new Point(inset, this.height())).containsPoint(pos) && this.scrollX(-(inset - (this.right() - pos.x))), 
    new Point(this.left(), this.bottom() - inset).extent(new Point(this.width(), inset)).containsPoint(pos) && this.scrollY(-(inset - (this.bottom() - pos.y))), 
    this.adjustScrollBars();
}, ScrollFrameMorph.prototype.scrollCursorIntoView = function(morph) {
    var txt = morph.target, offset = txt.position().subtract(this.contents.position()), ft = this.top() + this.padding, fb = this.bottom() - this.padding;
    this.contents.setExtent(txt.extent().add(offset).add(this.padding)), morph.top() < ft ? (this.contents.setTop(this.contents.top() + ft - morph.top()), 
    morph.setTop(ft)) : morph.bottom() > fb && (this.contents.setBottom(this.contents.bottom() + fb - morph.bottom()), 
    morph.setBottom(fb)), this.adjustScrollBars();
}, ScrollFrameMorph.prototype.mouseScroll = function(y, x) {
    y && this.scrollY(y * MorphicPreferences.mouseScrollAmount), x && this.scrollX(x * MorphicPreferences.mouseScrollAmount), 
    this.adjustScrollBars();
}, ScrollFrameMorph.prototype.copyRecordingReferences = function(dict) {
    var c = ScrollFrameMorph.uber.copyRecordingReferences.call(this, dict);
    return c.contents && dict[this.contents] && (c.contents = dict[this.contents]), 
    c.hBar && dict[this.hBar] && (c.hBar = dict[this.hBar], c.hBar.action = function(num) {
        c.contents.setPosition(new Point(c.left() - num, c.contents.position().y));
    }), c.vBar && dict[this.vBar] && (c.vBar = dict[this.vBar], c.vBar.action = function(num) {
        c.contents.setPosition(new Point(c.contents.position().x, c.top() - num));
    }), c;
}, ScrollFrameMorph.prototype.developersMenu = function() {
    var menu = ScrollFrameMorph.uber.developersMenu.call(this);
    return this.isTextLineWrapping ? menu.addItem("auto line wrap off...", "toggleTextLineWrapping", "turn automatic\nline wrapping\noff") : menu.addItem("auto line wrap on...", "toggleTextLineWrapping", "enable automatic\nline wrapping"), 
    menu;
}, ScrollFrameMorph.prototype.toggleTextLineWrapping = function() {
    this.isTextLineWrapping = !this.isTextLineWrapping;
}, ListMorph.prototype = new ScrollFrameMorph(), ListMorph.prototype.constructor = ListMorph, 
ListMorph.uber = ScrollFrameMorph.prototype;

function ListMorph(elements, labelGetter, format, doubleClickAction) {
    this.init(elements || [], labelGetter || function(element) {
        return isString(element) ? element : element.toSource ? element.toSource() : element.toString();
    }, format || [], doubleClickAction);
}

ListMorph.prototype.init = function(elements, labelGetter, format, doubleClickAction) {
    ListMorph.uber.init.call(this), this.contents.acceptsDrops = !1, this.color = new Color(255, 255, 255), 
    this.hBar.alpha = .6, this.vBar.alpha = .6, this.elements = elements || [], this.labelGetter = labelGetter, 
    this.format = format, this.listContents = null, this.selected = null, this.active = null, 
    this.action = null, this.doubleClickAction = doubleClickAction || null, this.acceptsDrops = !1, 
    this.buildListContents();
}, ListMorph.prototype.buildListContents = function() {
    var myself = this;
    this.listContents && this.listContents.destroy(), this.listContents = new MenuMorph(this.select, null, this), 
    0 === this.elements.length && (this.elements = [ "(empty)" ]), this.elements.forEach(function(element) {
        var color = null, bold = !1, italic = !1;
        myself.format.forEach(function(pair) {
            pair[1].call(null, element) && ("bold" === pair[0] ? bold = !0 : "italic" === pair[0] ? italic = !0 : color = pair[0]);
        }), myself.listContents.addItem(myself.labelGetter(element), element, null, color, bold, italic, myself.doubleClickAction);
    }), this.listContents.setPosition(this.contents.position()), this.listContents.isListContents = !0, 
    this.listContents.drawNew(), this.addContents(this.listContents);
}, ListMorph.prototype.select = function(item, trigger) {
    isNil(item) || (this.selected = item, this.active = trigger, this.action && this.action.call(null, item));
}, ListMorph.prototype.setExtent = function(aPoint) {
    var lb = this.listContents.bounds, nb = this.bounds.origin.copy().corner(this.bounds.origin.add(aPoint));
    nb.right() > lb.right() && nb.width() <= lb.width() && this.listContents.setRight(nb.right()), 
    nb.bottom() > lb.bottom() && nb.height() <= lb.height() && this.listContents.setBottom(nb.bottom()), 
    ListMorph.uber.setExtent.call(this, aPoint);
}, StringFieldMorph.prototype = new FrameMorph(), StringFieldMorph.prototype.constructor = StringFieldMorph, 
StringFieldMorph.uber = FrameMorph.prototype;

function StringFieldMorph(defaultContents, minWidth, fontSize, fontStyle, bold, italic, isNumeric) {
    this.init(defaultContents || "", minWidth || 100, fontSize || 12, fontStyle || "sans-serif", bold || !1, italic || !1, isNumeric);
}

StringFieldMorph.prototype.init = function(defaultContents, minWidth, fontSize, fontStyle, bold, italic, isNumeric) {
    this.defaultContents = defaultContents, this.minWidth = minWidth, this.fontSize = fontSize, 
    this.fontStyle = fontStyle, this.isBold = bold, this.isItalic = italic, this.isNumeric = isNumeric || !1, 
    this.text = null, StringFieldMorph.uber.init.call(this), this.color = new Color(255, 255, 255), 
    this.isEditable = !0, this.acceptsDrops = !1, this.drawNew();
}, StringFieldMorph.prototype.drawNew = function() {
    var txt;
    txt = this.text ? this.string() : this.defaultContents, this.text = null, this.children.forEach(function(child) {
        child.destroy();
    }), this.children = [], this.text = new StringMorph(txt, this.fontSize, this.fontStyle, this.isBold, this.isItalic, this.isNumeric), 
    this.text.isNumeric = this.isNumeric, this.text.setPosition(this.bounds.origin.copy()), 
    this.text.isEditable = this.isEditable, this.text.isDraggable = !1, this.text.enableSelecting(), 
    this.silentSetExtent(new Point(Math.max(this.width(), this.minWidth), this.text.height())), 
    StringFieldMorph.uber.drawNew.call(this), this.add(this.text);
}, StringFieldMorph.prototype.string = function() {
    return this.text.text;
}, StringFieldMorph.prototype.mouseClickLeft = function(pos) {
    this.isEditable ? this.text.edit() : this.escalateEvent("mouseClickLeft", pos);
}, StringFieldMorph.prototype.copyRecordingReferences = function(dict) {
    var c = StringFieldMorph.uber.copyRecordingReferences.call(this, dict);
    return c.text && dict[this.text] && (c.text = dict[this.text]), c;
};

var BouncerMorph;

BouncerMorph.prototype = new Morph(), BouncerMorph.prototype.constructor = BouncerMorph, 
BouncerMorph.uber = Morph.prototype;

function BouncerMorph() {
    this.init();
}

BouncerMorph.prototype.init = function(type, speed) {
    BouncerMorph.uber.init.call(this), this.fps = 50, this.isStopped = !1, this.type = type || "vertical", 
    "vertical" === this.type ? this.direction = "down" : this.direction = "right", this.speed = speed || 1;
}, BouncerMorph.prototype.moveUp = function() {
    this.moveBy(new Point(0, -this.speed));
}, BouncerMorph.prototype.moveDown = function() {
    this.moveBy(new Point(0, this.speed));
}, BouncerMorph.prototype.moveRight = function() {
    this.moveBy(new Point(this.speed, 0));
}, BouncerMorph.prototype.moveLeft = function() {
    this.moveBy(new Point(-this.speed, 0));
}, BouncerMorph.prototype.step = function() {
    this.isStopped || ("vertical" === this.type ? ("down" === this.direction ? this.moveDown() : this.moveUp(), 
    this.fullBounds().top() < this.parent.top() && "up" === this.direction && (this.direction = "down"), 
    this.fullBounds().bottom() > this.parent.bottom() && "down" === this.direction && (this.direction = "up")) : "horizontal" === this.type && ("right" === this.direction ? this.moveRight() : this.moveLeft(), 
    this.fullBounds().left() < this.parent.left() && "left" === this.direction && (this.direction = "right"), 
    this.fullBounds().right() > this.parent.right() && "right" === this.direction && (this.direction = "left")));
}, HandMorph.prototype = new Morph(), HandMorph.prototype.constructor = HandMorph, 
HandMorph.uber = Morph.prototype;

function HandMorph(aWorld) {
    this.init(aWorld);
}

HandMorph.prototype.init = function(aWorld) {
    HandMorph.uber.init.call(this), this.bounds = new Rectangle(), this.world = aWorld, 
    this.mouseButton = null, this.mouseOverList = [], this.morphToGrab = null, this.grabOrigin = null, 
    this.temporaries = [], this.touchHoldTimeout = null, this.contextMenuEnabled = !1;
}, HandMorph.prototype.changed = function() {
    null !== this.world && (this.fullBounds().extent().eq(new Point()) || this.world.broken.push(this.fullBounds().spread()));
}, HandMorph.prototype.morphAtPointer = function() {
    var myself = this, result = null;
    return this.world.allChildren().slice(0).reverse().forEach(function(m) {
        !m.visibleBounds().containsPoint(myself.bounds.origin) || null !== result || !m.isVisible || !m.noticesTransparentClick && m.isTransparentAt(myself.bounds.origin) || m instanceof ShadowMorph || !m.allParents().every(function(each) {
            return each.isVisible;
        }) || (result = m);
    }), null !== result ? result : this.world;
}, HandMorph.prototype.allMorphsAtPointer = function() {
    var myself = this;
    return this.world.allChildren().filter(function(m) {
        return m.isVisible && m.visibleBounds().containsPoint(myself.bounds.origin);
    });
}, HandMorph.prototype.dropTargetFor = function(aMorph) {
    for (var target = this.morphAtPointer(); !target.wantsDropOf(aMorph); ) target = target.parent;
    return target;
}, HandMorph.prototype.grab = function(aMorph) {
    var oldParent = aMorph.parent;
    if (aMorph instanceof WorldMorph) return null;
    0 === this.children.length && (this.world.stopEditing(), this.grabOrigin = aMorph.situation(), 
    aMorph.addShadow(), aMorph.prepareToBeGrabbed && aMorph.prepareToBeGrabbed(this), 
    this.add(aMorph), this.changed(), oldParent && oldParent.reactToGrabOf && oldParent.reactToGrabOf(aMorph));
}, HandMorph.prototype.drop = function() {
    var target, morphToDrop;
    0 !== this.children.length && (morphToDrop = this.children[0], target = this.dropTargetFor(morphToDrop), 
    this.changed(), target.add(morphToDrop), morphToDrop.changed(), morphToDrop.removeShadow(), 
    this.children = [], this.setExtent(new Point()), morphToDrop.justDropped && morphToDrop.justDropped(this), 
    target.reactToDropOf && target.reactToDropOf(morphToDrop, this), this.dragOrigin = null);
}, HandMorph.prototype.processMouseDown = function(event) {
    var morph, actualClick;
    if (this.destroyTemporaries(), this.contextMenuEnabled = !0, this.morphToGrab = null, 
    0 !== this.children.length) this.drop(), this.mouseButton = null; else {
        for (morph = this.morphAtPointer(), this.world.activeMenu && (contains(morph.allParents(), this.world.activeMenu) ? clearInterval(this.touchHoldTimeout) : this.world.activeMenu.destroy()), 
        this.world.activeHandle && morph !== this.world.activeHandle && this.world.activeHandle.destroy(), 
        this.world.cursor && morph !== this.world.cursor.target && this.world.stopEditing(), 
        morph.mouseMove || (this.morphToGrab = morph.rootForGrab()), 2 === event.button || event.ctrlKey ? (this.mouseButton = "right", 
        actualClick = "mouseDownRight") : (this.mouseButton = "left", actualClick = "mouseDownLeft"); !morph[actualClick]; ) morph = morph.parent;
        morph[actualClick](this.bounds.origin);
    }
}, HandMorph.prototype.processTouchStart = function(event) {
    var myself = this;
    MorphicPreferences.isTouchDevice = !0, clearInterval(this.touchHoldTimeout), 1 === event.touches.length && (this.touchHoldTimeout = setInterval(function() {
        myself.processMouseDown({
            button: 2
        }), myself.processMouseUp({
            button: 2
        }), event.preventDefault(), clearInterval(myself.touchHoldTimeout);
    }, 400), this.processMouseMove(event.touches[0]), this.processMouseDown({
        button: 0
    }), event.preventDefault());
}, HandMorph.prototype.processTouchMove = function(event) {
    if (MorphicPreferences.isTouchDevice = !0, 1 === event.touches.length) {
        var touch = event.touches[0];
        this.processMouseMove(touch), clearInterval(this.touchHoldTimeout);
    }
}, HandMorph.prototype.processTouchEnd = function(event) {
    MorphicPreferences.isTouchDevice = !0, clearInterval(this.touchHoldTimeout), nop(event), 
    this.processMouseUp({
        button: 0
    });
}, HandMorph.prototype.processMouseUp = function() {
    var context, contextMenu, expectedClick, morph = this.morphAtPointer();
    if (this.destroyTemporaries(), 0 !== this.children.length) this.drop(); else {
        if ("left" === this.mouseButton) expectedClick = "mouseClickLeft"; else if (expectedClick = "mouseClickRight", 
        this.mouseButton && this.contextMenuEnabled) {
            for (contextMenu = (context = morph).contextMenu(); !contextMenu && context.parent; ) contextMenu = (context = context.parent).contextMenu();
            contextMenu && contextMenu.popUpAtHand(this.world);
        }
        for (;!morph[expectedClick]; ) morph = morph.parent;
        morph[expectedClick](this.bounds.origin);
    }
    this.mouseButton = null;
}, HandMorph.prototype.processDoubleClick = function() {
    var morph = this.morphAtPointer();
    if (this.destroyTemporaries(), 0 !== this.children.length) this.drop(); else {
        for (;morph && !morph.mouseDoubleClick; ) morph = morph.parent;
        morph && morph.mouseDoubleClick(this.bounds.origin);
    }
    this.mouseButton = null;
}, HandMorph.prototype.processMouseMove = function(event) {
    var pos, mouseOverNew, morph, topMorph, fb, posInDocument = getDocumentPositionOf(this.world.worldCanvas), myself = this;
    pos = new Point(event.pageX - posInDocument.x, event.pageY - posInDocument.y), this.setPosition(pos), 
    mouseOverNew = this.morphAtPointer().allParents(), !this.children.length && this.mouseButton && (morph = (topMorph = this.morphAtPointer()).rootForGrab(), 
    topMorph.mouseMove && (topMorph.mouseMove(pos, this.mouseButton), "right" === this.mouseButton && (this.contextMenuEnabled = !1)), 
    "left" === this.mouseButton && this.morphToGrab && (this.morphToGrab.isDraggable ? (morph = this.morphToGrab, 
    this.grab(morph)) : this.morphToGrab.isTemplate && ((morph = this.morphToGrab.fullCopy()).isTemplate = !1, 
    morph.isDraggable = !0, this.grab(morph), this.grabOrigin = this.morphToGrab.situation()), 
    morph && ((fb = morph.fullBounds()).containsPoint(pos) || (this.bounds.origin = fb.center(), 
    this.grab(morph), this.setPosition(pos))))), this.mouseOverList.forEach(function(old) {
        contains(mouseOverNew, old) || (old.mouseLeave && old.mouseLeave(), old.mouseLeaveDragging && myself.mouseButton && old.mouseLeaveDragging());
    }), mouseOverNew.forEach(function(newMorph) {
        contains(myself.mouseOverList, newMorph) || (newMorph.mouseEnter && newMorph.mouseEnter(), 
        newMorph.mouseEnterDragging && myself.mouseButton && newMorph.mouseEnterDragging()), 
        myself.children.length > 0 && newMorph instanceof ScrollFrameMorph && (newMorph.bounds.insetBy(3 * MorphicPreferences.scrollBarSize).containsPoint(myself.bounds.origin) || newMorph.startAutoScrolling());
    }), this.mouseOverList = mouseOverNew;
}, HandMorph.prototype.processMouseScroll = function(event) {
    for (var morph = this.morphAtPointer(); morph && !morph.mouseScroll; ) morph = morph.parent;
    morph && morph.mouseScroll(event.detail / -3 || (Object.prototype.hasOwnProperty.call(event, "wheelDeltaY") ? event.wheelDeltaY / 120 : event.wheelDelta / 120), event.wheelDeltaX / 120 || 0);
}, HandMorph.prototype.processDrop = function(event) {
    var file, src, canvas, i, files = event instanceof FileList ? event : event.target.files || event.dataTransfer.files, url = event.dataTransfer ? event.dataTransfer.getData("URL") : null, txt = event.dataTransfer ? event.dataTransfer.getData("Text/HTML") : null, target = this.morphAtPointer(), img = new Image();
    function readSVG(aFile) {
        for (var pic = new Image(), frd = new FileReader(); !target.droppedSVG; ) target = target.parent;
        pic.onload = function() {
            target.droppedSVG(pic, aFile.name);
        }, (frd = new FileReader()).onloadend = function(e) {
            pic.src = e.target.result;
        }, frd.readAsDataURL(aFile);
    }
    function readImage(aFile) {
        for (var pic = new Image(), frd = new FileReader(); !target.droppedImage; ) target = target.parent;
        pic.onload = function() {
            (canvas = newCanvas(new Point(pic.width, pic.height))).getContext("2d").drawImage(pic, 0, 0), 
            target.droppedImage(canvas, aFile.name);
        }, (frd = new FileReader()).onloadend = function(e) {
            pic.src = e.target.result;
        }, frd.readAsDataURL(aFile);
    }
    function readAudio(aFile) {
        for (var snd = new Audio(), frd = new FileReader(); !target.droppedAudio; ) target = target.parent;
        frd.onloadend = function(e) {
            snd.src = e.target.result, target.droppedAudio(snd, aFile.name);
        }, frd.readAsDataURL(aFile);
    }
    function readText(aFile) {
        for (var frd = new FileReader(); !target.droppedText; ) target = target.parent;
        frd.onloadend = function(e) {
            target.droppedText(e.target.result, aFile.name);
        }, frd.readAsText(aFile);
    }
    function readBinary(aFile) {
        for (var frd = new FileReader(); !target.droppedBinary; ) target = target.parent;
        frd.onloadend = function(e) {
            target.droppedBinary(e.target.result, aFile.name);
        }, frd.readAsArrayBuffer(aFile);
    }
    if (files.length > 0) for (i = 0; i < files.length; i += 1) -1 === (file = files[i]).type.indexOf("svg") || MorphicPreferences.rasterizeSVGs ? 0 === file.type.indexOf("image") ? readImage(file) : 0 === file.type.indexOf("audio") ? readAudio(file) : 0 === file.type.indexOf("text") ? readText(file) : readBinary(file) : readSVG(file); else if (url) {
        if (contains([ "gif", "png", "jpg", "jpeg", "bmp" ], url.slice(url.lastIndexOf(".") + 1).toLowerCase())) {
            for (;!target.droppedImage; ) target = target.parent;
            (img = new Image()).onload = function() {
                (canvas = newCanvas(new Point(img.width, img.height))).getContext("2d").drawImage(img, 0, 0), 
                target.droppedImage(canvas);
            }, img.src = url;
        }
    } else if (txt) {
        for (;!target.droppedImage; ) target = target.parent;
        (img = new Image()).onload = function() {
            (canvas = newCanvas(new Point(img.width, img.height))).getContext("2d").drawImage(img, 0, 0), 
            target.droppedImage(canvas);
        }, (src = function(html) {
            var idx, c, iurl = "", start = html.indexOf('<img src="');
            if (-1 === start) return null;
            for (idx = start += 10; idx < html.length; idx += 1) {
                if ('"' === (c = html[idx])) return iurl;
                iurl = iurl.concat(c);
            }
            return null;
        }(txt)) && (img.src = src);
    }
}, HandMorph.prototype.destroyTemporaries = function() {
    var myself = this;
    this.temporaries.forEach(function(morph) {
        morph.isClickable && morph.bounds.containsPoint(myself.position()) || (morph.destroy(), 
        myself.temporaries.splice(myself.temporaries.indexOf(morph), 1));
    });
}, HandMorph.prototype.moveBy = function(delta) {
    Morph.prototype.trackChanges = !1, HandMorph.uber.moveBy.call(this, delta), Morph.prototype.trackChanges = !0, 
    this.fullChanged();
}, WorldMorph.prototype = new FrameMorph(), WorldMorph.prototype.constructor = WorldMorph, 
WorldMorph.uber = FrameMorph.prototype;

function WorldMorph(aCanvas, fillPage) {
    this.init(aCanvas, fillPage);
}

WorldMorph.prototype.init = function(aCanvas, fillPage) {
    for (WorldMorph.uber.init.call(this), this.color = new Color(205, 205, 205), this.alpha = 1, 
    this.bounds = new Rectangle(0, 0, aCanvas.width, aCanvas.height), this.drawNew(), 
    this.isVisible = !0, this.isDraggable = !1, this.currentKey = null, this.worldCanvas = aCanvas, 
    this.stamp = Date.now(); this.stamp === Date.now(); ) nop();
    this.stamp = Date.now(), this.useFillPage = fillPage, void 0 === this.useFillPage && (this.useFillPage = !0), 
    this.isDevMode = !1, this.broken = [], this.hand = new HandMorph(this), this.keyboardReceiver = null, 
    this.lastEditedText = null, this.cursor = null, this.activeMenu = null, this.activeHandle = null, 
    this.virtualKeyboard = null, this.initEventListeners();
}, WorldMorph.prototype.brokenFor = function(aMorph) {
    var fb = aMorph.fullBounds();
    return this.broken.filter(function(rect) {
        return rect.intersects(fb);
    });
}, WorldMorph.prototype.fullDrawOn = function(aCanvas, aRect) {
    WorldMorph.uber.fullDrawOn.call(this, aCanvas, aRect), this.hand.fullDrawOn(aCanvas, aRect);
}, WorldMorph.prototype.updateBroken = function() {
    var myself = this;
    this.condenseDamages(), this.broken.forEach(function(rect) {
        rect.extent().gt(new Point(0, 0)) && myself.fullDrawOn(myself.worldCanvas, rect);
    }), this.broken = [];
}, WorldMorph.prototype.condenseDamages = function() {
    function condense(src) {
        var hit, trgt = [];
        return src.forEach(function(rect) {
            (hit = detect(trgt, function(each) {
                return each.isNearTo(rect, 20);
            })) ? hit.mergeWith(rect) : trgt.push(rect);
        }), trgt;
    }
    for (var again = !0, size = this.broken.length; again; ) this.broken = condense(this.broken), 
    again = this.broken.length < size, size = this.broken.length;
}, WorldMorph.prototype.doOneCycle = function() {
    this.stepFrame(), this.updateBroken();
}, WorldMorph.prototype.fillPage = function() {
    var pos = getDocumentPositionOf(this.worldCanvas), clientHeight = window.innerHeight, clientWidth = window.innerWidth, myself = this;
    pos.x > 0 && (this.worldCanvas.style.position = "absolute", this.worldCanvas.style.left = "0px", 
    pos.x = 0), pos.y > 0 && (this.worldCanvas.style.position = "absolute", this.worldCanvas.style.top = "0px", 
    pos.y = 0), document.documentElement.scrollTop && (clientHeight = document.documentElement.clientHeight), 
    document.documentElement.scrollLeft && (clientWidth = document.documentElement.clientWidth), 
    this.worldCanvas.width !== clientWidth && (this.worldCanvas.width = clientWidth, 
    this.setWidth(clientWidth)), this.worldCanvas.height !== clientHeight && (this.worldCanvas.height = clientHeight, 
    this.setHeight(clientHeight)), this.children.forEach(function(child) {
        child.reactToWorldResize && child.reactToWorldResize(myself.bounds.copy());
    });
}, WorldMorph.prototype.getGlobalPixelColor = function(point) {
    var dta = this.worldCanvas.getContext("2d").getImageData(point.x, point.y, 1, 1).data;
    return new Color(dta[0], dta[1], dta[2]);
}, WorldMorph.prototype.initVirtualKeyboard = function() {
    var myself = this;
    this.virtualKeyboard && (document.body.removeChild(this.virtualKeyboard), this.virtualKeyboard = null), 
    MorphicPreferences.isTouchDevice && MorphicPreferences.useVirtualKeyboard && (this.virtualKeyboard = document.createElement("input"), 
    this.virtualKeyboard.type = "text", this.virtualKeyboard.style.color = "transparent", 
    this.virtualKeyboard.style.backgroundColor = "transparent", this.virtualKeyboard.style.border = "none", 
    this.virtualKeyboard.style.outline = "none", this.virtualKeyboard.style.position = "absolute", 
    this.virtualKeyboard.style.top = "0px", this.virtualKeyboard.style.left = "0px", 
    this.virtualKeyboard.style.width = "0px", this.virtualKeyboard.style.height = "0px", 
    this.virtualKeyboard.autocapitalize = "none", document.body.appendChild(this.virtualKeyboard), 
    this.virtualKeyboard.addEventListener("keydown", function(event) {
        myself.currentKey = event.keyCode, myself.keyboardReceiver && myself.keyboardReceiver.processKeyDown(event), 
        "U+0008" !== event.keyIdentifier && "Backspace" !== event.keyIdentifier || event.preventDefault(), 
        "U+0009" !== event.keyIdentifier && "Tab" !== event.keyIdentifier || (myself.keyboardReceiver && myself.keyboardReceiver.processKeyPress(event), 
        event.preventDefault());
    }, !1), this.virtualKeyboard.addEventListener("keyup", function(event) {
        myself.currentKey = null, myself.keyboardReceiver && myself.keyboardReceiver.processKeyUp && myself.keyboardReceiver.processKeyUp(event), 
        event.preventDefault();
    }, !1), this.virtualKeyboard.addEventListener("keypress", function(event) {
        myself.keyboardReceiver && myself.keyboardReceiver.processKeyPress(event), event.preventDefault();
    }, !1));
}, WorldMorph.prototype.initEventListeners = function() {
    var canvas = this.worldCanvas, myself = this;
    myself.useFillPage ? myself.fillPage() : this.changed(), canvas.addEventListener("mousedown", function(event) {
        event.preventDefault(), canvas.focus(), myself.hand.processMouseDown(event);
    }, !1), canvas.addEventListener("touchstart", function(event) {
        myself.hand.processTouchStart(event);
    }, !1), canvas.addEventListener("mouseup", function(event) {
        event.preventDefault(), myself.hand.processMouseUp(event);
    }, !1), canvas.addEventListener("dblclick", function(event) {
        event.preventDefault(), myself.hand.processDoubleClick(event);
    }, !1), canvas.addEventListener("touchend", function(event) {
        myself.hand.processTouchEnd(event);
    }, !1), canvas.addEventListener("mousemove", function(event) {
        myself.hand.processMouseMove(event);
    }, !1), canvas.addEventListener("touchmove", function(event) {
        myself.hand.processTouchMove(event);
    }, !1), canvas.addEventListener("contextmenu", function(event) {
        event.preventDefault();
    }, !1), canvas.addEventListener("keydown", function(event) {
        myself.currentKey = event.keyCode, myself.keyboardReceiver && myself.keyboardReceiver.processKeyDown(event), 
        "U+0008" !== event.keyIdentifier && "Backspace" !== event.keyIdentifier || event.preventDefault(), 
        "U+0009" !== event.keyIdentifier && "Tab" !== event.keyIdentifier || (myself.keyboardReceiver && myself.keyboardReceiver.processKeyPress(event), 
        event.preventDefault()), (event.ctrlKey || event.metaKey) && "U+0056" !== event.keyIdentifier && event.preventDefault();
    }, !1), canvas.addEventListener("keyup", function(event) {
        myself.currentKey = null, myself.keyboardReceiver && myself.keyboardReceiver.processKeyUp && myself.keyboardReceiver.processKeyUp(event), 
        event.preventDefault();
    }, !1), canvas.addEventListener("keypress", function(event) {
        myself.keyboardReceiver && myself.keyboardReceiver.processKeyPress(event), event.preventDefault();
    }, !1), canvas.addEventListener("mousewheel", function(event) {
        myself.hand.processMouseScroll(event), event.preventDefault();
    }, !1), canvas.addEventListener("DOMMouseScroll", function(event) {
        myself.hand.processMouseScroll(event), event.preventDefault();
    }, !1), document.body.addEventListener("paste", function(event) {
        var txt = event.clipboardData.getData("Text");
        txt && myself.cursor && myself.cursor.insert(txt);
    }, !1), window.addEventListener("dragover", function(event) {
        event.preventDefault();
    }, !1), window.addEventListener("drop", function(event) {
        myself.hand.processDrop(event), event.preventDefault();
    }, !1), window.addEventListener("resize", function() {
        myself.useFillPage && myself.fillPage();
    }, !1);
}, WorldMorph.prototype.mouseDownLeft = function() {
    nop();
}, WorldMorph.prototype.mouseClickLeft = function() {
    nop();
}, WorldMorph.prototype.mouseDownRight = function() {
    nop();
}, WorldMorph.prototype.mouseClickRight = function() {
    nop();
}, WorldMorph.prototype.wantsDropOf = function() {
    return this.acceptsDrops;
}, WorldMorph.prototype.droppedImage = function() {
    return null;
}, WorldMorph.prototype.droppedSVG = function() {
    return null;
}, WorldMorph.prototype.nextTab = function(editField) {
    var next = this.nextEntryField(editField);
    next && (editField.clearSelection(), next.selectAll(), next.edit());
}, WorldMorph.prototype.previousTab = function(editField) {
    var prev = this.previousEntryField(editField);
    prev && (editField.clearSelection(), prev.selectAll(), prev.edit());
}, WorldMorph.prototype.contextMenu = function() {
    var menu;
    return menu = this.isDevMode ? new MenuMorph(this, this.constructor.name || this.constructor.toString().split(" ")[1].split("(")[0]) : new MenuMorph(this, "Morphic"), 
    this.isDevMode && (menu.addItem("demo...", "userCreateMorph", "sample morphs"), 
    menu.addLine(), menu.addItem("hide all...", "hideAll"), menu.addItem("show all...", "showAllHiddens"), 
    menu.addItem("move all inside...", "keepAllSubmorphsWithin", "keep all submorphs\nwithin and visible"), 
    menu.addItem("inspect...", "inspect", "open a window on\nall properties"), menu.addLine(), 
    menu.addItem("restore display", "changed", "redraw the\nscreen once"), menu.addItem("fill page...", "fillPage", "let the World automatically\nadjust to browser resizings"), 
    useBlurredShadows ? menu.addItem("sharp shadows...", "toggleBlurredShadows", "sharp drop shadows\nuse for old browsers") : menu.addItem("blurred shadows...", "toggleBlurredShadows", "blurry shades,\n use for new browsers"), 
    menu.addItem("color...", function() {
        this.pickColor(menu.title + "\ncolor:", this.setColor, this, this.color);
    }, "choose the World's\nbackground color"), MorphicPreferences === standardSettings ? menu.addItem("touch screen settings", "togglePreferences", "bigger menu fonts\nand sliders") : menu.addItem("standard settings", "togglePreferences", "smaller menu fonts\nand sliders"), 
    menu.addLine()), this.isDevMode ? menu.addItem("user mode...", "toggleDevMode", "disable developers'\ncontext menus") : menu.addItem("development mode...", "toggleDevMode"), 
    menu.addItem("about morphic.js...", "about"), menu;
}, WorldMorph.prototype.userCreateMorph = function() {
    var menu, newMorph, myself = this;
    function create(aMorph) {
        aMorph.isDraggable = !0, aMorph.pickUp(myself);
    }
    (menu = new MenuMorph(this, "make a morph")).addItem("rectangle", function() {
        create(new Morph());
    }), menu.addItem("box", function() {
        create(new BoxMorph());
    }), menu.addItem("circle box", function() {
        create(new CircleBoxMorph());
    }), menu.addLine(), menu.addItem("slider", function() {
        create(new SliderMorph());
    }), menu.addItem("frame", function() {
        (newMorph = new FrameMorph()).setExtent(new Point(350, 250)), create(newMorph);
    }), menu.addItem("scroll frame", function() {
        (newMorph = new ScrollFrameMorph()).contents.acceptsDrops = !0, newMorph.contents.adjustBounds(), 
        newMorph.setExtent(new Point(350, 250)), create(newMorph);
    }), menu.addItem("handle", function() {
        create(new HandleMorph());
    }), menu.addLine(), menu.addItem("string", function() {
        (newMorph = new StringMorph("Hello, World!")).isEditable = !0, create(newMorph);
    }), menu.addItem("text", function() {
        (newMorph = new TextMorph("Ich weiß nicht, was soll es bedeuten, dass ich so traurig bin, ein Märchen aus uralten Zeiten, das kommt mir nicht aus dem Sinn. Die Luft ist kühl und es dunkelt, und ruhig fließt der Rhein; der Gipfel des Berges funkelt im Abendsonnenschein. Die schönste Jungfrau sitzet dort oben wunderbar, ihr gold'nes Geschmeide blitzet, sie kämmt ihr goldenes Haar, sie kämmt es mit goldenem Kamme, und singt ein Lied dabei; das hat eine wundersame, gewalt'ge Melodei. Den Schiffer im kleinen Schiffe, ergreift es mit wildem Weh; er schaut nicht die Felsenriffe, er schaut nur hinauf in die Höh'. Ich glaube, die Wellen verschlingen am Ende Schiffer und Kahn, und das hat mit ihrem Singen, die Loreley getan.")).isEditable = !0, 
        newMorph.maxWidth = 300, newMorph.drawNew(), create(newMorph);
    }), menu.addItem("speech bubble", function() {
        create(newMorph = new SpeechBubbleMorph("Hello, World!"));
    }), menu.addLine(), menu.addItem("gray scale palette", function() {
        create(new GrayPaletteMorph());
    }), menu.addItem("color palette", function() {
        create(new ColorPaletteMorph());
    }), menu.addItem("color picker", function() {
        create(new ColorPickerMorph());
    }), menu.addLine(), menu.addItem("sensor demo", function() {
        (newMorph = new MouseSensorMorph()).setColor(new Color(230, 200, 100)), newMorph.edge = 35, 
        newMorph.border = 15, newMorph.borderColor = new Color(200, 100, 50), newMorph.alpha = .2, 
        newMorph.setExtent(new Point(100, 100)), create(newMorph);
    }), menu.addItem("animation demo", function() {
        var foo, bar, baz, garply, fred;
        (foo = new BouncerMorph()).setPosition(new Point(50, 20)), foo.setExtent(new Point(300, 200)), 
        foo.alpha = .9, foo.speed = 3, (bar = new BouncerMorph()).setColor(new Color(50, 50, 50)), 
        bar.setPosition(new Point(80, 80)), bar.setExtent(new Point(80, 250)), bar.type = "horizontal", 
        bar.direction = "right", bar.alpha = .9, bar.speed = 5, (baz = new BouncerMorph()).setColor(new Color(20, 20, 20)), 
        baz.setPosition(new Point(90, 140)), baz.setExtent(new Point(40, 30)), baz.type = "horizontal", 
        baz.direction = "right", baz.speed = 3, (garply = new BouncerMorph()).setColor(new Color(200, 20, 20)), 
        garply.setPosition(new Point(90, 140)), garply.setExtent(new Point(20, 20)), garply.type = "vertical", 
        garply.direction = "up", garply.speed = 8, (fred = new BouncerMorph()).setColor(new Color(20, 200, 20)), 
        fred.setPosition(new Point(120, 140)), fred.setExtent(new Point(20, 20)), fred.type = "vertical", 
        fred.direction = "down", fred.speed = 4, bar.add(garply), bar.add(baz), foo.add(fred), 
        foo.add(bar), create(foo);
    }), menu.addItem("pen", function() {
        create(new PenMorph());
    }), myself.customMorphs && (menu.addLine(), myself.customMorphs().forEach(function(morph) {
        menu.addItem(morph.toString(), function() {
            create(morph);
        });
    })), menu.popUpAtHand(this);
}, WorldMorph.prototype.toggleDevMode = function() {
    this.isDevMode = !this.isDevMode;
}, WorldMorph.prototype.hideAll = function() {
    this.children.forEach(function(child) {
        child.hide();
    });
}, WorldMorph.prototype.showAllHiddens = function() {
    this.forAllChildren(function(child) {
        child.isVisible || child.show();
    });
}, WorldMorph.prototype.about = function() {
    var module, versions = "";
    for (module in modules) Object.prototype.hasOwnProperty.call(modules, module) && (versions += "\n" + module + " (" + modules[module] + ")");
    "" !== versions && (versions = "\n\nmodules:\n\nmorphic (" + morphicVersion + ")" + versions), 
    this.inform("morphic.js\n\na lively Web GUI\ninspired by Squeak\n" + morphicVersion + "\n\nwritten by Jens Mönig\njens@moenig.org" + versions);
}, WorldMorph.prototype.edit = function(aStringOrTextMorph) {
    var pos = getDocumentPositionOf(this.worldCanvas);
    if (!aStringOrTextMorph.isEditable) return null;
    this.cursor && this.cursor.destroy(), this.lastEditedText && this.lastEditedText.clearSelection(), 
    this.cursor = new CursorMorph(aStringOrTextMorph), aStringOrTextMorph.parent.add(this.cursor), 
    this.keyboardReceiver = this.cursor, this.initVirtualKeyboard(), MorphicPreferences.isTouchDevice && MorphicPreferences.useVirtualKeyboard && (this.virtualKeyboard.style.top = this.cursor.top() + pos.y + "px", 
    this.virtualKeyboard.style.left = this.cursor.left() + pos.x + "px", this.virtualKeyboard.focus()), 
    MorphicPreferences.useSliderForInput && (aStringOrTextMorph.parentThatIsA(MenuMorph) || this.slide(aStringOrTextMorph));
}, WorldMorph.prototype.slide = function(aStringOrTextMorph) {
    var menu, slider, val = parseFloat(aStringOrTextMorph.text);
    isNaN(val) && (val = 0), menu = new MenuMorph(), (slider = new SliderMorph(val - 25, val + 25, val, 10, "horizontal")).alpha = 1, 
    slider.color = new Color(225, 225, 225), slider.button.color = menu.borderColor, 
    slider.button.highlightColor = slider.button.color.copy(), slider.button.highlightColor.b += 100, 
    slider.button.pressColor = slider.button.color.copy(), slider.button.pressColor.b += 150, 
    slider.silentSetHeight(MorphicPreferences.scrollBarSize), slider.silentSetWidth(10 * MorphicPreferences.menuFontSize), 
    slider.drawNew(), slider.action = function(num) {
        aStringOrTextMorph.changed(), aStringOrTextMorph.text = Math.round(num).toString(), 
        aStringOrTextMorph.drawNew(), aStringOrTextMorph.changed(), aStringOrTextMorph.escalateEvent("reactToSliderEdit", aStringOrTextMorph);
    }, menu.items.push(slider), menu.popup(this, aStringOrTextMorph.bottomLeft().add(new Point(0, 5)));
}, WorldMorph.prototype.stopEditing = function() {
    this.cursor && (this.lastEditedText = this.cursor.target, this.cursor.destroy(), 
    this.cursor = null, this.lastEditedText.escalateEvent("reactToEdit", this.lastEditedText)), 
    this.keyboardReceiver = null, this.virtualKeyboard && (this.virtualKeyboard.blur(), 
    document.body.removeChild(this.virtualKeyboard), this.virtualKeyboard = null), this.worldCanvas.focus();
}, WorldMorph.prototype.toggleBlurredShadows = function() {
    useBlurredShadows = !useBlurredShadows;
}, WorldMorph.prototype.togglePreferences = function() {
    MorphicPreferences = MorphicPreferences === standardSettings ? touchScreenSettings : standardSettings;
}, modules.locale = "2015-January-21";

var Localizer, SnapTranslator = new Localizer();

function localize(string) {
    return SnapTranslator.translate(string);
}

function Localizer(language, dict) {
    this.language = language || "en", this.dict = dict || {};
}

Localizer.prototype.translate = function(string) {
    return Object.prototype.hasOwnProperty.call(this.dict[this.language], string) ? this.dict[this.language][string] : string;
}, Localizer.prototype.languages = function() {
    var property, arr = [];
    for (property in this.dict) Object.prototype.hasOwnProperty.call(this.dict, property) && arr.push(property);
    return arr.sort();
}, Localizer.prototype.languageName = function(lang) {
    return this.dict[lang].language_name || lang;
}, Localizer.prototype.credits = function() {
    var txt = "", myself = this;
    return this.languages().forEach(function(lang) {
        txt = txt + "\n" + myself.languageName(lang) + " (" + lang + ") - " + myself.dict[lang].language_translator + " - " + myself.dict[lang].last_changed;
    }), txt;
}, Localizer.prototype.unload = function() {
    var dict, keep = [ "language_name", "language_translator", "last_changed" ], myself = this;
    this.languages().forEach(function(lang) {
        var key;
        if ("en" !== lang) {
            dict = myself.dict[lang];
            for (key in dict) Object.prototype.hasOwnProperty.call(dict, key) && !contains(keep, key) && delete dict[key];
        }
    });
}, SnapTranslator.dict.en = {
    language_name: "English",
    language_translator: "Jens Mönig",
    "translator_e-mail": "jens@moenig.org",
    last_changed: "2012-10-16",
    "file menu import hint": "load an exported project file\nor block library, a costume\nor a sound",
    "settings menu prefer empty slots hint": "check to focus on empty slots\nwhen dragging & dropping reporters",
    "costumes tab help": "import a picture from another web page or from\na file on your computer by dropping it here\n",
    "block deletion dialog text": "Are you sure you want to delete this\ncustom block and all its instances?"
}, SnapTranslator.dict.de = {
    language_name: "Deutsch",
    language_translator: "Jens Mönig",
    "translator_e-mail": "jens@moenig.org",
    last_changed: "2014-07-29"
}, SnapTranslator.dict.it = {
    language_name: "Italiano",
    language_translator: "Stefano Federici, Alberto Firpo",
    "translator_e-mail": "s_federici@yahoo.com, albertofirpo12@gmail.com",
    last_changed: "2015-01-12"
}, SnapTranslator.dict.ja = {
    language_name: "日本語",
    language_translator: "Kazuhiro Abe",
    "translator_e-mail": "abee@squeakland.jp",
    last_changed: "2012-04-02"
}, SnapTranslator.dict["ja-hira"] = {
    language_name: "にほんご",
    language_translator: "Kazuhiro Abe",
    "translator_e-mail": "abee@squeakland.jp",
    last_changed: "2012-04-02"
}, SnapTranslator.dict.ko = {
    language_name: "한국어",
    language_translator: "Yunjae Jang",
    "translator_e-mail": "janggoons@gmail.com",
    last_changed: "2015-01-21"
}, SnapTranslator.dict.pt = {
    language_name: "Português",
    language_translator: "Manuel Menezes de Sequeira",
    "translator_e-mail": "mmsequeira@gmail.com",
    last_changed: "2014-10-01"
}, SnapTranslator.dict.cs = {
    language_name: "Česky",
    language_translator: "Michal Moc",
    "translator_e-mail": "info@iguru.eu",
    last_changed: "2013-03-11"
}, SnapTranslator.dict.zh = {
    language_name: "简体中文",
    language_translator: "邓江华",
    "translator_e-mail": "djh@rhjxx.cn",
    last_changed: "2013-03-25"
}, SnapTranslator.dict.eo = {
    language_name: "Esperanto",
    language_translator: "Sebastian Cyprych",
    "translator_e-mail": "scy(ĉe)epf.pl",
    last_changed: "2012-11-11"
}, SnapTranslator.dict.fr = {
    language_name: "Français",
    language_translator: "Jean-Jacques Valliet, Mark Rafter, Martin Quinson",
    "translator_e-mail": "i.scool@mac.com",
    last_changed: "2014-02-04"
}, SnapTranslator.dict.si = {
    language_name: "Slovenščina",
    language_translator: "Sasa Divjak",
    "translator_e-mail": "sasa.divjak@fri.uni-lj.si",
    last_changed: "2013-01-07"
}, SnapTranslator.dict.ru = {
    language_name: "Русский",
    language_translator: "Svetlana Ptashnaya",
    "translator_e-mail": "svetlanap@berkeley.edu",
    last_changed: "2014-09-29"
}, SnapTranslator.dict.es = {
    language_name: "Español",
    language_translator: "Víctor Manuel Muratalla Morales",
    "translator_e-mail": "victor.muratalla@yahoo.com",
    last_changed: "2013-03-25"
}, SnapTranslator.dict.nl = {
    language_name: "Nederlands",
    language_translator: "Frank Sierens, Sjoerd Dirk Meijer",
    "translator_e-mail": "frank.sierens@telenet.be, sjoerddirk@fromScratchEd.nl",
    last_changed: "2013-08-12"
}, SnapTranslator.dict.pl = {
    language_name: "Polski",
    language_translator: "Witek Kranas",
    "translator_e-mail": "witek@oeiizk.waw.pl",
    last_changed: "2013-08-05"
}, SnapTranslator.dict.tw = {
    language_name: "繁體中文",
    language_translator: "cch",
    "translator_e-mail": "cchuang2009@gmail.com",
    last_changed: "2013-8-14"
}, SnapTranslator.dict.no = {
    language_name: "Norsk",
    language_translator: "Olav A Marschall",
    "translator_e-mail": "mattebananer@gmail.com",
    last_changed: "2013-09-16"
}, SnapTranslator.dict.dk = {
    language_name: "Dansk",
    language_translator: "FAB",
    "translator_e-mail": "fab@nielsen.mail.dk",
    last_changed: "2013-09-16"
}, SnapTranslator.dict.el = {
    language_name: "Ελληνικά",
    language_translator: "Ino Samaras",
    "translator_e-mail": "ino.samaras@berkeley.edu",
    last_changed: "2013-09-16"
}, SnapTranslator.dict.ca = {
    language_name: "Català",
    language_translator: "Bernat Romagosa Carrasquer",
    "translator_e-mail": "bromagosa@citilab.eu",
    last_changed: "2015-01-21"
}, SnapTranslator.dict.fi = {
    language_name: "suomi",
    language_translator: "Jouni K. Seppänen",
    "translator_e-mail": "jks@iki.fi",
    last_changed: "2014-04-18"
}, SnapTranslator.dict.sv = {
    language_name: "svenska",
    language_translator: "Erik A. Olsson",
    "translator_e-mail": "eolsson@gmail.com",
    last_changed: "2014-12-14"
}, SnapTranslator.dict["pt-br"] = {
    language_name: "Português do Brasil",
    language_translator: "Aldo von Wangenheim",
    "translator_e-mail": "awangenh@inf.ufsc.br",
    last_changed: "2014-04-20"
}, SnapTranslator.dict.bn = {
    language_name: "বাংলা",
    language_translator: "Dr. Mokter Hossain",
    "translator_e-mail": "mokter@gmail.com",
    last_changed: "2014-07-02"
}, SnapTranslator.dict.kn = {
    language_name: "ಕನ್ನಡ",
    language_translator: "Vinayakumar R",
    "translator_e-mail": "vnkmr7620@gmail.com",
    last_changed: "2014-12-02"
}, modules.widgets = "2014-February-13";

var PushButtonMorph, ToggleButtonMorph, TabMorph, ToggleMorph, ToggleElementMorph, DialogBoxMorph, AlignmentMorph, InputFieldMorph;

PushButtonMorph.prototype = new TriggerMorph(), PushButtonMorph.prototype.constructor = PushButtonMorph, 
PushButtonMorph.uber = TriggerMorph.prototype, PushButtonMorph.prototype.fontSize = 10, 
PushButtonMorph.prototype.fontStyle = "sans-serif", PushButtonMorph.prototype.labelColor = new Color(0, 0, 0), 
PushButtonMorph.prototype.labelShadowColor = new Color(255, 255, 255), PushButtonMorph.prototype.labelShadowOffset = new Point(1, 1), 
PushButtonMorph.prototype.color = new Color(220, 220, 220), PushButtonMorph.prototype.pressColor = new Color(115, 180, 240), 
PushButtonMorph.prototype.highlightColor = PushButtonMorph.prototype.pressColor.lighter(50), 
PushButtonMorph.prototype.outlineColor = new Color(30, 30, 30), PushButtonMorph.prototype.outlineGradient = !1, 
PushButtonMorph.prototype.contrast = 60, PushButtonMorph.prototype.edge = 2, PushButtonMorph.prototype.corner = 5, 
PushButtonMorph.prototype.outline = 1.00001, PushButtonMorph.prototype.padding = 3;

function PushButtonMorph(target, action, labelString, environment, hint, template) {
    this.init(target, action, labelString, environment, hint, template);
}

PushButtonMorph.prototype.init = function(target, action, labelString, environment, hint, template) {
    this.is3D = !1, this.target = target || null, this.action = action || null, this.environment = environment || null, 
    this.labelString = labelString || null, this.label = null, this.labelMinExtent = new Point(0, 0), 
    this.hint = hint || null, this.template = template || null, TriggerMorph.uber.init.call(this), 
    this.color = PushButtonMorph.prototype.color, this.drawNew(), this.fixLayout();
}, PushButtonMorph.prototype.fixLayout = function() {
    if (null !== this.label) {
        var padding = 2 * this.padding + 2 * this.outline + 2 * this.edge;
        this.setExtent(new Point(Math.max(this.label.width(), this.labelMinExtent.x) + padding, Math.max(this.label instanceof StringMorph ? this.label.rawHeight() : this.label.height(), this.labelMinExtent.y) + padding)), 
        this.label.setCenter(this.center());
    }
}, PushButtonMorph.prototype.mouseDownLeft = function() {
    PushButtonMorph.uber.mouseDownLeft.call(this), this.label && this.label.setCenter(this.center().add(1));
}, PushButtonMorph.prototype.mouseClickLeft = function() {
    PushButtonMorph.uber.mouseClickLeft.call(this), this.label && this.label.setCenter(this.center());
}, PushButtonMorph.prototype.mouseLeave = function() {
    PushButtonMorph.uber.mouseLeave.call(this), this.label && this.label.setCenter(this.center());
}, PushButtonMorph.prototype.outlinePath = BoxMorph.prototype.outlinePath, PushButtonMorph.prototype.drawOutline = function(context) {
    var outlineStyle, isFlat = MorphicPreferences.isFlat && !this.is3D;
    if (!this.outline || isFlat) return null;
    this.outlineGradient ? ((outlineStyle = context.createLinearGradient(0, 0, 0, this.height())).addColorStop(1, "white"), 
    outlineStyle.addColorStop(0, this.outlineColor.darker().toString())) : outlineStyle = this.outlineColor.toString(), 
    context.fillStyle = outlineStyle, context.beginPath(), this.outlinePath(context, isFlat ? 0 : this.corner, 0), 
    context.closePath(), context.fill();
}, PushButtonMorph.prototype.drawBackground = function(context, color) {
    var isFlat = MorphicPreferences.isFlat && !this.is3D;
    context.fillStyle = color.toString(), context.beginPath(), this.outlinePath(context, isFlat ? 0 : Math.max(this.corner - this.outline, 0), this.outline), 
    context.closePath(), context.fill(), context.lineWidth = this.outline;
}, PushButtonMorph.prototype.drawEdges = function(context, color, topColor, bottomColor) {
    if (!MorphicPreferences.isFlat || this.is3D) {
        var gradient, minInset = Math.max(this.corner, this.outline + this.edge), w = this.width(), h = this.height();
        (gradient = context.createLinearGradient(0, this.outline, 0, this.outline + this.edge)).addColorStop(0, topColor.toString()), 
        gradient.addColorStop(1, color.toString()), context.strokeStyle = gradient, context.lineCap = "round", 
        context.lineWidth = this.edge, context.beginPath(), context.moveTo(minInset, this.outline + this.edge / 2), 
        context.lineTo(w - minInset, this.outline + this.edge / 2), context.stroke(), (gradient = context.createRadialGradient(this.corner, this.corner, Math.max(this.corner - this.outline - this.edge, 0), this.corner, this.corner, Math.max(this.corner - this.outline, 0))).addColorStop(1, topColor.toString()), 
        gradient.addColorStop(0, color.toString()), context.strokeStyle = gradient, context.lineCap = "round", 
        context.lineWidth = this.edge, context.beginPath(), context.arc(this.corner, this.corner, Math.max(this.corner - this.outline - this.edge / 2, 0), radians(180), radians(270), !1), 
        context.stroke(), (gradient = context.createLinearGradient(this.outline, 0, this.outline + this.edge, 0)).addColorStop(0, topColor.toString()), 
        gradient.addColorStop(1, color.toString()), context.strokeStyle = gradient, context.lineCap = "round", 
        context.lineWidth = this.edge, context.beginPath(), context.moveTo(this.outline + this.edge / 2, minInset), 
        context.lineTo(this.outline + this.edge / 2, h - minInset), context.stroke(), (gradient = context.createLinearGradient(0, h - this.outline, 0, h - this.outline - this.edge)).addColorStop(0, bottomColor.toString()), 
        gradient.addColorStop(1, color.toString()), context.strokeStyle = gradient, context.lineCap = "round", 
        context.lineWidth = this.edge, context.beginPath(), context.moveTo(minInset, h - this.outline - this.edge / 2), 
        context.lineTo(w - minInset, h - this.outline - this.edge / 2), context.stroke(), 
        (gradient = context.createRadialGradient(w - this.corner, h - this.corner, Math.max(this.corner - this.outline - this.edge, 0), w - this.corner, h - this.corner, Math.max(this.corner - this.outline, 0))).addColorStop(1, bottomColor.toString()), 
        gradient.addColorStop(0, color.toString()), context.strokeStyle = gradient, context.lineCap = "round", 
        context.lineWidth = this.edge, context.beginPath(), context.arc(w - this.corner, h - this.corner, Math.max(this.corner - this.outline - this.edge / 2, 0), radians(0), radians(90), !1), 
        context.stroke(), (gradient = context.createLinearGradient(w - this.outline, 0, w - this.outline - this.edge, 0)).addColorStop(0, bottomColor.toString()), 
        gradient.addColorStop(1, color.toString()), context.strokeStyle = gradient, context.lineCap = "round", 
        context.lineWidth = this.edge, context.beginPath(), context.moveTo(w - this.outline - this.edge / 2, minInset), 
        context.lineTo(w - this.outline - this.edge / 2, h - minInset), context.stroke();
    }
}, PushButtonMorph.prototype.createBackgrounds = function() {
    var context, ext = this.extent();
    if (this.template) return this.image = this.template.image, this.normalImage = this.template.normalImage, 
    this.highlightImage = this.template.highlightImage, this.pressImage = this.template.pressImage, 
    null;
    this.normalImage = newCanvas(ext), context = this.normalImage.getContext("2d"), 
    this.drawOutline(context), this.drawBackground(context, this.color), this.drawEdges(context, this.color, this.color.lighter(this.contrast), this.color.darker(this.contrast)), 
    this.highlightImage = newCanvas(ext), context = this.highlightImage.getContext("2d"), 
    this.drawOutline(context), this.drawBackground(context, this.highlightColor), this.drawEdges(context, this.highlightColor, this.highlightColor.lighter(this.contrast), this.highlightColor.darker(this.contrast)), 
    this.pressImage = newCanvas(ext), context = this.pressImage.getContext("2d"), this.drawOutline(context), 
    this.drawBackground(context, this.pressColor), this.drawEdges(context, this.pressColor, this.pressColor.darker(this.contrast), this.pressColor.lighter(this.contrast)), 
    this.image = this.normalImage;
}, PushButtonMorph.prototype.createLabel = function() {
    var shading = !MorphicPreferences.isFlat || this.is3D;
    null !== this.label && this.label.destroy(), this.labelString instanceof SymbolMorph ? (this.label = this.labelString.fullCopy(), 
    shading && (this.label.shadowOffset = this.labelShadowOffset, this.label.shadowColor = this.labelShadowColor), 
    this.label.color = this.labelColor, this.label.drawNew()) : this.label = new StringMorph(localize(this.labelString), this.fontSize, this.fontStyle, !0, !1, !1, shading ? this.labelShadowOffset : null, this.labelShadowColor, this.labelColor), 
    this.add(this.label);
}, ToggleButtonMorph.prototype = new PushButtonMorph(), ToggleButtonMorph.prototype.constructor = ToggleButtonMorph, 
ToggleButtonMorph.uber = PushButtonMorph.prototype, ToggleButtonMorph.prototype.contrast = 30;

function ToggleButtonMorph(colors, target, action, labelString, query, environment, hint, template, minWidth, hasPreview, isPicture) {
    this.init(colors, target, action, labelString, query, environment, hint, template, minWidth, hasPreview, isPicture);
}

ToggleButtonMorph.prototype.init = function(colors, target, action, labelString, query, environment, hint, template, minWidth, hasPreview, isPicture) {
    this.state = !1, this.query = query || function() {
        return !0;
    }, this.minWidth = minWidth || null, this.hasPreview = hasPreview || !1, this.isPicture = isPicture || !1, 
    this.trueStateLabel = null, ToggleButtonMorph.uber.init.call(this, target, action, labelString, environment, hint, template), 
    colors && (this.color = colors[0], this.highlightColor = colors[1], this.pressColor = colors[2]), 
    this.refresh(), this.drawNew();
}, ToggleButtonMorph.prototype.mouseEnter = function() {
    this.state || (this.image = this.highlightImage, this.changed()), this.hint && this.bubbleHelp(this.hint);
}, ToggleButtonMorph.prototype.mouseLeave = function() {
    this.state || (this.image = this.normalImage, this.changed()), this.hint && this.world().hand.destroyTemporaries();
}, ToggleButtonMorph.prototype.mouseDownLeft = function() {
    this.state || (this.image = this.pressImage, this.changed());
}, ToggleButtonMorph.prototype.mouseClickLeft = function() {
    this.state || (this.image = this.highlightImage, this.changed()), this.trigger();
}, ToggleButtonMorph.prototype.trigger = function() {
    ToggleButtonMorph.uber.trigger.call(this), this.refresh();
}, ToggleButtonMorph.prototype.refresh = function() {
    "function" == typeof this.query ? this.state = this.query.call(this.target) : this.state = this.target[this.query](), 
    this.state ? (this.image = this.pressImage, this.trueStateLabel && (this.label.hide(), 
    this.trueStateLabel.show())) : (this.image = this.normalImage, this.trueStateLabel && (this.label.show(), 
    this.trueStateLabel.hide())), this.changed();
}, ToggleButtonMorph.prototype.fixLayout = function() {
    if (null !== this.label) {
        var lw = Math.max(this.label.width(), this.labelMinExtent.x), padding = 2 * this.padding + 2 * this.outline + 2 * this.edge;
        this.setExtent(new Point(this.minWidth ? Math.max(this.minWidth, lw) + padding : lw + padding, Math.max(this.label instanceof StringMorph ? this.label.rawHeight() : this.label.height(), this.labelMinExtent.y) + padding)), 
        this.label.setCenter(this.center()), this.trueStateLabel && this.trueStateLabel.setCenter(this.center()), 
        this.minWidth && this.label.setLeft(this.left() + this.outline + this.edge + this.corner + this.padding);
    }
}, ToggleButtonMorph.prototype.createBackgrounds = function() {
    var context, ext = this.extent();
    if (this.template) return this.image = this.template.image, this.normalImage = this.template.normalImage, 
    this.highlightImage = this.template.highlightImage, this.pressImage = this.template.pressImage, 
    null;
    this.normalImage = newCanvas(ext), context = this.normalImage.getContext("2d"), 
    this.drawOutline(context), this.drawBackground(context, this.color), this.drawEdges(context, this.color, this.color.lighter(this.contrast), this.color.darker(this.contrast)), 
    this.highlightImage = newCanvas(ext), context = this.highlightImage.getContext("2d"), 
    this.drawOutline(context), this.drawBackground(context, this.highlightColor), this.drawEdges(context, this.highlightColor, this.highlightColor.lighter(this.contrast), this.highlightColor.darker(this.contrast)), 
    this.pressImage = newCanvas(ext), context = this.pressImage.getContext("2d"), this.drawOutline(context), 
    this.drawBackground(context, this.pressColor), this.drawEdges(context, this.pressColor, this.pressColor.lighter(40), this.pressColor.darker(40)), 
    this.image = this.normalImage;
}, ToggleButtonMorph.prototype.drawEdges = function(context, color, topColor, bottomColor) {
    var gradient;
    if (ToggleButtonMorph.uber.drawEdges.call(this, context, color, topColor, bottomColor), 
    this.hasPreview) {
        if (MorphicPreferences.isFlat && !this.is3D) return context.fillStyle = this.pressColor.toString(), 
        void context.fillRect(this.outline, this.outline, this.corner, this.height() - 2 * this.outline);
        (gradient = context.createLinearGradient(0, 0, this.corner, 0)).addColorStop(0, this.pressColor.lighter(40).toString()), 
        gradient.addColorStop(1, this.pressColor.darker(40).toString()), context.fillStyle = gradient, 
        context.beginPath(), this.previewPath(context, Math.max(this.corner - this.outline, 0), this.outline), 
        context.closePath(), context.fill();
    }
}, ToggleButtonMorph.prototype.previewPath = function(context, radius, inset) {
    var offset = radius + inset, h = this.height();
    context.arc(offset, offset, radius, radians(-180), radians(-90), !1), context.arc(offset, h - offset, radius, radians(90), radians(180), !1);
}, ToggleButtonMorph.prototype.createLabel = function() {
    var shading = !MorphicPreferences.isFlat || this.is3D, none = new Point();
    null !== this.label && this.label.destroy(), null !== this.trueStateLabel && this.trueStateLabel.destroy(), 
    this.labelString instanceof Array && 2 === this.labelString.length ? this.labelString[0] instanceof SymbolMorph ? (this.label = this.labelString[0].fullCopy(), 
    this.trueStateLabel = this.labelString[1].fullCopy(), this.isPicture || (this.label.shadowOffset = shading ? this.labelShadowOffset : none, 
    this.label.shadowColor = this.labelShadowColor, this.label.color = this.labelColor, 
    this.label.drawNew(), this.trueStateLabel.shadowOffset = shading ? this.labelShadowOffset : none, 
    this.trueStateLabel.shadowColor = this.labelShadowColor, this.trueStateLabel.color = this.labelColor, 
    this.trueStateLabel.drawNew())) : this.labelString[0] instanceof Morph ? (this.label = this.labelString[0].fullCopy(), 
    this.trueStateLabel = this.labelString[1].fullCopy()) : (this.label = new StringMorph(localize(this.labelString[0]), this.fontSize, this.fontStyle, !0, !1, !1, shading ? this.labelShadowOffset : null, this.labelShadowColor, this.labelColor), 
    this.trueStateLabel = new StringMorph(localize(this.labelString[1]), this.fontSize, this.fontStyle, !0, !1, !1, shading ? this.labelShadowOffset : null, this.labelShadowColor, this.labelColor)) : this.labelString instanceof SymbolMorph ? (this.label = this.labelString.fullCopy(), 
    this.isPicture || (this.label.shadowOffset = shading ? this.labelShadowOffset : none, 
    this.label.shadowColor = this.labelShadowColor, this.label.color = this.labelColor, 
    this.label.drawNew())) : this.labelString instanceof Morph ? this.label = this.labelString.fullCopy() : this.label = new StringMorph(localize(this.labelString), this.fontSize, this.fontStyle, !0, !1, !1, shading ? this.labelShadowOffset : none, this.labelShadowColor, this.labelColor), 
    this.add(this.label), this.trueStateLabel && this.add(this.trueStateLabel);
}, ToggleButtonMorph.prototype.hide = function() {
    this.isVisible = !1, this.changed();
}, ToggleButtonMorph.prototype.show = function() {
    this.isVisible = !0, this.changed();
}, TabMorph.prototype = new ToggleButtonMorph(), TabMorph.prototype.constructor = TabMorph, 
TabMorph.uber = ToggleButtonMorph.prototype;

function TabMorph(colors, target, action, labelString, query, environment, hint) {
    this.init(colors, target, action, labelString, query, environment, hint);
}

TabMorph.prototype.fixLayout = function() {
    null !== this.label && (this.setExtent(new Point(this.label.width() + 2 * this.padding + 3 * this.corner + 2 * this.edge, (this.label instanceof StringMorph ? this.label.rawHeight() : this.label.height()) + 2 * this.padding + this.edge)), 
    this.label.setCenter(this.center()));
}, TabMorph.prototype.refresh = function() {
    this.state && this.parent && this.parent.add(this), TabMorph.uber.refresh.call(this);
}, TabMorph.prototype.drawBackground = function(context, color) {
    var w = this.width(), h = this.height(), c = this.corner;
    context.fillStyle = color.toString(), context.beginPath(), context.moveTo(0, h), 
    context.bezierCurveTo(c, h, c, 0, 2 * c, 0), context.lineTo(w - 2 * c, 0), context.bezierCurveTo(w - c, 0, w - c, h, w, h), 
    context.closePath(), context.fill();
}, TabMorph.prototype.drawOutline = function() {
    nop();
}, TabMorph.prototype.drawEdges = function(context, color, topColor, bottomColor) {
    if (!MorphicPreferences.isFlat || this.is3D) {
        var gradient, w = this.width(), h = this.height(), c = this.corner, e = this.edge, eh = e / 2;
        nop(color), (gradient = context.createLinearGradient(0, 0, w, 0)).addColorStop(0, topColor.toString()), 
        gradient.addColorStop(1, bottomColor.toString()), context.strokeStyle = gradient, 
        context.lineCap = "round", context.lineWidth = e, context.beginPath(), context.moveTo(0, h + eh), 
        context.bezierCurveTo(c, h, c, 0, 2 * c, eh), context.lineTo(w - 2 * c, eh), context.bezierCurveTo(w - c, 0, w - c, h, w, h + eh), 
        context.stroke();
    }
}, ToggleMorph.prototype = new PushButtonMorph(), ToggleMorph.prototype.constructor = ToggleMorph, 
ToggleMorph.uber = PushButtonMorph.prototype;

function ToggleMorph(style, target, action, labelString, query, environment, hint, template, element, builder) {
    this.init(style, target, action, labelString, query, environment, hint, template, element, builder);
}

ToggleMorph.prototype.init = function(style, target, action, labelString, query, environment, hint, template, element, builder) {
    this.padding = 1, style = style || "checkbox", this.corner = "checkbox" === style ? 0 : fontHeight(this.fontSize) / 2 + this.outline + this.padding, 
    this.state = !1, this.query = query || function() {
        return !0;
    }, this.tick = null, this.captionString = labelString || null, this.labelAlignment = "right", 
    this.element = element || null, this.builder = builder || null, this.toggleElement = null, 
    ToggleMorph.uber.init.call(this, target, action, "checkbox" === style ? "✓" : "●", environment, hint, template), 
    this.refresh(), this.drawNew();
}, ToggleMorph.prototype.fixLayout = function() {
    var y, padding = 2 * this.padding + 2 * this.outline;
    null !== this.tick && (this.silentSetHeight(this.tick.rawHeight() + padding), this.silentSetWidth(this.tick.width() + padding), 
    this.setExtent(new Point(Math.max(this.width(), this.height()), Math.max(this.width(), this.height()))), 
    this.tick.setCenter(this.center())), this.state ? this.tick.show() : this.tick.hide(), 
    this.toggleElement && "right" === this.labelAlignment && (y = this.top() + (this.height() - this.toggleElement.height()) / 2, 
    this.toggleElement.setPosition(new Point(this.right() + padding, y))), null !== this.label && (y = this.top() + (this.height() - this.label.height()) / 2, 
    "right" === this.labelAlignment ? this.label.setPosition(new Point(this.toggleElement ? this.toggleElement instanceof ToggleElementMorph ? this.toggleElement.right() : this.toggleElement.right() + padding : this.right() + padding, y)) : this.label.setPosition(new Point(this.left() - this.label.width() - padding, y)));
}, ToggleMorph.prototype.createLabel = function() {
    var shading = !MorphicPreferences.isFlat || this.is3D;
    null === this.label && this.captionString && (this.label = new TextMorph(localize(this.captionString), this.fontSize, this.fontStyle, !0), 
    this.add(this.label)), null === this.tick && (this.tick = new StringMorph(localize(this.labelString), this.fontSize, this.fontStyle, !0, !1, !1, shading ? new Point(1, 1) : null, new Color(240, 240, 240)), 
    this.add(this.tick)), null === this.toggleElement && this.element && (this.element instanceof Morph ? this.toggleElement = new ToggleElementMorph(this.target, this.action, this.element, this.query, this.environment, this.hint, this.builder) : this.element instanceof HTMLCanvasElement && (this.toggleElement = new Morph(), 
    this.toggleElement.silentSetExtent(new Point(this.element.width, this.element.height)), 
    this.toggleElement.image = this.element), this.add(this.toggleElement));
}, ToggleMorph.prototype.trigger = function() {
    ToggleMorph.uber.trigger.call(this), this.refresh();
}, ToggleMorph.prototype.refresh = function() {
    "function" == typeof this.query ? this.state = this.query.call(this.target) : this.state = this.target[this.query](), 
    this.state ? this.tick.show() : this.tick.hide(), this.toggleElement && this.toggleElement.refresh && this.toggleElement.refresh();
}, ToggleMorph.prototype.mouseDownLeft = function() {
    PushButtonMorph.uber.mouseDownLeft.call(this), this.tick && this.tick.setCenter(this.center().add(1));
}, ToggleMorph.prototype.mouseClickLeft = function() {
    PushButtonMorph.uber.mouseClickLeft.call(this), this.tick && this.tick.setCenter(this.center());
}, ToggleMorph.prototype.mouseLeave = function() {
    PushButtonMorph.uber.mouseLeave.call(this), this.tick && this.tick.setCenter(this.center());
}, ToggleMorph.prototype.hide = ToggleButtonMorph.prototype.hide, ToggleMorph.prototype.show = ToggleButtonMorph.prototype.show, 
ToggleElementMorph.prototype = new TriggerMorph(), ToggleElementMorph.prototype.constructor = ToggleElementMorph, 
ToggleElementMorph.uber = TriggerMorph.prototype, ToggleElementMorph.prototype.contrast = 50, 
ToggleElementMorph.prototype.shadowOffset = new Point(2, 2), ToggleElementMorph.prototype.shadowAlpha = .6, 
ToggleElementMorph.prototype.fontSize = 10, ToggleElementMorph.prototype.inactiveColor = new Color(180, 180, 180);

function ToggleElementMorph(target, action, element, query, environment, hint, builder, labelString) {
    this.init(target, action, element, query, environment, hint, builder, labelString);
}

ToggleElementMorph.prototype.init = function(target, action, element, query, environment, hint, builder, labelString) {
    this.target = target || null, this.action = action || null, this.element = element, 
    this.query = query || function() {
        return !0;
    }, this.environment = environment || null, this.hint = hint || null, this.builder = builder || "nop", 
    this.captionString = labelString || null, this.labelAlignment = "right", this.state = !1, 
    TriggerMorph.uber.init.call(this), this.color = element.color, this.createLabel();
}, ToggleElementMorph.prototype.createBackgrounds = function() {
    var shading = !MorphicPreferences.isFlat || this.is3D;
    this.color = this.element.color, this.element.removeShadow(), this.element[this.builder](), 
    shading && this.element.addShadow(this.shadowOffset, this.shadowAlpha), this.silentSetExtent(this.element.fullBounds().extent()), 
    this.pressImage = this.element.fullImage(), this.element.removeShadow(), this.element.setColor(this.inactiveColor), 
    this.element[this.builder](this.contrast), shading && this.element.addShadow(this.shadowOffset, 0), 
    this.normalImage = this.element.fullImage(), this.element.removeShadow(), this.element.setColor(this.color.lighter(this.contrast)), 
    this.element[this.builder](this.contrast), shading && this.element.addShadow(this.shadowOffset, this.shadowAlpha), 
    this.highlightImage = this.element.fullImage(), this.element.removeShadow(), this.element.setColor(this.color), 
    this.element[this.builder](), this.image = this.normalImage;
}, ToggleElementMorph.prototype.setColor = function(aColor) {
    this.element.setColor(aColor), this.createBackgrounds(), this.refresh();
}, ToggleElementMorph.prototype.createLabel = function() {
    var y;
    this.captionString && (this.label = new StringMorph(this.captionString, this.fontSize, this.fontStyle, !0), 
    this.add(this.label), y = this.top() + (this.height() - this.label.height()) / 2, 
    "right" === this.labelAlignment ? this.label.setPosition(new Point(this.right(), y)) : this.label.setPosition(new Point(this.left() - this.label.width(), y)));
}, ToggleElementMorph.prototype.trigger = ToggleButtonMorph.prototype.trigger, ToggleElementMorph.prototype.refresh = ToggleButtonMorph.prototype.refresh, 
ToggleElementMorph.prototype.mouseEnter = ToggleButtonMorph.prototype.mouseEnter, 
ToggleElementMorph.prototype.mouseLeave = ToggleButtonMorph.prototype.mouseLeave, 
ToggleElementMorph.prototype.mouseDownLeft = ToggleButtonMorph.prototype.mouseDownLeft, 
ToggleElementMorph.prototype.mouseClickLeft = ToggleButtonMorph.prototype.mouseClickLeft, 
DialogBoxMorph.prototype = new Morph(), DialogBoxMorph.prototype.constructor = DialogBoxMorph, 
DialogBoxMorph.uber = Morph.prototype, DialogBoxMorph.prototype.fontSize = 12, DialogBoxMorph.prototype.titleFontSize = 14, 
DialogBoxMorph.prototype.fontStyle = "sans-serif", DialogBoxMorph.prototype.color = PushButtonMorph.prototype.color, 
DialogBoxMorph.prototype.titleTextColor = new Color(255, 255, 255), DialogBoxMorph.prototype.titleBarColor = PushButtonMorph.prototype.pressColor, 
DialogBoxMorph.prototype.contrast = 40, DialogBoxMorph.prototype.corner = 12, DialogBoxMorph.prototype.padding = 14, 
DialogBoxMorph.prototype.titlePadding = 6, DialogBoxMorph.prototype.buttonContrast = 50, 
DialogBoxMorph.prototype.buttonFontSize = 12, DialogBoxMorph.prototype.buttonCorner = 12, 
DialogBoxMorph.prototype.buttonEdge = 6, DialogBoxMorph.prototype.buttonPadding = 0, 
DialogBoxMorph.prototype.buttonOutline = 3, DialogBoxMorph.prototype.buttonOutlineColor = PushButtonMorph.prototype.color, 
DialogBoxMorph.prototype.buttonOutlineGradient = !0, DialogBoxMorph.prototype.instances = {};

function DialogBoxMorph(target, action, environment) {
    this.init(target, action, environment);
}

DialogBoxMorph.prototype.init = function(target, action, environment) {
    this.is3D = !1, this.target = target || null, this.action = action || null, this.environment = environment || null, 
    this.key = null, this.labelString = null, this.label = null, this.head = null, this.body = null, 
    this.buttons = null, DialogBoxMorph.uber.init.call(this), this.isDraggable = !0, 
    this.color = PushButtonMorph.prototype.color, this.createLabel(), this.createButtons(), 
    this.setExtent(new Point(300, 150));
}, DialogBoxMorph.prototype.inform = function(title, textString, world, pic) {
    var txt = new TextMorph(textString, this.fontSize, this.fontStyle, !0, !1, "center", null, null, MorphicPreferences.isFlat ? null : new Point(1, 1), new Color(255, 255, 255));
    this.key || (this.key = "inform" + title + textString), this.labelString = title, 
    this.createLabel(), pic && this.setPicture(pic), textString && this.addBody(txt), 
    this.addButton("ok", "OK"), this.drawNew(), this.fixLayout(), this.popUp(world);
}, DialogBoxMorph.prototype.askYesNo = function(title, textString, world, pic) {
    var txt = new TextMorph(textString, this.fontSize, this.fontStyle, !0, !1, "center", null, null, MorphicPreferences.isFlat ? null : new Point(1, 1), new Color(255, 255, 255));
    this.key || (this.key = "decide" + title + textString), this.labelString = title, 
    this.createLabel(), pic && this.setPicture(pic), this.addBody(txt), this.addButton("ok", "Yes"), 
    this.addButton("cancel", "No"), this.fixLayout(), this.drawNew(), this.fixLayout(), 
    this.popUp(world);
}, DialogBoxMorph.prototype.prompt = function(title, defaultString, world, pic, choices, isReadOnly, isNumeric, sliderMin, sliderMax, sliderAction) {
    var sld, head, txt = new InputFieldMorph(defaultString, isNumeric || !1, choices || null, !!choices && (isReadOnly || !1));
    txt.setWidth(250), isNumeric ? (pic && (head = new AlignmentMorph("column", this.padding), 
    pic.setPosition(head.position()), head.add(pic)), isNil(sliderMin) || isNil(sliderMax) || ((sld = new SliderMorph(100 * sliderMin, 100 * sliderMax, 100 * parseFloat(defaultString), (sliderMax - sliderMin) / 10 * 100, "horizontal")).alpha = 1, 
    sld.color = this.color.lighter(50), sld.setHeight(.7 * txt.height()), sld.setWidth(txt.width()), 
    sld.action = function(num) {
        sliderAction && sliderAction(num / 100), txt.setContents(num / 100), txt.edit();
    }, head || (head = new AlignmentMorph("column", this.padding)), head.add(sld)), 
    head && (head.fixLayout(), this.setPicture(head), head.fixLayout())) : pic && this.setPicture(pic), 
    this.reactToChoice = function(inp) {
        sld && (sld.value = 100 * inp, sld.drawNew(), sld.changed()), sliderAction && sliderAction(inp);
    }, txt.reactToKeystroke = function() {
        var inp = txt.getValue();
        sld && (inp = Math.max(inp, sliderMin), sld.value = 100 * inp, sld.drawNew(), sld.changed()), 
        sliderAction && sliderAction(inp);
    }, this.labelString = title, this.createLabel(), this.key || (this.key = "prompt" + title + defaultString), 
    this.addBody(txt), txt.drawNew(), this.addButton("ok", "OK"), this.addButton("cancel", "Cancel"), 
    this.fixLayout(), this.drawNew(), this.fixLayout(), this.popUp(world);
}, DialogBoxMorph.prototype.promptCode = function(title, defaultString, world, pic, instructions) {
    var frame = new ScrollFrameMorph(), text = new TextMorph(defaultString || ""), bdy = new AlignmentMorph("column", this.padding), size = pic ? Math.max(pic.width, 400) : 400;
    this.getInput = function() {
        return text.text;
    };
    frame.padding = 6, frame.setWidth(size), frame.acceptsDrops = !1, frame.contents.acceptsDrops = !1, 
    text.fontName = "monospace", text.fontStyle = "monospace", text.fontSize = 11, text.setPosition(frame.topLeft().add(frame.padding)), 
    text.enableSelecting(), text.isEditable = !0, frame.setHeight(size / 4), frame.fixLayout = nop, 
    frame.edge = InputFieldMorph.prototype.edge, frame.fontSize = InputFieldMorph.prototype.fontSize, 
    frame.typeInPadding = InputFieldMorph.prototype.typeInPadding, frame.contrast = InputFieldMorph.prototype.contrast, 
    frame.drawNew = InputFieldMorph.prototype.drawNew, frame.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, 
    frame.addContents(text), text.drawNew(), pic && this.setPicture(pic), this.labelString = title, 
    this.createLabel(), this.key || (this.key = "promptCode" + title + defaultString), 
    bdy.setColor(this.color), bdy.add(frame), instructions && bdy.add(new TextMorph(localize(instructions), 10, null, !1, null, null, null, null, MorphicPreferences.isFlat ? null : new Point(1, 1), new Color(255, 255, 255)));
    bdy.fixLayout(), this.addBody(bdy), frame.drawNew(), bdy.drawNew(), this.addButton("ok", "OK"), 
    this.addButton("cancel", "Cancel"), this.fixLayout(), this.drawNew(), this.fixLayout(), 
    this.popUp(world), text.edit();
}, DialogBoxMorph.prototype.promptVector = function(title, point, deflt, xLabel, yLabel, world, pic, msg) {
    var vec = new AlignmentMorph("row", 4), xInp = new InputFieldMorph(point.x.toString(), !0), yInp = new InputFieldMorph(point.y.toString(), !0), xCol = new AlignmentMorph("column", 2), yCol = new AlignmentMorph("column", 2), inp = new AlignmentMorph("column", 2), bdy = new AlignmentMorph("column", this.padding);
    function labelText(string) {
        return new TextMorph(localize(string), 10, null, !1, null, null, null, null, MorphicPreferences.isFlat ? null : new Point(1, 1), new Color(255, 255, 255));
    }
    inp.alignment = "left", inp.setColor(this.color), bdy.setColor(this.color), xCol.alignment = "left", 
    xCol.setColor(this.color), yCol.alignment = "left", yCol.setColor(this.color), xCol.add(labelText(xLabel)), 
    xCol.add(xInp), yCol.add(labelText(yLabel)), yCol.add(yInp), vec.add(xCol), vec.add(yCol), 
    inp.add(vec), msg && bdy.add(labelText(msg)), bdy.add(inp), vec.fixLayout(), xCol.fixLayout(), 
    yCol.fixLayout(), inp.fixLayout(), bdy.fixLayout(), this.labelString = title, this.createLabel(), 
    pic && this.setPicture(pic), this.addBody(bdy), vec.drawNew(), xCol.drawNew(), xInp.drawNew(), 
    yCol.drawNew(), yInp.drawNew(), bdy.fixLayout(), this.addButton("ok", "OK"), deflt instanceof Point && this.addButton(function() {
        xInp.setContents(deflt.x.toString()), yInp.setContents(deflt.y.toString());
    }, "Default"), this.addButton("cancel", "Cancel"), this.fixLayout(), this.drawNew(), 
    this.fixLayout(), this.edit = function() {
        xInp.edit();
    }, this.getInput = function() {
        return new Point(xInp.getValue(), yInp.getValue());
    }, this.key || (this.key = "vector" + title), this.popUp(world);
}, DialogBoxMorph.prototype.promptCredentials = function(title, purpose, tosURL, tosLabel, prvURL, prvLabel, checkBoxLabel, world, pic, msg) {
    var bmn, byr, emlLabel, chk, usr = new InputFieldMorph(), eml = new InputFieldMorph(), pw1 = new InputFieldMorph(), pw2 = new InputFieldMorph(), opw = new InputFieldMorph(), agree = !1, dof = new AlignmentMorph("row", 4), mCol = new AlignmentMorph("column", 2), yCol = new AlignmentMorph("column", 2), inp = new AlignmentMorph("column", 2), lnk = new AlignmentMorph("row", 4), bdy = new AlignmentMorph("column", this.padding), years = {}, currentYear = new Date().getFullYear(), firstYear = currentYear - 20, myself = this;
    function labelText(string) {
        return new TextMorph(localize(string), 10, null, !1, null, null, null, null, MorphicPreferences.isFlat ? null : new Point(1, 1), new Color(255, 255, 255));
    }
    function linkButton(label, url) {
        var btn = new PushButtonMorph(myself, function() {
            window.open(url);
        }, "  " + localize(label) + "  ");
        return btn.fontSize = 10, btn.corner = myself.buttonCorner, btn.edge = myself.buttonEdge, 
        btn.outline = myself.buttonOutline, btn.outlineColor = myself.buttonOutlineColor, 
        btn.outlineGradient = myself.buttonOutlineGradient, btn.padding = myself.buttonPadding, 
        btn.contrast = myself.buttonContrast, btn.drawNew(), btn.fixLayout(), btn;
    }
    for (bmn = new InputFieldMorph(null, !1, {
        January: [ "January" ],
        February: [ "February" ],
        March: [ "March" ],
        April: [ "April" ],
        May: [ "May" ],
        June: [ "June" ],
        July: [ "July" ],
        August: [ "August" ],
        September: [ "September" ],
        October: [ "October" ],
        November: [ "November" ],
        December: [ "December" ]
    }, !0); currentYear > firstYear; currentYear -= 1) years[currentYear.toString() + " "] = currentYear;
    years[firstYear + " " + localize("or before")] = "< " + currentYear, byr = new InputFieldMorph(null, !1, years, !0), 
    inp.alignment = "left", inp.setColor(this.color), bdy.setColor(this.color), mCol.alignment = "left", 
    mCol.setColor(this.color), yCol.alignment = "left", yCol.setColor(this.color), usr.setWidth(200), 
    bmn.setWidth(100), byr.contents().minWidth = 80, byr.setWidth(80), eml.setWidth(200), 
    pw1.setWidth(200), pw2.setWidth(200), opw.setWidth(200), pw1.contents().text.toggleIsPassword(), 
    pw2.contents().text.toggleIsPassword(), opw.contents().text.toggleIsPassword(), 
    "login" === purpose && (inp.add(labelText("User name:")), inp.add(usr)), "signup" === purpose && (inp.add(labelText("User name:")), 
    inp.add(usr), mCol.add(labelText("Birth date:")), mCol.add(bmn), yCol.add(labelText("year:")), 
    yCol.add(byr), dof.add(mCol), dof.add(yCol), inp.add(dof), emlLabel = labelText("foo"), 
    inp.add(emlLabel), inp.add(eml)), "login" === purpose && (inp.add(labelText("Password:")), 
    inp.add(pw1)), "changePassword" === purpose && (inp.add(labelText("Old password:")), 
    inp.add(opw), inp.add(labelText("New password:")), inp.add(pw1), inp.add(labelText("Repeat new password:")), 
    inp.add(pw2)), "resetPassword" === purpose && (inp.add(labelText("User name:")), 
    inp.add(usr)), msg && bdy.add(labelText(msg)), bdy.add(inp), (tosURL || prvURL) && bdy.add(lnk), 
    tosURL && lnk.add(linkButton(tosLabel, tosURL)), prvURL && lnk.add(linkButton(prvLabel, prvURL)), 
    checkBoxLabel && ((chk = new ToggleMorph("checkbox", this, function() {
        agree = !agree;
    }, checkBoxLabel, function() {
        return agree;
    })).edge = this.buttonEdge / 2, chk.outline = this.buttonOutline / 2, chk.outlineColor = this.buttonOutlineColor, 
    chk.outlineGradient = this.buttonOutlineGradient, chk.contrast = this.buttonContrast, 
    chk.drawNew(), chk.fixLayout(), bdy.add(chk)), dof.fixLayout(), mCol.fixLayout(), 
    yCol.fixLayout(), inp.fixLayout(), lnk.fixLayout(), bdy.fixLayout(), this.labelString = title, 
    this.createLabel(), pic && this.setPicture(pic), this.addBody(bdy), usr.drawNew(), 
    dof.drawNew(), mCol.drawNew(), bmn.drawNew(), yCol.drawNew(), byr.drawNew(), pw1.drawNew(), 
    pw2.drawNew(), opw.drawNew(), eml.drawNew(), bdy.fixLayout(), this.addButton("ok", "OK"), 
    this.addButton("cancel", "Cancel"), this.fixLayout(), this.drawNew(), this.fixLayout();
    this.accept = function() {
        (function() {
            var checklist, empty, em = eml.getValue();
            function indicate(morph, string) {
                var bubble = new SpeechBubbleMorph(localize(string));
                bubble.isPointingRight = !1, bubble.drawNew(), bubble.popUp(world, morph.leftCenter().subtract(new Point(bubble.width() + 2, 0))), 
                morph.edit && morph.edit();
            }
            if ("login" === purpose ? checklist = [ usr, pw1 ] : "signup" === purpose ? checklist = [ usr, bmn, byr, eml ] : "changePassword" === purpose ? checklist = [ opw, pw1, pw2 ] : "resetPassword" === purpose && (checklist = [ usr ]), 
            empty = detect(checklist, function(inp) {
                return !inp.getValue();
            })) return indicate(empty, "please fill out\nthis field"), !1;
            if ("signup" === purpose) {
                if (usr.getValue().length < 4) return indicate(usr, "User name must be four\ncharacters or longer"), 
                !1;
                if (em.indexOf(" ") > -1 || -1 === em.indexOf("@") || -1 === em.indexOf(".")) return indicate(eml, "please provide a valid\nemail address"), 
                !1;
            }
            if ("changePassword" === purpose) {
                if (pw1.getValue().length < 6) return indicate(pw1, "password must be six\ncharacters or longer"), 
                !1;
                if (pw1.getValue() !== pw2.getValue()) return indicate(pw2, "passwords do\nnot match"), 
                !1;
            }
            return !("signup" === purpose && !agree && (indicate(chk, "please agree to\nthe TOS"), 
            1));
        })() && DialogBoxMorph.prototype.accept.call(myself);
    }, this.edit = function() {
        "changePassword" === purpose ? opw.edit() : usr.edit();
    }, this.getInput = function() {
        return {
            username: usr.getValue(),
            email: eml.getValue(),
            oldpassword: opw.getValue(),
            password: pw1.getValue(),
            choice: agree
        };
    }, this.reactToChoice = function() {
        "signup" === purpose && (emlLabel.changed(), emlLabel.text = function() {
            var month, today = new Date().getFullYear() + new Date().getMonth() / 12, year = +byr.getValue() || 0, monthName = bmn.getValue();
            return monthName instanceof Array && (monthName = monthName[0]), isNaN(year) && (year = 0), 
            month = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ].indexOf(monthName), 
            isNaN(month) && (month = 0), today - (year + month / 12);
        }() <= 13 ? "E-mail address of parent or guardian:" : "E-mail address:", emlLabel.text = localize(emlLabel.text), 
        emlLabel.drawNew(), emlLabel.changed());
    }, this.reactToChoice(), this.key || (this.key = "credentials" + title + purpose), 
    this.popUp(world);
}, DialogBoxMorph.prototype.accept = function() {
    this.action && ("function" == typeof this.target ? "function" == typeof this.action ? this.target.call(this.environment, this.action.call()) : this.target.call(this.environment, this.action) : "function" == typeof this.action ? this.action.call(this.target, this.getInput()) : this.target[this.action](this.getInput())), 
    this.destroy();
}, DialogBoxMorph.prototype.withKey = function(key) {
    return this.key = key, this;
}, DialogBoxMorph.prototype.popUp = function(world) {
    world && (this.key && (this.instances[world.stamp] ? (this.instances[world.stamp][this.key] && this.instances[world.stamp][this.key].destroy(), 
    this.instances[world.stamp][this.key] = this) : (this.instances[world.stamp] = {}, 
    this.instances[world.stamp][this.key] = this)), world.add(this), world.keyboardReceiver = this, 
    this.setCenter(world.center()), this.edit());
}, DialogBoxMorph.prototype.destroy = function() {
    DialogBoxMorph.uber.destroy.call(this), this.key && delete this.instances[this.key];
}, DialogBoxMorph.prototype.ok = function() {
    this.accept();
}, DialogBoxMorph.prototype.cancel = function() {
    this.destroy();
}, DialogBoxMorph.prototype.edit = function() {
    this.children.forEach(function(c) {
        if (c.edit) return c.edit();
    });
}, DialogBoxMorph.prototype.getInput = function() {
    return this.body instanceof InputFieldMorph ? this.body.getValue() : null;
}, DialogBoxMorph.prototype.justDropped = function(hand) {
    hand.world.keyboardReceiver = this, this.edit();
}, DialogBoxMorph.prototype.destroy = function() {
    var world = this.world();
    world.keyboardReceiver = null, world.hand.destroyTemporaries(), DialogBoxMorph.uber.destroy.call(this);
}, DialogBoxMorph.prototype.normalizeSpaces = function(string) {
    var i, c, ans = "", flag = !1;
    for (i = 0; i < string.length; i += 1) " " === (c = string[i]) ? flag && (ans += c, 
    flag = !1) : (ans += c, flag = !0);
    return ans.trim();
}, DialogBoxMorph.prototype.createLabel = function() {
    var shading = !MorphicPreferences.isFlat || this.is3D;
    this.label && this.label.destroy(), this.labelString && (this.label = new StringMorph(localize(this.labelString), this.titleFontSize, this.fontStyle, !0, !1, !1, shading ? new Point(2, 1) : null, this.titleBarColor.darker(this.contrast)), 
    this.label.color = this.titleTextColor, this.label.drawNew(), this.add(this.label));
}, DialogBoxMorph.prototype.createButtons = function() {
    this.buttons && this.buttons.destroy(), this.buttons = new AlignmentMorph("row", this.padding), 
    this.add(this.buttons);
}, DialogBoxMorph.prototype.addButton = function(action, label) {
    var button = new PushButtonMorph(this, action || "ok", "  " + localize(label || "OK") + "  ");
    return button.fontSize = this.buttonFontSize, button.corner = this.buttonCorner, 
    button.edge = this.buttonEdge, button.outline = this.buttonOutline, button.outlineColor = this.buttonOutlineColor, 
    button.outlineGradient = this.buttonOutlineGradient, button.padding = this.buttonPadding, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), this.buttons.add(button), 
    button;
}, DialogBoxMorph.prototype.setPicture = function(aMorphOrCanvas) {
    var morph;
    aMorphOrCanvas instanceof Morph ? morph = aMorphOrCanvas : ((morph = new Morph()).image = aMorphOrCanvas, 
    morph.silentSetWidth(aMorphOrCanvas.width), morph.silentSetHeight(aMorphOrCanvas.height)), 
    this.addHead(morph);
}, DialogBoxMorph.prototype.addHead = function(aMorph) {
    this.head && this.head.destroy(), this.head = aMorph, this.add(this.head);
}, DialogBoxMorph.prototype.addBody = function(aMorph) {
    this.body && this.body.destroy(), this.body = aMorph, this.add(this.body);
}, DialogBoxMorph.prototype.addShadow = function() {
    nop();
}, DialogBoxMorph.prototype.removeShadow = function() {
    nop();
}, DialogBoxMorph.prototype.fixLayout = function() {
    var w, th = fontHeight(this.titleFontSize) + 2 * this.titlePadding;
    this.head && (this.head.setPosition(this.position().add(new Point(this.padding, th + this.padding))), 
    this.silentSetWidth(this.head.width() + 2 * this.padding), this.silentSetHeight(this.head.height() + 2 * this.padding + th)), 
    this.body && (this.head ? (this.body.setPosition(this.head.bottomLeft().add(new Point(0, this.padding))), 
    this.silentSetWidth(Math.max(this.width(), this.body.width() + 2 * this.padding)), 
    this.silentSetHeight(this.height() + this.body.height() + this.padding), w = this.width(), 
    this.head.setLeft(this.left() + Math.round((w - this.head.width()) / 2)), this.body.setLeft(this.left() + Math.round((w - this.body.width()) / 2))) : (this.body.setPosition(this.position().add(new Point(this.padding, th + this.padding))), 
    this.silentSetWidth(this.body.width() + 2 * this.padding), this.silentSetHeight(this.body.height() + 2 * this.padding + th))), 
    this.label && (this.label.setCenter(this.center()), this.label.setTop(this.top() + (th - this.label.height()) / 2)), 
    this.buttons && this.buttons.children.length > 0 && (this.buttons.fixLayout(), this.silentSetHeight(this.height() + this.buttons.height() + this.padding), 
    this.buttons.setCenter(this.center()), this.buttons.setBottom(this.bottom() - this.padding));
}, DialogBoxMorph.prototype.shadowImage = function(off, color) {
    var fb, img, outline, sha, ctx, offset = off || new Point(7, 7), clr = color || new Color(0, 0, 0);
    return fb = this.extent(), img = this.image, (ctx = (outline = newCanvas(fb)).getContext("2d")).drawImage(img, 0, 0), 
    ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, -offset.x, -offset.y), 
    (ctx = (sha = newCanvas(fb)).getContext("2d")).drawImage(outline, 0, 0), ctx.globalCompositeOperation = "source-atop", 
    ctx.fillStyle = clr.toString(), ctx.fillRect(0, 0, fb.x, fb.y), sha;
}, DialogBoxMorph.prototype.shadowImageBlurred = function(off, color) {
    var fb, img, sha, ctx, offset = off || new Point(7, 7), blur = this.shadowBlur, clr = color || new Color(0, 0, 0);
    return fb = this.extent().add(2 * blur), img = this.image, (ctx = (sha = newCanvas(fb)).getContext("2d")).shadowOffsetX = offset.x, 
    ctx.shadowOffsetY = offset.y, ctx.shadowBlur = blur, ctx.shadowColor = clr.toString(), 
    ctx.drawImage(img, blur - offset.x, blur - offset.y), ctx.shadowOffsetX = 0, ctx.shadowOffsetY = 0, 
    ctx.shadowBlur = 0, ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, blur - offset.x, blur - offset.y), 
    sha;
}, DialogBoxMorph.prototype.processKeyPress = function() {
    nop();
}, DialogBoxMorph.prototype.processKeyDown = function(event) {
    switch (event.keyCode) {
      case 13:
        this.ok();
        break;

      case 27:
        this.cancel();
        break;

      default:
        nop();
    }
}, DialogBoxMorph.prototype.drawNew = function() {
    this.fullChanged(), Morph.prototype.trackChanges = !1, DialogBoxMorph.uber.removeShadow.call(this), 
    this.fixLayout();
    var context, gradient, x, y, w = this.width(), h = this.height(), th = Math.floor(fontHeight(this.titleFontSize) + 2 * this.titlePadding), shift = this.corner / 2, isFlat = MorphicPreferences.isFlat && !this.is3D;
    if (this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 
    isFlat ? context.fillStyle = this.titleBarColor.toString() : ((gradient = context.createLinearGradient(0, 0, 0, th)).addColorStop(0, this.titleBarColor.lighter(this.contrast / 2).toString()), 
    gradient.addColorStop(1, this.titleBarColor.darker(this.contrast).toString()), context.fillStyle = gradient), 
    context.beginPath(), this.outlinePathTitle(context, isFlat ? 0 : this.corner), context.closePath(), 
    context.fill(), context.fillStyle = this.color.toString(), context.beginPath(), 
    this.outlinePathBody(context, isFlat ? 0 : this.corner), context.closePath(), context.fill(), 
    isFlat) return DialogBoxMorph.uber.addShadow.call(this), Morph.prototype.trackChanges = !0, 
    void this.fullChanged();
    (gradient = context.createLinearGradient(0, h - this.corner, 0, h)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, this.color.darker(this.contrast.toString())), context.lineWidth = this.corner, 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.corner, h - shift), context.lineTo(this.corner + 1, h - shift), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - this.corner, 0, h)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, this.color.darker(this.contrast.toString())), context.lineWidth = this.corner, 
    context.lineCap = "butt", context.strokeStyle = gradient, context.beginPath(), context.moveTo(this.corner, h - shift), 
    context.lineTo(w - this.corner, h - shift), context.stroke(), (gradient = context.createLinearGradient(w - this.corner, 0, w, 0)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, this.color.darker(this.contrast).toString()), context.lineWidth = this.corner, 
    context.lineCap = "butt", context.strokeStyle = gradient, context.beginPath(), context.moveTo(w - shift, th), 
    context.lineTo(w - shift, h - this.corner), context.stroke(), x = w - this.corner, 
    y = h - this.corner, (gradient = context.createRadialGradient(x, y, 0, x, y, this.corner)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, this.color.darker(this.contrast.toString())), context.lineCap = "butt", 
    context.strokeStyle = gradient, context.beginPath(), context.arc(x, y, shift, radians(90), radians(0), !0), 
    context.stroke(), (gradient = context.createLinearGradient(0, 0, this.corner, 0)).addColorStop(1, this.color.toString()), 
    gradient.addColorStop(0, this.color.lighter(this.contrast).toString()), context.lineCap = "butt", 
    context.strokeStyle = gradient, context.beginPath(), context.moveTo(shift, th), 
    context.lineTo(shift, h - 2 * this.corner), context.stroke(), (gradient = context.createLinearGradient(0, 0, this.corner, 0)).addColorStop(1, this.color.toString()), 
    gradient.addColorStop(0, this.color.lighter(this.contrast).toString()), context.lineCap = "round", 
    context.strokeStyle = gradient, context.beginPath(), context.moveTo(shift, h - 2 * this.corner), 
    context.lineTo(shift, h - this.corner - shift), context.stroke(), DialogBoxMorph.uber.addShadow.call(this), 
    Morph.prototype.trackChanges = !0, this.fullChanged();
}, DialogBoxMorph.prototype.outlinePathTitle = function(context, radius) {
    var w = this.width(), h = Math.ceil(fontHeight(this.titleFontSize)) + 2 * this.titlePadding;
    context.arc(radius, radius, radius, radians(-180), radians(-90), !1), context.arc(w - radius, radius, radius, radians(-90), radians(-0), !1), 
    context.lineTo(w, h), context.lineTo(0, h);
}, DialogBoxMorph.prototype.outlinePathBody = function(context, radius) {
    var w = this.width(), h = this.height(), th = Math.floor(fontHeight(this.titleFontSize)) + 2 * this.titlePadding;
    context.moveTo(0, th), context.lineTo(w, th), context.arc(w - radius, h - radius, radius, radians(0), radians(90), !1), 
    context.arc(radius, h - radius, radius, radians(90), radians(180), !1);
}, AlignmentMorph.prototype = new Morph(), AlignmentMorph.prototype.constructor = AlignmentMorph, 
AlignmentMorph.uber = Morph.prototype;

function AlignmentMorph(orientation, padding) {
    this.init(orientation, padding);
}

AlignmentMorph.prototype.init = function(orientation, padding) {
    this.orientation = orientation || "row", this.alignment = "center", this.padding = padding || 0, 
    this.respectHiddens = !1, AlignmentMorph.uber.init.call(this);
}, AlignmentMorph.prototype.drawNew = function() {
    this.image = newCanvas(new Point(1, 1)), this.fixLayout();
}, AlignmentMorph.prototype.fixLayout = function() {
    var newBounds, myself = this, last = null;
    if (0 === this.children.length) return null;
    this.children.forEach(function(c) {
        var lfb, cfb = c.fullBounds();
        (c.isVisible || myself.respectHiddens) && (last ? (lfb = last.fullBounds(), "row" === myself.orientation ? c.setPosition(lfb.topRight().add(new Point(myself.padding, (lfb.height() - cfb.height()) / 2))) : c.setPosition(lfb.bottomLeft().add(new Point("center" === myself.alignment ? (lfb.width() - cfb.width()) / 2 : 0, myself.padding))), 
        newBounds = newBounds.merge(cfb)) : newBounds = cfb, last = c);
    }), this.bounds = newBounds;
}, InputFieldMorph.prototype = new Morph(), InputFieldMorph.prototype.constructor = InputFieldMorph, 
InputFieldMorph.uber = Morph.prototype, InputFieldMorph.prototype.edge = 2, InputFieldMorph.prototype.fontSize = 12, 
InputFieldMorph.prototype.typeInPadding = 2, InputFieldMorph.prototype.contrast = 65;

function InputFieldMorph(text, isNumeric, choiceDict, isReadOnly) {
    this.init(text, isNumeric, choiceDict, isReadOnly);
}

InputFieldMorph.prototype.init = function(text, isNumeric, choiceDict, isReadOnly) {
    var contents = new StringFieldMorph(text || ""), arrow = new ArrowMorph("down", 0, Math.max(Math.floor(this.fontSize / 6), 1));
    this.choices = choiceDict || null, this.isReadOnly = isReadOnly || !1, this.isNumeric = isNumeric || !1, 
    contents.alpha = 0, contents.fontSize = this.fontSize, contents.drawNew(), this.oldContentsExtent = contents.extent(), 
    this.isNumeric = isNumeric || !1, InputFieldMorph.uber.init.call(this), this.color = new Color(255, 255, 255), 
    this.add(contents), this.add(arrow), contents.isDraggable = !1, this.drawNew();
}, InputFieldMorph.prototype.contents = function() {
    return detect(this.children, function(child) {
        return child instanceof StringFieldMorph;
    });
}, InputFieldMorph.prototype.arrow = function() {
    return detect(this.children, function(child) {
        return child instanceof ArrowMorph;
    });
}, InputFieldMorph.prototype.setChoice = function(aStringOrFloat) {
    this.setContents(aStringOrFloat), this.escalateEvent("reactToChoice", aStringOrFloat);
}, InputFieldMorph.prototype.setContents = function(aStringOrFloat) {
    var cnts = this.contents();
    if (cnts.text.text = aStringOrFloat, void 0 === aStringOrFloat) return null;
    null === aStringOrFloat ? cnts.text.text = "" : aStringOrFloat.toString && (cnts.text.text = aStringOrFloat.toString()), 
    cnts.drawNew(), cnts.changed();
}, InputFieldMorph.prototype.edit = function() {
    var c = this.contents();
    c.text.edit(), c.text.selectAll();
}, InputFieldMorph.prototype.setIsNumeric = function(bool) {
    var value;
    this.isNumeric = bool, this.contents().isNumeric = bool, this.contents().text.isNumeric = bool, 
    value = this.getValue(), this.isNumeric && (value = parseFloat(value), isNaN(value) && (value = null)), 
    this.setContents(value);
}, InputFieldMorph.prototype.dropDownMenu = function() {
    var key, choices = this.choices, menu = new MenuMorph(this.setChoice, null, this, this.fontSize);
    if (choices instanceof Function ? choices = choices.call(this) : isString(choices) && (choices = this[choices]()), 
    !choices) return null;
    if (menu.addItem(" ", null), choices instanceof Array) choices.forEach(function(choice) {
        menu.addItem(choice[0], choice[1]);
    }); else for (key in choices) Object.prototype.hasOwnProperty.call(choices, key) && ("~" === key[0] ? menu.addLine() : menu.addItem(key, choices[key]));
    if (!(menu.items.length > 0)) return null;
    menu.popUpAtHand(this.world());
}, InputFieldMorph.prototype.fixLayout = function() {
    var contents = this.contents(), arrow = this.arrow();
    if (!contents) return null;
    contents.isNumeric = this.isNumeric, contents.isEditable = !this.isReadOnly, this.choices ? (arrow.setSize(this.fontSize), 
    arrow.show()) : (arrow.setSize(0), arrow.hide()), this.silentSetHeight(contents.height() + 2 * this.edge + 2 * this.typeInPadding), 
    this.silentSetWidth(Math.max(contents.minWidth + 2 * this.edge + 2 * this.typeInPadding, this.width())), 
    contents.setWidth(this.width() - this.edge - this.typeInPadding - (this.choices ? arrow.width() + this.typeInPadding : 0)), 
    contents.silentSetPosition(new Point(this.edge, this.edge).add(this.typeInPadding).add(this.position())), 
    arrow.silentSetPosition(new Point(this.right() - arrow.width() - this.edge, contents.top()));
}, InputFieldMorph.prototype.mouseClickLeft = function(pos) {
    this.arrow().bounds.containsPoint(pos) ? this.dropDownMenu() : this.isReadOnly ? this.dropDownMenu() : this.escalateEvent("mouseClickLeft", pos);
}, InputFieldMorph.prototype.getValue = function() {
    var num, contents = this.contents();
    return this.isNumeric && (num = parseFloat(contents.text), !isNaN(num)) ? num : this.normalizeSpaces(contents.string());
}, InputFieldMorph.prototype.normalizeSpaces = DialogBoxMorph.prototype.normalizeSpaces, 
InputFieldMorph.prototype.drawNew = function() {
    var context, borderColor;
    this.fixLayout(), this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 
    this.parent ? (this.parent.color.eq(new Color(255, 255, 255)) ? this.color = this.parent.color.darker(.1 * this.contrast) : this.color = this.parent.color.lighter(.75 * this.contrast), 
    borderColor = this.parent.color) : borderColor = new Color(120, 120, 120), context.fillStyle = this.color.toString(), 
    this.cachedClr = borderColor.toString(), this.cachedClrBright = borderColor.lighter(this.contrast).toString(), 
    this.cachedClrDark = borderColor.darker(this.contrast).toString(), context.fillRect(this.edge, this.edge, this.width() - 2 * this.edge, this.height() - 2 * this.edge), 
    this.drawRectBorder(context);
}, InputFieldMorph.prototype.drawRectBorder = function(context) {
    var gradient, shift = .5 * this.edge;
    MorphicPreferences.isFlat && !this.is3D || (context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.shadowOffsetY = shift, context.shadowBlur = 4 * this.edge, 
    context.shadowColor = this.cachedClrDark, (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.edge, shift), context.lineTo(this.width() - this.edge - shift, shift), 
    context.stroke(), context.shadowOffsetY = 0, (gradient = context.createLinearGradient(0, 0, this.edge, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, this.edge), context.lineTo(shift, this.height() - this.edge - shift), 
    context.stroke(), context.shadowOffsetX = 0, context.shadowOffsetY = 0, context.shadowBlur = 0, 
    (gradient = context.createLinearGradient(0, this.height() - this.edge, 0, this.height())).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.edge, this.height() - shift), context.lineTo(this.width() - this.edge, this.height() - shift), 
    context.stroke(), (gradient = context.createLinearGradient(this.width() - this.edge, 0, this.width(), 0)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.width() - shift, this.edge), context.lineTo(this.width() - shift, this.height() - this.edge), 
    context.stroke());
}, modules.blocks = "2014-November-21";

var SyntaxElementMorph, BlockMorph, CommandBlockMorph, ReporterBlockMorph, ScriptsMorph, ArgMorph, CommandSlotMorph, CSlotMorph, InputSlotMorph, BooleanSlotMorph, ArrowMorph, ColorSlotMorph, HatBlockMorph, BlockHighlightMorph, MultiArgMorph, TemplateSlotMorph, FunctionSlotMorph, ReporterSlotMorph, RingMorph, RingCommandSlotMorph, RingReporterSlotMorph, SymbolMorph, CommentMorph, ArgLabelMorph, TextSlotMorph;

WorldMorph.prototype.customMorphs = function() {
    return [];
}, SyntaxElementMorph.prototype = new Morph(), SyntaxElementMorph.prototype.constructor = SyntaxElementMorph, 
SyntaxElementMorph.uber = Morph.prototype, SyntaxElementMorph.prototype.setScale = function(num) {
    var scale = Math.min(Math.max(num, 1), 25);
    this.scale = scale, this.corner = 3 * scale, this.rounding = 9 * scale, this.edge = 1.000001 * scale, 
    this.inset = 6 * scale, this.hatHeight = 12 * scale, this.hatWidth = 70 * scale, 
    this.rfBorder = 3 * scale, this.minWidth = 0, this.dent = 8 * scale, this.bottomPadding = 3 * scale, 
    this.cSlotPadding = 4 * scale, this.typeInPadding = scale, this.labelPadding = 4 * scale, 
    this.labelFontName = "Verdana", this.labelFontStyle = "sans-serif", this.fontSize = 10 * scale, 
    this.embossing = new Point(-1 * Math.max(scale / 2, 1), -1 * Math.max(scale / 2, 1)), 
    this.labelWidth = 450 * scale, this.labelWordWrap = !0, this.dynamicInputLabels = !0, 
    this.feedbackColor = new Color(255, 255, 255), this.feedbackMinHeight = 5, this.minSnapDistance = 20, 
    this.reporterDropFeedbackPadding = 10 * scale, this.contrast = 65, this.labelContrast = 25, 
    this.activeHighlight = new Color(153, 255, 213), this.errorHighlight = new Color(173, 15, 0), 
    this.activeBlur = 20, this.activeBorder = 4, this.rfColor = new Color(120, 120, 120);
}, SyntaxElementMorph.prototype.setScale(1);

function SyntaxElementMorph() {
    this.init();
}

SyntaxElementMorph.prototype.init = function() {
    this.cachedClr = null, this.cachedClrBright = null, this.cachedClrDark = null, this.isStatic = !1, 
    SyntaxElementMorph.uber.init.call(this), this.defaults = [];
}, SyntaxElementMorph.prototype.parts = function() {
    var nb = null;
    return this.nextBlock && (nb = this.nextBlock()), this.children.filter(function(child) {
        return !(child === nb || child instanceof ShadowMorph || child instanceof BlockHighlightMorph);
    });
}, SyntaxElementMorph.prototype.inputs = function() {
    return this.parts().filter(function(part) {
        return part instanceof SyntaxElementMorph;
    });
}, SyntaxElementMorph.prototype.allInputs = function() {
    var myself = this;
    return this.allChildren().slice(0).reverse().filter(function(child) {
        return child instanceof ArgMorph || child instanceof ReporterBlockMorph && child !== myself;
    });
}, SyntaxElementMorph.prototype.allEmptySlots = function() {
    var empty = [];
    return this instanceof RingMorph || "reportJSFunction" === this.selector || this.children.forEach(function(morph) {
        morph.isEmptySlot && morph.isEmptySlot() ? empty.push(morph) : morph.allEmptySlots && (empty = empty.concat(morph.allEmptySlots()));
    }), empty;
}, SyntaxElementMorph.prototype.tagExitBlocks = function(stopTag, isCommand) {
    "doReport" === this.selector ? this.partOfCustomCommand = isCommand : "doStopThis" === this.selector ? this.exitTag = stopTag : this instanceof RingMorph || this.children.forEach(function(morph) {
        morph.tagExitBlocks && morph.tagExitBlocks(stopTag, isCommand);
    });
}, SyntaxElementMorph.prototype.replaceInput = function(oldArg, newArg) {
    var nb, scripts = this.parentThatIsA(ScriptsMorph), replacement = newArg, idx = this.children.indexOf(oldArg), i = 0;
    if (-1 === idx && newArg instanceof MultiArgMorph && this.children.forEach(function(morph) {
        morph instanceof ArgLabelMorph && morph.argMorph() === oldArg && (idx = i), i += 1;
    }), -1 === idx || null === scripts) return null;
    this.startLayout(), newArg.parent && newArg.parent.removeChild(newArg), oldArg instanceof MultiArgMorph && (oldArg.inputs().forEach(function(inp) {
        oldArg.replaceInput(inp, new InputSlotMorph());
    }), this.dynamicInputLabels && (replacement = new ArgLabelMorph(newArg))), replacement.parent = this, 
    this.children[idx] = replacement, oldArg instanceof ReporterBlockMorph ? oldArg instanceof RingMorph && !(oldArg instanceof RingMorph && oldArg.contents()) || (scripts.add(oldArg), 
    oldArg.moveBy(replacement.extent()), oldArg.fixBlockColor()) : oldArg instanceof CommandSlotMorph && (nb = oldArg.nestedBlock()) && (scripts.add(nb), 
    nb.moveBy(replacement.extent()), nb.fixBlockColor()), replacement instanceof MultiArgMorph || replacement instanceof ArgLabelMorph || replacement.constructor === CommandSlotMorph ? (replacement.fixLayout(), 
    this.fixLabelColor && this.fixLabelColor()) : (replacement.drawNew(), this.fixLayout()), 
    this.endLayout();
}, SyntaxElementMorph.prototype.silentReplaceInput = function(oldArg, newArg) {
    var replacement, i = this.children.indexOf(oldArg);
    -1 !== i && (newArg.parent && newArg.parent.removeChild(newArg), (replacement = oldArg instanceof MultiArgMorph && this.dynamicInputLabels ? new ArgLabelMorph(newArg) : newArg).parent = this, 
    this.children[i] = replacement, replacement instanceof MultiArgMorph || replacement instanceof ArgLabelMorph || replacement.constructor === CommandSlotMorph ? (replacement.fixLayout(), 
    this.fixLabelColor && this.fixLabelColor()) : (replacement.drawNew(), this.fixLayout()));
}, SyntaxElementMorph.prototype.revertToDefaultInput = function(arg, noValues) {
    var idx = this.parts().indexOf(arg), inp = this.inputs().indexOf(arg), deflt = new InputSlotMorph();
    -1 !== idx && (this instanceof BlockMorph ? (deflt = this.labelPart(this.parseSpec(this.blockSpec)[idx])) instanceof InputSlotMorph && this.definition && (deflt.setChoices.apply(deflt, this.definition.inputOptionsOfIdx(inp)), 
    deflt.setContents(this.definition.defaultValueOfInputIdx(inp))) : this instanceof MultiArgMorph ? deflt = this.labelPart(this.slotSpec) : this instanceof ReporterSlotMorph && (deflt = this.emptySlot())), 
    noValues || -1 !== inp && (deflt instanceof MultiArgMorph ? (deflt.setContents(this.defaults), 
    deflt.defaults = this.defaults) : isNil(this.defaults[inp]) || deflt.setContents(this.defaults[inp])), 
    this.silentReplaceInput(arg, deflt), deflt instanceof MultiArgMorph ? deflt.refresh() : deflt instanceof RingMorph && deflt.fixBlockColor();
}, SyntaxElementMorph.prototype.isLocked = function() {
    return this.isStatic;
}, SyntaxElementMorph.prototype.topBlock = function() {
    return this.parent && this.parent.topBlock ? this.parent.topBlock() : this;
}, SyntaxElementMorph.prototype.reactToGrabOf = function(grabbedMorph) {
    var affected, topBlock = this.topBlock();
    grabbedMorph instanceof CommandBlockMorph && (affected = this.parentThatIsA(CommandSlotMorph)) && (this.startLayout(), 
    affected.fixLayout(), this.endLayout()), topBlock && (topBlock.allComments().forEach(function(comment) {
        comment.align(topBlock);
    }), topBlock.getHighlight() && topBlock.addHighlight(topBlock.removeHighlight()));
}, SyntaxElementMorph.prototype.bright = function() {
    return this.color.lighter(this.contrast).toString();
}, SyntaxElementMorph.prototype.dark = function() {
    return this.color.darker(this.contrast).toString();
}, SyntaxElementMorph.prototype.setColor = function(aColor) {
    aColor && (this.color.eq(aColor) || (this.color = aColor, this.drawNew(), this.children.forEach(function(child) {
        child.drawNew(), child.changed();
    }), this.changed()));
}, SyntaxElementMorph.prototype.setLabelColor = function(textColor, shadowColor, shadowOffset) {
    this.children.forEach(function(morph) {
        morph instanceof StringMorph && !morph.isProtectedLabel ? (morph.shadowOffset = shadowOffset || morph.shadowOffset, 
        morph.shadowColor = shadowColor || morph.shadowColor, morph.setColor(textColor)) : (morph instanceof MultiArgMorph || morph instanceof ArgLabelMorph || morph instanceof SymbolMorph && !morph.isProtectedLabel || morph instanceof InputSlotMorph && morph.isReadOnly) && morph.setLabelColor(textColor, shadowColor, shadowOffset);
    });
}, SyntaxElementMorph.prototype.fixBlockColor = function(nearestBlock, isForced) {
    this.children.forEach(function(morph) {
        morph instanceof SyntaxElementMorph && morph.fixBlockColor(nearestBlock, isForced);
    });
}, SyntaxElementMorph.prototype.labelPart = function(spec) {
    var part, tokens;
    if ("%" === spec[0] && spec.length > 1 && ("reportGetVar" !== this.selector || "%turtleOutline" === spec && this.isObjInputFragment())) {
        if (spec.length > 5 && "%mult" === spec.slice(0, 5)) return (part = new MultiArgMorph(spec.slice(5))).addInput(), 
        part;
        switch (spec) {
          case "%imgsource":
            (part = new InputSlotMorph(null, !1, {
                "pen trails": [ "pen trails" ],
                "stage image": [ "stage image" ]
            }, !0)).setContents([ "pen trails" ]);
            break;

          case "%inputs":
            (part = new MultiArgMorph("%s", "with inputs")).isStatic = !1, part.canBeEmpty = !1;
            break;

          case "%scriptVars":
            (part = new MultiArgMorph("%t", null, 1, spec)).canBeEmpty = !1;
            break;

          case "%parms":
            (part = new MultiArgMorph("%t", "Input Names:", 0, spec)).canBeEmpty = !1;
            break;

          case "%ringparms":
            part = new MultiArgMorph("%t", "input names:", 0, spec);
            break;

          case "%cmdRing":
            (part = new RingMorph()).color = SpriteMorph.prototype.blockColor.other, part.selector = "reifyScript", 
            part.setSpec("%rc %ringparms"), part.isDraggable = !0;
            break;

          case "%repRing":
            (part = new RingMorph()).color = SpriteMorph.prototype.blockColor.other, part.selector = "reifyReporter", 
            part.setSpec("%rr %ringparms"), part.isDraggable = !0, part.isStatic = !0;
            break;

          case "%predRing":
            (part = new RingMorph(!0)).color = SpriteMorph.prototype.blockColor.other, part.selector = "reifyPredicate", 
            part.setSpec("%rp %ringparms"), part.isDraggable = !0, part.isStatic = !0;
            break;

          case "%words":
            (part = new MultiArgMorph("%s", null, 0)).addInput(), part.addInput(), part.isStatic = !1;
            break;

          case "%exp":
            (part = new MultiArgMorph("%s", null, 0)).addInput(), part.isStatic = !0, part.canBeEmpty = !1;
            break;

          case "%br":
            (part = new Morph()).setExtent(new Point(0, 0)), part.isBlockLabelBreak = !0, part.getSpec = function() {
                return "%br";
            };
            break;

          case "%inputName":
            (part = new ReporterBlockMorph()).category = "variables", part.color = SpriteMorph.prototype.blockColor.variables, 
            part.setSpec(localize("Input name"));
            break;

          case "%s":
            part = new InputSlotMorph();
            break;

          case "%anyUE":
            (part = new InputSlotMorph()).isUnevaluated = !0;
            break;

          case "%txt":
            (part = new InputSlotMorph()).minWidth = 1.7 * part.height(), part.fixLayout();
            break;

          case "%mlt":
            (part = new TextSlotMorph()).fixLayout();
            break;

          case "%code":
            (part = new TextSlotMorph()).contents().fontName = "monospace", part.contents().fontStyle = "monospace", 
            part.fixLayout();
            break;

          case "%obj":
            part = new ArgMorph("object");
            break;

          case "%n":
            part = new InputSlotMorph(null, !0);
            break;

          case "%dir":
            (part = new InputSlotMorph(null, !0, {
                "(90) right": 90,
                "(-90) left": -90,
                "(0) up": "0",
                "(180) down": 180
            })).setContents(90);
            break;

          case "%inst":
            (part = new InputSlotMorph(null, !0, {
                "(1) Acoustic Grand": 1,
                "(2) Bright Acoustic": 2,
                "(3) Electric Grand": 3,
                "(4) Honky Tonk": 4,
                "(5) Electric Piano 1": 5,
                "(6) Electric Piano 2": 6,
                "(7) Harpsichord": 7
            })).setContents(1);
            break;

          case "%month":
            part = new InputSlotMorph(null, !1, {
                January: [ "January" ],
                February: [ "February" ],
                March: [ "March" ],
                April: [ "April" ],
                May: [ "May" ],
                June: [ "June" ],
                July: [ "July" ],
                August: [ "August" ],
                September: [ "September" ],
                October: [ "October" ],
                November: [ "November" ],
                December: [ "December" ]
            }, !0);
            break;

          case "%dates":
            (part = new InputSlotMorph(null, !1, {
                year: [ "year" ],
                month: [ "month" ],
                date: [ "date" ],
                "day of week": [ "day of week" ],
                hour: [ "hour" ],
                minute: [ "minute" ],
                second: [ "second" ],
                "time in milliseconds": [ "time in milliseconds" ]
            }, !0)).setContents([ "date" ]);
            break;

          case "%delim":
            part = new InputSlotMorph(null, !1, {
                letter: [ "letter" ],
                whitespace: [ "whitespace" ],
                line: [ "line" ],
                tab: [ "tab" ],
                cr: [ "cr" ]
            }, !1);
            break;

          case "%ida":
            (part = new InputSlotMorph(null, !0, {
                "1": 1,
                last: [ "last" ],
                "~": null,
                all: [ "all" ]
            })).setContents(1);
            break;

          case "%idx":
            (part = new InputSlotMorph(null, !0, {
                "1": 1,
                last: [ "last" ],
                any: [ "any" ]
            })).setContents(1);
            break;

          case "%spr":
            part = new InputSlotMorph(null, !1, "objectsMenu", !0);
            break;

          case "%col":
            part = new InputSlotMorph(null, !1, "collidablesMenu", !0);
            break;

          case "%dst":
            part = new InputSlotMorph(null, !1, "distancesMenu", !0);
            break;

          case "%cln":
            part = new InputSlotMorph(null, !1, "clonablesMenu", !0);
            break;

          case "%cst":
            part = new InputSlotMorph(null, !1, "costumesMenu", !0);
            break;

          case "%eff":
            (part = new InputSlotMorph(null, !1, {
                brightness: [ "brightness" ],
                ghost: [ "ghost" ],
                negative: [ "negative" ],
                comic: [ "comic" ],
                duplicate: [ "duplicate" ],
                confetti: [ "confetti" ]
            }, !0)).setContents([ "ghost" ]);
            break;

          case "%snd":
            part = new InputSlotMorph(null, !1, "soundsMenu", !0);
            break;

          case "%key":
            (part = new InputSlotMorph(null, !1, {
                "up arrow": [ "up arrow" ],
                "down arrow": [ "down arrow" ],
                "right arrow": [ "right arrow" ],
                "left arrow": [ "left arrow" ],
                space: [ "space" ],
                a: [ "a" ],
                b: [ "b" ],
                c: [ "c" ],
                d: [ "d" ],
                e: [ "e" ],
                f: [ "f" ],
                g: [ "g" ],
                h: [ "h" ],
                i: [ "i" ],
                j: [ "j" ],
                k: [ "k" ],
                l: [ "l" ],
                m: [ "m" ],
                n: [ "n" ],
                o: [ "o" ],
                p: [ "p" ],
                q: [ "q" ],
                r: [ "r" ],
                s: [ "s" ],
                t: [ "t" ],
                u: [ "u" ],
                v: [ "v" ],
                w: [ "w" ],
                x: [ "x" ],
                y: [ "y" ],
                z: [ "z" ],
                "0": [ "0" ],
                "1": [ "1" ],
                "2": [ "2" ],
                "3": [ "3" ],
                "4": [ "4" ],
                "5": [ "5" ],
                "6": [ "6" ],
                "7": [ "7" ],
                "8": [ "8" ],
                "9": [ "9" ]
            }, !0)).setContents([ "space" ]);
            break;

          case "%keyHat":
            (part = this.labelPart("%key")).isStatic = !0;
            break;

          case "%msg":
            part = new InputSlotMorph(null, !1, "messagesMenu", !0);
            break;

          case "%msgHat":
            (part = new InputSlotMorph(null, !1, "messagesReceivedMenu", !0)).isStatic = !0;
            break;

          case "%att":
            part = new InputSlotMorph(null, !1, "attributesMenu", !0);
            break;

          case "%fun":
            (part = new InputSlotMorph(null, !1, {
                abs: [ "abs" ],
                floor: [ "floor" ],
                sqrt: [ "sqrt" ],
                sin: [ "sin" ],
                cos: [ "cos" ],
                tan: [ "tan" ],
                asin: [ "asin" ],
                acos: [ "acos" ],
                atan: [ "atan" ],
                ln: [ "ln" ],
                "e^": [ "e^" ]
            }, !0)).setContents([ "sqrt" ]);
            break;

          case "%txtfun":
            (part = new InputSlotMorph(null, !1, {
                "encode URI": [ "encode URI" ],
                "decode URI": [ "decode URI" ],
                "encode URI component": [ "encode URI component" ],
                "decode URI component": [ "decode URI component" ],
                "XML escape": [ "XML escape" ],
                "XML unescape": [ "XML unescape" ],
                "hex sha512 hash": [ "hex sha512 hash" ]
            }, !0)).setContents([ "encode URI" ]);
            break;

          case "%stopChoices":
            (part = new InputSlotMorph(null, !1, {
                all: [ "all" ],
                "this script": [ "this script" ],
                "this block": [ "this block" ]
            }, !0)).setContents([ "all" ]), part.isStatic = !0;
            break;

          case "%stopOthersChoices":
            (part = new InputSlotMorph(null, !1, {
                "all but this script": [ "all but this script" ],
                "other scripts in sprite": [ "other scripts in sprite" ]
            }, !0)).setContents([ "all but this script" ]), part.isStatic = !0;
            break;

          case "%typ":
            (part = new InputSlotMorph(null, !1, {
                number: [ "number" ],
                text: [ "text" ],
                Boolean: [ "Boolean" ],
                list: [ "list" ],
                command: [ "command" ],
                reporter: [ "reporter" ],
                predicate: [ "predicate" ]
            }, !0)).setContents([ "number" ]);
            break;

          case "%var":
            (part = new InputSlotMorph(null, !1, "getVarNamesDict", !0)).isStatic = !0;
            break;

          case "%lst":
            part = new InputSlotMorph(null, !1, {
                list1: "list1",
                list2: "list2",
                list3: "list3"
            }, !0);
            break;

          case "%codeKind":
            (part = new InputSlotMorph(null, !1, {
                code: [ "code" ],
                header: [ "header" ]
            }, !0)).setContents([ "code" ]);
            break;

          case "%l":
            part = new ArgMorph("list");
            break;

          case "%b":
          case "%boolUE":
            part = new BooleanSlotMorph(null, !0);
            break;

          case "%cmd":
            part = new CommandSlotMorph();
            break;

          case "%rc":
            (part = new RingCommandSlotMorph()).isStatic = !0;
            break;

          case "%rr":
            (part = new RingReporterSlotMorph()).isStatic = !0;
            break;

          case "%rp":
            (part = new RingReporterSlotMorph(!0)).isStatic = !0;
            break;

          case "%c":
            (part = new CSlotMorph()).isStatic = !0;
            break;

          case "%cs":
            part = new CSlotMorph();
            break;

          case "%clr":
            (part = new ColorSlotMorph()).isStatic = !0;
            break;

          case "%t":
            part = new TemplateSlotMorph("a");
            break;

          case "%upvar":
            part = new TemplateSlotMorph("↑");
            break;

          case "%f":
            part = new FunctionSlotMorph();
            break;

          case "%r":
            part = new ReporterSlotMorph();
            break;

          case "%p":
            part = new ReporterSlotMorph(!0);
            break;

          case "%codeListPart":
            part = new InputSlotMorph(null, !1, {
                list: [ "list" ],
                item: [ "item" ],
                delimiter: [ "delimiter" ]
            }, !0);
            break;

          case "%codeListKind":
            part = new InputSlotMorph(null, !1, {
                collection: [ "collection" ],
                variables: [ "variables" ],
                parameters: [ "parameters" ]
            }, !0);
            break;

          case "%turtle":
            (part = new SymbolMorph("turtle")).size = 1.2 * this.fontSize, part.color = new Color(255, 255, 255), 
            part.shadowColor = this.color.darker(this.labelContrast), part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, 
            part.drawNew();
            break;

          case "%turtleOutline":
            (part = new SymbolMorph("turtleOutline")).size = this.fontSize, part.color = new Color(255, 255, 255), 
            part.isProtectedLabel = !0, part.shadowColor = this.color.darker(this.labelContrast), 
            part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
            break;

          case "%clockwise":
            (part = new SymbolMorph("turnRight")).size = 1.5 * this.fontSize, part.color = new Color(255, 255, 255), 
            part.isProtectedLabel = !1, part.shadowColor = this.color.darker(this.labelContrast), 
            part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
            break;

          case "%counterclockwise":
            (part = new SymbolMorph("turnLeft")).size = 1.5 * this.fontSize, part.color = new Color(255, 255, 255), 
            part.isProtectedLabel = !1, part.shadowColor = this.color.darker(this.labelContrast), 
            part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
            break;

          case "%greenflag":
            (part = new SymbolMorph("flag")).size = 1.5 * this.fontSize, part.color = new Color(0, 200, 0), 
            part.isProtectedLabel = !0, part.shadowColor = this.color.darker(this.labelContrast), 
            part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
            break;

          case "%stop":
            (part = new SymbolMorph("octagon")).size = 1.5 * this.fontSize, part.color = new Color(200, 0, 0), 
            part.isProtectedLabel = !0, part.shadowColor = this.color.darker(this.labelContrast), 
            part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
            break;

          case "%pause":
            (part = new SymbolMorph("pause")).size = this.fontSize, part.color = new Color(255, 220, 0), 
            part.isProtectedLabel = !0, part.shadowColor = this.color.darker(this.labelContrast), 
            part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
            break;

          default:
            nop();
        }
    } else if ("$" === spec[0] && spec.length > 1 && "reportGetVar" !== this.selector) {
        if (tokens = spec.slice(1).split("-"), !contains(SymbolMorph.prototype.names, tokens[0])) return (part = new StringMorph(spec)).fontName = this.labelFontName, 
        part.fontStyle = this.labelFontStyle, part.fontSize = this.fontSize, part.color = new Color(255, 255, 255), 
        part.isBold = !0, part.shadowColor = this.color.darker(this.labelContrast), part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, 
        part.drawNew(), part;
        (part = new SymbolMorph(tokens[0])).size = this.fontSize * (+tokens[1] || 1.2), 
        part.color = new Color(0 == +tokens[2] ? 0 : +tokens[2] || 255, 0 == +tokens[3] ? 0 : +tokens[3] || 255, 0 == +tokens[4] ? 0 : +tokens[4] || 255), 
        part.isProtectedLabel = tokens.length > 2, part.shadowColor = this.color.darker(this.labelContrast), 
        part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, part.drawNew();
    } else (part = new StringMorph(spec)).fontName = this.labelFontName, part.fontStyle = this.labelFontStyle, 
    part.fontSize = this.fontSize, part.color = new Color(255, 255, 255), part.isBold = !0, 
    part.shadowColor = this.color.darker(this.labelContrast), part.shadowOffset = MorphicPreferences.isFlat ? new Point() : this.embossing, 
    part.drawNew();
    return part;
}, SyntaxElementMorph.prototype.isObjInputFragment = function() {
    return "reportGetVar" === this.selector && "%t" === this.getSlotSpec() && "%obj" === this.parent.fragment.type;
}, SyntaxElementMorph.prototype.fixLayout = function() {
    var nb, y, blockHeight, affected, bottomCorrection, parts = this.parts(), myself = this, x = 0, lineHeight = 0, maxX = 0, blockWidth = this.minWidth, l = [], lines = [], space = this.isPrototype ? 1 : Math.floor(fontHeight(this.fontSize) / 3), initialExtent = this.extent();
    if (this instanceof MultiArgMorph && "%c" !== this.slotSpec ? blockWidth += this.arrows().width() : blockWidth += this instanceof ReporterBlockMorph ? 2 * this.rounding + 2 * this.edge : 4 * this.corner + 2 * this.edge + 3 * this.inset + this.dent, 
    this.nextBlock && (nb = this.nextBlock()), parts.forEach(function(part) {
        part instanceof CSlotMorph || "%c" === part.slotSpec ? l.length > 0 ? (lines.push(l), 
        lines.push([ part ]), l = [], x = 0) : lines.push([ part ]) : part instanceof BlockHighlightMorph ? nop() : (part.isVisible && (x += part.fullBounds().width() + space), 
        (x > myself.labelWidth || part.isBlockLabelBreak) && l.length > 0 && (lines.push(l), 
        l = [], x = part.fullBounds().width() + space), l.push(part), part.isBlockLabelBreak && (x = 0));
    }), l.length > 0 && lines.push(l), this instanceof CommandBlockMorph ? (y = this.top() + this.corner + this.edge, 
    this instanceof HatBlockMorph && (y += this.hatHeight)) : this instanceof ReporterBlockMorph ? y = this.top() + 2 * this.edge : (this instanceof MultiArgMorph || this instanceof ArgLabelMorph) && (y = this.top()), 
    lines.forEach(function(line) {
        x = myself.left() + myself.edge + myself.labelPadding, myself instanceof RingMorph ? x = myself.left() + space : myself.isPredicate ? x = myself.left() + myself.rounding : (myself instanceof MultiArgMorph || myself instanceof ArgLabelMorph) && (x = myself.left()), 
        y += lineHeight, lineHeight = 0, line.forEach(function(part) {
            part instanceof CSlotMorph ? (x -= myself.labelPadding, myself.isPredicate && (x = myself.left() + myself.rounding), 
            part.setColor(myself.color), part.setPosition(new Point(x, y)), lineHeight = part.height()) : (part.setPosition(new Point(x, y)), 
            part.isBlockLabelBreak || ("%c" === part.slotSpec ? x += part.width() : part.isVisible && (x += part.fullBounds().width() + space)), 
            maxX = Math.max(maxX, x), lineHeight = Math.max(lineHeight, part instanceof StringMorph ? part.rawHeight() : part.height()));
        }), line.forEach(function(part) {
            part.moveBy(new Point(0, Math.floor((lineHeight - part.height()) / 2)));
        });
    }), y += lineHeight, this.children.some(function(any) {
        return any instanceof CSlotMorph;
    }) && (bottomCorrection = this.bottomPadding, this instanceof ReporterBlockMorph && !this.isPredicate && (bottomCorrection = Math.max(this.bottomPadding, this.rounding - this.bottomPadding)), 
    y += bottomCorrection), this instanceof CommandBlockMorph ? blockHeight = y - this.top() + 2 * this.corner : this instanceof ReporterBlockMorph ? blockHeight = y - this.top() + 2 * this.edge : (this instanceof MultiArgMorph || this instanceof ArgLabelMorph) && (blockHeight = y - this.top()), 
    this.isPredicate ? blockWidth = Math.max(blockWidth, maxX - this.left() + this.rounding) : this instanceof MultiArgMorph || this instanceof ArgLabelMorph ? blockWidth = Math.max(blockWidth, maxX - this.left() - space) : (blockWidth = Math.max(blockWidth, maxX - this.left() + this.labelPadding - this.edge), 
    parts[parts.length - 1] instanceof MultiArgMorph && 1 === lines.length && (blockWidth -= space), 
    this instanceof HatBlockMorph && (blockWidth = Math.max(blockWidth, 1.5 * this.hatWidth))), 
    this.setExtent(new Point(blockWidth, blockHeight)), parts.forEach(function(part) {
        part instanceof CSlotMorph && (myself.isPredicate ? part.setWidth(blockWidth - 2 * myself.rounding) : part.setWidth(blockWidth - myself.edge));
    }), this.drawNew(), nb && nb.setPosition(new Point(this.left(), this.bottom() - this.corner)), 
    this instanceof CommandBlockMorph) {
        if (this.height() !== initialExtent.y && (affected = this.parentThatIsA(CommandSlotMorph)) && affected.fixLayout(), 
        this.width() !== initialExtent.x && (affected = this.parentThatIsAnyOf([ ReporterBlockMorph, CommandSlotMorph, RingCommandSlotMorph ])) && affected.fixLayout(), 
        affected) return;
    } else if (this instanceof ReporterBlockMorph && this.parent && this.parent.fixLayout) return this.parent.fixLayout();
    this.fixHighlight();
}, SyntaxElementMorph.prototype.fixHighlight = function() {
    var top = this.topBlock();
    top.getHighlight && top.getHighlight() && top.addHighlight(top.removeHighlight());
}, SyntaxElementMorph.prototype.evaluate = function() {
    return null;
}, SyntaxElementMorph.prototype.isEmptySlot = function() {
    return !1;
}, SyntaxElementMorph.prototype.showBubble = function(value, exportPic) {
    var bubble, txt, img, morphToShow, isClickable = !1, sf = this.parentThatIsA(ScrollFrameMorph), wrrld = this.world();
    if (void 0 === value || !wrrld) return null;
    value instanceof ListWatcherMorph ? ((morphToShow = value).update(!0), morphToShow.step = value.update, 
    morphToShow.isDraggable = !1, isClickable = !0) : value instanceof Morph ? (img = value.fullImage(), 
    (morphToShow = new Morph()).silentSetWidth(img.width), morphToShow.silentSetHeight(img.height), 
    morphToShow.image = img) : value instanceof Costume ? (img = value.thumbnail(new Point(40, 40)), 
    (morphToShow = new Morph()).silentSetWidth(img.width), morphToShow.silentSetHeight(img.height), 
    morphToShow.image = img) : value instanceof Context ? (img = value.image(), (morphToShow = new Morph()).silentSetWidth(img.width), 
    morphToShow.silentSetHeight(img.height), morphToShow.image = img) : "boolean" == typeof value ? morphToShow = SpriteMorph.prototype.booleanMorph.call(null, value) : isString(value) ? (txt = value.length > 500 ? value.slice(0, 500) + "..." : value, 
    morphToShow = new TextMorph(txt, this.fontSize)) : null === value ? morphToShow = new TextMorph("", this.fontSize) : 0 === value ? morphToShow = new TextMorph("0", this.fontSize) : value.toString && (morphToShow = new TextMorph(value.toString(), this.fontSize)), 
    (bubble = new SpeechBubbleMorph(morphToShow, null, Math.max(this.rounding - 2, 6), 0)).popUp(wrrld, this.rightCenter().add(new Point(2, 0)), isClickable), 
    exportPic && this.exportPictureWithResult(bubble), sf && bubble.keepWithin(sf);
}, SyntaxElementMorph.prototype.exportPictureWithResult = function(aBubble) {
    var scr = this.fullImage(), bub = aBubble.fullImageClassic(), taller = Math.max(0, bub.height - scr.height), pic = newCanvas(new Point(scr.width + bub.width + 2, scr.height + taller)), ctx = pic.getContext("2d");
    ctx.drawImage(scr, 0, pic.height - scr.height), ctx.drawImage(bub, scr.width + 2, 0), 
    window.open(pic.toDataURL());
}, SyntaxElementMorph.prototype.mappedCode = function(definitions) {
    var result = this.evaluate();
    return result instanceof BlockMorph ? result.mappedCode(definitions) : result;
}, SyntaxElementMorph.prototype.startLayout = function() {
    this.topBlock().fullChanged(), Morph.prototype.trackChanges = !1;
}, SyntaxElementMorph.prototype.endLayout = function() {
    Morph.prototype.trackChanges = !0, this.topBlock().fullChanged();
}, BlockMorph.prototype = new SyntaxElementMorph(), BlockMorph.prototype.constructor = BlockMorph, 
BlockMorph.uber = SyntaxElementMorph.prototype, BlockMorph.prototype.zebraContrast = 40, 
BlockMorph.prototype.snapSound = null, BlockMorph.prototype.toggleSnapSound = function() {
    null !== this.snapSound ? this.snapSound = null : (BlockMorph.prototype.snapSound = document.createElement("audio"), 
    BlockMorph.prototype.snapSound.src = "/assets/apps/snap/click.wav"), CommentMorph.prototype.snapSound = BlockMorph.prototype.snapSound;
};

function BlockMorph() {
    this.init();
}

BlockMorph.prototype.init = function() {
    this.selector = null, this.blockSpec = "", this.comment = null, this.instantiationSpec = null, 
    this.category = null, BlockMorph.uber.init.call(this), this.color = new Color(0, 17, 173);
}, BlockMorph.prototype.receiver = function() {
    for (var up = this.parent; up; ) {
        if (up.owner) return up.owner;
        up = up.parent;
    }
    return null;
}, BlockMorph.prototype.toString = function() {
    return "a " + (this.constructor.name || this.constructor.toString().split(" ")[1].split("(")[0]) + ' ("' + this.blockSpec.slice(0, 30) + '...")';
}, BlockMorph.prototype.parseSpec = function(spec) {
    var words, result = [], word = "";
    if (0 === (words = isString(spec) ? spec.split(" ") : []).length && (words = [ spec ]), 
    this.labelWordWrap) return words;
    return words.forEach(function(each) {
        "%" === (w = each)[0] && w.length > 1 ? ("" !== word && (result.push(word), word = ""), 
        result.push(w)) : "" !== word ? word += " " + w : word = w;
        var w;
    }), "" !== word && result.push(word), result;
}, BlockMorph.prototype.setSpec = function(spec) {
    var part, myself = this, inputIdx = -1;
    spec && (this.parts().forEach(function(part) {
        part.destroy();
    }), this.isPrototype && this.add(this.placeHolder()), this.parseSpec(spec).forEach(function(word) {
        "%" === word[0] && (inputIdx += 1), part = myself.labelPart(word), myself.add(part), 
        part instanceof CommandSlotMorph || part.drawNew(), part instanceof RingMorph && part.fixBlockColor(), 
        (part instanceof MultiArgMorph || contains([ CommandSlotMorph, RingCommandSlotMorph ], part.constructor)) && part.fixLayout(), 
        myself.isPrototype && myself.add(myself.placeHolder()), part instanceof InputSlotMorph && myself.definition && part.setChoices.apply(part, myself.definition.inputOptionsOfIdx(inputIdx));
    }), this.blockSpec = spec, this.fixLayout());
}, BlockMorph.prototype.buildSpec = function() {
    var myself = this;
    this.blockSpec = "", this.parts().forEach(function(part) {
        part instanceof StringMorph ? myself.blockSpec += part.text : part instanceof ArgMorph ? myself.blockSpec += part.getSpec() : part.isBlockLabelBreak ? myself.blockSpec += part.getSpec() : myself.blockSpec += "[undefined]", 
        myself.blockSpec += " ";
    }), this.blockSpec = this.blockSpec.trim();
}, BlockMorph.prototype.rebuild = function(contrast) {
    this.setSpec(this.blockSpec), contrast && this.inputs().forEach(function(input) {
        input instanceof ReporterBlockMorph && (input.setColor(input.color.lighter(contrast)), 
        input.setSpec(input.blockSpec));
    });
}, BlockMorph.prototype.userMenu = function() {
    var alternatives, top, blck, menu = new MenuMorph(this), world = this.world(), myself = this, shiftClicked = 16 === world.currentKey;
    return menu.addItem("help...", "showHelp"), shiftClicked && (top = this.topBlock()) instanceof ReporterBlockMorph && menu.addItem("script pic with result...", function() {
        top.ExportResultPic();
    }, "open a new window\nwith a picture of both\nthis script and its result", new Color(100, 0, 0)), 
    this.isTemplate ? (this.parent instanceof SyntaxElementMorph || ("evaluateCustomBlock" !== this.selector && menu.addItem("hide", "hidePrimitive"), 
    StageMorph.prototype.enableCodeMapping && (menu.addLine(), menu.addItem("header mapping...", "mapToHeader"), 
    menu.addItem("code mapping...", "mapToCode"))), menu) : (menu.addLine(), "reportGetVar" === this.selector ? ((blck = this.fullCopy()).addShadow(), 
    menu.addItem("rename...", function() {
        new DialogBoxMorph(myself, myself.setSpec, myself).prompt("Variable name", myself.blockSpec, world, blck.fullImage(), InputSlotMorph.prototype.getVarNamesDict.call(myself));
    })) : SpriteMorph.prototype.blockAlternatives[this.selector] ? menu.addItem("relabel...", function() {
        myself.relabel(SpriteMorph.prototype.blockAlternatives[myself.selector]);
    }) : this.definition && this.alternatives && (alternatives = this.alternatives()).length > 0 && menu.addItem("relabel...", function() {
        myself.relabel(alternatives);
    }), menu.addItem("duplicate", function() {
        var dup = myself.fullCopy(), ide = myself.parentThatIsA(IDE_Morph);
        dup.pickUp(world), ide && (world.hand.grabOrigin = {
            origin: ide.palette,
            position: ide.palette.center()
        });
    }, "make a copy\nand pick it up"), this instanceof CommandBlockMorph && this.nextBlock() && menu.addItem(this.thumbnail(.5, 60, !1), function() {
        var cpy = this.fullCopy(), nb = cpy.nextBlock(), ide = myself.parentThatIsA(IDE_Morph);
        nb && nb.destroy(), cpy.pickUp(world), ide && (world.hand.grabOrigin = {
            origin: ide.palette,
            position: ide.palette.center()
        });
    }, "only duplicate this block"), menu.addItem("delete", "userDestroy"), menu.addItem("script pic...", function() {
        window.open(myself.topBlock().fullImage().toDataURL());
    }, "open a new window\nwith a picture of this script"), this.parentThatIsA(RingMorph) ? (menu.addLine(), 
    menu.addItem("unringify", "unringify"), menu.addItem("ringify", "ringify"), menu) : this.parent instanceof ReporterSlotMorph || this.parent instanceof CommandSlotMorph || this instanceof HatBlockMorph || this instanceof CommandBlockMorph && this.topBlock() instanceof HatBlockMorph ? menu : (menu.addLine(), 
    menu.addItem("ringify", "ringify"), StageMorph.prototype.enableCodeMapping && (menu.addLine(), 
    menu.addItem("header mapping...", "mapToHeader"), menu.addItem("code mapping...", "mapToCode")), 
    menu));
}, BlockMorph.prototype.developersMenu = function() {
    var menu = BlockMorph.uber.developersMenu.call(this);
    return menu.addLine(), menu.addItem("delete block", "deleteBlock"), menu.addItem("spec...", function() {
        new DialogBoxMorph(this, this.setSpec, this).prompt(menu.title + "\nspec", this.blockSpec, this.world());
    }), menu;
}, BlockMorph.prototype.hidePrimitive = function() {
    var cat, ide = this.parentThatIsA(IDE_Morph);
    ide && (StageMorph.prototype.hiddenPrimitives[this.selector] = !0, "lists" === (cat = {
        doWarp: "control",
        reifyScript: "operators",
        reifyReporter: "operators",
        reifyPredicate: "operators",
        doDeclareVariables: "variables"
    }[this.selector] || this.category) && (cat = "variables"), ide.flushBlocksCache(cat), 
    ide.refreshPalette());
}, BlockMorph.prototype.deleteBlock = function() {
    var tobefixed, isindef, scripts = this.parentThatIsA(ScriptsMorph), nb = this.nextBlock ? this.nextBlock() : null;
    scripts && (nb && scripts.add(nb), this.inputs().forEach(function(inp) {
        inp instanceof BlockMorph && scripts.add(inp);
    })), this instanceof ReporterBlockMorph ? this.parent instanceof BlockMorph && this.parent.revertToDefaultInput(this) : this.parent ? this.parent.fixLayout && (tobefixed = this.parentThatIsA(ArgMorph)) : isindef = !0, 
    this.destroy(), isindef && (this.isCorpse = !0), tobefixed && tobefixed.fixLayout();
}, BlockMorph.prototype.ringify = function() {
    var ring = new RingMorph(), top = this.topBlock(), center = top.fullBounds().center();
    if (null === this.parent) return null;
    this.parent instanceof SyntaxElementMorph ? this instanceof ReporterBlockMorph ? (this.parent.silentReplaceInput(this, ring), 
    ring.embed(this)) : top && (top.parent.add(ring), ring.embed(top), ring.setCenter(center)) : (this.parent.add(ring), 
    ring.embed(this), ring.setCenter(center)), this.fixBlockColor(null, !0);
}, BlockMorph.prototype.unringify = function() {
    var block, center, ring = this.parentThatIsA(RingMorph), scripts = this.parentThatIsA(ScriptsMorph);
    if (null === ring) return null;
    block = ring.contents(), center = ring.center(), ring.parent instanceof SyntaxElementMorph ? block instanceof ReporterBlockMorph ? ring.parent.silentReplaceInput(ring, block) : scripts && (scripts.add(block), 
    block.setFullCenter(center), block.moveBy(20), ring.parent.revertToDefaultInput(ring)) : (ring.parent.add(block), 
    block.setFullCenter(center), ring.destroy()), this.fixBlockColor(null, !0);
}, BlockMorph.prototype.relabel = function(alternativeSelectors) {
    var menu = new MenuMorph(this), oldInputs = this.inputs(), myself = this;
    alternativeSelectors.forEach(function(sel) {
        var block = SpriteMorph.prototype.blockForSelector(sel);
        block.restoreInputs(oldInputs), block.fixBlockColor(null, !0), block.addShadow(new Point(3, 3)), 
        menu.addItem(block, function() {
            myself.setSelector(sel);
        });
    }), menu.popup(this.world(), this.bottomLeft().subtract(new Point(8, this instanceof CommandBlockMorph ? this.corner : 0)));
}, BlockMorph.prototype.setSelector = function(aSelector) {
    var info, oldInputs = this.inputs();
    info = SpriteMorph.prototype.blocks[aSelector], this.setCategory(info.category), 
    this.selector = aSelector, this.setSpec(localize(info.spec)), this.restoreInputs(oldInputs), 
    this.fixLabelColor();
}, BlockMorph.prototype.restoreInputs = function(oldInputs) {
    var old, nb, i = 0, myself = this;
    this.inputs().forEach(function(inp) {
        (old = oldInputs[i]) instanceof ReporterBlockMorph ? myself.silentReplaceInput(inp, old.fullCopy()) : old && inp instanceof InputSlotMorph ? old.contents && inp.setContents(old.contents().text) : old instanceof CSlotMorph && inp instanceof CSlotMorph && (nb = old.nestedBlock()) && inp.nestedBlock(nb.fullCopy()), 
        i += 1;
    });
}, BlockMorph.prototype.showHelp = function() {
    var help, comment, block, myself = this, pic = new Image(), isCustomBlock = "evaluateCustomBlock" === this.selector, spec = isCustomBlock ? this.definition.helpSpec() : this.selector;
    pic.onload = function() {
        help = newCanvas(new Point(pic.width, pic.height)), help.getContext("2d").drawImage(pic, 0, 0), 
        new DialogBoxMorph().inform("Help", null, myself.world(), help);
    }, isCustomBlock && this.definition.comment ? ((block = this.fullCopy()).addShadow(), 
    (comment = this.definition.comment.fullCopy()).contents.parse(), help = "", comment.contents.lines.forEach(function(line) {
        help = help + "\n" + line;
    }), new DialogBoxMorph().inform("Help", help.substr(1), myself.world(), block.fullImage())) : pic.src = "/assets/apps/snap/help/" + spec + ".png";
}, BlockMorph.prototype.mapToHeader = function() {
    var help, pic, key = "reify" === this.selector.substr(0, 5) ? "reify" : this.selector, block = this.codeDefinitionHeader(), myself = this;
    block.addShadow(new Point(3, 3)), pic = block.fullImageClassic(), help = this.definition ? "Enter code that corresponds to the block's definition. Use the formal parameter\nnames as shown and <body> to reference the definition body's generated text code." : "Enter code that corresponds to the block's definition. Choose your own\nformal parameter names (ignoring the ones shown).", 
    new DialogBoxMorph(this, function(code) {
        "evaluateCustomBlock" === key ? myself.definition.codeHeader = code : StageMorph.prototype.codeHeaders[key] = code;
    }, this).promptCode("Header mapping", "evaluateCustomBlock" === key ? this.definition.codeHeader || "" : StageMorph.prototype.codeHeaders[key] || "", this.world(), pic, help);
}, BlockMorph.prototype.mapToCode = function() {
    var pic, key = "reify" === this.selector.substr(0, 5) ? "reify" : this.selector, block = this.codeMappingHeader(), myself = this;
    block.addShadow(new Point(3, 3)), pic = block.fullImageClassic(), new DialogBoxMorph(this, function(code) {
        "evaluateCustomBlock" === key ? myself.definition.codeMapping = code : StageMorph.prototype.codeMappings[key] = code;
    }, this).promptCode("Code mapping", "evaluateCustomBlock" === key ? this.definition.codeMapping || "" : StageMorph.prototype.codeMappings[key] || "", this.world(), pic, "Enter code that corresponds to the block's operation (usually a single\nfunction invocation). Use <#n> to reference actual arguments as shown.");
}, BlockMorph.prototype.mapHeader = function(aString, key) {
    var sel = key || "reify" === this.selector.substr(0, 5) ? "reify" : this.selector;
    aString && (this.definition ? this.definition.codeHeader = aString : StageMorph.prototype.codeHeaders[sel] = aString);
}, BlockMorph.prototype.mapCode = function(aString, key) {
    var sel = key || "reify" === this.selector.substr(0, 5) ? "reify" : this.selector;
    aString && (this.definition ? this.definition.codeMapping = aString : StageMorph.prototype.codeMappings[sel] = aString);
}, BlockMorph.prototype.mappedCode = function(definitions) {
    var code, codeLines, header, headers, headerLines, body, bodyLines, key = "reify" === this.selector.substr(0, 5) ? "reify" : this.selector, count = 1, defKey = this.definition ? this.definition.spec : key, defs = definitions || {}, parts = [];
    return code = "reportGetVar" === key ? this.blockSpec : this.definition ? this.definition.codeMapping || "" : StageMorph.prototype.codeMappings[key] || "", 
    "reportGetVar" === key || defs.hasOwnProperty(defKey) || (defs[defKey] = null, this.definition ? (-1 !== (header = this.definition.codeHeader || "").indexOf("<body") && (body = "", 
    this.definition.body && (body = this.definition.body.expression.mappedCode(defs)), 
    bodyLines = body.split("\n"), (headerLines = header.split("\n")).forEach(function(headerLine, idx) {
        var indent, prefix = "";
        0 === headerLine.trimLeft().indexOf("<body") && (indent = headerLine.indexOf("<body"), 
        prefix = headerLine.slice(0, indent)), headerLines[idx] = headerLine.replace(new RegExp("<body>"), bodyLines.join("\n" + prefix)), 
        headerLines[idx] = headerLines[idx].replace(new RegExp("<body>", "g"), bodyLines.join("\n"));
    }), header = headerLines.join("\n")), defs[defKey] = header) : defs[defKey] = StageMorph.prototype.codeHeaders[defKey]), 
    codeLines = code.split("\n"), this.inputs().forEach(function(input) {
        parts.push(input.mappedCode(defs).toString());
    }), parts.forEach(function(part) {
        var partLines = part.split("\n"), placeHolder = "<#" + count + ">", rx = new RegExp(placeHolder, "g");
        codeLines.forEach(function(codeLine, idx) {
            var indent, prefix = "";
            0 === codeLine.trimLeft().indexOf(placeHolder) && (indent = codeLine.indexOf(placeHolder), 
            prefix = codeLine.slice(0, indent)), codeLines[idx] = codeLine.replace(new RegExp(placeHolder), partLines.join("\n" + prefix)), 
            codeLines[idx] = codeLines[idx].replace(rx, partLines.join("\n"));
        }), count += 1;
    }), code = codeLines.join("\n"), this.nextBlock && this.nextBlock() && (code += "\n" + this.nextBlock().mappedCode(defs)), 
    !definitions && (headers = [], Object.keys(defs).forEach(function(each) {
        defs[each] && headers.push(defs[each]);
    }), headers.length) ? headers.join("\n\n") + "\n\n" + code : code;
}, BlockMorph.prototype.codeDefinitionHeader = function() {
    var block = this.definition ? new PrototypeHatBlockMorph(this.definition) : SpriteMorph.prototype.blockForSelector(this.selector), hat = new HatBlockMorph(), count = 1;
    return this.definition ? block : (block.inputs().forEach(function(input) {
        var part = new TemplateSlotMorph("#" + count);
        block.silentReplaceInput(input, part), count += 1;
    }), block.isPrototype = !0, hat.setCategory("control"), hat.setSpec("%s"), hat.silentReplaceInput(hat.inputs()[0], block), 
    "control" === this.category && hat.alternateBlockColor(), hat);
}, BlockMorph.prototype.codeMappingHeader = function() {
    var block = this.definition ? this.definition.blockInstance() : SpriteMorph.prototype.blockForSelector(this.selector), hat = new HatBlockMorph(), count = 1;
    return block.inputs().forEach(function(input) {
        var part = new TemplateSlotMorph("<#" + count + ">");
        block.silentReplaceInput(input, part), count += 1;
    }), block.isPrototype = !0, hat.setCategory("control"), hat.setSpec("%s"), hat.silentReplaceInput(hat.inputs()[0], block), 
    "control" === this.category && hat.alternateBlockColor(), hat;
}, BlockMorph.prototype.eraseHoles = function(context) {
    var gradient, rightX, myself = this, isReporter = this instanceof ReporterBlockMorph, shift = .5 * this.edge, holes = this.parts().filter(function(part) {
        return part.isHole;
    });
    this.isPredicate && holes.length > 0 && (rightX = this.width() - this.rounding, 
    context.clearRect(rightX, 0, this.width(), this.height()), (gradient = context.createLinearGradient(rightX - this.edge, 0, this.width(), 0)).addColorStop(0, this.color.toString()), 
    gradient.addColorStop(1, this.dark()), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(rightX - shift, this.edge + shift), context.lineTo(rightX - shift, this.height() - this.edge - shift), 
    context.stroke()), holes.forEach(function(hole) {
        var w = hole.width(), h = Math.floor(hole.height()) - 2;
        context.clearRect(Math.floor(hole.bounds.origin.x - myself.bounds.origin.x) + 1, Math.floor(hole.bounds.origin.y - myself.bounds.origin.y) + 1, isReporter ? w - 1 : w + 1, h);
    });
}, BlockMorph.prototype.addHighlight = function(oldHighlight) {
    var highlight, isHidden = !this.isVisible;
    return isHidden && this.show(), highlight = this.highlight(oldHighlight ? oldHighlight.color : this.activeHighlight, this.activeBlur, this.activeBorder), 
    this.addBack(highlight), this.fullChanged(), isHidden && this.hide(), highlight;
}, BlockMorph.prototype.addErrorHighlight = function() {
    var highlight, isHidden = !this.isVisible;
    return isHidden && this.show(), this.removeHighlight(), highlight = this.highlight(this.errorHighlight, this.activeBlur, this.activeBorder), 
    this.addBack(highlight), this.fullChanged(), isHidden && this.hide(), highlight;
}, BlockMorph.prototype.removeHighlight = function() {
    var highlight = this.getHighlight();
    return null !== highlight && (this.fullChanged(), this.removeChild(highlight)), 
    highlight;
}, BlockMorph.prototype.toggleHighlight = function() {
    this.getHighlight() ? this.removeHighlight() : this.addHighlight();
}, BlockMorph.prototype.highlight = function(color, blur, border) {
    var highlight = new BlockHighlightMorph(), fb = this.fullBounds(), edge = useBlurredShadows && !MorphicPreferences.isFlat ? blur : border;
    return highlight.setExtent(fb.extent().add(2 * edge)), highlight.color = color, 
    highlight.image = useBlurredShadows && !MorphicPreferences.isFlat ? this.highlightImageBlurred(color, blur) : this.highlightImage(color, border), 
    highlight.setPosition(fb.origin.subtract(new Point(edge, edge))), highlight;
}, BlockMorph.prototype.highlightImage = function(color, border) {
    var fb, img, hi, ctx, out;
    return fb = this.fullBounds().extent(), img = this.fullImage(), (ctx = (hi = newCanvas(fb.add(2 * border))).getContext("2d")).drawImage(img, 0, 0), 
    ctx.drawImage(img, border, 0), ctx.drawImage(img, 2 * border, 0), ctx.drawImage(img, 2 * border, border), 
    ctx.drawImage(img, 2 * border, 2 * border), ctx.drawImage(img, border, 2 * border), 
    ctx.drawImage(img, 0, 2 * border), ctx.drawImage(img, 0, border), ctx.globalCompositeOperation = "destination-out", 
    ctx.drawImage(img, border, border), (ctx = (out = newCanvas(fb.add(2 * border))).getContext("2d")).drawImage(hi, 0, 0), 
    ctx.globalCompositeOperation = "source-atop", ctx.fillStyle = color.toString(), 
    ctx.fillRect(0, 0, out.width, out.height), out;
}, BlockMorph.prototype.highlightImageBlurred = function(color, blur) {
    var fb, img, hi, ctx;
    return fb = this.fullBounds().extent(), img = this.fullImage(), (ctx = (hi = newCanvas(fb.add(2 * blur))).getContext("2d")).shadowBlur = blur, 
    ctx.shadowColor = color.toString(), ctx.drawImage(img, blur, blur), ctx.shadowBlur = 0, 
    ctx.globalCompositeOperation = "destination-out", ctx.drawImage(img, blur, blur), 
    hi;
}, BlockMorph.prototype.getHighlight = function() {
    var highlights;
    return 0 !== (highlights = this.children.slice(0).reverse().filter(function(child) {
        return child instanceof BlockHighlightMorph;
    })).length ? highlights[0] : null;
}, BlockMorph.prototype.fixBlockColor = function(nearestBlock, isForced) {
    var clr, cslot, nearest = nearestBlock;
    if (this.zebraContrast || isForced) {
        if (!this.zebraContrast && isForced) return this.forceNormalColoring();
        nearest || this.parent && (this.isPrototype ? nearest = null : this instanceof ReporterBlockMorph ? nearest = this.parent.parentThatIsA(BlockMorph) : (cslot = this.parentThatIsA(CommandSlotMorph)) && (nearest = cslot.parentThatIsA(BlockMorph))), 
        nearest ? nearest.category === this.category ? nearest.color.eq(this.color) && this.alternateBlockColor() : this.category && !this.color.eq(SpriteMorph.prototype.blockColor[this.category]) && this.alternateBlockColor() : (clr = SpriteMorph.prototype.blockColor[this.category], 
        this.color.eq(clr) || this.alternateBlockColor()), isForced && this.fixChildrensBlockColor(!0);
    }
}, BlockMorph.prototype.forceNormalColoring = function() {
    var clr = SpriteMorph.prototype.blockColor[this.category];
    this.setColor(clr), this.setLabelColor(new Color(255, 255, 255), clr.darker(this.labelContrast), new Point(-1, -1)), 
    this.fixChildrensBlockColor(!0);
}, BlockMorph.prototype.alternateBlockColor = function() {
    var clr = SpriteMorph.prototype.blockColor[this.category];
    this.color.eq(clr) ? this.setColor(this.zebraContrast < 0 ? clr.darker(Math.abs(this.zebraContrast)) : clr.lighter(this.zebraContrast)) : this.setColor(clr), 
    this.fixLabelColor(), this.fixChildrensBlockColor(!0);
}, BlockMorph.prototype.fixLabelColor = function() {
    if (this.zebraContrast > 0 && this.category) {
        var clr = SpriteMorph.prototype.blockColor[this.category];
        this.color.eq(clr) ? this.setLabelColor(new Color(255, 255, 255), clr.darker(this.labelContrast), MorphicPreferences.isFlat ? null : new Point(-1, -1)) : this.setLabelColor(new Color(0, 0, 0), clr.lighter(this.zebraContrast).lighter(2 * this.labelContrast), MorphicPreferences.isFlat ? null : new Point(1, 1));
    }
}, BlockMorph.prototype.fixChildrensBlockColor = function(isForced) {
    var myself = this;
    this.children.forEach(function(morph) {
        morph instanceof CommandBlockMorph ? morph.fixBlockColor(null, isForced) : morph instanceof SyntaxElementMorph && morph.fixBlockColor(myself, isForced);
    });
}, BlockMorph.prototype.setCategory = function(aString) {
    this.category = aString, this.startLayout(), this.fixBlockColor(), this.endLayout();
}, BlockMorph.prototype.fullCopy = function() {
    var ans = BlockMorph.uber.fullCopy.call(this);
    return ans.removeHighlight(), ans.isDraggable = !0, this.instantiationSpec && ans.setSpec(this.instantiationSpec), 
    ans.allChildren().filter(function(block) {
        return !isNil(block.comment);
    }).forEach(function(block) {
        var cmnt = block.comment.fullCopy();
        block.comment = cmnt, cmnt.block = block;
    }), ans;
}, BlockMorph.prototype.mouseClickLeft = function() {
    var stage, top = this.topBlock(), receiver = top.receiver();
    if (top instanceof PrototypeHatBlockMorph) return top.mouseClickLeft();
    receiver && (stage = receiver.parentThatIsA(StageMorph)) && stage.threads.toggleProcess(top);
}, BlockMorph.prototype.thumbnail = function(scale, clipWidth, noShadow) {
    var ext, trgt, ctx, gradient, block = this.fullCopy(), nb = block.nextBlock();
    return nb && nb.destroy(), noShadow || block.addShadow(), ext = block.fullBounds().extent(), 
    noShadow || (ext = ext.subtract(this.shadowBlur * (useBlurredShadows && !MorphicPreferences.isFlat ? 1 : 2))), 
    (ctx = (trgt = newCanvas(new Point(Math.min(ext.x * scale, clipWidth || ext.x), ext.y * scale))).getContext("2d")).scale(scale, scale), 
    ctx.drawImage(block.fullImage(), 0, 0), trgt.width === clipWidth && ((gradient = ctx.createLinearGradient(trgt.width / scale - 12, 0, trgt.width / scale, 0)).addColorStop(0, new Color(255, 255, 255, 0).toString()), 
    gradient.addColorStop(1, "white"), ctx.fillStyle = gradient, ctx.fillRect(trgt.width / scale - 12, 0, trgt.width / scale, trgt.height / scale)), 
    trgt;
}, BlockMorph.prototype.rootForGrab = function() {
    return this;
}, BlockMorph.prototype.wantsDropOf = function(aMorph) {
    return (aMorph instanceof ArgMorph || aMorph instanceof StringMorph || aMorph instanceof TextMorph) && !this.isTemplate;
}, BlockMorph.prototype.reactToDropOf = function(droppedMorph) {
    droppedMorph.isDraggable = !1, droppedMorph instanceof InputSlotMorph ? droppedMorph.drawNew() : droppedMorph instanceof MultiArgMorph && droppedMorph.fixLayout(), 
    this.fixLayout(), this.buildSpec();
}, BlockMorph.prototype.situation = function() {
    var scripts = this.parentThatIsA(ScriptsMorph);
    return scripts ? {
        origin: scripts,
        position: this.position().subtract(scripts.position())
    } : BlockMorph.uber.situation.call(this);
}, BlockMorph.prototype.prepareToBeGrabbed = function(hand) {
    var myself = this;
    this.allComments().forEach(function(comment) {
        comment.startFollowing(myself, hand.world);
    });
}, BlockMorph.prototype.justDropped = function() {
    this.allComments().forEach(function(comment) {
        comment.stopFollowing();
    });
}, BlockMorph.prototype.allComments = function() {
    return this.allChildren().filter(function(block) {
        return !isNil(block.comment);
    }).map(function(block) {
        return block.comment;
    });
}, BlockMorph.prototype.destroy = function() {
    this.allComments().forEach(function(comment) {
        comment.destroy();
    }), BlockMorph.uber.destroy.call(this);
}, BlockMorph.prototype.stackHeight = function() {
    var fb = this.fullBounds(), commentsBottom = Math.max(this.allComments().map(function(comment) {
        return comment.bottom();
    })) || this.bottom();
    return Math.max(fb.bottom(), commentsBottom) - fb.top();
}, BlockMorph.prototype.snap = function() {
    var top = this.topBlock();
    top.allComments().forEach(function(comment) {
        comment.align(top);
    }), this.getHighlight() && this !== top && this.removeHighlight(), top.getHighlight() && top.addHighlight(top.removeHighlight());
}, CommandBlockMorph.prototype = new BlockMorph(), CommandBlockMorph.prototype.constructor = CommandBlockMorph, 
CommandBlockMorph.uber = BlockMorph.prototype;

function CommandBlockMorph() {
    this.init();
}

CommandBlockMorph.prototype.init = function() {
    CommandBlockMorph.uber.init.call(this), this.setExtent(new Point(200, 100)), this.partOfCustomCommand = !1, 
    this.exitTag = null;
}, CommandBlockMorph.prototype.blockSequence = function() {
    var nb = this.nextBlock(), result = [ this ];
    return nb && (result = result.concat(nb.blockSequence())), result;
}, CommandBlockMorph.prototype.bottomBlock = function() {
    return this.nextBlock() ? this.nextBlock().bottomBlock() : this;
}, CommandBlockMorph.prototype.nextBlock = function(block) {
    if (!block) return detect(this.children, function(child) {
        return child instanceof CommandBlockMorph && !child.isPrototype;
    });
    var nb = this.nextBlock(), affected = this.parentThatIsA(CommandSlotMorph);
    this.add(block), nb && block.bottomBlock().nextBlock(nb), this.fixLayout(), affected && affected.fixLayout();
}, CommandBlockMorph.prototype.topAttachPoint = function() {
    return new Point(this.dentCenter(), this.top());
}, CommandBlockMorph.prototype.bottomAttachPoint = function() {
    return new Point(this.dentCenter(), this.bottom());
}, CommandBlockMorph.prototype.dentLeft = function() {
    return this.left() + this.corner + this.inset;
}, CommandBlockMorph.prototype.dentCenter = function() {
    return this.dentLeft() + this.corner + .5 * this.dent;
}, CommandBlockMorph.prototype.attachTargets = function() {
    var answer = [];
    return this instanceof HatBlockMorph || this.parent instanceof SyntaxElementMorph || answer.push({
        point: this.topAttachPoint(),
        element: this,
        loc: "top",
        type: "block"
    }), this.isStop() || answer.push({
        point: this.bottomAttachPoint(),
        element: this,
        loc: "bottom",
        type: "block"
    }), answer;
}, CommandBlockMorph.prototype.allAttachTargets = function(newParent) {
    var myself = this, answer = [];
    return (newParent || this.parent).children.filter(function(child) {
        return child !== myself && child instanceof SyntaxElementMorph && !child.isTemplate;
    }).forEach(function(block) {
        block.forAllChildren(function(child) {
            child.attachTargets && child.attachTargets().forEach(function(at) {
                answer.push(at);
            });
        });
    }), answer;
}, CommandBlockMorph.prototype.closestAttachTarget = function(newParent) {
    var dist, target = newParent || this.parent, bottomBlock = this.bottomBlock(), answer = null, thresh = Math.max(2 * this.corner + this.dent, this.minSnapDistance), ref = [], minDist = 1e3;
    return this instanceof HatBlockMorph || ref.push({
        point: this.topAttachPoint(),
        loc: "top"
    }), this.isStop() || ref.push({
        point: bottomBlock.bottomAttachPoint(),
        loc: "bottom"
    }), this.allAttachTargets(target).forEach(function(eachTarget) {
        ref.forEach(function(eachRef) {
            eachRef.loc !== eachTarget.loc && (dist = eachRef.point.distanceTo(eachTarget.point)) < thresh && dist < minDist && (minDist = dist, 
            answer = eachTarget);
        });
    }), answer;
}, CommandBlockMorph.prototype.snap = function() {
    var next, offsetY, affected, target = this.closestAttachTarget(), scripts = this.parentThatIsA(ScriptsMorph);
    if (scripts.clearDropHistory(), scripts.lastDroppedBlock = this, null === target) return this.startLayout(), 
    this.fixBlockColor(), this.endLayout(), void CommandBlockMorph.uber.snap.call(this);
    scripts.lastDropTarget = target, this.startLayout(), "bottom" === target.loc ? ("slot" === target.type ? (this.removeHighlight(), 
    scripts.lastNextBlock = target.element.nestedBlock(), target.element.nestedBlock(this)) : (scripts.lastNextBlock = target.element.nextBlock(), 
    target.element.nextBlock(this)), this.isStop() && (next = this.nextBlock()) && (scripts.add(next), 
    next.moveBy(this.extent().floorDivideBy(2)), (affected = this.parentThatIsA(CommandSlotMorph)) && affected.fixLayout())) : "top" === target.loc && (target.element.removeHighlight(), 
    offsetY = this.bottomBlock().bottom() - this.bottom(), this.setBottom(target.element.top() + this.corner - offsetY), 
    this.setLeft(target.element.left()), this.bottomBlock().nextBlock(target.element)), 
    this.fixBlockColor(), this.endLayout(), CommandBlockMorph.uber.snap.call(this), 
    this.snapSound && this.snapSound.play();
}, CommandBlockMorph.prototype.isStop = function() {
    return [ "doStopThis", "doStop", "doStopBlock", "doStopAll", "doForever", "doReport", "removeClone" ].indexOf(this.selector) > -1;
}, CommandBlockMorph.prototype.userDestroy = function() {
    if (this.nextBlock()) this.userDestroyJustThis(); else {
        var cslot = this.parentThatIsA(CSlotMorph);
        this.destroy(), cslot && cslot.fixLayout();
    }
}, CommandBlockMorph.prototype.userDestroyJustThis = function() {
    var pb, above, scripts = this.parentThatIsA(ScriptsMorph), cs = this.parentThatIsA(CommandSlotMorph), nb = this.nextBlock(), cslot = this.parentThatIsA(CSlotMorph);
    this.parent && (pb = this.parent.parentThatIsA(CommandBlockMorph)), pb && pb.nextBlock() === this ? above = pb : cs && cs.nestedBlock() === this && (above = cs), 
    this.destroy(), nb ? above instanceof CommandSlotMorph ? above.nestedBlock(nb) : above instanceof CommandBlockMorph ? above.nextBlock(nb) : scripts.add(nb) : cslot && cslot.fixLayout();
}, CommandBlockMorph.prototype.drawNew = function() {
    var context;
    this.cachedClr = this.color.toString(), this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), 
    this.image = newCanvas(this.extent()), (context = this.image.getContext("2d")).fillStyle = this.cachedClr, 
    this.drawTop(context), this.drawBody(context), this.drawBottom(context), MorphicPreferences.isFlat ? nop() : (this.drawTopDentEdge(context, 0, 0), 
    this.drawBottomDentEdge(context, 0, this.height() - this.corner), this.drawLeftEdge(context), 
    this.drawRightEdge(context), this.drawTopLeftEdge(context), this.drawBottomRightEdge(context)), 
    this.eraseHoles(context);
}, CommandBlockMorph.prototype.drawBody = function(context) {
    context.fillRect(0, Math.floor(this.corner), this.width(), this.height() - Math.floor(3 * this.corner) + 1);
}, CommandBlockMorph.prototype.drawTop = function(context) {
    context.beginPath(), context.arc(this.corner, this.corner, this.corner, radians(-180), radians(-90), !1), 
    this.drawDent(context, 0, 0), context.arc(this.width() - this.corner, this.corner, this.corner, radians(-90), radians(-0), !1), 
    context.closePath(), context.fill();
}, CommandBlockMorph.prototype.drawBottom = function(context) {
    var y = this.height() - 2 * this.corner;
    context.beginPath(), context.arc(this.corner, y, this.corner, radians(180), radians(90), !0), 
    this.isStop() || this.drawDent(context, 0, this.height() - this.corner), context.arc(this.width() - this.corner, y, this.corner, radians(90), radians(0), !0), 
    context.closePath(), context.fill();
}, CommandBlockMorph.prototype.drawDent = function(context, x, y) {
    var indent = x + 2 * this.corner + this.inset;
    context.lineTo(x + this.corner + this.inset, y), context.lineTo(indent, y + this.corner), 
    context.lineTo(indent + this.dent, y + this.corner), context.lineTo(x + 3 * this.corner + this.inset + this.dent, y), 
    context.lineTo(this.width() - this.corner, y);
}, CommandBlockMorph.prototype.drawTopDentEdge = function(context, x, y) {
    var upperGradient, lowerGradient, leftGradient, lgx, shift = .5 * this.edge, indent = x + 2 * this.corner + this.inset;
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    (upperGradient = context.createLinearGradient(0, y, 0, y + this.edge)).addColorStop(0, this.cachedClrBright), 
    upperGradient.addColorStop(1, this.cachedClr), context.strokeStyle = upperGradient, 
    context.beginPath(), context.moveTo(this.corner, y + shift), context.lineTo(x + this.corner + this.inset, y + shift), 
    context.stroke(), context.strokeStyle = upperGradient, context.beginPath(), context.moveTo(x + 3 * this.corner + this.inset + this.dent + shift, y + shift), 
    context.lineTo(this.width() - this.corner, y + shift), context.stroke(), lgx = x + this.corner + this.inset, 
    (leftGradient = context.createLinearGradient(lgx - this.edge, y + this.edge, lgx, y)).addColorStop(0, this.cachedClr), 
    leftGradient.addColorStop(1, this.cachedClrBright), context.strokeStyle = leftGradient, 
    context.beginPath(), context.moveTo(x + this.corner + this.inset, y + shift), context.lineTo(indent, y + this.corner + shift), 
    context.stroke(), (lowerGradient = context.createLinearGradient(0, y + this.corner, 0, y + this.corner + this.edge)).addColorStop(0, this.cachedClrBright), 
    lowerGradient.addColorStop(1, this.cachedClr), context.strokeStyle = lowerGradient, 
    context.beginPath(), context.moveTo(indent, y + this.corner + shift), context.lineTo(indent + this.dent, y + this.corner + shift), 
    context.stroke();
}, CommandBlockMorph.prototype.drawBottomDentEdge = function(context, x, y) {
    var upperGradient, lowerGradient, rightGradient, shift = .5 * this.edge, indent = x + 2 * this.corner + this.inset;
    if (context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    (upperGradient = context.createLinearGradient(0, y - this.edge, 0, y)).addColorStop(0, this.cachedClr), 
    upperGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = upperGradient, 
    context.beginPath(), context.moveTo(this.corner, y - shift), this.isStop() ? context.lineTo(this.width() - this.corner, y - shift) : context.lineTo(x + this.corner + this.inset - shift, y - shift), 
    context.stroke(), this.isStop()) return null;
    (lowerGradient = context.createLinearGradient(0, y + this.corner - this.edge, 0, y + this.corner)).addColorStop(0, this.cachedClr), 
    lowerGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = lowerGradient, 
    context.beginPath(), context.moveTo(indent + shift, y + this.corner - shift), context.lineTo(indent + this.dent, y + this.corner - shift), 
    context.stroke(), (rightGradient = context.createLinearGradient(x + indent + this.dent - this.edge, y + this.corner - this.edge, x + indent + this.dent, y + this.corner)).addColorStop(0, this.cachedClr), 
    rightGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = rightGradient, 
    context.beginPath(), context.moveTo(x + indent + this.dent, y + this.corner - shift), 
    context.lineTo(x + 3 * this.corner + this.inset + this.dent, y - shift), context.stroke(), 
    context.strokeStyle = upperGradient, context.beginPath(), context.moveTo(x + 3 * this.corner + this.inset + this.dent, y - shift), 
    context.lineTo(this.width() - this.corner, y - shift), context.stroke();
}, CommandBlockMorph.prototype.drawFlatBottomDentEdge = function(context) {
    this.isStop() || (context.fillStyle = this.color.darker(this.contrast / 2).toString(), 
    context.beginPath(), this.drawDent(context, 0, this.height() - this.corner), context.closePath(), 
    context.fill());
}, CommandBlockMorph.prototype.drawLeftEdge = function(context) {
    var shift = .5 * this.edge, gradient = context.createLinearGradient(0, 0, this.edge, 0);
    gradient.addColorStop(0, this.cachedClrBright), gradient.addColorStop(1, this.cachedClr), 
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    context.strokeStyle = gradient, context.beginPath(), context.moveTo(shift, this.corner), 
    context.lineTo(shift, this.height() - 2 * this.corner - shift), context.stroke();
}, CommandBlockMorph.prototype.drawRightEdge = function(context) {
    var gradient, shift = .5 * this.edge, x = this.width();
    (gradient = context.createLinearGradient(x - this.edge, 0, x, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(x - shift, this.corner + shift), context.lineTo(x - shift, this.height() - 2 * this.corner), 
    context.stroke();
}, CommandBlockMorph.prototype.drawTopLeftEdge = function(context) {
    var gradient, shift = .5 * this.edge;
    (gradient = context.createRadialGradient(this.corner, this.corner, this.corner, this.corner, this.corner, this.corner - this.edge)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.arc(this.corner, this.corner, this.corner - shift, radians(-180), radians(-90), !1), 
    context.stroke();
}, CommandBlockMorph.prototype.drawBottomRightEdge = function(context) {
    var gradient, shift = .5 * this.edge, x = this.width() - this.corner, y = this.height() - 2 * this.corner;
    (gradient = context.createRadialGradient(x, y, this.corner, x, y, this.corner - this.edge)).addColorStop(0, this.cachedClrDark), 
    gradient.addColorStop(1, this.cachedClr), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.arc(x, y, this.corner - shift, radians(90), radians(0), !0), context.stroke();
}, HatBlockMorph.prototype = new CommandBlockMorph(), HatBlockMorph.prototype.constructor = HatBlockMorph, 
HatBlockMorph.uber = CommandBlockMorph.prototype;

function HatBlockMorph() {
    this.init();
}

HatBlockMorph.prototype.init = function() {
    HatBlockMorph.uber.init.call(this), this.setExtent(new Point(300, 150));
}, HatBlockMorph.prototype.blockSequence = function() {
    var result = HatBlockMorph.uber.blockSequence.call(this);
    return result.shift(), result;
}, HatBlockMorph.prototype.drawTop = function(context) {
    var s = this.hatWidth, h = this.hatHeight, r = (4 * h * h + s * s) / (8 * h), sa = degrees(4 * Math.atan(2 * h / s)) / 2, sp = Math.min(1.7 * s, this.width() - this.corner);
    context.beginPath(), context.moveTo(0, h + this.corner), context.arc(s / 2, r, r, radians(-sa - 90), radians(-90), !1), 
    context.bezierCurveTo(s, 0, s, h, sp, h), context.arc(this.width() - this.corner, h + this.corner, this.corner, radians(-90), radians(-0), !1), 
    context.closePath(), context.fill();
}, HatBlockMorph.prototype.drawBody = function(context) {
    context.fillRect(0, this.hatHeight + Math.floor(this.corner) - 1, this.width(), this.height() - Math.floor(3 * this.corner) - this.hatHeight + 2);
}, HatBlockMorph.prototype.drawLeftEdge = function(context) {
    var shift = .5 * this.edge, gradient = context.createLinearGradient(0, 0, this.edge, 0);
    gradient.addColorStop(0, this.cachedClrBright), gradient.addColorStop(1, this.cachedClr), 
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    context.strokeStyle = gradient, context.beginPath(), context.moveTo(shift, this.hatHeight + shift), 
    context.lineTo(shift, this.height() - 2 * this.corner - shift), context.stroke();
}, HatBlockMorph.prototype.drawRightEdge = function(context) {
    var gradient, shift = .5 * this.edge, x = this.width();
    (gradient = context.createLinearGradient(x - this.edge, 0, x, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(x - shift, this.corner + this.hatHeight + shift), context.lineTo(x - shift, this.height() - 2 * this.corner), 
    context.stroke();
}, HatBlockMorph.prototype.drawTopDentEdge = function() {
    return null;
}, HatBlockMorph.prototype.drawTopLeftEdge = function(context) {
    var gradient, shift = .5 * this.edge, s = this.hatWidth, h = this.hatHeight, r = (4 * h * h + s * s) / (8 * h), sa = degrees(4 * Math.atan(2 * h / s)) / 2, sp = Math.min(1.7 * s, this.width() - this.corner);
    (gradient = context.createRadialGradient(s / 2, r, r - this.edge, s / 2, r, r)).addColorStop(1, this.cachedClrBright), 
    gradient.addColorStop(0, this.cachedClr), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.arc(Math.round(s / 2), r, r - shift, radians(-sa - 90), radians(-90), !1), 
    context.moveTo(s / 2, shift), context.bezierCurveTo(s, shift, s, h + shift, sp, h + shift), 
    context.lineTo(this.width() - this.corner, h + shift), context.stroke();
}, ReporterBlockMorph.prototype = new BlockMorph(), ReporterBlockMorph.prototype.constructor = ReporterBlockMorph, 
ReporterBlockMorph.uber = BlockMorph.prototype;

function ReporterBlockMorph(isPredicate) {
    this.init(isPredicate);
}

ReporterBlockMorph.prototype.init = function(isPredicate) {
    ReporterBlockMorph.uber.init.call(this), this.isPredicate = isPredicate || !1, this.setExtent(new Point(200, 80));
}, ReporterBlockMorph.prototype.snap = function(hand) {
    var target, scripts = this.parent;
    if (!scripts instanceof ScriptsMorph) return null;
    scripts.clearDropHistory(), scripts.lastDroppedBlock = this, null !== (target = scripts.closestInput(this, hand)) && (scripts.lastReplacedInput = target, 
    scripts.lastDropTarget = target.parent, target instanceof MultiArgMorph && (scripts.lastPreservedBlocks = target.inputs(), 
    scripts.lastReplacedInput = target.fullCopy()), target.parent.replaceInput(target, this), 
    this.snapSound && this.snapSound.play()), this.startLayout(), this.fixBlockColor(), 
    this.endLayout(), ReporterBlockMorph.uber.snap.call(this);
}, ReporterBlockMorph.prototype.prepareToBeGrabbed = function(handMorph) {
    var oldPos = this.position();
    nop(handMorph), (this.parent instanceof BlockMorph || this.parent instanceof MultiArgMorph || this.parent instanceof ReporterSlotMorph) && (this.parent.revertToDefaultInput(this), 
    this.setPosition(oldPos)), ReporterBlockMorph.uber.prepareToBeGrabbed.call(this, handMorph);
}, ReporterBlockMorph.prototype.blockSequence = function() {
    return this;
}, ReporterBlockMorph.prototype.isUnevaluated = function() {
    return contains([ "%anyUE", "%boolUE", "%f" ], this.getSlotSpec());
}, ReporterBlockMorph.prototype.isLocked = function() {
    return this.isStatic || "%t" === this.getSlotSpec();
}, ReporterBlockMorph.prototype.getSlotSpec = function() {
    var idx;
    return this.parent instanceof BlockMorph && -1 !== (idx = this.parent.parts().filter(function(part) {
        return !(part instanceof BlockHighlightMorph);
    }).indexOf(this)) && this.parent.blockSpec ? this.parseSpec(this.parent.blockSpec)[idx] : this.parent instanceof MultiArgMorph ? this.parent.slotSpec : this.parent instanceof TemplateSlotMorph ? this.parent.getSpec() : null;
}, ReporterBlockMorph.prototype.mouseClickLeft = function(pos) {
    var isRing;
    if (this.parent instanceof BlockInputFragmentMorph) return this.parent.mouseClickLeft();
    this.parent instanceof TemplateSlotMorph ? (isRing = this.parent.parent && this.parent.parent.parent && this.parent.parent.parent instanceof RingMorph, 
    new DialogBoxMorph(this, this.setSpec, this).prompt(isRing ? "Input name" : "Script variable name", this.blockSpec, this.world())) : ReporterBlockMorph.uber.mouseClickLeft.call(this, pos);
}, ReporterBlockMorph.prototype.ExportResultPic = function() {
    var stage, top = this.topBlock(), receiver = top.receiver();
    top === this && receiver && (stage = receiver.parentThatIsA(StageMorph)) && (stage.threads.stopProcess(top), 
    stage.threads.startProcess(top, !1, !0));
}, ReporterBlockMorph.prototype.userDestroy = function() {
    this.prepareToBeGrabbed(this.world().hand), this.destroy();
}, ReporterBlockMorph.prototype.drawNew = function() {
    var context;
    this.cachedClr = this.color.toString(), this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), 
    this.image = newCanvas(this.extent()), (context = this.image.getContext("2d")).fillStyle = this.cachedClr, 
    this.isPredicate ? this.drawDiamond(context) : this.drawRounded(context), this.eraseHoles(context);
}, ReporterBlockMorph.prototype.drawRounded = function(context) {
    var gradient, h = this.height(), r = Math.min(this.rounding, h / 2), w = this.width(), shift = this.edge / 2;
    context.fillStyle = this.cachedClr, context.beginPath(), context.arc(r, r, r, radians(-180), radians(-90), !1), 
    context.arc(w - r, r, r, radians(-90), radians(-0), !1), context.arc(w - r, h - r, r, radians(0), radians(90), !1), 
    context.arc(r, h - r, r, radians(90), radians(180), !1), context.closePath(), context.fill(), 
    MorphicPreferences.isFlat || (context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", (gradient = context.createRadialGradient(r, h - r, r - this.edge, r, h - r, r + this.edge)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.arc(r, h - r, r - shift, radians(90), radians(180), !1), 
    context.stroke(), (gradient = context.createRadialGradient(w - r, r, r - this.edge, w - r, r, r + this.edge)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(w - r, r, r - shift, radians(-90), radians(0), !1), context.stroke(), 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r - shift, shift), context.lineTo(w - r + shift, shift), context.stroke(), 
    (gradient = context.createRadialGradient(r, r, r - this.edge, r, r, r)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.arc(r, r, r - shift, radians(180), radians(270), !1), 
    context.stroke(), (gradient = context.createRadialGradient(w - r, h - r, r - this.edge, w - r, h - r, r)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(w - r, h - r, r - shift, radians(0), radians(90), !1), context.stroke(), 
    (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r - shift, h - shift), context.lineTo(w - r + shift, h - shift), 
    context.stroke(), (gradient = context.createLinearGradient(0, 0, this.edge, 0)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, r), context.lineTo(shift, h - r), context.stroke(), (gradient = context.createLinearGradient(w - this.edge, 0, w, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(w - shift, r + shift), context.lineTo(w - shift, h - r), context.stroke());
}, ReporterBlockMorph.prototype.drawDiamond = function(context) {
    var gradient, w = this.width(), h = this.height(), h2 = Math.floor(h / 2), r = this.rounding, shift = this.edge / 2;
    context.fillStyle = this.cachedClr, context.beginPath(), context.moveTo(0, h2), 
    context.lineTo(r, 0), context.lineTo(w - r, 0), context.lineTo(w, h2), context.lineTo(w - r, h), 
    context.lineTo(r, h), context.closePath(), context.fill(), MorphicPreferences.isFlat || (context.lineWidth = this.edge, 
    context.lineJoin = "round", context.lineCap = "round", (gradient = context.createLinearGradient(-r, 0, r, 0)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(shift, h2), context.lineTo(r, h - shift), context.closePath(), 
    context.stroke(), (gradient = context.createLinearGradient(w - r, 0, w + r, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(w - shift, h2), context.lineTo(w - r, shift), context.closePath(), 
    context.stroke(), (gradient = context.createLinearGradient(0, 0, r, 0)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, h2), context.lineTo(r, shift), context.closePath(), context.stroke(), 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r, shift), context.lineTo(w - r, shift), context.closePath(), context.stroke(), 
    (gradient = context.createLinearGradient(w - r, 0, w, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(w - r, h - shift), context.lineTo(w - shift, h2), context.closePath(), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r + shift, h - shift), context.lineTo(w - r - shift, h - shift), 
    context.closePath(), context.stroke());
}, RingMorph.prototype = new ReporterBlockMorph(), RingMorph.prototype.constructor = RingMorph, 
RingMorph.uber = ReporterBlockMorph.prototype;

function RingMorph() {
    this.init();
}

RingMorph.prototype.init = function() {
    RingMorph.uber.init.call(this), this.category = "other", this.alpha = RingMorph.prototype.alpha, 
    this.contrast = RingMorph.prototype.contrast, this.setExtent(new Point(200, 80));
}, RingMorph.prototype.rootForGrab = function() {
    return this.isDraggable ? this : BlockMorph.uber.rootForGrab.call(this);
}, RingMorph.prototype.embed = function(aBlock, inputNames) {
    var slot;
    this.color = SpriteMorph.prototype.blockColor.other, this.isDraggable = !0, aBlock instanceof CommandBlockMorph ? (this.isStatic = !1, 
    this.setSpec("%rc %ringparms"), this.selector = "reifyScript", (slot = this.parts()[0]).nestedBlock(aBlock)) : aBlock.isPredicate ? (this.isStatic = !0, 
    this.setSpec("%rp %ringparms"), this.selector = "reifyPredicate", (slot = this.parts()[0]).silentReplaceInput(slot.contents(), aBlock)) : (this.isStatic = !1, 
    this.setSpec("%rr %ringparms"), this.selector = "reifyReporter", (slot = this.parts()[0]).silentReplaceInput(slot.contents(), aBlock)), 
    slot = this.parts()[1], inputNames && inputNames.forEach(function(name) {
        slot.addInput(name);
    }), this.fixBlockColor(null, !0);
}, RingMorph.prototype.vanishForSimilar = function() {
    var block = this.parts()[0].nestedBlock();
    return block && this.parent instanceof SyntaxElementMorph ? this.parent instanceof RingReporterSlotMorph || this.parent instanceof RingCommandSlotMorph ? null : void (("reportGetVar" === block.selector || block instanceof RingMorph) && this.parent.silentReplaceInput(this, block)) : null;
}, RingMorph.prototype.contents = function() {
    return this.parts()[0].nestedBlock();
}, RingMorph.prototype.inputNames = function() {
    return this.parts()[1].evaluate();
}, RingMorph.prototype.dataType = function() {
    switch (this.selector) {
      case "reifyScript":
        return "command";

      case "reifyPredicate":
        return "predicate";

      default:
        return "reporter";
    }
}, RingMorph.prototype.fixBlockColor = function(nearest, isForced) {
    var slot = this.parts()[0];
    RingMorph.uber.fixBlockColor.call(this, nearest, isForced), slot instanceof RingCommandSlotMorph && slot.fixLayout();
}, ScriptsMorph.prototype = new FrameMorph(), ScriptsMorph.prototype.constructor = ScriptsMorph, 
ScriptsMorph.uber = FrameMorph.prototype, ScriptsMorph.prototype.cleanUpMargin = 20, 
ScriptsMorph.prototype.cleanUpSpacing = 15, ScriptsMorph.prototype.isPreferringEmptySlots = !0;

function ScriptsMorph(owner) {
    this.init(owner);
}

ScriptsMorph.prototype.init = function(owner) {
    this.owner = owner || null, this.feedbackColor = SyntaxElementMorph.prototype.feedbackColor, 
    this.feedbackMorph = new BoxMorph(), this.lastDroppedBlock = null, this.lastReplacedInput = null, 
    this.lastDropTarget = null, this.lastPreservedBlocks = null, this.lastNextBlock = null, 
    ScriptsMorph.uber.init.call(this), this.setColor(new Color(70, 70, 70));
}, ScriptsMorph.prototype.fullCopy = function() {
    var child, cpy = new ScriptsMorph(), pos = this.position();
    return this.children.forEach(function(morph) {
        morph.block || ((child = morph.fullCopy()).setPosition(morph.position().subtract(pos)), 
        cpy.add(child), child instanceof BlockMorph && child.allComments().forEach(function(comment) {
            comment.align(child);
        }));
    }), cpy.adjustBounds(), cpy;
}, ScriptsMorph.prototype.step = function() {
    var block, hand = this.world().hand;
    return this.feedbackMorph.parent && (this.feedbackMorph.destroy(), this.feedbackMorph.parent = null), 
    0 === hand.children.length ? null : this.bounds.containsPoint(hand.bounds.origin) && ((block = hand.children[0]) instanceof BlockMorph || block instanceof CommentMorph) && contains(hand.morphAtPointer().allParents(), this) ? void (block instanceof CommentMorph ? this.showCommentDropFeedback(block, hand) : block instanceof ReporterBlockMorph ? this.showReporterDropFeedback(block, hand) : this.showCommandDropFeedback(block)) : null;
}, ScriptsMorph.prototype.showReporterDropFeedback = function(block, hand) {
    var target = this.closestInput(block, hand);
    if (null === target) return null;
    this.feedbackMorph.bounds = target.fullBounds().expandBy(Math.max(2 * block.edge, block.reporterDropFeedbackPadding)), 
    this.feedbackMorph.edge = SyntaxElementMorph.prototype.rounding, this.feedbackMorph.border = Math.max(SyntaxElementMorph.prototype.edge, 3), 
    this.add(this.feedbackMorph), target instanceof MultiArgMorph ? (this.feedbackMorph.color = SpriteMorph.prototype.blockColor.lists.copy(), 
    this.feedbackMorph.borderColor = SpriteMorph.prototype.blockColor.lists) : (this.feedbackMorph.color = this.feedbackColor.copy(), 
    this.feedbackMorph.borderColor = this.feedbackColor), this.feedbackMorph.color.a = .5, 
    this.feedbackMorph.drawNew(), this.feedbackMorph.changed();
}, ScriptsMorph.prototype.showCommandDropFeedback = function(block) {
    var y, target;
    if (!(target = block.closestAttachTarget(this))) return null;
    this.add(this.feedbackMorph), this.feedbackMorph.border = 0, this.feedbackMorph.edge = 0, 
    this.feedbackMorph.alpha = 1, this.feedbackMorph.setExtent(new Point(target.element.width(), Math.max(SyntaxElementMorph.prototype.corner, SyntaxElementMorph.prototype.feedbackMinHeight))), 
    this.feedbackMorph.color = this.feedbackColor, this.feedbackMorph.drawNew(), this.feedbackMorph.changed(), 
    y = target.point.y, "bottom" === target.loc && ("block" === target.type ? target.element.nextBlock() && (y -= SyntaxElementMorph.prototype.corner) : "slot" === target.type && target.element.nestedBlock() && (y -= SyntaxElementMorph.prototype.corner)), 
    this.feedbackMorph.setPosition(new Point(target.element.left(), y));
}, ScriptsMorph.prototype.showCommentDropFeedback = function(comment, hand) {
    var target = this.closestBlock(comment, hand);
    if (!target) return null;
    this.feedbackMorph.bounds = target.bounds.expandBy(Math.max(2 * BlockMorph.prototype.edge, BlockMorph.prototype.reporterDropFeedbackPadding)), 
    this.feedbackMorph.edge = SyntaxElementMorph.prototype.rounding, this.feedbackMorph.border = Math.max(SyntaxElementMorph.prototype.edge, 3), 
    this.add(this.feedbackMorph), this.feedbackMorph.color = comment.color.copy(), this.feedbackMorph.color.a = .25, 
    this.feedbackMorph.borderColor = comment.titleBar.color, this.feedbackMorph.drawNew(), 
    this.feedbackMorph.changed();
}, ScriptsMorph.prototype.closestInput = function(reporter, hand) {
    var handPos, target, all, fb = reporter.fullBoundsNoShadow(), stacks = this.children.filter(function(child) {
        return child instanceof BlockMorph && child.fullBounds().intersects(fb);
    }), blackList = reporter.allInputs();
    if (all = [], stacks.forEach(function(stack) {
        all = all.concat(stack.allInputs());
    }), 0 === all.length) return null;
    function touchingVariadicArrowsIfAny(inp, point) {
        return !(inp instanceof MultiArgMorph) || (point ? inp.arrows().bounds.containsPoint(point) : inp.arrows().bounds.intersects(fb));
    }
    if (this.isPreferringEmptySlots) {
        if (hand && (handPos = hand.position(), target = detect(all, function(input) {
            return (input instanceof InputSlotMorph || input instanceof ArgMorph || input instanceof RingMorph && !input.contents() || input.isEmptySlot()) && !input.isLocked() && input.bounds.containsPoint(handPos) && !contains(blackList, input) && touchingVariadicArrowsIfAny(input, handPos);
        }))) return target;
        if (target = detect(all, function(input) {
            return (input instanceof InputSlotMorph || input instanceof ArgMorph || input instanceof RingMorph && !input.contents() || input.isEmptySlot()) && !input.isLocked() && input.bounds.intersects(fb) && !contains(blackList, input) && touchingVariadicArrowsIfAny(input);
        })) return target;
    }
    return hand && (handPos = hand.position(), target = detect(all, function(input) {
        return input !== reporter && !input.isLocked() && input.bounds.containsPoint(handPos) && !(input.parent instanceof PrototypeHatBlockMorph) && !contains(blackList, input);
    })) ? target : detect(all, function(input) {
        return input !== reporter && !input.isLocked() && input.fullBounds().intersects(fb) && !(input.parent instanceof PrototypeHatBlockMorph) && !contains(blackList, input);
    });
}, ScriptsMorph.prototype.closestBlock = function(comment, hand) {
    var handPos, target, all, fb = comment.bounds, stacks = this.children.filter(function(child) {
        return child instanceof BlockMorph && child.fullBounds().intersects(fb);
    });
    return all = [], stacks.forEach(function(stack) {
        all = all.concat(stack.allChildren().slice(0).reverse().filter(function(child) {
            return child instanceof BlockMorph && !child.isTemplate;
        }));
    }), 0 === all.length ? null : hand && (handPos = hand.position(), target = detect(all, function(block) {
        return !block.comment && !block.isPrototype && block.bounds.containsPoint(handPos);
    })) ? target : detect(all, function(block) {
        return !block.comment && !block.isPrototype && block.bounds.intersects(fb);
    });
}, ScriptsMorph.prototype.userMenu = function() {
    var blockEditor, menu = new MenuMorph(this), ide = this.parentThatIsA(IDE_Morph), myself = this, obj = this.owner, stage = obj.parentThatIsA(StageMorph);
    return ide || (blockEditor = this.parentThatIsA(BlockEditorMorph)) && (ide = blockEditor.target.parentThatIsA(IDE_Morph)), 
    menu.addItem("clean up", "cleanUp", "arrange scripts\nvertically"), menu.addItem("add comment", "addComment"), 
    this.lastDroppedBlock && menu.addItem("undrop", "undrop", "undo the last\nblock drop\nin this pane"), 
    menu.addItem("scripts pic...", "exportScriptsPicture", "open a new window\nwith a picture of all scripts"), 
    ide && (menu.addLine(), menu.addItem("make a block...", function() {
        new BlockDialogMorph(null, function(definition) {
            "" !== definition.spec && (definition.isGlobal ? stage.globalBlocks.push(definition) : obj.customBlocks.push(definition), 
            ide.flushPaletteCache(), ide.refreshPalette(), new BlockEditorMorph(definition, obj).popUp());
        }, myself).prompt("Make a block", null, myself.world());
    })), menu;
}, ScriptsMorph.prototype.cleanUp = function() {
    var origin = this.topLeft(), y = this.cleanUpMargin, myself = this;
    this.children.sort(function(a, b) {
        return a instanceof PrototypeHatBlockMorph ? 0 : a.top() - b.top();
    }).forEach(function(child) {
        child instanceof CommentMorph && child.block || (child.setPosition(origin.add(new Point(myself.cleanUpMargin, y))), 
        child instanceof BlockMorph && child.allComments().forEach(function(comment) {
            comment.align(child, !0);
        }), y += child.stackHeight() + myself.cleanUpSpacing);
    }), this.parent && this.setPosition(this.parent.topLeft()), this.adjustBounds();
}, ScriptsMorph.prototype.exportScriptsPicture = function() {
    var pic = this.scriptsPicture();
    pic && window.open(pic.toDataURL());
}, ScriptsMorph.prototype.scriptsPicture = function() {
    var boundingBox, pic, ctx;
    if (0 !== this.children.length) return boundingBox = this.children[0].fullBounds(), 
    this.children.forEach(function(child) {
        child.isVisible && (boundingBox = boundingBox.merge(child.fullBounds()));
    }), pic = newCanvas(boundingBox.extent()), ctx = pic.getContext("2d"), this.children.forEach(function(child) {
        var pos = child.position();
        child.isVisible && ctx.drawImage(child.fullImageClassic(), pos.x - boundingBox.origin.x, pos.y - boundingBox.origin.y);
    }), pic;
}, ScriptsMorph.prototype.addComment = function() {
    new CommentMorph().pickUp(this.world());
}, ScriptsMorph.prototype.undrop = function() {
    this.lastDroppedBlock && (this.lastDroppedBlock instanceof CommandBlockMorph ? (this.lastNextBlock && this.add(this.lastNextBlock), 
    this.lastDropTarget && ("bottom" === this.lastDropTarget.loc ? "slot" === this.lastDropTarget.type ? this.lastNextBlock && this.lastDropTarget.element.nestedBlock(this.lastNextBlock) : this.lastNextBlock && this.lastDropTarget.element.nextBlock(this.lastNextBlock) : "top" === this.lastDropTarget.loc && this.add(this.lastDropTarget.element))) : this.lastDropTarget && (this.lastDropTarget.replaceInput(this.lastDroppedBlock, this.lastReplacedInput), 
    this.lastDropTarget.fixBlockColor(null, !0), this.lastPreservedBlocks && this.lastPreservedBlocks.forEach(function(morph) {
        morph.destroy();
    })), this.lastDroppedBlock.pickUp(this.world()), this.clearDropHistory());
}, ScriptsMorph.prototype.clearDropHistory = function() {
    this.lastDroppedBlock = null, this.lastReplacedInput = null, this.lastDropTarget = null, 
    this.lastPreservedBlocks = null, this.lastNextBlock = null;
}, ScriptsMorph.prototype.fixMultiArgs = function() {
    var oldFlag = Morph.prototype.trackChanges;
    Morph.prototype.trackChanges = !1, this.forAllChildren(function(morph) {
        morph instanceof MultiArgMorph && morph.fixLayout();
    }), Morph.prototype.trackChanges = oldFlag;
}, ScriptsMorph.prototype.wantsDropOf = function(aMorph) {
    return aMorph instanceof SyntaxElementMorph || aMorph instanceof CommentMorph;
}, ScriptsMorph.prototype.reactToDropOf = function(droppedMorph, hand) {
    (droppedMorph instanceof BlockMorph || droppedMorph instanceof CommentMorph) && droppedMorph.snap(hand), 
    this.adjustBounds();
}, ArgMorph.prototype = new SyntaxElementMorph(), ArgMorph.prototype.constructor = ArgMorph, 
ArgMorph.uber = SyntaxElementMorph.prototype;

function ArgMorph(type) {
    this.init(type);
}

ArgMorph.prototype.init = function(type) {
    this.type = type || null, this.isHole = !1, ArgMorph.uber.init.call(this), this.color = new Color(0, 17, 173), 
    this.setExtent(new Point(50, 50));
}, ArgMorph.prototype.justDropped = function() {
    this instanceof CommandSlotMorph || (this.drawNew(), this.changed());
}, ArgMorph.prototype.getSpec = function() {
    return "%s";
}, ArgMorph.prototype.drawNew = function() {
    "list" === this.type ? (this.image = this.listIcon(), this.silentSetExtent(new Point(this.image.width, this.image.height))) : "object" === this.type ? (this.image = this.objectIcon(), 
    this.silentSetExtent(new Point(this.image.width, this.image.height))) : ArgMorph.uber.drawNew.call(this);
}, ArgMorph.prototype.listIcon = function() {
    var source, icon, context, ratio, frame = new Morph(), first = new CellMorph(), second = new CellMorph();
    return frame.color = new Color(255, 255, 255), second.setPosition(first.bottomLeft().add(new Point(0, this.fontSize / 3))), 
    first.add(second), first.setPosition(frame.position().add(this.fontSize)), frame.add(first), 
    frame.bounds.corner = second.bounds.corner.add(this.fontSize), frame.drawNew(), 
    source = frame.fullImage(), ratio = (this.fontSize + this.edge) / source.height, 
    (context = (icon = newCanvas(new Point(Math.ceil(source.width * ratio) + 1, Math.ceil(source.height * ratio) + 1))).getContext("2d")).fillStyle = "black", 
    context.fillRect(0, 0, icon.width, icon.height), context.scale(ratio, ratio), context.drawImage(source, 1 / ratio, 1 / ratio), 
    icon;
}, ArgMorph.prototype.objectIcon = function() {
    return this.labelPart("%turtle").image;
}, ArgMorph.prototype.isEmptySlot = function() {
    return null !== this.type;
}, CommandSlotMorph.prototype = new ArgMorph(), CommandSlotMorph.prototype.constructor = CommandSlotMorph, 
CommandSlotMorph.uber = ArgMorph.prototype;

function CommandSlotMorph() {
    this.init();
}

CommandSlotMorph.prototype.init = function() {
    CommandSlotMorph.uber.init.call(this), this.color = new Color(0, 17, 173), this.setExtent(new Point(230, 4 * this.corner + this.cSlotPadding));
}, CommandSlotMorph.prototype.getSpec = function() {
    return "%cmd";
}, CommandSlotMorph.prototype.topBlock = function() {
    return this.parent.topBlock ? this.parent.topBlock() : this.nestedBlock();
}, CommandSlotMorph.prototype.nestedBlock = function(block) {
    if (!block) return detect(this.children, function(child) {
        return child instanceof CommandBlockMorph;
    });
    var nb = this.nestedBlock();
    this.add(block), nb && block.bottomBlock().nextBlock(nb), this.fixLayout();
}, CommandSlotMorph.prototype.slotAttachPoint = function() {
    return new Point(this.dentCenter(), this.top() + 2 * this.corner);
}, CommandSlotMorph.prototype.dentLeft = function() {
    return this.left() + this.corner + 2 * this.inset;
}, CommandSlotMorph.prototype.dentCenter = function() {
    return this.dentLeft() + this.corner + .5 * this.dent;
}, CommandSlotMorph.prototype.attachTargets = function() {
    var answer = [];
    return answer.push({
        point: this.slotAttachPoint(),
        element: this,
        loc: "bottom",
        type: "slot"
    }), answer;
}, CommandSlotMorph.prototype.fixLayout = function() {
    var nb = this.nestedBlock();
    this.parent && (this.color.eq(this.parent.color) || this.setColor(this.parent.color)), 
    nb ? (nb.setPosition(new Point(this.left() + this.edge + this.rfBorder, this.top() + this.edge + this.rfBorder)), 
    this.setWidth(nb.fullBounds().width() + 2 * (this.edge + this.rfBorder)), this.setHeight(nb.fullBounds().height() + this.edge + 2 * this.rfBorder - (this.corner - this.edge))) : (this.setHeight(4 * this.corner), 
    this.setWidth(4 * this.corner + this.inset + this.dent)), this.parent.fixLayout && this.parent.fixLayout();
}, CommandSlotMorph.prototype.evaluate = function() {
    return this.nestedBlock();
}, CommandSlotMorph.prototype.isEmptySlot = function() {
    return !this.isStatic && null === this.nestedBlock();
}, CommandSlotMorph.prototype.attach = function() {
    var choices = this.overlappedMorphs(), menu = new MenuMorph(this, "choose new parent:"), myself = this;
    choices.forEach(function(each) {
        menu.addItem(each.toString().slice(0, 50), function() {
            each.add(myself), myself.isDraggable = !1, each.fixLayout && each.fixLayout();
        });
    }), choices.length > 0 && menu.popUpAtHand(this.world());
}, CommandSlotMorph.prototype.drawNew = function() {
    var context;
    this.cachedClr = this.color.toString(), this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), 
    this.image = newCanvas(this.extent()), (context = this.image.getContext("2d")).fillStyle = this.cachedClr, 
    context.fillRect(0, 0, this.width(), this.height()), context.fillStyle = this.rfColor.toString(), 
    this.drawFlat(context), MorphicPreferences.isFlat || this.drawEdges(context);
}, CommandSlotMorph.prototype.drawFlat = function(context) {
    var isFilled = null !== this.nestedBlock(), ins = isFilled ? this.inset : this.inset / 2, dent = isFilled ? this.dent : this.dent / 2, indent = 2 * this.corner + ins, edge = this.edge, rf = isFilled ? this.rfBorder : 0, y = this.height() - this.corner - edge;
    context.beginPath(), context.arc(this.corner + edge, this.corner + edge, this.corner, radians(-180), radians(-90), !1), 
    context.lineTo(this.corner + ins + edge + 2 * rf, edge), context.lineTo(indent + edge + 2 * rf, this.corner + edge), 
    context.lineTo(indent + edge + 2 * rf + (dent - 2 * rf), this.corner + edge), context.lineTo(indent + edge + 2 * rf + (dent - 2 * rf) + this.corner, edge), 
    context.lineTo(this.width() - this.corner - edge, edge), context.arc(this.width() - this.corner - edge, this.corner + edge, this.corner, radians(-90), radians(-0), !1), 
    context.arc(this.width() - this.corner - edge, y, this.corner, radians(0), radians(90), !1), 
    context.arc(this.corner + edge, y, this.corner, radians(90), radians(180), !1), 
    context.closePath(), context.fill();
}, CommandSlotMorph.prototype.drawEdges = function(context) {
    var gradient, upperGradient, lowerGradient, rightGradient, isFilled = null !== this.nestedBlock(), ins = isFilled ? this.inset : this.inset / 2, dent = isFilled ? this.dent : this.dent / 2, indent = 2 * this.corner + ins, edge = this.edge, rf = isFilled ? this.rfBorder : 0, shift = .5 * this.edge;
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    (gradient = context.createLinearGradient(0, this.height(), 0, this.height() - this.edge)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(this.corner + edge, this.height() - shift), 
    context.lineTo(this.width() - this.corner - edge, this.height() - shift), context.stroke(), 
    (gradient = context.createRadialGradient(this.width() - (this.corner + edge), this.height() - (this.corner + edge), this.corner, this.width() - (this.corner + edge), this.height() - (this.corner + edge), this.corner + edge)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(this.width() - (this.corner + edge), this.height() - (this.corner + edge), this.corner + shift, radians(0), radians(90), !1), 
    context.stroke(), (gradient = context.createLinearGradient(this.width(), 0, this.width() - this.edge, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(this.width() - shift, this.height() - this.corner - this.edge), 
    context.lineTo(this.width() - shift, edge + this.corner), context.stroke(), context.shadowOffsetY = shift, 
    context.shadowBlur = this.edge, context.shadowColor = this.rfColor.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, edge, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, edge + this.corner), context.lineTo(shift, this.height() - edge - this.corner), 
    context.stroke(), (gradient = context.createRadialGradient(this.corner + edge, this.corner + edge, this.corner, this.corner + edge, this.corner + edge, this.corner + edge)).addColorStop(0, this.cachedClrDark), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(this.corner + edge, this.corner + edge, this.corner + shift, radians(-180), radians(-90), !1), 
    context.stroke(), (upperGradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClr), 
    upperGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = upperGradient, 
    context.beginPath(), context.moveTo(this.corner + edge, shift), context.lineTo(this.corner + ins + edge + 2 * rf - shift, shift), 
    context.stroke(), (lowerGradient = context.createLinearGradient(0, this.corner, 0, this.corner + edge)).addColorStop(0, this.cachedClr), 
    lowerGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = lowerGradient, 
    context.beginPath(), context.moveTo(indent + edge + 2 * rf + shift, this.corner + shift), 
    context.lineTo(indent + edge + 2 * rf + (dent - 2 * rf), this.corner + shift), context.stroke(), 
    (rightGradient = context.createLinearGradient(indent + edge + 2 * rf + (dent - 2 * rf) - shift, this.corner, indent + edge + 2 * rf + (dent - 2 * rf) + .7 * shift, this.corner + shift + .7 * shift)).addColorStop(0, this.cachedClr), 
    rightGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = rightGradient, 
    context.beginPath(), context.moveTo(indent + edge + 2 * rf + (dent - 2 * rf), this.corner + shift), 
    context.lineTo(indent + edge + 2 * rf + (dent - 2 * rf) + this.corner, shift), context.stroke(), 
    context.strokeStyle = upperGradient, context.beginPath(), context.moveTo(indent + edge + 2 * rf + (dent - 2 * rf) + this.corner, shift), 
    context.lineTo(this.width() - this.corner - edge, shift), context.stroke();
}, RingCommandSlotMorph.prototype = new CommandSlotMorph(), RingCommandSlotMorph.prototype.constructor = RingCommandSlotMorph, 
RingCommandSlotMorph.uber = CommandSlotMorph.prototype, RingCommandSlotMorph.prototype.rfBorder = 0, 
RingCommandSlotMorph.prototype.edge = RingMorph.prototype.edge;

function RingCommandSlotMorph() {
    this.init();
}

RingCommandSlotMorph.prototype.init = function() {
    RingCommandSlotMorph.uber.init.call(this), this.isHole = !0, this.noticesTransparentClick = !0, 
    this.color = new Color(0, 17, 173), this.alpha = RingMorph.prototype.alpha, this.contrast = RingMorph.prototype.contrast;
}, RingCommandSlotMorph.prototype.getSpec = function() {
    return "%rc";
}, RingCommandSlotMorph.prototype.drawNew = function() {
    var context;
    this.cachedClr = this.color.toString(), this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), 
    this.image = newCanvas(this.extent()), (context = this.image.getContext("2d")).fillStyle = this.cachedClr, 
    this.drawFlat(context), MorphicPreferences.isFlat || this.drawEdges(context);
}, RingCommandSlotMorph.prototype.drawFlat = function(context) {
    var isFilled = null !== this.nestedBlock(), ins = isFilled ? this.inset : this.inset / 2, dent = isFilled ? this.dent : this.dent / 2, indent = 2 * this.corner + ins, edge = this.edge, w = this.width(), h = this.height(), rf = isFilled ? this.rfBorder : 0, y = h - this.corner - edge;
    context.beginPath(), context.moveTo(0, h / 2), context.lineTo(edge, h / 2), context.arc(this.corner + edge, this.corner + edge, this.corner, radians(-180), radians(-90), !1), 
    context.lineTo(this.corner + ins + edge + 2 * rf, edge), context.lineTo(indent + edge + 2 * rf, this.corner + edge), 
    context.lineTo(indent + edge + 2 * rf + (dent - 2 * rf), this.corner + edge), context.lineTo(indent + edge + 2 * rf + (dent - 2 * rf) + this.corner, edge), 
    context.lineTo(this.width() - this.corner - edge, edge), context.arc(w - this.corner - edge, this.corner + edge, this.corner, radians(-90), radians(-0), !1), 
    context.lineTo(w - this.edge, h / 2), context.lineTo(w, h / 2), context.lineTo(w, 0), 
    context.lineTo(0, 0), context.closePath(), context.fill(), context.beginPath(), 
    context.moveTo(w, h / 2), context.lineTo(w - edge, h / 2), context.arc(this.width() - this.corner - edge, y, this.corner, radians(0), radians(90), !1), 
    context.arc(this.corner + edge, y, this.corner, radians(90), radians(180), !1), 
    context.lineTo(edge, h / 2), context.lineTo(0, h / 2), context.lineTo(0, h), context.lineTo(w, h), 
    context.closePath(), context.fill();
}, CSlotMorph.prototype = new CommandSlotMorph(), CSlotMorph.prototype.constructor = CSlotMorph, 
CSlotMorph.uber = CommandSlotMorph.prototype;

function CSlotMorph() {
    this.init();
}

CSlotMorph.prototype.init = function() {
    CommandSlotMorph.uber.init.call(this), this.isHole = !0, this.color = new Color(0, 17, 173), 
    this.setExtent(new Point(230, 4 * this.corner + this.cSlotPadding));
}, CSlotMorph.prototype.getSpec = function() {
    return "%c";
}, CSlotMorph.prototype.mappedCode = function(definitions) {
    var codeLines = (StageMorph.prototype.codeMappings.reify || "<#1>").split("\n"), nested = this.nestedBlock(), partLines = (nested ? nested.mappedCode(definitions) : "").toString().split("\n"), rx = new RegExp("<#1>", "g");
    return codeLines.forEach(function(codeLine, idx) {
        var indent, prefix = "";
        0 === codeLine.trimLeft().indexOf("<#1>") && (indent = codeLine.indexOf("<#1>"), 
        prefix = codeLine.slice(0, indent)), codeLines[idx] = codeLine.replace(new RegExp("<#1>"), partLines.join("\n" + prefix)), 
        codeLines[idx] = codeLines[idx].replace(rx, partLines.join("\n"));
    }), codeLines.join("\n");
}, CSlotMorph.prototype.fixLayout = function() {
    var nb = this.nestedBlock();
    nb ? (nb.setPosition(new Point(this.left() + this.inset, this.top() + this.corner)), 
    this.setHeight(nb.fullBounds().height() + this.corner), this.setWidth(nb.fullBounds().width() + 2 * this.cSlotPadding)) : (this.setHeight(4 * this.corner + this.cSlotPadding), 
    this.setWidth(4 * this.corner + 2 * this.inset + this.dent + 2 * this.cSlotPadding)), 
    this.parent.fixLayout && this.parent.fixLayout();
}, CSlotMorph.prototype.drawNew = function() {
    var context;
    this.cachedClr = this.color.toString(), this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), 
    this.image = newCanvas(this.extent()), (context = this.image.getContext("2d")).fillStyle = this.cachedClr, 
    this.drawFlat(context), MorphicPreferences.isFlat || (this.drawTopRightEdge(context), 
    this.drawTopEdge(context, this.inset, this.corner), this.drawTopLeftEdge(context), 
    this.drawBottomEdge(context), this.drawRightEdge(context));
}, CSlotMorph.prototype.drawFlat = function(context) {
    context.beginPath(), context.moveTo(0, 0), context.lineTo(this.width(), 0), context.arc(this.width() - this.corner, 0, this.corner, radians(90), radians(0), !0), 
    context.lineTo(this.width() - this.corner, this.corner), context.lineTo(2 * this.inset + 3 * this.corner + this.dent, this.corner), 
    context.lineTo(2 * this.inset + 2 * this.corner + this.dent, 2 * this.corner), context.lineTo(2 * this.inset + 2 * this.corner, 2 * this.corner), 
    context.lineTo(2 * this.inset + this.corner, this.corner), context.lineTo(this.inset + this.corner, this.corner), 
    context.arc(this.inset + this.corner, 2 * this.corner, this.corner, radians(270), radians(180), !0), 
    context.lineTo(this.inset, this.height() - 2 * this.corner), context.arc(this.inset + this.corner, this.height() - 2 * this.corner, this.corner, radians(180), radians(90), !0), 
    context.lineTo(this.width() - this.corner, this.height() - this.corner), context.arc(this.width() - this.corner, this.height(), this.corner, radians(-90), radians(-0), !1), 
    context.lineTo(0, this.height()), context.closePath(), context.fill();
}, CSlotMorph.prototype.drawTopRightEdge = function(context) {
    var gradient, shift = .5 * this.edge, x = this.width() - this.corner;
    (gradient = context.createRadialGradient(x, 0, this.corner, x, 0, this.corner - this.edge)).addColorStop(0, this.cachedClrDark), 
    gradient.addColorStop(1, this.cachedClr), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.arc(x, 0, this.corner - shift, radians(90), radians(0), !0), context.stroke();
}, CSlotMorph.prototype.drawTopEdge = function(context, x, y) {
    var upperGradient, lowerGradient, rightGradient, shift = .5 * this.edge, indent = x + 2 * this.corner + this.inset;
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    (upperGradient = context.createLinearGradient(0, y - this.edge, 0, y)).addColorStop(0, this.cachedClr), 
    upperGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = upperGradient, 
    context.beginPath(), context.moveTo(x + this.corner, y - shift), context.lineTo(x + this.corner + this.inset - shift, y - shift), 
    context.stroke(), (lowerGradient = context.createLinearGradient(0, y + this.corner - this.edge, 0, y + this.corner)).addColorStop(0, this.cachedClr), 
    lowerGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = lowerGradient, 
    context.beginPath(), context.moveTo(indent + shift, y + this.corner - shift), context.lineTo(indent + this.dent, y + this.corner - shift), 
    context.stroke(), (rightGradient = context.createLinearGradient(x + this.inset + 2 * this.corner + this.dent - shift, y + this.corner - shift - shift, x + this.inset + 2 * this.corner + this.dent + .7 * shift, y + this.corner - shift + .7 * shift)).addColorStop(0, this.cachedClr), 
    rightGradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = rightGradient, 
    context.beginPath(), context.moveTo(x + this.inset + 2 * this.corner + this.dent, y + this.corner - shift), 
    context.lineTo(x + 3 * this.corner + this.inset + this.dent, y - shift), context.stroke(), 
    context.strokeStyle = upperGradient, context.beginPath(), context.moveTo(x + 3 * this.corner + this.inset + this.dent, y - shift), 
    context.lineTo(this.width() - this.corner, y - shift), context.stroke();
}, CSlotMorph.prototype.drawTopLeftEdge = function(context) {
    var gradient, shift = .5 * this.edge;
    (gradient = context.createRadialGradient(this.corner + this.inset, 2 * this.corner, this.corner, this.corner + this.inset, 2 * this.corner, this.corner + this.edge)).addColorStop(0, this.cachedClrDark), 
    gradient.addColorStop(1, this.cachedClr), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.arc(this.corner + this.inset, 2 * this.corner, this.corner + shift, radians(-180), radians(-90), !1), 
    context.stroke();
}, CSlotMorph.prototype.drawRightEdge = function(context) {
    var gradient, shift = .5 * this.edge, x = this.inset;
    (gradient = context.createLinearGradient(x - this.edge, 0, x, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(x - shift, 2 * this.corner), context.lineTo(x - shift, this.height() - 2 * this.corner), 
    context.stroke();
}, CSlotMorph.prototype.drawBottomEdge = function(context) {
    var gradient, upperGradient, shift = .5 * this.edge;
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    (upperGradient = context.createRadialGradient(this.corner + this.inset, this.height() - 2 * this.corner, this.corner, this.corner + this.inset, this.height() - 2 * this.corner, this.corner + this.edge)).addColorStop(0, this.cachedClrBright), 
    upperGradient.addColorStop(1, this.cachedClr), context.strokeStyle = upperGradient, 
    context.beginPath(), context.arc(this.corner + this.inset, this.height() - 2 * this.corner, this.corner + shift, radians(180), radians(90), !0), 
    context.stroke(), (gradient = context.createLinearGradient(0, this.height() - this.corner, 0, this.height() - this.corner + this.edge)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.inset + this.corner, this.height() - this.corner + shift), context.lineTo(this.width() - this.corner, this.height() - this.corner + shift), 
    context.stroke();
}, InputSlotMorph.prototype = new ArgMorph(), InputSlotMorph.prototype.constructor = InputSlotMorph, 
InputSlotMorph.uber = ArgMorph.prototype, InputSlotMorph.prototype.executeOnSliderEdit = !1;

function InputSlotMorph(text, isNumeric, choiceDict, isReadOnly) {
    this.init(text, isNumeric, choiceDict, isReadOnly);
}

InputSlotMorph.prototype.init = function(text, isNumeric, choiceDict, isReadOnly) {
    var contents = new StringMorph(""), arrow = new ArrowMorph("down", 0, Math.max(Math.floor(this.fontSize / 6), 1));
    contents.fontSize = this.fontSize, contents.isShowingBlanks = !0, contents.drawNew(), 
    this.isUnevaluated = !1, this.choices = choiceDict || null, this.oldContentsExtent = contents.extent(), 
    this.isNumeric = isNumeric || !1, this.isReadOnly = isReadOnly || !1, this.minWidth = 0, 
    this.constant = null, InputSlotMorph.uber.init.call(this), this.color = new Color(255, 255, 255), 
    this.add(contents), this.add(arrow), contents.isEditable = !0, contents.isDraggable = !1, 
    contents.enableSelecting(), this.setContents(text);
}, InputSlotMorph.prototype.getSpec = function() {
    return this.isNumeric ? "%n" : "%s";
}, InputSlotMorph.prototype.contents = function() {
    return detect(this.children, function(child) {
        return child instanceof StringMorph;
    });
}, InputSlotMorph.prototype.arrow = function() {
    return detect(this.children, function(child) {
        return child instanceof ArrowMorph;
    });
}, InputSlotMorph.prototype.setContents = function(aStringOrFloat) {
    var cnts = this.contents(), dta = aStringOrFloat, isConstant = dta instanceof Array;
    if (isConstant) dta = localize(dta[0]), cnts.isItalic = !this.isReadOnly; else if (cnts.isItalic = !1, 
    null !== this.choices && this.choices[dta] instanceof Array) return this.setContents(this.choices[dta]);
    cnts.text = dta, isNil(dta) ? cnts.text = "" : dta.toString && (cnts.text = dta.toString()), 
    cnts.drawNew(), this.isReadOnly && this.parent instanceof BlockMorph && this.parent.fixLabelColor(), 
    this.constant = isConstant ? aStringOrFloat : null;
}, InputSlotMorph.prototype.dropDownMenu = function() {
    var key, choices = this.choices, menu = new MenuMorph(this.setContents, null, this, this.fontSize);
    if (choices instanceof Function ? choices = choices.call(this) : isString(choices) && (choices = this[choices]()), 
    !choices) return null;
    menu.addItem(" ", null);
    for (key in choices) Object.prototype.hasOwnProperty.call(choices, key) && ("~" === key[0] ? menu.addLine() : menu.addItem(key, choices[key]));
    if (!(menu.items.length > 0)) return null;
    menu.popUpAtHand(this.world());
}, InputSlotMorph.prototype.messagesMenu = function() {
    var dict = {}, stage = this.parentThatIsA(BlockMorph).receiver().parentThatIsA(StageMorph), myself = this, allNames = [];
    return stage.children.concat(stage).forEach(function(morph) {
        (morph instanceof SpriteMorph || morph instanceof StageMorph) && (allNames = allNames.concat(morph.allMessageNames()));
    }), allNames.forEach(function(name) {
        dict[name] = name;
    }), allNames.length > 0 && (dict["~"] = null), dict["new..."] = function() {
        new DialogBoxMorph(myself, myself.setContents, myself).prompt("Message name", null, myself.world());
    }, dict;
}, InputSlotMorph.prototype.messagesReceivedMenu = function() {
    var dict = {
        "any message": [ "any message" ]
    }, stage = this.parentThatIsA(BlockMorph).receiver().parentThatIsA(StageMorph), myself = this, allNames = [];
    return stage.children.concat(stage).forEach(function(morph) {
        (morph instanceof SpriteMorph || morph instanceof StageMorph) && (allNames = allNames.concat(morph.allMessageNames()));
    }), allNames.forEach(function(name) {
        dict[name] = name;
    }), dict["~"] = null, dict["new..."] = function() {
        new DialogBoxMorph(myself, myself.setContents, myself).prompt("Message name", null, myself.world());
    }, dict;
}, InputSlotMorph.prototype.collidablesMenu = function() {
    var dict = {
        "mouse-pointer": [ "mouse-pointer" ],
        edge: [ "edge" ],
        "pen trails": [ "pen trails" ]
    }, rcvr = this.parentThatIsA(BlockMorph).receiver(), allNames = [];
    return rcvr.parentThatIsA(StageMorph).children.forEach(function(morph) {
        morph instanceof SpriteMorph && !morph.isClone && morph.name !== rcvr.name && (allNames = allNames.concat(morph.name));
    }), allNames.length > 0 && (dict["~"] = null, allNames.forEach(function(name) {
        dict[name] = name;
    })), dict;
}, InputSlotMorph.prototype.distancesMenu = function() {
    var dict = {
        "mouse-pointer": [ "mouse-pointer" ]
    }, rcvr = this.parentThatIsA(BlockMorph).receiver(), allNames = [];
    return rcvr.parentThatIsA(StageMorph).children.forEach(function(morph) {
        morph instanceof SpriteMorph && morph.name !== rcvr.name && (allNames = allNames.concat(morph.name));
    }), allNames.length > 0 && (dict["~"] = null, allNames.forEach(function(name) {
        dict[name] = name;
    })), dict;
}, InputSlotMorph.prototype.clonablesMenu = function() {
    var dict = {}, rcvr = this.parentThatIsA(BlockMorph).receiver(), stage = rcvr.parentThatIsA(StageMorph), allNames = [];
    return rcvr instanceof SpriteMorph && (dict.myself = [ "myself" ]), stage.children.forEach(function(morph) {
        morph instanceof SpriteMorph && !morph.isClone && (allNames = allNames.concat(morph.name));
    }), allNames.length > 0 && (dict["~"] = null, allNames.forEach(function(name) {
        dict[name] = name;
    })), dict;
}, InputSlotMorph.prototype.objectsMenu = function() {
    var stage = this.parentThatIsA(BlockMorph).receiver().parentThatIsA(StageMorph), dict = {}, allNames = [];
    return dict[stage.name] = stage.name, stage.children.forEach(function(morph) {
        morph instanceof SpriteMorph && allNames.push(morph.name);
    }), allNames.length > 0 && (dict["~"] = null, allNames.forEach(function(name) {
        dict[name] = name;
    })), dict;
}, InputSlotMorph.prototype.attributesMenu = function() {
    var obj, block = this.parentThatIsA(BlockMorph), objName = block.inputs()[1].evaluate(), stage = block.receiver().parentThatIsA(StageMorph), dict = {}, varNames = [];
    return (obj = objName === stage.name ? stage : detect(stage.children, function(morph) {
        return morph.name === objName;
    })) ? (dict = obj instanceof SpriteMorph ? {
        "x position": [ "x position" ],
        "y position": [ "y position" ],
        direction: [ "direction" ],
        "costume #": [ "costume #" ],
        "costume name": [ "costume name" ],
        size: [ "size" ]
    } : {
        "costume #": [ "costume #" ],
        "costume name": [ "costume name" ]
    }, (varNames = obj.variables.names()).length > 0 && (dict["~"] = null, varNames.forEach(function(name) {
        dict[name] = name;
    })), dict) : dict;
}, InputSlotMorph.prototype.costumesMenu = function() {
    var dict, rcvr = this.parentThatIsA(BlockMorph).receiver(), allNames = [];
    return dict = rcvr instanceof SpriteMorph ? {
        Turtle: [ "Turtle" ]
    } : {
        Empty: [ "Empty" ]
    }, rcvr.costumes.asArray().forEach(function(costume) {
        allNames = allNames.concat(costume.name);
    }), allNames.length > 0 && (dict["~"] = null, allNames.forEach(function(name) {
        dict[name] = name;
    })), dict;
}, InputSlotMorph.prototype.soundsMenu = function() {
    var allNames = [], dict = {};
    return this.parentThatIsA(BlockMorph).receiver().sounds.asArray().forEach(function(sound) {
        allNames = allNames.concat(sound.name);
    }), allNames.length > 0 && allNames.forEach(function(name) {
        dict[name] = name;
    }), dict;
}, InputSlotMorph.prototype.getVarNamesDict = function() {
    var rcvr, dict, block = this.parentThatIsA(BlockMorph), tempVars = [];
    return block ? (rcvr = block.receiver(), block.allParents().forEach(function(morph) {
        morph instanceof PrototypeHatBlockMorph ? tempVars.push.apply(tempVars, morph.inputs()[0].inputFragmentNames()) : morph instanceof BlockMorph && morph.inputs().forEach(function(inp) {
            inp instanceof TemplateSlotMorph ? tempVars.push(inp.contents()) : inp instanceof MultiArgMorph && inp.children.forEach(function(m) {
                m instanceof TemplateSlotMorph && tempVars.push(m.contents());
            });
        });
    }), rcvr ? (dict = rcvr.variables.allNamesDict(), tempVars.forEach(function(name) {
        dict[name] = name;
    }), dict) : {}) : {};
}, InputSlotMorph.prototype.setChoices = function(dict, readonly) {
    var cnts = this.contents();
    this.choices = dict, this.isReadOnly = readonly || !1, this.parent instanceof BlockMorph && (this.parent.fixLabelColor(), 
    readonly || (cnts.shadowOffset = new Point(), cnts.shadowColor = null, cnts.setColor(new Color(0, 0, 0)))), 
    this.fixLayout();
}, InputSlotMorph.prototype.fixLayout = function() {
    var contents = this.contents(), arrow = this.arrow();
    contents.isNumeric = this.isNumeric, contents.isEditable = !this.isReadOnly, this.isReadOnly ? (contents.disableSelecting(), 
    contents.color = new Color(254, 254, 254)) : (contents.enableSelecting(), contents.color = new Color(0, 0, 0)), 
    this.choices ? (arrow.setSize(this.fontSize), arrow.show()) : (arrow.setSize(0), 
    arrow.hide()), this.setHeight(contents.height() + 2 * this.edge), this.isNumeric ? this.setWidth(contents.width() + Math.floor(.5 * arrow.width()) + this.height() + 2 * this.typeInPadding) : this.setWidth(Math.max(contents.width() + arrow.width() + 2 * this.edge + 2 * this.typeInPadding, contents.rawHeight ? contents.rawHeight() + arrow.width() : contents.height() / 1.2 + arrow.width(), this.minWidth)), 
    this.isNumeric ? contents.setPosition(new Point(Math.floor(this.height() / 2), this.edge).add(new Point(this.typeInPadding, 0)).add(this.position())) : contents.setPosition(new Point(this.edge, this.edge).add(new Point(this.typeInPadding, 0)).add(this.position())), 
    arrow.setPosition(new Point(this.right() - arrow.width() - this.edge, contents.top())), 
    this.parent && this.parent.fixLayout && (this.world() ? (this.startLayout(), this.parent.fixLayout(), 
    this.endLayout()) : this.parent.fixLayout());
}, InputSlotMorph.prototype.mouseClickLeft = function(pos) {
    this.arrow().bounds.containsPoint(pos) ? this.dropDownMenu() : this.isReadOnly ? this.dropDownMenu() : (this.contents().edit(), 
    this.contents().selectAll());
}, InputSlotMorph.prototype.reactToKeystroke = function() {
    var cnts;
    this.constant && (cnts = this.contents(), this.constant = null, cnts.isItalic = !1, 
    cnts.drawNew());
}, InputSlotMorph.prototype.reactToEdit = function() {
    this.contents().clearSelection();
}, InputSlotMorph.prototype.reactToSliderEdit = function() {
    var block, top, receiver, stage;
    if (this.executeOnSliderEdit && (block = this.parentThatIsA(BlockMorph))) {
        if (receiver = (top = block.topBlock()).receiver(), top instanceof PrototypeHatBlockMorph) return;
        receiver && ((stage = receiver.parentThatIsA(StageMorph)) && stage.isThreadSafe ? stage.threads.startProcess(top, stage.isThreadSafe) : top.mouseClickLeft());
    }
}, InputSlotMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this);
    return !StageMorph.prototype.enableCodeMapping || this.isNumeric ? this.parent.userMenu() : (menu.addItem("code string mapping...", "mapToCode"), 
    menu);
}, InputSlotMorph.prototype.mapToCode = function() {
    new DialogBoxMorph(this, function(code) {
        StageMorph.prototype.codeMappings.string = code;
    }, this).promptCode("Code mapping - String <#1>", StageMorph.prototype.codeMappings.string || "", this.world());
}, InputSlotMorph.prototype.mappedCode = function() {
    var code = StageMorph.prototype.codeMappings.string || "<#1>", block = this.parentThatIsA(BlockMorph), val = this.evaluate();
    return this.isNumeric ? val : isNaN(parseFloat(val)) && isString(val) ? block && contains([ "doSetVar", "doChangeVar", "doShowVar", "doHideVar" ], block.selector) ? val : code.replace(/<#1>/g, val) : val;
}, InputSlotMorph.prototype.evaluate = function() {
    var num, contents = this.contents();
    return this.constant ? this.constant : this.isNumeric && (num = parseFloat(contents.text || "0"), 
    !isNaN(num)) ? num : contents.text;
}, InputSlotMorph.prototype.isEmptySlot = function() {
    return "" === this.contents().text;
}, InputSlotMorph.prototype.drawNew = function() {
    var context, borderColor, r;
    this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), borderColor = this.parent ? this.parent.color : new Color(120, 120, 120), 
    context.fillStyle = this.color.toString(), this.isReadOnly && (context.fillStyle = borderColor.darker().toString()), 
    this.cachedClr = borderColor.toString(), this.cachedClrBright = borderColor.lighter(this.contrast).toString(), 
    this.cachedClrDark = borderColor.darker(this.contrast).toString(), this.isNumeric ? (r = (this.height() - 2 * this.edge) / 2, 
    context.beginPath(), context.arc(r + this.edge, r + this.edge, r, radians(90), radians(-90), !1), 
    context.arc(this.width() - r - this.edge, r + this.edge, r, radians(-90), radians(90), !1), 
    context.closePath(), context.fill(), MorphicPreferences.isFlat || this.drawRoundBorder(context)) : (context.fillRect(this.edge, this.edge, this.width() - 2 * this.edge, this.height() - 2 * this.edge), 
    MorphicPreferences.isFlat || this.drawRectBorder(context));
}, InputSlotMorph.prototype.drawRectBorder = function(context) {
    var gradient, shift = .5 * this.edge;
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    context.shadowOffsetY = shift, context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.edge, shift), context.lineTo(this.width() - this.edge - shift, shift), 
    context.stroke(), context.shadowOffsetY = 0, (gradient = context.createLinearGradient(0, 0, this.edge, 0)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, this.edge), context.lineTo(shift, this.height() - this.edge - shift), 
    context.stroke(), context.shadowOffsetX = 0, context.shadowOffsetY = 0, context.shadowBlur = 0, 
    (gradient = context.createLinearGradient(0, this.height() - this.edge, 0, this.height())).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.edge, this.height() - shift), context.lineTo(this.width() - this.edge, this.height() - shift), 
    context.stroke(), (gradient = context.createLinearGradient(this.width() - this.edge, 0, this.width(), 0)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(this.width() - shift, this.edge), context.lineTo(this.width() - shift, this.height() - this.edge), 
    context.stroke();
}, InputSlotMorph.prototype.drawRoundBorder = function(context) {
    var start, end, gradient, shift = .5 * this.edge, r = (this.height() - 2 * this.edge) / 2;
    context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    start = r + this.edge, (end = this.width() - r - this.edge) > start && (context.shadowOffsetX = shift, 
    context.shadowOffsetY = shift, context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(start, shift), context.lineTo(end, shift), context.stroke(), context.shadowOffsetX = 0, 
    context.shadowOffsetY = 0, context.shadowBlur = 0), (gradient = context.createLinearGradient(0, this.height() - this.edge, 0, this.height())).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r + this.edge, this.height() - shift), context.lineTo(this.width() - r - this.edge, this.height() - shift), 
    context.stroke(), r = this.height() / 2, context.shadowOffsetX = shift, context.shadowOffsetY = shift, 
    context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createRadialGradient(r, r, r - this.edge, r, r, r)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(r, r, r - shift, radians(180), radians(270), !1), context.stroke(), 
    context.shadowOffsetX = 0, context.shadowOffsetY = 0, context.shadowBlur = 0, (gradient = context.createRadialGradient(this.width() - r, r, r - this.edge, this.width() - r, r, r)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.arc(this.width() - r, r, r - shift, radians(0), radians(90), !1), 
    context.stroke();
}, TemplateSlotMorph.prototype = new ArgMorph(), TemplateSlotMorph.prototype.constructor = TemplateSlotMorph, 
TemplateSlotMorph.uber = ArgMorph.prototype;

function TemplateSlotMorph(name) {
    this.init(name);
}

TemplateSlotMorph.prototype.init = function(name) {
    var template = new ReporterBlockMorph();
    this.labelString = name || "", template.isDraggable = !1, template.isTemplate = !0, 
    void 0 !== modules.objects ? (template.color = SpriteMorph.prototype.blockColor.variables, 
    template.category = "variables") : (template.color = new Color(243, 118, 29), template.category = null), 
    template.setSpec(this.labelString), template.selector = "reportGetVar", TemplateSlotMorph.uber.init.call(this), 
    this.add(template), this.fixLayout(), this.isDraggable = !1, this.isStatic = !0;
}, TemplateSlotMorph.prototype.getSpec = function() {
    return "%t";
}, TemplateSlotMorph.prototype.template = function() {
    return this.children[0];
}, TemplateSlotMorph.prototype.contents = function() {
    return this.template().blockSpec;
}, TemplateSlotMorph.prototype.setContents = function(aString) {
    var tmp = this.template();
    tmp.setSpec(aString), tmp.fixBlockColor(), tmp.fixLabelColor();
}, TemplateSlotMorph.prototype.evaluate = function() {
    return this.contents();
}, TemplateSlotMorph.prototype.fixLayout = function() {
    var template = this.template();
    this.setExtent(template.extent().add(2 * this.edge + 2)), template.setPosition(this.position().add(this.edge + 1)), 
    this.parent && this.parent.fixLayout && this.parent.fixLayout();
}, TemplateSlotMorph.prototype.drawNew = function() {
    var context;
    this.parent instanceof Morph && (this.color = this.parent.color.copy()), this.cachedClr = this.color.toString(), 
    this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), this.image = newCanvas(this.extent()), 
    (context = this.image.getContext("2d")).fillStyle = this.cachedClr, this.drawRounded(context);
}, TemplateSlotMorph.prototype.drawRounded = ReporterBlockMorph.prototype.drawRounded, 
BooleanSlotMorph.prototype = new ArgMorph(), BooleanSlotMorph.prototype.constructor = BooleanSlotMorph, 
BooleanSlotMorph.uber = ArgMorph.prototype;

function BooleanSlotMorph() {
    this.init();
}

BooleanSlotMorph.prototype.init = function() {
    BooleanSlotMorph.uber.init.call(this);
}, BooleanSlotMorph.prototype.getSpec = function() {
    return "%b";
}, BooleanSlotMorph.prototype.drawNew = function() {
    var context;
    this.silentSetExtent(new Point(2 * (this.fontSize + 2 * this.edge), this.fontSize + 2 * this.edge)), 
    this.parent && (this.color = this.parent.color), this.cachedClr = this.color.toString(), 
    this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), this.image = newCanvas(this.extent()), 
    context = this.image.getContext("2d"), this.drawDiamond(context, !0);
}, BooleanSlotMorph.prototype.drawDiamond = function(context) {
    var gradient, w = this.width(), h = this.height(), r = h / 2, shift = this.edge / 2;
    context.fillStyle = this.color.darker(25).toString(), context.beginPath(), context.moveTo(0, r), 
    context.lineTo(r, 0), context.lineTo(w - r, 0), context.lineTo(w, r), context.lineTo(w - r, h), 
    context.lineTo(r, h), context.closePath(), context.fill(), MorphicPreferences.isFlat || (context.lineWidth = this.edge, 
    context.lineJoin = "round", context.lineCap = "round", context.shadowOffsetX = shift, 
    context.shadowBlur = shift, context.shadowColor = "black", (gradient = context.createLinearGradient(0, r, .6 * this.edge, r + .6 * this.edge)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, r), context.lineTo(r, shift), context.closePath(), context.stroke(), 
    context.shadowOffsetX = 0, context.shadowOffsetY = shift, context.shadowBlur = this.edge, 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r, shift), context.lineTo(w - r, shift), context.closePath(), context.stroke(), 
    context.shadowOffsetY = 0, context.shadowBlur = 0, (gradient = context.createLinearGradient(w - r - .6 * this.edge, h - .6 * this.edge, w - r, h)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(w - r, h - shift), context.lineTo(w - shift, r), 
    context.closePath(), context.stroke(), (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(r, h - shift), context.lineTo(w - r - shift, h - shift), 
    context.closePath(), context.stroke());
}, BooleanSlotMorph.prototype.isEmptySlot = function() {
    return !0;
}, ArrowMorph.prototype = new Morph(), ArrowMorph.prototype.constructor = ArrowMorph, 
ArrowMorph.uber = Morph.prototype;

function ArrowMorph(direction, size, padding, color) {
    this.init(direction, size, padding, color);
}

ArrowMorph.prototype.init = function(direction, size, padding, color) {
    this.direction = direction || "down", this.size = size || (0 === size ? 0 : 50), 
    this.padding = padding || 0, ArrowMorph.uber.init.call(this), this.color = color || new Color(0, 0, 0), 
    this.setExtent(new Point(this.size, this.size));
}, ArrowMorph.prototype.setSize = function(size) {
    var min = Math.max(size, 1);
    this.size = size, this.setExtent(new Point(min, min));
}, ArrowMorph.prototype.drawNew = function() {
    this.image = newCanvas(this.extent());
    var context = this.image.getContext("2d"), pad = this.padding, h = this.height(), h2 = Math.floor(h / 2), w = this.width(), w2 = Math.floor(w / 2);
    context.fillStyle = this.color.toString(), context.beginPath(), "down" === this.direction ? (context.moveTo(pad, h2), 
    context.lineTo(w - pad, h2), context.lineTo(w2, h - pad)) : "up" === this.direction ? (context.moveTo(pad, h2), 
    context.lineTo(w - pad, h2), context.lineTo(w2, pad)) : "left" === this.direction ? (context.moveTo(pad, h2), 
    context.lineTo(w2, pad), context.lineTo(w2, h - pad)) : (context.moveTo(w2, pad), 
    context.lineTo(w - pad, h2), context.lineTo(w2, h - pad)), context.closePath(), 
    context.fill();
}, TextSlotMorph.prototype = new InputSlotMorph(), TextSlotMorph.prototype.constructor = TextSlotMorph, 
TextSlotMorph.uber = InputSlotMorph.prototype;

function TextSlotMorph(text, isNumeric, choiceDict, isReadOnly) {
    this.init(text, isNumeric, choiceDict, isReadOnly);
}

TextSlotMorph.prototype.init = function(text, isNumeric, choiceDict, isReadOnly) {
    var contents = new TextMorph(""), arrow = new ArrowMorph("down", 0, Math.max(Math.floor(this.fontSize / 6), 1));
    contents.fontSize = this.fontSize, contents.drawNew(), this.isUnevaluated = !1, 
    this.choices = choiceDict || null, this.oldContentsExtent = contents.extent(), this.isNumeric = isNumeric || !1, 
    this.isReadOnly = isReadOnly || !1, this.minWidth = 0, this.constant = null, InputSlotMorph.uber.init.call(this), 
    this.color = new Color(255, 255, 255), this.add(contents), this.add(arrow), contents.isEditable = !0, 
    contents.isDraggable = !1, contents.enableSelecting(), this.setContents(text);
}, TextSlotMorph.prototype.getSpec = function() {
    return this.isNumeric ? "%mln" : "%mlt";
}, TextSlotMorph.prototype.contents = function() {
    return detect(this.children, function(child) {
        return child instanceof TextMorph;
    });
}, TextSlotMorph.prototype.layoutChanged = function() {
    this.fixLayout();
}, SymbolMorph.prototype = new Morph(), SymbolMorph.prototype.constructor = SymbolMorph, 
SymbolMorph.uber = Morph.prototype, SymbolMorph.prototype.names = [ "square", "pointRight", "gears", "file", "fullScreen", "normalScreen", "smallStage", "normalStage", "turtle", "stage", "turtleOutline", "pause", "flag", "octagon", "cloud", "cloudOutline", "cloudGradient", "turnRight", "turnLeft", "storage", "poster", "flash", "brush", "rectangle", "rectangleSolid", "circle", "circleSolid", "line", "crosshairs", "paintbucket", "eraser", "pipette", "speechBubble", "speechBubbleOutline", "arrowUp", "arrowUpOutline", "arrowLeft", "arrowLeftOutline", "arrowDown", "arrowDownOutline", "arrowRight", "arrowRightOutline", "robot" ];

function SymbolMorph(name, size, color, shadowOffset, shadowColor) {
    this.init(name, size, color, shadowOffset, shadowColor);
}

SymbolMorph.prototype.init = function(name, size, color, shadowOffset, shadowColor) {
    this.isProtectedLabel = !1, this.isReadOnly = !0, this.name = name || "square", 
    this.size = size || (0 === size ? 0 : 50), this.shadowOffset = shadowOffset || new Point(0, 0), 
    this.shadowColor = shadowColor || null, SymbolMorph.uber.init.call(this), this.color = color || new Color(0, 0, 0), 
    this.drawNew();
}, SymbolMorph.prototype.setLabelColor = function(textColor, shadowColor, shadowOffset) {
    this.shadowOffset = shadowOffset, this.shadowColor = shadowColor, this.setColor(textColor);
}, SymbolMorph.prototype.drawNew = function() {
    var ctx, x, y, sx, sy;
    this.image = newCanvas(new Point(this.symbolWidth() + Math.abs(this.shadowOffset.x), this.size + Math.abs(this.shadowOffset.y))), 
    this.silentSetWidth(this.image.width), this.silentSetHeight(this.image.height), 
    ctx = this.image.getContext("2d"), sx = this.shadowOffset.x < 0 ? 0 : this.shadowOffset.x, 
    sy = this.shadowOffset.y < 0 ? 0 : this.shadowOffset.y, x = this.shadowOffset.x < 0 ? Math.abs(this.shadowOffset.x) : 0, 
    y = this.shadowOffset.y < 0 ? Math.abs(this.shadowOffset.y) : 0, this.shadowColor && ctx.drawImage(this.symbolCanvasColored(this.shadowColor), sx, sy), 
    ctx.drawImage(this.symbolCanvasColored(this.color), x, y);
}, SymbolMorph.prototype.symbolCanvasColored = function(aColor) {
    if (this.name instanceof Costume) return this.name.thumbnail(new Point(this.symbolWidth(), this.size));
    var canvas = newCanvas(new Point(this.symbolWidth(), this.size));
    switch (this.name) {
      case "square":
        return this.drawSymbolStop(canvas, aColor);

      case "pointRight":
        return this.drawSymbolPointRight(canvas, aColor);

      case "gears":
        return this.drawSymbolGears(canvas, aColor);

      case "file":
        return this.drawSymbolFile(canvas, aColor);

      case "fullScreen":
        return this.drawSymbolFullScreen(canvas, aColor);

      case "normalScreen":
        return this.drawSymbolNormalScreen(canvas, aColor);

      case "smallStage":
        return this.drawSymbolSmallStage(canvas, aColor);

      case "normalStage":
        return this.drawSymbolNormalStage(canvas, aColor);

      case "turtle":
        return this.drawSymbolTurtle(canvas, aColor);

      case "stage":
        return this.drawSymbolStop(canvas, aColor);

      case "turtleOutline":
        return this.drawSymbolTurtleOutline(canvas, aColor);

      case "pause":
        return this.drawSymbolPause(canvas, aColor);

      case "flag":
        return this.drawSymbolFlag(canvas, aColor);

      case "octagon":
        return this.drawSymbolOctagon(canvas, aColor);

      case "cloud":
        return this.drawSymbolCloud(canvas, aColor);

      case "cloudOutline":
        return this.drawSymbolCloudOutline(canvas, aColor);

      case "cloudGradient":
        return this.drawSymbolCloudGradient(canvas, aColor);

      case "turnRight":
        return this.drawSymbolTurnRight(canvas, aColor);

      case "turnLeft":
        return this.drawSymbolTurnLeft(canvas, aColor);

      case "storage":
        return this.drawSymbolStorage(canvas, aColor);

      case "poster":
        return this.drawSymbolPoster(canvas, aColor);

      case "flash":
        return this.drawSymbolFlash(canvas, aColor);

      case "brush":
        return this.drawSymbolBrush(canvas, aColor);

      case "rectangle":
        return this.drawSymbolRectangle(canvas, aColor);

      case "rectangleSolid":
        return this.drawSymbolRectangleSolid(canvas, aColor);

      case "circle":
        return this.drawSymbolCircle(canvas, aColor);

      case "circleSolid":
        return this.drawSymbolCircleSolid(canvas, aColor);

      case "line":
        return this.drawSymbolLine(canvas, aColor);

      case "crosshairs":
        return this.drawSymbolCrosshairs(canvas, aColor);

      case "paintbucket":
        return this.drawSymbolPaintbucket(canvas, aColor);

      case "eraser":
        return this.drawSymbolEraser(canvas, aColor);

      case "pipette":
        return this.drawSymbolPipette(canvas, aColor);

      case "speechBubble":
        return this.drawSymbolSpeechBubble(canvas, aColor);

      case "speechBubbleOutline":
        return this.drawSymbolSpeechBubbleOutline(canvas, aColor);

      case "arrowUp":
        return this.drawSymbolArrowUp(canvas, aColor);

      case "arrowUpOutline":
        return this.drawSymbolArrowUpOutline(canvas, aColor);

      case "arrowLeft":
        return this.drawSymbolArrowLeft(canvas, aColor);

      case "arrowLeftOutline":
        return this.drawSymbolArrowLeftOutline(canvas, aColor);

      case "arrowDown":
        return this.drawSymbolArrowDown(canvas, aColor);

      case "arrowDownOutline":
        return this.drawSymbolArrowDownOutline(canvas, aColor);

      case "arrowRight":
        return this.drawSymbolArrowRight(canvas, aColor);

      case "arrowRightOutline":
        return this.drawSymbolArrowRightOutline(canvas, aColor);

      case "robot":
        return this.drawSymbolRobot(canvas, aColor);

      default:
        return canvas;
    }
}, SymbolMorph.prototype.symbolWidth = function() {
    var size = this.size;
    if (this.name instanceof Costume) return size / this.name.height() * this.name.width();
    switch (this.name) {
      case "pointRight":
        return Math.sqrt(size * size - Math.pow(size / 2, 2));

      case "flash":
      case "file":
        return .8 * size;

      case "smallStage":
      case "normalStage":
        return 1.2 * size;

      case "turtle":
      case "turtleOutline":
      case "stage":
        return 1.3 * size;

      case "cloud":
      case "cloudGradient":
      case "cloudOutline":
        return 1.6 * size;

      case "turnRight":
      case "turnLeft":
        return size / 3 * 2;

      default:
        return size;
    }
}, SymbolMorph.prototype.drawSymbolStop = function(canvas, color) {
    var ctx = canvas.getContext("2d");
    return ctx.fillStyle = color.toString(), ctx.fillRect(0, 0, canvas.width, canvas.height), 
    canvas;
}, SymbolMorph.prototype.drawSymbolPointRight = function(canvas, color) {
    var ctx = canvas.getContext("2d");
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(0, 0), ctx.lineTo(canvas.width, Math.round(canvas.height / 2)), 
    ctx.lineTo(0, canvas.height), ctx.lineTo(0, 0), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolGears = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, r = w / 2, e = w / 6;
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = canvas.width / 7, ctx.beginPath(), 
    ctx.arc(r, r, w, radians(0), radians(360), !0), ctx.arc(r, r, 1.5 * e, radians(0), radians(360), !1), 
    ctx.closePath(), ctx.clip(), ctx.moveTo(0, r), ctx.lineTo(w, r), ctx.stroke(), ctx.moveTo(r, 0), 
    ctx.lineTo(r, w), ctx.stroke(), ctx.moveTo(e, e), ctx.lineTo(w - e, w - e), ctx.stroke(), 
    ctx.moveTo(w - e, e), ctx.lineTo(e, w - e), ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolFile = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = Math.min(canvas.width, canvas.height) / 2;
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(0, 0), ctx.lineTo(w, 0), 
    ctx.lineTo(w, w), ctx.lineTo(canvas.width, w), ctx.lineTo(canvas.width, canvas.height), 
    ctx.lineTo(0, canvas.height), ctx.closePath(), ctx.fill(), ctx.fillStyle = color.darker(25).toString(), 
    ctx.beginPath(), ctx.moveTo(w, 0), ctx.lineTo(canvas.width, w), ctx.lineTo(w, w), 
    ctx.lineTo(w, 0), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolFullScreen = function(canvas, color) {
    var ctx = canvas.getContext("2d"), h = canvas.height, c = canvas.width / 2, off = canvas.width / 20, w = canvas.width / 2;
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = canvas.width / 5, ctx.moveTo(c - off, c + off), 
    ctx.lineTo(0, h), ctx.stroke(), ctx.strokeStyle = color.toString(), ctx.lineWidth = canvas.width / 5, 
    ctx.moveTo(c + off, c - off), ctx.lineTo(h, 0), ctx.stroke(), ctx.fillStyle = color.toString(), 
    ctx.beginPath(), ctx.moveTo(0, h), ctx.lineTo(0, h - w), ctx.lineTo(w, h), ctx.closePath(), 
    ctx.fill(), ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(h, 0), 
    ctx.lineTo(h - w, 0), ctx.lineTo(h, w), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolNormalScreen = function(canvas, color) {
    var ctx = canvas.getContext("2d"), h = canvas.height, c = canvas.width / 2, off = canvas.width / 20, w = canvas.width;
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = canvas.width / 5, ctx.moveTo(c - 3 * off, c + 3 * off), 
    ctx.lineTo(0, h), ctx.stroke(), ctx.strokeStyle = color.toString(), ctx.lineWidth = canvas.width / 5, 
    ctx.moveTo(c + 3 * off, c - 3 * off), ctx.lineTo(h, 0), ctx.stroke(), ctx.fillStyle = color.toString(), 
    ctx.beginPath(), ctx.moveTo(c + off, c - off), ctx.lineTo(w, c - off), ctx.lineTo(c + off, 0), 
    ctx.closePath(), ctx.fill(), ctx.fillStyle = color.toString(), ctx.beginPath(), 
    ctx.moveTo(c - off, c + off), ctx.lineTo(0, c + off), ctx.lineTo(c - off, w), ctx.closePath(), 
    ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolSmallStage = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, w2 = w / 2, h2 = h / 2;
    return ctx.fillStyle = color.darker(40).toString(), ctx.fillRect(0, 0, w, h), ctx.fillStyle = color.toString(), 
    ctx.fillRect(w2, 0, w2, h2), canvas;
}, SymbolMorph.prototype.drawSymbolNormalStage = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, w2 = w / 2, h2 = h / 2;
    return ctx.fillStyle = color.toString(), ctx.fillRect(0, 0, w, h), ctx.fillStyle = color.darker(25).toString(), 
    ctx.fillRect(w2, 0, w2, h2), canvas;
}, SymbolMorph.prototype.drawSymbolTurtle = function(canvas, color) {
    var ctx = canvas.getContext("2d");
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(0, 0), ctx.lineTo(canvas.width, canvas.height / 2), 
    ctx.lineTo(0, canvas.height), ctx.lineTo(canvas.height / 2, canvas.height / 2), 
    ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolTurtleOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d");
    return ctx.strokeStyle = color.toString(), ctx.beginPath(), ctx.moveTo(0, 0), ctx.lineTo(canvas.width, canvas.height / 2), 
    ctx.lineTo(0, canvas.height), ctx.lineTo(canvas.height / 2, canvas.height / 2), 
    ctx.closePath(), ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolPause = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width / 5;
    return ctx.fillStyle = color.toString(), ctx.fillRect(0, 0, 2 * w, canvas.height), 
    ctx.fillRect(3 * w, 0, 2 * w, canvas.height), canvas;
}, SymbolMorph.prototype.drawSymbolFlag = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, l = Math.max(w / 12, 1), h = canvas.height;
    return ctx.lineWidth = l, ctx.strokeStyle = color.toString(), ctx.beginPath(), ctx.moveTo(l / 2, 0), 
    ctx.lineTo(l / 2, canvas.height), ctx.stroke(), ctx.lineWidth = h / 2, ctx.beginPath(), 
    ctx.moveTo(0, h / 4), ctx.bezierCurveTo(.8 * w, h / 4, .1 * w, .5 * h, w, .5 * h), 
    ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolOctagon = function(canvas, color) {
    var ctx = canvas.getContext("2d"), side = canvas.width, vert = (side - .383 * side) / 2;
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(vert, 0), ctx.lineTo(side - vert, 0), 
    ctx.lineTo(side, vert), ctx.lineTo(side, side - vert), ctx.lineTo(side - vert, side), 
    ctx.lineTo(vert, side), ctx.lineTo(0, side - vert), ctx.lineTo(0, vert), ctx.closePath(), 
    ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolCloud = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, r1 = 2 * h / 5, r2 = h / 4, r3 = 3 * h / 10, r4 = h / 5;
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.arc(r2, h - r2, r2, radians(90), radians(259), !1), 
    ctx.arc(w / 20 * 5, h / 9 * 4, r4, radians(165), radians(300), !1), ctx.arc(w / 20 * 11, r1, r1, radians(200), radians(357), !1), 
    ctx.arc(w - r3, h - r3, r3, radians(269), radians(90), !1), ctx.closePath(), ctx.fill(), 
    canvas;
}, SymbolMorph.prototype.drawSymbolCloudGradient = function(canvas, color) {
    var gradient, ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, r1 = 2 * h / 5, r2 = h / 4, r3 = 3 * h / 10, r4 = h / 5;
    return (gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, w)).addColorStop(0, color.lighter(25).toString()), 
    gradient.addColorStop(1, color.darker(25).toString()), ctx.fillStyle = gradient, 
    ctx.beginPath(), ctx.arc(r2, h - r2, r2, radians(90), radians(259), !1), ctx.arc(w / 20 * 5, h / 9 * 4, r4, radians(165), radians(300), !1), 
    ctx.arc(w / 20 * 11, r1, r1, radians(200), radians(357), !1), ctx.arc(w - r3, h - r3, r3, radians(269), radians(90), !1), 
    ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolCloudOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, r1 = 2 * h / 5, r2 = h / 4, r3 = 3 * h / 10, r4 = h / 5;
    return ctx.strokeStyle = color.toString(), ctx.beginPath(), ctx.arc(r2 + 1, h - r2 - 1, r2, radians(90), radians(259), !1), 
    ctx.arc(w / 20 * 5, h / 9 * 4, r4, radians(165), radians(300), !1), ctx.arc(w / 20 * 11, r1 + 1, r1, radians(200), radians(357), !1), 
    ctx.arc(w - r3 - 1, h - r3 - 1, r3, radians(269), radians(90), !1), ctx.closePath(), 
    ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolTurnRight = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, l = Math.max(w / 10, 1), r = w / 2;
    return ctx.lineWidth = l, ctx.strokeStyle = color.toString(), ctx.beginPath(), ctx.arc(r, 2 * r, r - l / 2, radians(0), radians(-90), !1), 
    ctx.stroke(), ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(w, r), 
    ctx.lineTo(r, 0), ctx.lineTo(r, 2 * r), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolTurnLeft = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, l = Math.max(w / 10, 1), r = w / 2;
    return ctx.lineWidth = l, ctx.strokeStyle = color.toString(), ctx.beginPath(), ctx.arc(r, 2 * r, r - l / 2, radians(180), radians(-90), !0), 
    ctx.stroke(), ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(0, r), 
    ctx.lineTo(r, 0), ctx.lineTo(r, 2 * r), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolStorage = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, r = canvas.height, unit = canvas.height / 11;
    function drawDisk(bottom, fillTop) {
        ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.arc(w / 2, bottom - h, r, radians(60), radians(120), !1), 
        ctx.lineTo(0, bottom - 2 * unit), ctx.arc(w / 2, bottom - h - 2 * unit, r, radians(120), radians(60), !0), 
        ctx.closePath(), ctx.fill(), ctx.fillStyle = color.darker(25).toString(), ctx.beginPath(), 
        fillTop && ctx.arc(w / 2, bottom - h - 2 * unit, r, radians(120), radians(60), !0), 
        ctx.arc(w / 2, bottom + 6 * unit + 1, r, radians(60), radians(120), !0), ctx.closePath(), 
        fillTop ? ctx.fill() : ctx.stroke();
    }
    return ctx.strokeStyle = color.toString(), drawDisk(h), drawDisk(h - 3 * unit), 
    drawDisk(h - 6 * unit, !1), canvas;
}, SymbolMorph.prototype.drawSymbolPoster = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, bottom = .75 * h, edge = canvas.height / 5;
    return ctx.fillStyle = color.toString(), ctx.strokeStyle = color.toString(), ctx.lineWidth = w / 15, 
    ctx.moveTo(w / 2, h / 3), ctx.lineTo(w / 6, h), ctx.stroke(), ctx.moveTo(w / 2, h / 3), 
    ctx.lineTo(w / 2, h), ctx.stroke(), ctx.moveTo(w / 2, h / 3), ctx.lineTo(5 * w / 6, h), 
    ctx.stroke(), ctx.fillRect(0, 0, w, bottom), ctx.clearRect(0, bottom, w, w / 20), 
    ctx.clearRect(w - edge, bottom - edge, edge + 1, edge + 1), ctx.fillStyle = color.darker(25).toString(), 
    ctx.beginPath(), ctx.moveTo(w, bottom - edge), ctx.lineTo(w - edge, bottom - edge), 
    ctx.lineTo(w - edge, bottom), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolFlash = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, w3 = w / 3, h = canvas.height, h3 = h / 3, off = h3 / 3;
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(w3, 0), ctx.lineTo(0, h3), 
    ctx.lineTo(w3, h3), ctx.lineTo(0, 2 * h3), ctx.lineTo(w3, 2 * h3), ctx.lineTo(0, h), 
    ctx.lineTo(w, 2 * h3 - off), ctx.lineTo(2 * w3, 2 * h3 - off), ctx.lineTo(w, h3 - off), 
    ctx.lineTo(2 * w3, h3 - off), ctx.lineTo(w, 0), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolBrush = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, l = Math.max(w / 30, .5);
    return ctx.fillStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(w / 8 * 3, h / 2), ctx.quadraticCurveTo(0, h / 2, l, h - l), ctx.quadraticCurveTo(w / 2, h, w / 2, h / 8 * 5), 
    ctx.closePath(), ctx.fill(), ctx.lineJoin = "round", ctx.lineCap = "round", ctx.strokeStyle = color.toString(), 
    ctx.moveTo(w / 8 * 3, h / 2), ctx.lineTo(.75 * w, l), ctx.quadraticCurveTo(w, 0, w - l, .25 * h), 
    ctx.stroke(), ctx.moveTo(w / 2, h / 8 * 5), ctx.lineTo(w - l, .25 * h), ctx.stroke(), 
    canvas;
}, SymbolMorph.prototype.drawSymbolRectangle = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.width, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(l, l), ctx.lineTo(w - l, l), ctx.lineTo(w - l, h - l), ctx.lineTo(l, h - l), 
    ctx.closePath(), ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolRectangleSolid = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.width;
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(0, 0), ctx.lineTo(w, 0), 
    ctx.lineTo(w, h), ctx.lineTo(0, h), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolCircle = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.arc(w / 2, w / 2, w / 2 - l, radians(0), radians(360), !1), 
    ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolCircleSolid = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.fillStyle = color.toString(), ctx.arc(w / 2, w / 2, w / 2, radians(0), radians(360), !1), 
    ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolLine = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.lineCap = "round", 
    ctx.moveTo(l, l), ctx.lineTo(w - l, h - l), ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolCrosshairs = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, l = .5;
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 1, ctx.moveTo(l, h / 2), 
    ctx.lineTo(w - l, h / 2), ctx.stroke(), ctx.moveTo(w / 2, l), ctx.lineTo(w / 2, h - l), 
    ctx.stroke(), ctx.moveTo(w / 2, h / 2), ctx.arc(w / 2, w / 2, w / 3 - l, radians(0), radians(360), !1), 
    ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolPaintbucket = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 5, l = Math.max(w / 30, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(2 * n, n), ctx.lineTo(4 * n, 3 * n), ctx.lineTo(3 * n, 4 * n), ctx.quadraticCurveTo(2 * n, h, n, 4 * n), 
    ctx.quadraticCurveTo(0, 3 * n, n, 2 * n), ctx.closePath(), ctx.stroke(), ctx.lineWidth = l, 
    ctx.moveTo(2 * n, 2.5 * n), ctx.arc(2 * n, 2.5 * n, l, radians(0), radians(360), !1), 
    ctx.stroke(), ctx.moveTo(2 * n, 2.5 * n), ctx.lineTo(2 * n, n / 2 + l), ctx.stroke(), 
    ctx.arc(1.5 * n, n / 2 + l, n / 2, radians(0), radians(180), !0), ctx.stroke(), 
    ctx.moveTo(n, n / 2 + l), ctx.lineTo(n, 2 * n), ctx.stroke(), ctx.fillStyle = color.toString(), 
    ctx.beginPath(), ctx.moveTo(3.5 * n, 3.5 * n), ctx.quadraticCurveTo(w, 3.5 * n, w - l, h), 
    ctx.lineTo(w, h), ctx.quadraticCurveTo(w, 2 * n, 2.5 * n, 1.5 * n), ctx.lineTo(4 * n, 3 * n), 
    ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolEraser = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 4, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(3 * n, l), ctx.lineTo(l, 3 * n), ctx.quadraticCurveTo(n, h, 2 * n, 3 * n), 
    ctx.lineTo(w - l, n), ctx.closePath(), ctx.stroke(), ctx.fillStyle = color.toString(), 
    ctx.beginPath(), ctx.moveTo(3 * n, 0), ctx.lineTo(1.5 * n, 1.5 * n), ctx.lineTo(2.5 * n, 2.5 * n), 
    ctx.lineTo(w, n), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolPipette = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 4, n2 = n / 2, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(l, h - l), ctx.quadraticCurveTo(n2, h - n2, n2, h - n), ctx.lineTo(2 * n, 1.5 * n), 
    ctx.stroke(), ctx.beginPath(), ctx.moveTo(l, h - l), ctx.quadraticCurveTo(n2, h - n2, n, h - n2), 
    ctx.lineTo(2.5 * n, 2 * n), ctx.stroke(), ctx.fillStyle = color.toString(), ctx.arc(3 * n, n, n - l, radians(0), radians(360), !1), 
    ctx.fill(), ctx.beginPath(), ctx.moveTo(2 * n, n), ctx.lineTo(3 * n, 2 * n), ctx.stroke(), 
    canvas;
}, SymbolMorph.prototype.drawSymbolSpeechBubble = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 3, l = Math.max(w / 20, .5);
    return ctx.fillStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(n, 2 * n), ctx.quadraticCurveTo(l, 2 * n, l, n), ctx.quadraticCurveTo(l, l, n, l), 
    ctx.lineTo(2 * n, l), ctx.quadraticCurveTo(w - l, l, w - l, n), ctx.quadraticCurveTo(w - l, 2 * n, 2 * n, 2 * n), 
    ctx.lineTo(n / 2, h - l), ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolSpeechBubbleOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 3, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(n, 2 * n), ctx.quadraticCurveTo(l, 2 * n, l, n), ctx.quadraticCurveTo(l, l, n, l), 
    ctx.lineTo(2 * n, l), ctx.quadraticCurveTo(w - l, l, w - l, n), ctx.quadraticCurveTo(w - l, 2 * n, 2 * n, 2 * n), 
    ctx.lineTo(n / 2, h - l), ctx.closePath(), ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowUp = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 2, l = Math.max(w / 20, .5);
    return ctx.fillStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(l, n), ctx.lineTo(n, l), ctx.lineTo(w - l, n), ctx.lineTo(.65 * w, n), 
    ctx.lineTo(.65 * w, h - l), ctx.lineTo(.35 * w, h - l), ctx.lineTo(.35 * w, n), 
    ctx.closePath(), ctx.fill(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowUpOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 2, l = Math.max(w / 20, .5);
    return ctx.strokeStyle = color.toString(), ctx.lineWidth = 2 * l, ctx.beginPath(), 
    ctx.moveTo(l, n), ctx.lineTo(n, l), ctx.lineTo(w - l, n), ctx.lineTo(.65 * w, n), 
    ctx.lineTo(.65 * w, h - l), ctx.lineTo(.35 * w, h - l), ctx.lineTo(.35 * w, n), 
    ctx.closePath(), ctx.stroke(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowDown = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.save(), ctx.translate(w, w), ctx.rotate(radians(180)), this.drawSymbolArrowUp(canvas, color), 
    ctx.restore(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowDownOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.save(), ctx.translate(w, w), ctx.rotate(radians(180)), this.drawSymbolArrowUpOutline(canvas, color), 
    ctx.restore(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowLeft = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.save(), ctx.translate(0, w), ctx.rotate(radians(-90)), this.drawSymbolArrowUp(canvas, color), 
    ctx.restore(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowLeftOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.save(), ctx.translate(0, w), ctx.rotate(radians(-90)), this.drawSymbolArrowUpOutline(canvas, color), 
    ctx.restore(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowRight = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.save(), ctx.translate(w, 0), ctx.rotate(radians(90)), this.drawSymbolArrowUp(canvas, color), 
    ctx.restore(), canvas;
}, SymbolMorph.prototype.drawSymbolArrowRightOutline = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width;
    return ctx.save(), ctx.translate(w, 0), ctx.rotate(radians(90)), this.drawSymbolArrowUpOutline(canvas, color), 
    ctx.restore(), canvas;
}, SymbolMorph.prototype.drawSymbolRobot = function(canvas, color) {
    var ctx = canvas.getContext("2d"), w = canvas.width, h = canvas.height, n = canvas.width / 6, n2 = n / 2, l = Math.max(w / 20, .5);
    return ctx.fillStyle = color.toString(), ctx.beginPath(), ctx.moveTo(n + l, n), 
    ctx.lineTo(2 * n, n), ctx.lineTo(2.5 * n, 1.5 * n), ctx.lineTo(3.5 * n, 1.5 * n), 
    ctx.lineTo(4 * n, n), ctx.lineTo(5 * n - l, n), ctx.lineTo(4 * n, 3 * n), ctx.lineTo(4 * n, 4 * n - l), 
    ctx.lineTo(2 * n, 4 * n - l), ctx.lineTo(2 * n, 3 * n), ctx.closePath(), ctx.fill(), 
    ctx.beginPath(), ctx.moveTo(2.75 * n, n + l), ctx.lineTo(2.4 * n, n), ctx.lineTo(2.2 * n, 0), 
    ctx.lineTo(3.8 * n, 0), ctx.lineTo(3.6 * n, n), ctx.lineTo(3.25 * n, n + l), ctx.closePath(), 
    ctx.fill(), ctx.beginPath(), ctx.moveTo(2.5 * n, 4 * n), ctx.lineTo(n, 4 * n), ctx.lineTo(n2 + l, h), 
    ctx.lineTo(2 * n, h), ctx.closePath(), ctx.fill(), ctx.beginPath(), ctx.moveTo(3.5 * n, 4 * n), 
    ctx.lineTo(5 * n, 4 * n), ctx.lineTo(w - (n2 + l), h), ctx.lineTo(4 * n, h), ctx.closePath(), 
    ctx.fill(), ctx.beginPath(), ctx.moveTo(n, n), ctx.lineTo(l, 1.5 * n), ctx.lineTo(l, 3.25 * n), 
    ctx.lineTo(1.5 * n, 3.5 * n), ctx.closePath(), ctx.fill(), ctx.beginPath(), ctx.moveTo(5 * n, n), 
    ctx.lineTo(w - l, 1.5 * n), ctx.lineTo(w - l, 3.25 * n), ctx.lineTo(4.5 * n, 3.5 * n), 
    ctx.closePath(), ctx.fill(), canvas;
}, ColorSlotMorph.prototype = new ArgMorph(), ColorSlotMorph.prototype.constructor = ColorSlotMorph, 
ColorSlotMorph.uber = ArgMorph.prototype;

function ColorSlotMorph(clr) {
    this.init(clr);
}

ColorSlotMorph.prototype.init = function(clr) {
    ColorSlotMorph.uber.init.call(this), this.setColor(clr || new Color(145, 26, 68));
}, ColorSlotMorph.prototype.getSpec = function() {
    return "%clr";
}, ColorSlotMorph.prototype.getUserColor = function() {
    var myself = this, world = this.world(), hand = world.hand, posInDocument = getDocumentPositionOf(world.worldCanvas), mouseMoveBak = hand.processMouseMove, mouseDownBak = hand.processMouseDown, mouseUpBak = hand.processMouseUp, pal = new ColorPaletteMorph(null, new Point(16 * this.fontSize, 10 * this.fontSize));
    world.add(pal), pal.setPosition(this.bottomLeft().add(new Point(0, this.edge))), 
    hand.processMouseMove = function(event) {
        hand.setPosition(new Point(event.pageX - posInDocument.x, event.pageY - posInDocument.y)), 
        myself.setColor(world.getGlobalPixelColor(hand.position()));
    }, hand.processMouseDown = nop, hand.processMouseUp = function() {
        pal.destroy(), hand.processMouseMove = mouseMoveBak, hand.processMouseDown = mouseDownBak, 
        hand.processMouseUp = mouseUpBak;
    };
}, ColorSlotMorph.prototype.mouseClickLeft = function() {
    this.getUserColor();
}, ColorSlotMorph.prototype.evaluate = function() {
    return this.color;
}, ColorSlotMorph.prototype.drawNew = function() {
    var context, borderColor, side;
    side = this.fontSize + 2 * this.edge + 2 * this.typeInPadding, this.silentSetExtent(new Point(side, side)), 
    this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), borderColor = this.parent ? this.parent.color : new Color(120, 120, 120), 
    context.fillStyle = this.color.toString(), this.cachedClr = borderColor.toString(), 
    this.cachedClrBright = borderColor.lighter(this.contrast).toString(), this.cachedClrDark = borderColor.darker(this.contrast).toString(), 
    context.fillRect(this.edge, this.edge, this.width() - 2 * this.edge, this.height() - 2 * this.edge), 
    MorphicPreferences.isFlat || this.drawRectBorder(context);
}, ColorSlotMorph.prototype.drawRectBorder = InputSlotMorph.prototype.drawRectBorder, 
BlockHighlightMorph.prototype = new Morph(), BlockHighlightMorph.prototype.constructor = BlockHighlightMorph, 
BlockHighlightMorph.uber = Morph.prototype;

function BlockHighlightMorph() {
    this.init();
}

MultiArgMorph.prototype = new ArgMorph(), MultiArgMorph.prototype.constructor = MultiArgMorph, 
MultiArgMorph.uber = ArgMorph.prototype;

function MultiArgMorph(slotSpec, labelTxt, min, eSpec, arrowColor, labelColor, shadowColor, shadowOffset, isTransparent) {
    this.init(slotSpec, labelTxt, min, eSpec, arrowColor, labelColor, shadowColor, shadowOffset, isTransparent);
}

MultiArgMorph.prototype.init = function(slotSpec, labelTxt, min, eSpec, arrowColor, labelColor, shadowColor, shadowOffset, isTransparent) {
    var label, leftArrow, rightArrow, i, arrows = new FrameMorph();
    for (this.slotSpec = slotSpec || "%s", this.labelText = localize(labelTxt || ""), 
    this.minInputs = min || 0, this.elementSpec = eSpec || null, this.labelColor = labelColor || null, 
    this.shadowColor = shadowColor || null, this.shadowOffset = shadowOffset || null, 
    this.canBeEmpty = !0, MultiArgMorph.uber.init.call(this), this.alpha = !1 === isTransparent ? 1 : 0, 
    arrows.alpha = !1 === isTransparent ? 1 : 0, arrows.noticesTransparentClick = !0, 
    this.noticesTransparentclick = !0, label = this.labelPart(this.labelText), this.add(label), 
    label.hide(), leftArrow = new ArrowMorph("left", this.fontSize, Math.max(Math.floor(this.fontSize / 6), 1), arrowColor), 
    rightArrow = new ArrowMorph("right", this.fontSize, Math.max(Math.floor(this.fontSize / 6), 1), arrowColor), 
    arrows.add(leftArrow), arrows.add(rightArrow), arrows.drawNew(), arrows.acceptsDrops = !1, 
    this.add(arrows), i = 0; i < this.minInputs; i += 1) this.addInput();
}, MultiArgMorph.prototype.label = function() {
    return this.children[0];
}, MultiArgMorph.prototype.arrows = function() {
    return this.children[this.children.length - 1];
}, MultiArgMorph.prototype.getSpec = function() {
    return "%mult" + this.slotSpec;
}, MultiArgMorph.prototype.setContents = function(anArray) {
    var i, inputs = this.inputs();
    for (i = 0; i < anArray.length; i += 1) null !== anArray[i] && inputs[i] && inputs[i].setContents(anArray[i]);
}, MultiArgMorph.prototype.hide = function() {
    this.isVisible = !1, this.changed();
}, MultiArgMorph.prototype.show = function() {
    this.isVisible = !0, this.changed();
}, MultiArgMorph.prototype.setLabelColor = function(textColor, shadowColor, shadowOffset) {
    this.textColor = textColor, this.shadowColor = shadowColor, this.shadowOffset = shadowOffset, 
    MultiArgMorph.uber.setLabelColor.call(this, textColor, shadowColor, shadowOffset);
}, MultiArgMorph.prototype.fixLayout = function() {
    if ("%t" === this.slotSpec && (this.isStatic = !0), this.parent) {
        var shadowColor, shadowOffset, label = this.label();
        this.color = this.parent.color, shadowColor = this.shadowColor || this.parent.color.darker(this.labelContrast), 
        shadowOffset = this.shadowOffset || label.shadowOffset, this.arrows().color = this.color, 
        "" !== this.labelText && (label.shadowColor.eq(shadowColor) || (label.shadowColor = shadowColor, 
        label.shadowOffset = shadowOffset, label.drawNew()));
    }
    this.fixArrowsLayout(), MultiArgMorph.uber.fixLayout.call(this), this.parent && this.parent.fixLayout();
}, MultiArgMorph.prototype.fixArrowsLayout = function() {
    var label = this.label(), arrows = this.arrows(), leftArrow = arrows.children[0], rightArrow = arrows.children[1], dim = new Point(rightArrow.width() / 2, rightArrow.height());
    this.inputs().length < this.minInputs + 1 ? (label.hide(), leftArrow.hide(), rightArrow.setPosition(arrows.position().subtract(new Point(dim.x, 0))), 
    arrows.setExtent(dim)) : ("" !== this.labelText && label.show(), leftArrow.show(), 
    rightArrow.setPosition(leftArrow.topCenter()), arrows.bounds.corner = rightArrow.bottomRight().copy()), 
    arrows.drawNew();
}, MultiArgMorph.prototype.refresh = function() {
    this.inputs().forEach(function(input) {
        input.drawNew();
    });
}, MultiArgMorph.prototype.drawNew = function() {
    MultiArgMorph.uber.drawNew.call(this), this.refresh();
}, MultiArgMorph.prototype.addInput = function(contents) {
    var i, name, newPart = this.labelPart(this.slotSpec), idx = this.children.length - 1;
    if (contents) newPart.setContents(contents); else if ("%scriptVars" === this.elementSpec) {
        for (name = "", i = idx; i > 0; ) name = String.fromCharCode(97 + (i - 1) % 26) + name, 
        i = Math.floor((i - 1) / 26);
        newPart.setContents(name);
    } else contains([ "%parms", "%ringparms" ], this.elementSpec) && newPart.setContents("#" + idx);
    newPart.parent = this, this.children.splice(idx, 0, newPart), newPart.drawNew(), 
    this.fixLayout();
}, MultiArgMorph.prototype.removeInput = function() {
    var oldPart, scripts;
    this.children.length > 1 && (oldPart = this.children[this.children.length - 2], 
    this.removeChild(oldPart), oldPart instanceof BlockMorph && (scripts = this.parentThatIsA(ScriptsMorph)) && scripts.add(oldPart)), 
    this.fixLayout();
}, MultiArgMorph.prototype.mouseClickLeft = function(pos) {
    var i, arrows = this.arrows(), leftArrow = arrows.children[0], rightArrow = arrows.children[1], repetition = 16 === this.world().currentKey ? 3 : 1;
    if (this.startLayout(), rightArrow.bounds.containsPoint(pos)) for (i = 0; i < repetition; i += 1) rightArrow.isVisible && this.addInput(); else if (leftArrow.bounds.containsPoint(pos)) for (i = 0; i < repetition; i += 1) leftArrow.isVisible && this.removeInput(); else this.escalateEvent("mouseClickLeft", pos);
    this.endLayout();
}, MultiArgMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this), block = this.parentThatIsA(BlockMorph), key = "", myself = this;
    return StageMorph.prototype.enableCodeMapping ? (block && (block instanceof RingMorph ? key = "parms_" : "doDeclareVariables" === block.selector && (key = "tempvars_")), 
    menu.addItem("code list mapping...", function() {
        myself.mapCodeList(key);
    }), menu.addItem("code item mapping...", function() {
        myself.mapCodeItem(key);
    }), menu.addItem("code delimiter mapping...", function() {
        myself.mapCodeDelimiter(key);
    }), menu) : this.parent.userMenu();
}, MultiArgMorph.prototype.mapCodeDelimiter = function(key) {
    this.mapToCode(key + "delim", "list item delimiter");
}, MultiArgMorph.prototype.mapCodeList = function(key) {
    this.mapToCode(key + "list", "list contents <#1>");
}, MultiArgMorph.prototype.mapCodeItem = function(key) {
    this.mapToCode(key + "item", "list item <#1>");
}, MultiArgMorph.prototype.mapToCode = function(key, label) {
    new DialogBoxMorph(this, function(code) {
        StageMorph.prototype.codeMappings[key] = code;
    }, this).promptCode("Code mapping - " + label, StageMorph.prototype.codeMappings[key] || "", this.world());
}, MultiArgMorph.prototype.mappedCode = function(definitions) {
    var code, itemCode, delim, block = this.parentThatIsA(BlockMorph), key = "", items = "", count = 0, parts = [];
    return block && (block instanceof RingMorph ? key = "parms_" : "doDeclareVariables" === block.selector && (key = "tempvars_")), 
    code = StageMorph.prototype.codeMappings[key + "list"] || "<#1>", itemCode = StageMorph.prototype.codeMappings[key + "item"] || "<#1>", 
    delim = StageMorph.prototype.codeMappings[key + "delim"] || " ", this.inputs().forEach(function(input) {
        parts.push(itemCode.replace(/<#1>/g, input.mappedCode(definitions)));
    }), parts.forEach(function(part) {
        count && (items += delim), items += part, count += 1;
    }), code = code.replace(/<#1>/g, items);
}, MultiArgMorph.prototype.evaluate = function() {
    var result = [];
    return this.inputs().forEach(function(slot) {
        result.push(slot.evaluate());
    }), result;
}, MultiArgMorph.prototype.isEmptySlot = function() {
    return !!this.canBeEmpty && 0 === this.inputs().length;
}, ArgLabelMorph.prototype = new ArgMorph(), ArgLabelMorph.prototype.constructor = ArgLabelMorph, 
ArgLabelMorph.uber = ArgMorph.prototype;

function ArgLabelMorph(argMorph, labelTxt) {
    this.init(argMorph, labelTxt);
}

ArgLabelMorph.prototype.init = function(argMorph, labelTxt) {
    var label;
    this.labelText = localize(labelTxt || "input list:"), ArgLabelMorph.uber.init.call(this), 
    this.isStatic = !0, this.alpha = 0, this.noticesTransparentclick = !0, label = this.labelPart(this.labelText), 
    this.add(label), this.add(argMorph);
}, ArgLabelMorph.prototype.label = function() {
    return this.children[0];
}, ArgLabelMorph.prototype.argMorph = function() {
    return this.children[1];
}, ArgLabelMorph.prototype.fixLayout = function() {
    var shadowColor, shadowOffset, label = this.label();
    this.parent && (this.color = this.parent.color, shadowColor = (shadowOffset = label.shadowOffset || new Point()).x < 0 ? this.parent.color.darker(this.labelContrast) : this.parent.color.lighter(this.labelContrast), 
    "" !== this.labelText && (label.shadowColor.eq(shadowColor) || (label.shadowColor = shadowColor, 
    label.shadowOffset = shadowOffset, label.drawNew()))), ArgLabelMorph.uber.fixLayout.call(this), 
    this.parent && this.parent.fixLayout();
}, ArgLabelMorph.prototype.refresh = function() {
    this.inputs().forEach(function(input) {
        input.drawNew();
    });
}, ArgLabelMorph.prototype.drawNew = function() {
    ArgLabelMorph.uber.drawNew.call(this), this.refresh();
}, ArgLabelMorph.prototype.setLabelColor = function(textColor, shadowColor, shadowOffset) {
    if ("" !== this.labelText) {
        var label = this.label();
        label.color = textColor, label.shadowColor = shadowColor, label.shadowOffset = shadowOffset, 
        label.drawNew();
    }
}, ArgLabelMorph.prototype.reactToGrabOf = function() {
    this.parent instanceof SyntaxElementMorph && this.parent.revertToDefaultInput(this);
}, ArgLabelMorph.prototype.evaluate = function() {
    return this.argMorph().evaluate();
}, ArgLabelMorph.prototype.isEmptySlot = function() {
    return !1;
}, FunctionSlotMorph.prototype = new ArgMorph(), FunctionSlotMorph.prototype.constructor = FunctionSlotMorph, 
FunctionSlotMorph.uber = ArgMorph.prototype;

function FunctionSlotMorph(isPredicate) {
    this.init(isPredicate);
}

FunctionSlotMorph.prototype.init = function(isPredicate) {
    FunctionSlotMorph.uber.init.call(this), this.isPredicate = isPredicate || !1, this.color = this.rfColor, 
    this.setExtent(new Point(2 * (this.fontSize + 2 * this.edge), this.fontSize + 2 * this.edge));
}, FunctionSlotMorph.prototype.getSpec = function() {
    return "%f";
}, FunctionSlotMorph.prototype.drawNew = function() {
    var context, borderColor;
    this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), borderColor = this.parent ? this.parent.color : new Color(120, 120, 120), 
    this.cachedClr = borderColor.toString(), this.cachedClrBright = borderColor.lighter(this.contrast).toString(), 
    this.cachedClrDark = borderColor.darker(this.contrast).toString(), this.isPredicate ? this.drawDiamond(context) : this.drawRounded(context);
}, FunctionSlotMorph.prototype.drawRounded = function(context) {
    var gradient, h = this.height(), r = Math.min(this.rounding, h / 2), w = this.width(), shift = this.edge / 2;
    context.fillStyle = this.color.toString(), context.beginPath(), context.arc(r, r, r, radians(-180), radians(-90), !1), 
    context.arc(w - r, r, r, radians(-90), radians(-0), !1), context.arc(w - r, h - r, r, radians(0), radians(90), !1), 
    context.arc(r, h - r, r, radians(90), radians(180), !1), context.closePath(), context.fill(), 
    MorphicPreferences.isFlat || (context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = this.cachedClr, context.beginPath(), 
    context.arc(r, h - r, r - shift, radians(90), radians(180), !1), context.stroke(), 
    context.strokeStyle = this.cachedClr, context.beginPath(), context.arc(w - r, r, r - shift, radians(-90), radians(0), !1), 
    context.stroke(), context.shadowOffsetX = shift, context.shadowOffsetY = shift, 
    context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r - shift, shift), context.lineTo(w - r + shift, shift), context.stroke(), 
    (gradient = context.createRadialGradient(r, r, r - this.edge, r, r, r)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(r, r, r - shift, radians(180), radians(270), !1), context.stroke(), 
    (gradient = context.createLinearGradient(0, 0, this.edge, 0)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, r), context.lineTo(shift, h - r), context.stroke(), context.shadowOffsetX = 0, 
    context.shadowOffsetY = 0, context.shadowBlur = 0, (gradient = context.createRadialGradient(w - r, h - r, r - this.edge, w - r, h - r, r)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.arc(w - r, h - r, r - shift, radians(0), radians(90), !1), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(r - shift, h - shift), context.lineTo(w - r + shift, h - shift), 
    context.stroke(), (gradient = context.createLinearGradient(w - this.edge, 0, w, 0)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(w - shift, r + shift), context.lineTo(w - shift, h - r), 
    context.stroke());
}, FunctionSlotMorph.prototype.drawDiamond = function(context) {
    var gradient, w = this.width(), h = this.height(), h2 = Math.floor(h / 2), r = Math.min(this.rounding, h2), shift = this.edge / 2;
    context.fillStyle = this.color.toString(), context.beginPath(), context.moveTo(0, h2), 
    context.lineTo(r, 0), context.lineTo(w - r, 0), context.lineTo(w, h2), context.lineTo(w - r, h), 
    context.lineTo(r, h), context.closePath(), context.fill(), MorphicPreferences.isFlat || (context.lineWidth = this.edge, 
    context.lineJoin = "round", context.lineCap = "round", context.strokeStyle = this.cachedClr, 
    context.beginPath(), context.moveTo(shift, h2), context.lineTo(r, h - shift), context.stroke(), 
    context.strokeStyle = this.cachedClr, context.beginPath(), context.moveTo(w - shift, h2), 
    context.lineTo(w - r, shift), context.stroke(), context.shadowOffsetX = shift, context.shadowOffsetY = shift, 
    context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, r, 0)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, h2), context.lineTo(r, shift), context.stroke(), (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r, shift), context.lineTo(w - r, shift), context.stroke(), context.shadowOffsetX = 0, 
    context.shadowOffsetY = 0, context.shadowBlur = 0, (gradient = context.createLinearGradient(w - r, 0, w, 0)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(w - r, h - shift), context.lineTo(w - shift, h2), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(r + shift, h - shift), context.lineTo(w - r - shift, h - shift), 
    context.stroke());
}, ReporterSlotMorph.prototype = new FunctionSlotMorph(), ReporterSlotMorph.prototype.constructor = ReporterSlotMorph, 
ReporterSlotMorph.uber = FunctionSlotMorph.prototype;

function ReporterSlotMorph(isPredicate) {
    this.init(isPredicate);
}

ReporterSlotMorph.prototype.init = function(isPredicate) {
    ReporterSlotMorph.uber.init.call(this, isPredicate), this.add(this.emptySlot()), 
    this.fixLayout();
}, ReporterSlotMorph.prototype.emptySlot = function() {
    var empty = new ArgMorph(), shrink = 2 * this.rfBorder + 2 * this.edge;
    return empty.color = this.rfColor, empty.alpha = 0, empty.setExtent(new Point(2 * (this.fontSize + 2 * this.edge) - shrink, this.fontSize + 2 * this.edge - shrink)), 
    empty;
}, ReporterSlotMorph.prototype.getSpec = function() {
    return "%r";
}, ReporterSlotMorph.prototype.contents = function() {
    return this.children[0];
}, ReporterSlotMorph.prototype.nestedBlock = function() {
    var contents = this.contents();
    return contents instanceof ReporterBlockMorph ? contents : null;
}, ReporterSlotMorph.prototype.evaluate = function() {
    return this.nestedBlock();
}, ReporterSlotMorph.prototype.isEmptySlot = function() {
    return null === this.nestedBlock();
}, ReporterSlotMorph.prototype.fixLayout = function() {
    var contents = this.contents();
    this.setExtent(contents.extent().add(2 * this.edge + 2 * this.rfBorder)), contents.setCenter(this.center()), 
    this.parent && this.parent.fixLayout && this.parent.fixLayout();
}, RingReporterSlotMorph.prototype = new ReporterSlotMorph(), RingReporterSlotMorph.prototype.constructor = RingReporterSlotMorph, 
RingReporterSlotMorph.uber = ReporterSlotMorph.prototype, RingReporterSlotMorph.prototype.rfBorder = RingCommandSlotMorph.prototype.rfBorder, 
RingReporterSlotMorph.prototype.edge = RingCommandSlotMorph.prototype.edge;

function RingReporterSlotMorph(isPredicate) {
    this.init(isPredicate);
}

RingReporterSlotMorph.prototype.init = function(isPredicate) {
    RingReporterSlotMorph.uber.init.call(this, isPredicate), this.alpha = RingMorph.prototype.alpha, 
    this.contrast = RingMorph.prototype.contrast, this.isHole = !0;
}, RingReporterSlotMorph.prototype.getSpec = function() {
    return "%rr";
}, RingReporterSlotMorph.prototype.replaceInput = function(source, target) {
    RingReporterSlotMorph.uber.replaceInput.call(this, source, target), this.parent instanceof RingMorph && this.parent.vanishForSimilar();
}, RingReporterSlotMorph.prototype.drawRounded = function(context) {
    var gradient, h = this.height(), r = Math.min(this.rounding, h / 2), w = this.width(), shift = this.edge / 2;
    context.fillStyle = this.cachedClr, context.beginPath(), context.moveTo(0, h / 2), 
    context.arc(r, r, r, radians(-180), radians(-90), !1), context.arc(w - r, r, r, radians(-90), radians(-0), !1), 
    context.lineTo(w, h / 2), context.lineTo(w, 0), context.lineTo(0, 0), context.closePath(), 
    context.fill(), context.beginPath(), context.moveTo(w, h / 2), context.arc(w - r, h - r, r, radians(0), radians(90), !1), 
    context.arc(r, h - r, r, radians(90), radians(180), !1), context.lineTo(0, h / 2), 
    context.lineTo(0, h), context.lineTo(w, h), context.closePath(), context.fill(), 
    MorphicPreferences.isFlat || (context.lineWidth = this.edge, context.lineJoin = "round", 
    context.lineCap = "round", context.strokeStyle = this.cachedClr, context.beginPath(), 
    context.arc(r, h - r, r - shift, radians(90), radians(180), !1), context.stroke(), 
    context.strokeStyle = this.cachedClr, context.beginPath(), context.arc(w - r, r, r - shift, radians(-90), radians(0), !1), 
    context.stroke(), context.shadowOffsetX = shift, context.shadowOffsetY = shift, 
    context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r - shift, shift), context.lineTo(w - r + shift, shift), context.stroke(), 
    (gradient = context.createRadialGradient(r, r, r - this.edge, r, r, r)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.arc(r, r, r - shift, radians(180), radians(270), !1), context.stroke(), 
    (gradient = context.createLinearGradient(0, 0, this.edge, 0)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, r), context.lineTo(shift, h - r), context.stroke(), context.shadowOffsetX = 0, 
    context.shadowOffsetY = 0, context.shadowBlur = 0, (gradient = context.createRadialGradient(w - r, h - r, r - this.edge, w - r, h - r, r)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.arc(w - r, h - r, r - shift, radians(0), radians(90), !1), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(r - shift, h - shift), context.lineTo(w - r + shift, h - shift), 
    context.stroke(), (gradient = context.createLinearGradient(w - this.edge, 0, w, 0)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(w - shift, r + shift), context.lineTo(w - shift, h - r), 
    context.stroke());
}, RingReporterSlotMorph.prototype.drawDiamond = function(context) {
    var gradient, w = this.width(), h = this.height(), h2 = Math.floor(h / 2), r = Math.min(this.rounding, h2), shift = this.edge / 2;
    context.fillStyle = this.cachedClr, context.beginPath(), context.moveTo(0, 0), context.lineTo(0, h2), 
    context.lineTo(r, 0), context.lineTo(w - r, 0), context.lineTo(w, h2), context.lineTo(w, 0), 
    context.closePath(), context.fill(), context.moveTo(w, h2), context.lineTo(w - r, h), 
    context.lineTo(r, h), context.lineTo(0, h2), context.lineTo(0, h), context.lineTo(w, h), 
    context.closePath(), context.fill(), MorphicPreferences.isFlat || (context.lineWidth = this.edge, 
    context.lineJoin = "round", context.lineCap = "round", context.strokeStyle = this.cachedClr, 
    context.beginPath(), context.moveTo(shift, h2), context.lineTo(r, h - shift), context.stroke(), 
    context.strokeStyle = this.cachedClr, context.beginPath(), context.moveTo(w - shift, h2), 
    context.lineTo(w - r, shift), context.stroke(), context.shadowOffsetX = shift, context.shadowOffsetY = shift, 
    context.shadowBlur = this.edge, context.shadowColor = this.color.darker(80).toString(), 
    (gradient = context.createLinearGradient(0, 0, r, 0)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, h2), context.lineTo(r, shift), context.stroke(), (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(1, this.cachedClrDark), 
    gradient.addColorStop(0, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(r, shift), context.lineTo(w - r, shift), context.stroke(), context.shadowOffsetX = 0, 
    context.shadowOffsetY = 0, context.shadowBlur = 0, (gradient = context.createLinearGradient(w - r, 0, w, 0)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(w - r, h - shift), context.lineTo(w - shift, h2), 
    context.stroke(), (gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(1, this.cachedClr), 
    gradient.addColorStop(0, this.cachedClrBright), context.strokeStyle = gradient, 
    context.beginPath(), context.moveTo(r + shift, h - shift), context.lineTo(w - r - shift, h - shift), 
    context.stroke());
}, CommentMorph.prototype = new BoxMorph(), CommentMorph.prototype.constructor = CommentMorph, 
CommentMorph.uber = BoxMorph.prototype, CommentMorph.prototype.refreshScale = function() {
    CommentMorph.prototype.fontSize = SyntaxElementMorph.prototype.fontSize, CommentMorph.prototype.padding = 5 * SyntaxElementMorph.prototype.scale, 
    CommentMorph.prototype.rounding = 8 * SyntaxElementMorph.prototype.scale;
}, CommentMorph.prototype.refreshScale();

function CommentMorph(contents) {
    this.init(contents);
}

CommentMorph.prototype.init = function(contents) {
    var myself = this, scale = SyntaxElementMorph.prototype.scale;
    this.block = null, this.stickyOffset = null, this.isCollapsed = !1, this.titleBar = new BoxMorph(this.rounding, 1.000001 * scale, new Color(255, 255, 180)), 
    this.titleBar.color = new Color(255, 255, 180), this.titleBar.setHeight(fontHeight(this.fontSize) + this.padding), 
    this.title = null, this.arrow = new ArrowMorph("down", this.fontSize), this.arrow.noticesTransparentClick = !0, 
    this.arrow.mouseClickLeft = function() {
        myself.toggleExpand();
    }, this.contents = new TextMorph(contents || localize("add comment here..."), this.fontSize), 
    this.contents.isEditable = !0, this.contents.enableSelecting(), this.contents.maxWidth = 90 * scale, 
    this.contents.drawNew(), this.handle = new HandleMorph(this.contents, 80, 2 * this.fontSize, -2, -2), 
    this.handle.setExtent(new Point(11 * scale, 11 * scale)), this.anchor = null, CommentMorph.uber.init.call(this, this.rounding, 1.000001 * scale, new Color(255, 255, 180)), 
    this.color = new Color(255, 255, 220), this.isDraggable = !0, this.add(this.titleBar), 
    this.add(this.arrow), this.add(this.contents), this.add(this.handle), this.fixLayout();
}, CommentMorph.prototype.fullCopy = function() {
    var cpy = new CommentMorph(this.contents.text);
    return cpy.isCollapsed = this.isCollapsed, cpy.setTextWidth(this.textWidth()), cpy;
}, CommentMorph.prototype.setTextWidth = function(pixels) {
    this.contents.maxWidth = pixels, this.contents.drawNew(), this.fixLayout();
}, CommentMorph.prototype.textWidth = function() {
    return this.contents.maxWidth;
}, CommentMorph.prototype.text = function() {
    return this.contents.text;
}, CommentMorph.prototype.toggleExpand = function() {
    this.isCollapsed = !this.isCollapsed, this.fixLayout(), this.align();
}, CommentMorph.prototype.layoutChanged = function() {
    this.fixLayout(), this.align();
}, CommentMorph.prototype.fixLayout = function() {
    var label, tw = this.contents.width() + 2 * this.padding, myself = this, oldFlag = Morph.prototype.trackChanges;
    Morph.prototype.trackChanges = !1, this.title && (this.title.destroy(), this.title = null), 
    this.isCollapsed ? (this.contents.hide(), this.title = new FrameMorph(), this.title.alpha = 0, 
    this.title.acceptsDrops = !1, (label = new StringMorph(this.contents.text, this.fontSize, null, !0)).rootForGrab = function() {
        return myself;
    }, this.title.add(label), this.title.setHeight(label.height()), this.title.setWidth(tw - this.arrow.width() - 2 * this.padding - this.rounding), 
    this.add(this.title)) : this.contents.show(), this.titleBar.setWidth(tw), this.contents.setLeft(this.titleBar.left() + this.padding), 
    this.contents.setTop(this.titleBar.bottom() + this.padding), this.arrow.direction = this.isCollapsed ? "right" : "down", 
    this.arrow.drawNew(), this.arrow.setCenter(this.titleBar.center()), this.arrow.setLeft(this.titleBar.left() + this.padding), 
    this.title && this.title.setPosition(this.arrow.topRight().add(new Point(this.padding, 0))), 
    Morph.prototype.trackChanges = oldFlag, this.changed(), this.silentSetHeight(this.titleBar.height() + (this.isCollapsed ? 0 : this.padding + this.contents.height() + this.padding)), 
    this.silentSetWidth(this.titleBar.width()), this.drawNew(), this.handle.drawNew(), 
    this.changed();
}, CommentMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this), myself = this;
    return menu.addItem("duplicate", function() {
        myself.fullCopy().pickUp(myself.world());
    }, "make a copy\nand pick it up"), menu.addItem("delete", "destroy"), menu.addItem("comment pic...", function() {
        window.open(myself.fullImage().toDataURL());
    }, "open a new window\nwith a picture of this comment"), menu;
}, CommentMorph.prototype.hide = function() {
    this.isVisible = !1, this.changed();
}, CommentMorph.prototype.show = function() {
    this.isVisible = !0, this.changed();
}, CommentMorph.prototype.prepareToBeGrabbed = function() {
    this.block && (this.block.comment = null, this.block = null), this.anchor && (this.anchor.destroy(), 
    this.anchor = null, this.removeShadow(), this.addShadow());
}, CommentMorph.prototype.snap = function(hand) {
    var target, scripts = this.parent;
    if (!scripts instanceof ScriptsMorph) return null;
    scripts.clearDropHistory(), scripts.lastDroppedBlock = this, null !== (target = scripts.closestBlock(this, hand)) && (target.comment = this, 
    this.block = target, this.snapSound && this.snapSound.play()), this.align();
}, CommentMorph.prototype.align = function(topBlock, ignoreLayer) {
    if (this.block) {
        var affectedBlocks, tp, bottom, rightMost, top = topBlock || this.block.topBlock(), scripts = top.parentThatIsA(ScriptsMorph);
        this.setTop(this.block.top() + this.block.corner), tp = this.top(), bottom = this.bottom(), 
        affectedBlocks = top.allChildren().filter(function(child) {
            return child instanceof BlockMorph && child.bottom() > tp && child.top() < bottom;
        }), rightMost = Math.max.apply(null, affectedBlocks.map(function(block) {
            return block.right();
        })), this.setLeft(rightMost + 5), !ignoreLayer && scripts && scripts.addBack(this), 
        this.anchor || (this.anchor = new Morph(), this.anchor.color = this.titleBar.color), 
        this.anchor.silentSetPosition(new Point(this.block.right(), this.top() + this.edge)), 
        this.anchor.bounds.corner = new Point(this.left(), this.top() + this.edge + 1), 
        this.anchor.drawNew(), this.addBack(this.anchor), this.anchor.changed();
    }
}, CommentMorph.prototype.startFollowing = function(topBlock, world) {
    this.align(topBlock), world.add(this), this.addShadow(), this.stickyOffset = this.position().subtract(this.block.position()), 
    this.step = function() {
        this.setPosition(this.block.position().add(this.stickyOffset));
    };
}, CommentMorph.prototype.stopFollowing = function() {
    this.removeShadow(), delete this.step;
}, CommentMorph.prototype.destroy = function() {
    this.block && (this.block.comment = null), CommentMorph.uber.destroy.call(this);
}, CommentMorph.prototype.stackHeight = function() {
    return this.height();
}, modules.threads = "2015-January-12";

var ThreadManager, Process, Context, VariableFrame;

function snapEquals(a, b) {
    if (a instanceof List || b instanceof List) return a instanceof List && b instanceof List && a.equalTo(b);
    var i, x = +a, y = +b, specials = [ !0, !1, "" ];
    for (i = 9; i <= 13; i += 1) specials.push(String.fromCharCode(i));
    return specials.push(String.fromCharCode(160)), (isNaN(x) || isNaN(y) || [ a, b ].some(function(any) {
        return contains(specials, any) || isString(any) && any.indexOf(" ") > -1;
    })) && (x = a, y = b), isString(x) && isString(y) ? x.toLowerCase() === y.toLowerCase() : x === y;
}

function ThreadManager() {
    this.processes = [];
}

ThreadManager.prototype.toggleProcess = function(block) {
    var active = this.findProcess(block);
    if (!active) return this.startProcess(block);
    active.stop();
}, ThreadManager.prototype.startProcess = function(block, isThreadSafe, exportResult, callback) {
    var newProc, active = this.findProcess(block), top = block.topBlock();
    if (active) {
        if (isThreadSafe) return active;
        active.stop(), this.removeTerminatedProcesses();
    }
    return (newProc = new Process(block.topBlock(), callback)).exportResult = exportResult, 
    newProc.homeContext.receiver.isClone || top.addHighlight(), this.processes.push(newProc), 
    newProc;
}, ThreadManager.prototype.stopAll = function(excpt) {
    this.processes.forEach(function(proc) {
        proc !== excpt && proc.stop();
    });
}, ThreadManager.prototype.stopAllForReceiver = function(rcvr, excpt) {
    this.processes.forEach(function(proc) {
        proc.homeContext.receiver === rcvr && proc !== excpt && (proc.stop(), rcvr.isClone && (proc.isDead = !0));
    });
}, ThreadManager.prototype.stopProcess = function(block) {
    var active = this.findProcess(block);
    active && active.stop();
}, ThreadManager.prototype.pauseAll = function(stage) {
    this.processes.forEach(function(proc) {
        proc.pause();
    }), stage && stage.pauseAllActiveSounds();
}, ThreadManager.prototype.isPaused = function() {
    return null !== detect(this.processes, function(proc) {
        return proc.isPaused;
    });
}, ThreadManager.prototype.resumeAll = function(stage) {
    this.processes.forEach(function(proc) {
        proc.resume();
    }), stage && stage.resumeAllActiveSounds();
}, ThreadManager.prototype.step = function() {
    this.processes.forEach(function(proc) {
        proc.homeContext.receiver.isPickedUp() || proc.isDead || proc.runStep();
    }), this.removeTerminatedProcesses();
}, ThreadManager.prototype.removeTerminatedProcesses = function() {
    var remaining = [];
    this.processes.forEach(function(proc) {
        !proc.isRunning() && !proc.errorFlag || proc.isDead ? (proc.topBlock instanceof BlockMorph && proc.topBlock.removeHighlight(), 
        proc.prompter && (proc.prompter.destroy(), proc.homeContext.receiver.stopTalking && proc.homeContext.receiver.stopTalking()), 
        proc.topBlock instanceof ReporterBlockMorph && (proc.onComplete instanceof Function ? proc.onComplete(proc.homeContext.inputs[0]) : proc.homeContext.inputs[0] instanceof List ? proc.topBlock.showBubble(new ListWatcherMorph(proc.homeContext.inputs[0]), proc.exportResult) : proc.topBlock.showBubble(proc.homeContext.inputs[0], proc.exportResult))) : remaining.push(proc);
    }), this.processes = remaining;
}, ThreadManager.prototype.findProcess = function(block) {
    var top = block.topBlock();
    return detect(this.processes, function(each) {
        return each.topBlock === top;
    });
}, Process.prototype = {}, Process.prototype.contructor = Process, Process.prototype.timeout = 500, 
Process.prototype.isCatchingErrors = !0;

function Process(topBlock, onComplete) {
    this.topBlock = topBlock || null, this.readyToYield = !1, this.readyToTerminate = !1, 
    this.isDead = !1, this.errorFlag = !1, this.context = null, this.homeContext = new Context(), 
    this.lastYield = Date.now(), this.isAtomic = !1, this.prompter = null, this.httpRequest = null, 
    this.isPaused = !1, this.pauseOffset = null, this.frameCount = 0, this.exportResult = !1, 
    this.onComplete = onComplete || null, this.procedureCount = 0, topBlock && (this.homeContext.receiver = topBlock.receiver(), 
    this.homeContext.variables.parentFrame = this.homeContext.receiver.variables, this.context = new Context(null, topBlock.blockSequence(), this.homeContext), 
    this.pushContext("doYield"));
}

Process.prototype.isRunning = function() {
    return null !== this.context && !this.readyToTerminate;
}, Process.prototype.runStep = function() {
    if (this.isPaused) return this.pauseStep();
    for (this.readyToYield = !1; !this.readyToYield && this.context && (!this.isAtomic || Date.now() - this.lastYield < this.timeout); ) {
        if (this.isPaused) return this.pauseStep();
        this.evaluateContext();
    }
    if (this.lastYield = Date.now(), this.isAtomic && this.homeContext.receiver && this.homeContext.receiver.endWarp && (this.homeContext.receiver.endWarp(), 
    this.homeContext.receiver.startWarp()), this.readyToTerminate) {
        for (;this.context; ) this.popContext();
        this.homeContext.receiver && this.homeContext.receiver.endWarp && this.homeContext.receiver.endWarp();
    }
}, Process.prototype.stop = function() {
    this.readyToYield = !0, this.readyToTerminate = !0, this.errorFlag = !1, this.context && this.context.stopMusic();
}, Process.prototype.pause = function() {
    this.isPaused = !0, this.context && this.context.startTime && (this.pauseOffset = Date.now() - this.context.startTime);
}, Process.prototype.resume = function() {
    this.isPaused = !1, this.pauseOffset = null;
}, Process.prototype.pauseStep = function() {
    this.lastYield = Date.now(), this.context && this.context.startTime && (this.context.startTime = this.lastYield - this.pauseOffset);
}, Process.prototype.evaluateContext = function() {
    var exp = this.context.expression;
    return this.frameCount += 1, "exit" === this.context.tag && this.expectReport(), 
    exp instanceof Array ? this.evaluateSequence(exp) : exp instanceof MultiArgMorph ? this.evaluateMultiSlot(exp, exp.inputs().length) : exp instanceof ArgLabelMorph ? this.evaluateArgLabel(exp) : exp instanceof ArgMorph || exp.bindingID ? this.evaluateInput(exp) : exp instanceof BlockMorph ? this.evaluateBlock(exp, exp.inputs().length) : isString(exp) ? this[exp]() : void this.popContext();
}, Process.prototype.evaluateBlock = function(block, argCount) {
    if (contains([ "reportOr", "reportAnd", "doReport" ], block.selector)) return this[block.selector](block);
    var rcvr = this.context.receiver || this.topBlock.receiver(), inputs = this.context.inputs;
    if (argCount > inputs.length) this.evaluateNextInput(block); else if (this[block.selector] && (rcvr = this), 
    this.isCatchingErrors) try {
        this.returnValueToParentContext(rcvr[block.selector].apply(rcvr, inputs)), this.popContext();
    } catch (error) {
        this.handleError(error, block);
    } else this.returnValueToParentContext(rcvr[block.selector].apply(rcvr, inputs)), 
    this.popContext();
}, Process.prototype.reportOr = function(block) {
    var inputs = this.context.inputs;
    inputs.length < 1 ? this.evaluateNextInput(block) : inputs[0] ? (this.returnValueToParentContext(!0), 
    this.popContext()) : inputs.length < 2 ? this.evaluateNextInput(block) : (this.returnValueToParentContext(!0 === inputs[1]), 
    this.popContext());
}, Process.prototype.reportAnd = function(block) {
    var inputs = this.context.inputs;
    inputs.length < 1 ? this.evaluateNextInput(block) : inputs[0] ? inputs.length < 2 ? this.evaluateNextInput(block) : (this.returnValueToParentContext(!0 === inputs[1]), 
    this.popContext()) : (this.returnValueToParentContext(!1), this.popContext());
}, Process.prototype.doReport = function(block) {
    var outer = this.context.outerContext;
    if (this.context.expression.partOfCustomCommand) this.doStopCustomBlock(), this.popContext(); else {
        for (;this.context && "exit" !== this.context.tag; ) "doStopWarping" === this.context.expression ? this.doStopWarping() : this.popContext();
        this.context && ("expectReport" === this.context.expression ? this.popContext() : this.context.tag = null);
    }
    this.pushContext(block.inputs()[0], outer);
}, Process.prototype.evaluateMultiSlot = function(multiSlot, argCount) {
    var ans, inputs = this.context.inputs;
    if (multiSlot.bindingID) {
        if (this.isCatchingErrors) try {
            ans = this.context.variables.getVar(multiSlot.bindingID);
        } catch (error) {
            this.handleError(error, multiSlot);
        } else ans = this.context.variables.getVar(multiSlot.bindingID);
        this.returnValueToParentContext(ans), this.popContext();
    } else argCount > inputs.length ? this.evaluateNextInput(multiSlot) : (this.returnValueToParentContext(new List(inputs)), 
    this.popContext());
}, Process.prototype.evaluateArgLabel = function(argLabel) {
    var inputs = this.context.inputs;
    inputs.length < 1 ? this.evaluateNextInput(argLabel) : (this.returnValueToParentContext(inputs[0]), 
    this.popContext());
}, Process.prototype.evaluateInput = function(input) {
    var ans;
    if (input.bindingID) if (this.isCatchingErrors) try {
        ans = this.context.variables.getVar(input.bindingID);
    } catch (error) {
        this.handleError(error, input);
    } else ans = this.context.variables.getVar(input.bindingID); else (ans = input.evaluate()) && (contains([ CommandSlotMorph, ReporterSlotMorph ], input.constructor) || input instanceof CSlotMorph && !input.isStatic) && (ans = this.reify(ans, new List()));
    this.returnValueToParentContext(ans), this.popContext();
}, Process.prototype.evaluateSequence = function(arr) {
    var pc = this.context.pc, outer = this.context.outerContext, isCustomBlock = this.context.isCustomBlock;
    pc === arr.length - 1 ? (this.context = new Context(this.context.parentContext, arr[pc], this.context.outerContext, this.context.receiver), 
    this.context.isCustomBlock = isCustomBlock) : pc >= arr.length ? this.popContext() : (this.context.pc += 1, 
    this.pushContext(arr[pc], outer));
}, Process.prototype.evaluateNextInput = function(element) {
    var nxt = this.context.inputs.length, exp = element.inputs()[nxt], outer = this.context.outerContext;
    exp.isUnevaluated && (!0 === exp.isUnevaluated || exp.isUnevaluated()) ? contains([ "reify", "reportScript" ], this.context.expression.selector) ? this.context.addInput(exp) : this.context.addInput(this.reify(exp, new List())) : this.pushContext(exp, outer);
}, Process.prototype.doYield = function() {
    this.popContext(), this.isAtomic || (this.readyToYield = !0);
}, Process.prototype.expectReport = function() {
    this.handleError(new Error("reporter didn't report"));
}, Process.prototype.handleError = function(error, element) {
    var m = element;
    this.stop(), this.errorFlag = !0, this.topBlock.addErrorHighlight(), (isNil(m) || isNil(m.world())) && (m = this.topBlock), 
    m.showBubble((m === element ? "" : "Inside: ") + error.name + "\n" + error.message);
}, Process.prototype.reify = function(topBlock, parameterNames, isCustomBlock) {
    var context = new Context(null, null, this.context ? this.context.outerContext : null), i = 0;
    return topBlock ? (context.expression = topBlock.fullCopy(), context.expression.show(), 
    isCustomBlock || (context.expression.allEmptySlots().forEach(function(slot) {
        i += 1, slot.bindingID = slot instanceof MultiArgMorph ? [ "arguments" ] : i;
    }), context.emptySlots = i)) : context.expression = [ this.context.expression.fullCopy() ], 
    context.inputs = parameterNames.asArray(), context.receiver = this.context ? this.context.receiver : topBlock.receiver(), 
    context;
}, Process.prototype.reportScript = function(parameterNames, topBlock) {
    return this.reify(topBlock, parameterNames);
}, Process.prototype.reifyScript = function(topBlock, parameterNames) {
    return this.reify(topBlock, parameterNames);
}, Process.prototype.reifyReporter = function(topBlock, parameterNames) {
    return this.reify(topBlock, parameterNames);
}, Process.prototype.reifyPredicate = function(topBlock, parameterNames) {
    return this.reify(topBlock, parameterNames);
}, Process.prototype.reportJSFunction = function(parmNames, body) {
    return Function.apply(null, parmNames.asArray().concat([ body ]));
}, Process.prototype.doRun = function(context, args) {
    return this.evaluate(context, args, !0);
}, Process.prototype.evaluate = function(context, args, isCommand) {
    if (!context) return null;
    if (context instanceof Function) return context.apply(this.blockReceiver(), args.asArray().concat([ this ]));
    if (context.isContinuation) return this.runContinuation(context, args);
    if (!(context instanceof Context)) throw new Error("expecting a ring but getting " + context);
    var exit, runnable, i, value, outer = new Context(null, null, context.outerContext), caller = this.context.parentContext, parms = args.asArray();
    if (outer.receiver || (outer.receiver = context.receiver), runnable = new Context(this.context.parentContext, context.expression, outer, context.receiver), 
    this.context.parentContext = runnable, context.expression instanceof ReporterBlockMorph && (this.readyToYield = Date.now() - this.lastYield > this.timeout), 
    parms.length > 0) {
        for (i = 0; i < context.inputs.length; i += 1) value = 0, isNil(parms[i]) || (value = parms[i]), 
        outer.variables.addVar(context.inputs[i], value);
        if (0 === context.inputs.length) if (outer.variables.addVar([ "arguments" ], args), 
        1 === parms.length) for (i = 1; i <= context.emptySlots; i += 1) outer.variables.addVar(i, parms[0]); else if (parms.length === context.emptySlots) for (i = 1; i <= parms.length; i += 1) outer.variables.addVar(i, parms[i - 1]); else if (1 !== context.emptySlots) throw new Error(localize("expecting") + " " + context.emptySlots + " " + localize("input(s), but getting") + " " + parms.length);
    }
    runnable.expression instanceof CommandBlockMorph && (runnable.expression = runnable.expression.blockSequence(), 
    isCommand || (caller ? caller.tag = "exit" : ((exit = new Context(runnable.parentContext, "expectReport", outer, outer.receiver)).tag = "exit", 
    runnable.parentContext = exit)));
}, Process.prototype.fork = function(context, args) {
    if (context.isContinuation) throw new Error("continuations cannot be forked");
    if (!(context instanceof Context)) throw new Error("expecting a ring but getting " + context);
    var i, value, outer = new Context(null, null, context.outerContext), runnable = new Context(null, context.expression, outer), parms = args.asArray(), stage = this.homeContext.receiver.parentThatIsA(StageMorph), proc = new Process();
    if (parms.length > 0) {
        for (i = 0; i < context.inputs.length; i += 1) value = 0, isNil(parms[i]) || (value = parms[i]), 
        outer.variables.addVar(context.inputs[i], value);
        if (0 === context.inputs.length) if (outer.variables.addVar([ "arguments" ], args), 
        1 === parms.length) for (i = 1; i <= context.emptySlots; i += 1) outer.variables.addVar(i, parms[0]); else if (parms.length === context.emptySlots) for (i = 1; i <= parms.length; i += 1) outer.variables.addVar(i, parms[i - 1]); else if (1 !== context.emptySlots) throw new Error(localize("expecting") + " " + context.emptySlots + " " + localize("input(s), but getting") + " " + parms.length);
    }
    runnable.expression instanceof CommandBlockMorph && (runnable.expression = runnable.expression.blockSequence()), 
    proc.homeContext = context.outerContext, proc.topBlock = context.expression, proc.context = runnable, 
    proc.pushContext("doYield"), stage.threads.processes.push(proc);
}, Process.prototype.doStopBlock = function() {
    var target = this.context.expression.exitTag;
    if (isNil(target)) return this.doStopCustomBlock();
    for (;this.context && (isNil(this.context.tag) || this.context.tag > target); ) "doStopWarping" === this.context.expression ? this.doStopWarping() : this.popContext();
    this.pushContext();
}, Process.prototype.doStopCustomBlock = function() {
    for (;this.context && !this.context.isCustomBlock; ) "doStopWarping" === this.context.expression ? this.doStopWarping() : this.popContext();
}, Process.prototype.doCallCC = function(aContext, isReporter) {
    this.evaluate(aContext, new List([ this.context.continuation() ]), !isReporter);
}, Process.prototype.reportCallCC = function(aContext) {
    this.doCallCC(aContext, !0);
}, Process.prototype.runContinuation = function(aContext, args) {
    var parms = args.asArray();
    this.context.parentContext = aContext.copyForContinuationCall(), 1 === parms.length && this.context.parentContext.outerContext.variables.addVar(1, parms[0]);
}, Process.prototype.evaluateCustomBlock = function() {
    var runnable, exit, i, value, outer, caller = this.context.parentContext, context = this.context.expression.definition.body, declarations = this.context.expression.definition.declarations, parms = new List(this.context.inputs).asArray();
    if (!context) return null;
    if (this.procedureCount += 1, (outer = new Context()).receiver = this.context.receiver, 
    outer.variables.parentFrame = outer.receiver ? outer.receiver.variables : null, 
    (runnable = new Context(this.context.parentContext, context.expression, outer, outer.receiver)).isCustomBlock = !0, 
    this.context.parentContext = runnable, parms.length > 0) for (i = 0; i < context.inputs.length; i += 1) value = 0, 
    isNil(parms[i]) || (value = parms[i]), outer.variables.addVar(context.inputs[i], value), 
    "%upvar" === declarations[context.inputs[i]][0] && (this.context.outerContext.variables.vars[value] = outer.variables.vars[context.inputs[i]]);
    "command" !== this.context.expression.definition.type ? (caller ? caller.tag = "exit" : ((exit = new Context(runnable.parentContext, "expectReport", outer, outer.receiver)).tag = "exit", 
    runnable.parentContext = exit), this.readyToYield = Date.now() - this.lastYield > this.timeout) : (runnable.expression.tagExitBlocks(this.procedureCount, !0), 
    caller && !caller.tag && (caller.tag = this.procedureCount), this.isAtomic || (this.readyToYield = !0)), 
    runnable.expression = runnable.expression.blockSequence();
}, Process.prototype.doDeclareVariables = function(varNames) {
    var varFrame = this.context.outerContext.variables;
    varNames.asArray().forEach(function(name) {
        varFrame.addVar(name);
    });
}, Process.prototype.doSetVar = function(varName, value) {
    var varFrame = this.context.variables, name = varName;
    name instanceof Context && "reportGetVar" === name.expression.selector && (name = name.expression.blockSpec), 
    varFrame.setVar(name, value);
}, Process.prototype.doChangeVar = function(varName, value) {
    var varFrame = this.context.variables, name = varName;
    name instanceof Context && "reportGetVar" === name.expression.selector && (name = name.expression.blockSpec), 
    varFrame.changeVar(name, value);
}, Process.prototype.reportGetVar = function() {
    return this.context.variables.getVar(this.context.expression.blockSpec);
}, Process.prototype.doShowVar = function(varName) {
    var stage, watcher, target, label, others, varFrame = this.context.variables, name = varName;
    if (name instanceof Context && "reportGetVar" === name.expression.selector && (name = name.expression.blockSpec), 
    this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph))) {
        if (target = varFrame.find(name), null !== (watcher = detect(stage.children, function(morph) {
            return morph instanceof WatcherMorph && morph.target === target && morph.getter === name;
        }))) return watcher.show(), void watcher.fixLayout();
        label = contains(this.homeContext.receiver.variables.parentFrame.names(), varName) || target.owner ? name : name + " " + localize("(temporary)"), 
        (watcher = new WatcherMorph(label, SpriteMorph.prototype.blockColor.variables, target, name)).setPosition(stage.position().add(10)), 
        (others = stage.watchers(watcher.left())).length > 0 && watcher.setTop(others[others.length - 1].bottom()), 
        stage.add(watcher), watcher.fixLayout();
    }
}, Process.prototype.doHideVar = function(varName) {
    var stage, watcher, target, varFrame = this.context.variables, name = varName;
    name instanceof Context && "reportGetVar" === name.expression.selector && (name = name.expression.blockSpec), 
    name ? this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && (target = varFrame.find(name), 
    null !== (watcher = detect(stage.children, function(morph) {
        return morph instanceof WatcherMorph && morph.target === target && morph.getter === name;
    })) && (watcher.isTemporary() ? watcher.destroy() : watcher.hide())) : this.doRemoveTemporaries();
}, Process.prototype.doRemoveTemporaries = function() {
    var stage;
    this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && stage.watchers().forEach(function(watcher) {
        watcher.isTemporary() && watcher.destroy();
    });
}, Process.prototype.reportNewList = function(elements) {
    return elements;
}, Process.prototype.reportCONS = function(car, cdr) {
    return new List().cons(car, cdr);
}, Process.prototype.reportCDR = function(list) {
    return list.cdr();
}, Process.prototype.doAddToList = function(element, list) {
    list.add(element);
}, Process.prototype.doDeleteFromList = function(index, list) {
    var idx = index;
    return "all" === this.inputOption(index) ? list.clear() : "" === index ? null : ("last" === this.inputOption(index) && (idx = list.length()), 
    void list.remove(idx));
}, Process.prototype.doInsertInList = function(element, index, list) {
    var idx = index;
    if ("" === index) return null;
    "any" === this.inputOption(index) && (idx = this.reportRandom(1, list.length() + 1)), 
    "last" === this.inputOption(index) && (idx = list.length() + 1), list.add(element, idx);
}, Process.prototype.doReplaceInList = function(index, list, element) {
    var idx = index;
    if ("" === index) return null;
    "any" === this.inputOption(index) && (idx = this.reportRandom(1, list.length())), 
    "last" === this.inputOption(index) && (idx = list.length()), list.put(element, idx);
}, Process.prototype.reportListItem = function(index, list) {
    var idx = index;
    return "" === index ? "" : ("any" === this.inputOption(index) && (idx = this.reportRandom(1, list.length())), 
    "last" === this.inputOption(index) && (idx = list.length()), list.at(idx));
}, Process.prototype.reportListLength = function(list) {
    return list.length();
}, Process.prototype.reportListContainsItem = function(list, element) {
    return list.contains(element);
}, Process.prototype.doIf = function() {
    var args = this.context.inputs, outer = this.context.outerContext, isCustomBlock = this.context.isCustomBlock;
    this.popContext(), args[0] && args[1] && (this.pushContext(args[1].blockSequence(), outer), 
    this.context.isCustomBlock = isCustomBlock), this.pushContext();
}, Process.prototype.doIfElse = function() {
    var args = this.context.inputs, outer = this.context.outerContext, isCustomBlock = this.context.isCustomBlock;
    this.popContext(), args[0] ? args[1] && this.pushContext(args[1].blockSequence(), outer) : args[2] ? this.pushContext(args[2].blockSequence(), outer) : this.pushContext("doYield"), 
    this.context && (this.context.isCustomBlock = isCustomBlock), this.pushContext();
}, Process.prototype.doStop = function() {
    this.stop();
}, Process.prototype.doStopAll = function() {
    var stage, ide;
    this.homeContext.receiver && ((stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && (stage.threads.resumeAll(stage), 
    stage.keysPressed = {}, stage.threads.stopAll(), stage.stopAllActiveSounds(), stage.children.forEach(function(morph) {
        morph.stopTalking && morph.stopTalking();
    }), stage.removeAllClones()), (ide = stage.parentThatIsA(IDE_Morph)) && ide.controlBar.pauseButton.refresh());
}, Process.prototype.doStopThis = function(choice) {
    switch (this.inputOption(choice)) {
      case "all":
        this.doStopAll();
        break;

      case "this script":
        this.doStop();
        break;

      case "this block":
        this.doStopBlock();
        break;

      default:
        nop();
    }
}, Process.prototype.doStopOthers = function(choice) {
    var stage;
    if (this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph))) switch (this.inputOption(choice)) {
      case "all but this script":
        stage.threads.stopAll(this);
        break;

      case "other scripts in sprite":
        stage.threads.stopAllForReceiver(this.homeContext.receiver, this);
        break;

      default:
        nop();
    }
}, Process.prototype.doWarp = function(body) {
    var stage, outer = this.context.outerContext, isCustomBlock = this.context.isCustomBlock;
    this.popContext(), body && (this.homeContext.receiver && (this.homeContext.receiver.startWarp && this.homeContext.receiver.startWarp(), 
    (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && (stage.fps = 0)), 
    this.pushContext("doYield"), this.context.isCustomBlock = isCustomBlock, this.isAtomic || this.pushContext("doStopWarping"), 
    this.pushContext(body.blockSequence(), outer), this.isAtomic = !0), this.pushContext();
}, Process.prototype.doStopWarping = function() {
    var stage;
    this.popContext(), this.isAtomic = !1, this.homeContext.receiver && (this.homeContext.receiver.endWarp && this.homeContext.receiver.endWarp(), 
    (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && (stage.fps = stage.frameRate));
}, Process.prototype.reportIsFastTracking = function() {
    var ide;
    return !(!this.homeContext.receiver || !(ide = this.homeContext.receiver.parentThatIsA(IDE_Morph))) && ide.stage.isFastTracked;
}, Process.prototype.doSetFastTracking = function(bool) {
    var ide;
    this.reportIsA(bool, "Boolean") && this.homeContext.receiver && (ide = this.homeContext.receiver.parentThatIsA(IDE_Morph)) && (bool ? ide.startFastTracking() : ide.stopFastTracking());
}, Process.prototype.doPauseAll = function() {
    var stage, ide;
    this.homeContext.receiver && ((stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && stage.threads.pauseAll(stage), 
    (ide = stage.parentThatIsA(IDE_Morph)) && ide.controlBar.pauseButton.refresh());
}, Process.prototype.doForever = function(body) {
    this.pushContext("doYield"), body && this.pushContext(body.blockSequence()), this.pushContext();
}, Process.prototype.doRepeat = function(counter, body) {
    var block = this.context.expression, outer = this.context.outerContext, isCustomBlock = this.context.isCustomBlock;
    if (counter < 1) return null;
    this.popContext(), this.pushContext(block, outer), this.context.isCustomBlock = isCustomBlock, 
    this.context.addInput(counter - 1), this.pushContext("doYield"), body && this.pushContext(body.blockSequence()), 
    this.pushContext();
}, Process.prototype.doUntil = function(goalCondition, body) {
    if (goalCondition) return this.popContext(), this.pushContext("doYield"), null;
    this.context.inputs = [], this.pushContext("doYield"), body && this.pushContext(body.blockSequence()), 
    this.pushContext();
}, Process.prototype.doWaitUntil = function(goalCondition) {
    if (goalCondition) return this.popContext(), this.pushContext("doYield"), null;
    this.context.inputs = [], this.pushContext("doYield"), this.pushContext();
}, Process.prototype.reportMap = function(reporter, list) {
    var next;
    if (list.isLinked) {
        if (this.context.inputs.length < 3 && (this.context.addInput(new List()), this.context.inputs[2].isLinked = !0, 
        this.context.addInput(this.context.inputs[2]), this.context.addInput(list)), 0 === this.context.inputs[4].length()) return this.context.inputs[3].rest = list.cons(this.context.inputs[5]), 
        void this.returnValueToParentContext(this.context.inputs[2].cdr());
        this.context.inputs.length > 5 && (this.context.inputs[3].rest = list.cons(this.context.inputs[5]), 
        this.context.inputs[3] = this.context.inputs[3].rest, this.context.inputs.splice(5)), 
        next = this.context.inputs[4].at(1), this.context.inputs[4] = this.context.inputs[4].cdr(), 
        this.pushContext(), this.evaluate(reporter, new List([ next ]));
    } else {
        if (this.context.inputs.length - 2 === list.length()) return void this.returnValueToParentContext(new List(this.context.inputs.slice(2)));
        next = list.at(this.context.inputs.length - 1), this.pushContext(), this.evaluate(reporter, new List([ next ]));
    }
}, Process.prototype.doForEach = function(upvar, list, script) {
    isNil(this.context.inputs[3]) && (this.context.inputs[3] = 1);
    var index = this.context.inputs[3];
    this.context.outerContext.variables.addVar(upvar), this.context.outerContext.variables.setVar(upvar, list.at(index)), 
    index > list.length() || (this.context.inputs[3] += 1, this.pushContext("doYield"), 
    this.pushContext(), this.evaluate(script, new List(), !0));
}, Process.prototype.doWait = function(secs) {
    if (this.context.startTime || (this.context.startTime = Date.now()), Date.now() - this.context.startTime >= 1e3 * secs) return null;
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.doGlide = function(secs, endX, endY) {
    if (this.context.startTime || (this.context.startTime = Date.now(), this.context.startValue = new Point(this.blockReceiver().xPosition(), this.blockReceiver().yPosition())), 
    Date.now() - this.context.startTime >= 1e3 * secs) return this.blockReceiver().gotoXY(endX, endY), 
    null;
    this.blockReceiver().glide(1e3 * secs, endX, endY, Date.now() - this.context.startTime, this.context.startValue), 
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.doSayFor = function(data, secs) {
    if (this.context.startTime || (this.context.startTime = Date.now(), this.blockReceiver().bubble(data)), 
    Date.now() - this.context.startTime >= 1e3 * secs) return this.blockReceiver().stopTalking(), 
    null;
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.doThinkFor = function(data, secs) {
    if (this.context.startTime || (this.context.startTime = Date.now(), this.blockReceiver().doThink(data)), 
    Date.now() - this.context.startTime >= 1e3 * secs) return this.blockReceiver().stopTalking(), 
    null;
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.blockReceiver = function() {
    return this.context ? this.context.receiver || this.homeContext.receiver : this.homeContext.receiver;
}, Process.prototype.doPlaySoundUntilDone = function(name) {
    var sprite = this.homeContext.receiver;
    if (null === this.context.activeAudio && (this.context.activeAudio = sprite.playSound(name)), 
    this.context.activeAudio.ended || this.context.activeAudio.terminated) return null;
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.doStopAllSounds = function() {
    var stage = this.homeContext.receiver.parentThatIsA(StageMorph);
    stage && (stage.threads.processes.forEach(function(thread) {
        thread.context && (thread.context.stopMusic(), thread.context.activeAudio && thread.popContext());
    }), stage.stopAllActiveSounds());
}, Process.prototype.doAsk = function(data) {
    var stage = this.homeContext.receiver.parentThatIsA(StageMorph), isStage = this.blockReceiver() instanceof StageMorph;
    if (this.prompter) {
        if (this.prompter.isDone) return stage.lastAnswer = this.prompter.inputField.getValue(), 
        this.prompter.destroy(), this.prompter = null, isStage || this.blockReceiver().stopTalking(), 
        null;
    } else detect(stage.children, function(morph) {
        return morph instanceof StagePrompterMorph;
    }) || (isStage || this.blockReceiver().bubble(data, !1, !0), this.prompter = new StagePrompterMorph(isStage ? data : null), 
    stage.scale < 1 ? this.prompter.setWidth(stage.width() - 10) : this.prompter.setWidth(stage.dimensions.x - 20), 
    this.prompter.fixLayout(), this.prompter.setCenter(stage.center()), this.prompter.setBottom(stage.bottom() - this.prompter.border), 
    stage.add(this.prompter), this.prompter.inputField.edit(), stage.changed());
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.reportLastAnswer = function() {
    return this.homeContext.receiver.parentThatIsA(StageMorph).lastAnswer;
}, Process.prototype.reportURL = function(url) {
    var response;
    if (this.httpRequest) {
        if (4 === this.httpRequest.readyState) return response = this.httpRequest.responseText, 
        this.httpRequest = null, response;
    } else this.httpRequest = new XMLHttpRequest(), this.httpRequest.open("GET", "http://" + url, !0), 
    this.httpRequest.send(null);
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.doBroadcast = function(message) {
    var stage = this.homeContext.receiver.parentThatIsA(StageMorph), hats = [], procs = [];
    return "" !== message && (stage.lastMessage = message, stage.children.concat(stage).forEach(function(morph) {
        (morph instanceof SpriteMorph || morph instanceof StageMorph) && (hats = hats.concat(morph.allHatBlocksFor(message)));
    }), hats.forEach(function(block) {
        procs.push(stage.threads.startProcess(block, stage.isThreadSafe));
    })), procs;
}, Process.prototype.doBroadcastAndWait = function(message) {
    if (this.context.activeSends || (this.context.activeSends = this.doBroadcast(message)), 
    this.context.activeSends = this.context.activeSends.filter(function(proc) {
        return proc.isRunning();
    }), 0 === this.context.activeSends.length) return null;
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.getLastMessage = function() {
    var stage;
    return this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) ? stage.getLastMessage() : "";
}, Process.prototype.reportIsA = function(thing, typeString) {
    return this.reportTypeOf(thing) === this.inputOption(typeString);
}, Process.prototype.reportTypeOf = function(thing) {
    var exp;
    return null === thing || void 0 === thing ? "nothing" : !0 === thing || !1 === thing ? "Boolean" : isNaN(parseFloat(thing)) ? isString(thing) ? "text" : thing instanceof List ? "list" : thing instanceof Context ? thing.expression instanceof RingMorph ? thing.expression.dataType() : thing.expression instanceof ReporterBlockMorph ? thing.expression.isPredicate ? "predicate" : "reporter" : thing.expression instanceof Array ? (exp = thing.expression[thing.pc || 0]).isPredicate ? "predicate" : exp instanceof RingMorph ? exp.dataType() : exp instanceof ReporterBlockMorph ? "reporter" : exp instanceof CommandBlockMorph ? "command" : "reporter" : thing.expression instanceof CommandBlockMorph ? "command" : "reporter" : "undefined" : "number";
}, Process.prototype.reportSum = function(a, b) {
    return +a + +b;
}, Process.prototype.reportDifference = function(a, b) {
    return +a - +b;
}, Process.prototype.reportProduct = function(a, b) {
    return +a * +b;
}, Process.prototype.reportQuotient = function(a, b) {
    return +a / +b;
}, Process.prototype.reportModulus = function(a, b) {
    var y = +b;
    return (+a % y + y) % y;
}, Process.prototype.reportRandom = function(min, max) {
    var floor = +min, ceil = +max;
    return floor % 1 != 0 || ceil % 1 != 0 ? Math.random() * (ceil - floor) + floor : Math.floor(Math.random() * (ceil - floor + 1)) + floor;
}, Process.prototype.reportLessThan = function(a, b) {
    var x = +a, y = +b;
    return (isNaN(x) || isNaN(y)) && (x = a, y = b), x < y;
}, Process.prototype.reportNot = function(bool) {
    return !bool;
}, Process.prototype.reportGreaterThan = function(a, b) {
    var x = +a, y = +b;
    return (isNaN(x) || isNaN(y)) && (x = a, y = b), x > y;
}, Process.prototype.reportEquals = function(a, b) {
    return snapEquals(a, b);
}, Process.prototype.reportIsIdentical = function(a, b) {
    var tag = "idTag";
    if (this.isImmutable(a) || this.isImmutable(b)) return snapEquals(a, b);
    function clear() {
        Object.prototype.hasOwnProperty.call(a, tag) && delete a[tag], Object.prototype.hasOwnProperty.call(b, tag) && delete b[tag];
    }
    return clear(), a[tag] = Date.now(), b[tag] === a[tag] ? (clear(), !0) : (clear(), 
    !1);
}, Process.prototype.isImmutable = function(obj) {
    return contains([ "nothing", "Boolean", "text", "number", "undefined" ], this.reportTypeOf(obj));
}, Process.prototype.reportTrue = function() {
    return !0;
}, Process.prototype.reportFalse = function() {
    return !1;
}, Process.prototype.reportRound = function(n) {
    return Math.round(+n);
}, Process.prototype.reportMonadic = function(fname, n) {
    var x = +n, result = 0;
    switch (this.inputOption(fname)) {
      case "abs":
        result = Math.abs(x);
        break;

      case "floor":
        result = Math.floor(x);
        break;

      case "sqrt":
        result = Math.sqrt(x);
        break;

      case "sin":
        result = Math.sin(radians(x));
        break;

      case "cos":
        result = Math.cos(radians(x));
        break;

      case "tan":
        result = Math.tan(radians(x));
        break;

      case "asin":
        result = degrees(Math.asin(x));
        break;

      case "acos":
        result = degrees(Math.acos(x));
        break;

      case "atan":
        result = degrees(Math.atan(x));
        break;

      case "ln":
        result = Math.log(x);
        break;

      case "log":
        result = 0;
        break;

      case "e^":
        result = Math.exp(x);
        break;

      case "10^":
        result = 0;
        break;

      default:
        nop();
    }
    return result;
}, Process.prototype.reportTextFunction = function(fname, string) {
    var x = (isNil(string) ? "" : string).toString(), result = "";
    switch (this.inputOption(fname)) {
      case "encode URI":
        result = encodeURI(x);
        break;

      case "decode URI":
        result = decodeURI(x);
        break;

      case "encode URI component":
        result = encodeURIComponent(x);
        break;

      case "decode URI component":
        result = decodeURIComponent(x);
        break;

      case "XML escape":
        result = new XML_Element().escape(x);
        break;

      case "XML unescape":
        result = new XML_Element().unescape(x);
        break;

      case "hex sha512 hash":
        result = hex_sha512(x);
        break;

      default:
        nop();
    }
    return result;
}, Process.prototype.reportJoin = function(a, b) {
    var x = (isNil(a) ? "" : a).toString(), y = (isNil(b) ? "" : b).toString();
    return x.concat(y);
}, Process.prototype.reportJoinWords = function(aList) {
    return aList instanceof List ? aList.asText() : (aList || "").toString();
}, Process.prototype.reportLetter = function(idx, string) {
    var i = +(idx || 0);
    return (string || "").toString()[i - 1] || "";
}, Process.prototype.reportStringSize = function(string) {
    if (string instanceof List) return string.length();
    return (string || "").toString().length;
}, Process.prototype.reportUnicode = function(string) {
    var str = (string || "").toString()[0];
    return str ? str.charCodeAt(0) : 0;
}, Process.prototype.reportUnicodeAsLetter = function(num) {
    var code = +(num || 0);
    return String.fromCharCode(code);
}, Process.prototype.reportTextSplit = function(string, delimiter) {
    var str, del, types = [ "text", "number" ], strType = this.reportTypeOf(string), delType = this.reportTypeOf(this.inputOption(delimiter));
    if (!contains(types, strType)) throw new Error("expecting text instead of a " + strType);
    if (!contains(types, delType)) throw new Error("expecting a text delimiter instead of a " + delType);
    switch (str = (string || "").toString(), this.inputOption(delimiter)) {
      case "line":
        del = /\r\n|[\n\v\f\r\x85\u2028\u2029]/;
        break;

      case "tab":
        del = "\t";
        break;

      case "cr":
        del = "\r";
        break;

      case "whitespace":
        str = str.trim(), del = /\s+/;
        break;

      case "letter":
        del = "";
        break;

      default:
        del = (delimiter || "").toString();
    }
    return new List(str.split(del));
}, Process.prototype.alert = function(data) {
    this.homeContext.receiver && this.homeContext.receiver.world().isDevMode && alert("Snap! " + data.asArray());
}, Process.prototype.log = function(data) {
    this.homeContext.receiver && this.homeContext.receiver.world().isDevMode && console.log("Snap! " + data.asArray());
}, Process.prototype.getOtherObject = function(name, thisObj, stageObj) {
    var stage = isNil(stageObj) ? thisObj.parentThatIsA(StageMorph) : stageObj, thatObj = null;
    return stage && ((thatObj = detect(stage.children, function(morph) {
        return morph.name === name;
    })) || (thatObj = detect(stage.world().hand.children, function(morph) {
        return morph instanceof SpriteMorph && morph.name === name;
    }))), thatObj;
}, Process.prototype.getObjectsNamed = function(name, thisObj, stageObj) {
    var stage = isNil(stageObj) ? thisObj.parentThatIsA(StageMorph) : stageObj, those = [];
    function check(obj) {
        return obj instanceof SpriteMorph && obj.isClone ? obj.cloneOriginName === name : obj.name === name;
    }
    return stage && ((those = stage.children.filter(check)).length || (those = stage.world().hand.children.filter(check))), 
    those;
}, Process.prototype.doFaceTowards = function(name) {
    var thatObj, thisObj = this.blockReceiver();
    thisObj && ("mouse-pointer" === this.inputOption(name) ? thisObj.faceToXY(this.reportMouseX(), this.reportMouseY()) : (thatObj = this.getOtherObject(name, this.homeContext.receiver)) && thisObj.faceToXY(thatObj.xPosition(), thatObj.yPosition()));
}, Process.prototype.doGotoObject = function(name) {
    var thatObj, thisObj = this.blockReceiver();
    thisObj && ("mouse-pointer" === this.inputOption(name) ? thisObj.gotoXY(this.reportMouseX(), this.reportMouseY()) : (thatObj = this.getOtherObject(name, this.homeContext.receiver)) && thisObj.gotoXY(thatObj.xPosition(), thatObj.yPosition()));
}, Process.prototype.createClone = function(name) {
    var thatObj, thisObj = this.homeContext.receiver;
    name && thisObj && ("myself" === this.inputOption(name) ? thisObj.createClone() : (thatObj = this.getOtherObject(name, thisObj)) && thatObj.createClone());
}, Process.prototype.reportTouchingObject = function(name) {
    var thisObj = this.blockReceiver();
    return !!thisObj && this.objectTouchingObject(thisObj, name);
}, Process.prototype.objectTouchingObject = function(thisObj, name) {
    var stage, box, mouse, myself = this;
    if ("mouse-pointer" === this.inputOption(name)) {
        if (mouse = thisObj.world().hand.position(), thisObj.bounds.containsPoint(mouse) && !thisObj.isTransparentAt(mouse)) return !0;
    } else if (stage = thisObj.parentThatIsA(StageMorph)) {
        if ("edge" === this.inputOption(name) && (box = thisObj.bounds, !thisObj.costume && thisObj.penBounds && (box = thisObj.penBounds.translateBy(thisObj.position())), 
        !stage.bounds.containsRectangle(box))) return !0;
        if ("pen trails" === this.inputOption(name) && thisObj.isTouching(stage.penTrailsMorph())) return !0;
        if (this.getObjectsNamed(name, thisObj, stage).some(function(any) {
            return thisObj.isTouching(any);
        })) return !0;
    }
    return thisObj.parts.some(function(any) {
        return myself.objectTouchingObject(any, name);
    });
}, Process.prototype.reportTouchingColor = function(aColor) {
    var stage, thisObj = this.homeContext.receiver;
    return !(!thisObj || !(stage = thisObj.parentThatIsA(StageMorph))) && (!!thisObj.isTouching(stage.colorFiltered(aColor, thisObj)) || thisObj.parts.some(function(any) {
        return any.isTouching(stage.colorFiltered(aColor, any));
    }));
}, Process.prototype.reportColorIsTouchingColor = function(color1, color2) {
    var stage, thisObj = this.homeContext.receiver;
    return !(!thisObj || !(stage = thisObj.parentThatIsA(StageMorph))) && (!!thisObj.colorFiltered(color1).isTouching(stage.colorFiltered(color2, thisObj)) || thisObj.parts.some(function(any) {
        return any.colorFiltered(color1).isTouching(stage.colorFiltered(color2, any));
    }));
}, Process.prototype.reportDistanceTo = function(name) {
    var thatObj, stage, rc, point, thisObj = this.blockReceiver();
    return thisObj ? (point = rc = thisObj.rotationCenter(), "mouse-pointer" === this.inputOption(name) && (point = thisObj.world().hand.position()), 
    stage = thisObj.parentThatIsA(StageMorph), (thatObj = this.getOtherObject(name, thisObj, stage)) && (point = thatObj.rotationCenter()), 
    rc.distanceTo(point) / stage.scale) : 0;
}, Process.prototype.reportAttributeOf = function(attribute, name) {
    var thatObj, stage, thisObj = this.blockReceiver();
    if (thisObj && (thatObj = (stage = thisObj.parentThatIsA(StageMorph)).name === name ? stage : this.getOtherObject(name, thisObj, stage))) {
        if (attribute instanceof Context) return this.reportContextFor(attribute, thatObj);
        if (isString(attribute)) return thatObj.variables.getVar(attribute);
        switch (this.inputOption(attribute)) {
          case "x position":
            return thatObj.xPosition ? thatObj.xPosition() : "";

          case "y position":
            return thatObj.yPosition ? thatObj.yPosition() : "";

          case "direction":
            return thatObj.direction ? thatObj.direction() : "";

          case "costume #":
            return thatObj.getCostumeIdx();

          case "costume name":
            return thatObj.costume ? thatObj.costume.name : localize(thatObj instanceof SpriteMorph ? "Turtle" : "Empty");

          case "size":
            return thatObj.getScale ? thatObj.getScale() : "";
        }
    }
    return "";
}, Process.prototype.reportContextFor = function(context, otherObj) {
    var result = copy(context);
    return result.receiver = otherObj, result.outerContext && (result.outerContext = copy(result.outerContext), 
    result.outerContext.receiver = otherObj, result.outerContext.variables.parentFrame = otherObj.variables), 
    result;
}, Process.prototype.reportMouseX = function() {
    var stage, world;
    return this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && (world = stage.world()) ? (world.hand.position().x - stage.center().x) / stage.scale : 0;
}, Process.prototype.reportMouseY = function() {
    var stage, world;
    return this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && (world = stage.world()) ? (stage.center().y - world.hand.position().y) / stage.scale : 0;
}, Process.prototype.reportMouseDown = function() {
    var world;
    return !(!this.homeContext.receiver || !(world = this.homeContext.receiver.world())) && "left" === world.hand.mouseButton;
}, Process.prototype.reportKeyPressed = function(keyString) {
    var stage;
    return !(!this.homeContext.receiver || !(stage = this.homeContext.receiver.parentThatIsA(StageMorph))) && void 0 !== stage.keysPressed[keyString];
}, Process.prototype.doResetTimer = function() {
    var stage;
    this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && stage.resetTimer();
}, Process.prototype.reportTimer = function() {
    var stage;
    return this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) ? stage.getTimer() : 0;
};

var dateMap = {
    year: "getFullYear",
    month: "getMonth",
    date: "getDate",
    "day of week": "getDay",
    hour: "getHours",
    minute: "getMinutes",
    second: "getSeconds",
    "time in milliseconds": "getTime"
};

Process.prototype.reportDate = function(datefn) {
    var inputFn = this.inputOption(datefn), result = new Date()[dateMap[inputFn]]();
    return dateMap[inputFn] ? ("month" !== inputFn && "day of week" !== inputFn || (result += 1), 
    result) : "";
}, Process.prototype.doMapCodeOrHeader = function(aContext, anOption, aString) {
    if ("code" === this.inputOption(anOption)) return this.doMapCode(aContext, aString);
    if ("header" === this.inputOption(anOption)) return this.doMapHeader(aContext, aString);
    throw new Error(" '" + anOption + "'\nis not a valid option");
}, Process.prototype.doMapHeader = function(aContext, aString) {
    if (aContext instanceof Context && aContext.expression instanceof SyntaxElementMorph) return aContext.expression.mapHeader(aString || "");
}, Process.prototype.doMapCode = function(aContext, aString) {
    if (aContext instanceof Context && aContext.expression instanceof SyntaxElementMorph) return aContext.expression.mapCode(aString || "");
}, Process.prototype.doMapStringCode = function(aString) {
    StageMorph.prototype.codeMappings.string = aString || "<#1>";
}, Process.prototype.doMapListCode = function(part, kind, aString) {
    var key1 = "", key2 = "delim";
    "parameters" === this.inputOption(kind) ? key1 = "parms_" : "variables" === this.inputOption(kind) && (key1 = "tempvars_"), 
    "list" === this.inputOption(part) ? key2 = "list" : "item" === this.inputOption(part) && (key2 = "item"), 
    StageMorph.prototype.codeMappings[key1 + key2] = aString || "";
}, Process.prototype.reportMappedCode = function(aContext) {
    return aContext instanceof Context && aContext.expression instanceof SyntaxElementMorph ? aContext.expression.mappedCode() : "";
}, Process.prototype.doRest = function(beats) {
    var tempo = this.reportTempo();
    this.doWait(60 / tempo * beats);
}, Process.prototype.reportTempo = function() {
    var stage;
    return this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) ? stage.getTempo() : 0;
}, Process.prototype.doChangeTempo = function(delta) {
    var stage;
    this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && stage.changeTempo(delta);
}, Process.prototype.doSetTempo = function(bpm) {
    var stage;
    this.homeContext.receiver && (stage = this.homeContext.receiver.parentThatIsA(StageMorph)) && stage.setTempo(bpm);
}, Process.prototype.doPlayNote = function(pitch, beats) {
    var tempo = this.reportTempo();
    this.doPlayNoteForSecs(parseFloat(pitch || "0"), 60 / tempo * parseFloat(beats || "0"));
}, Process.prototype.doPlayNoteForSecs = function(pitch, secs) {
    if (this.context.startTime || (this.context.startTime = Date.now(), this.context.activeNote = new Note(pitch), 
    this.context.activeNote.play()), Date.now() - this.context.startTime >= 1e3 * secs) return this.context.activeNote && (this.context.activeNote.stop(), 
    this.context.activeNote = null), null;
    this.pushContext("doYield"), this.pushContext();
}, Process.prototype.inputOption = function(dta) {
    return dta instanceof Array ? dta[0] : dta;
}, Process.prototype.pushContext = function(expression, outerContext) {
    this.context = new Context(this.context, expression, outerContext || (this.context ? this.context.outerContext : null), this.context ? this.context.receiver : this.homeContext.receiver);
}, Process.prototype.popContext = function() {
    this.context && this.context.stopMusic(), this.context = this.context ? this.context.parentContext : null;
}, Process.prototype.returnValueToParentContext = function(value) {
    if (void 0 !== value) {
        (this.context ? this.context.parentContext || this.homeContext : this.homeContext).addInput(value);
    }
}, Process.prototype.reportStackSize = function() {
    return this.context ? this.context.stackSize() : 0;
}, Process.prototype.reportFrameCount = function() {
    return this.frameCount;
};

function Context(parentContext, expression, outerContext, receiver) {
    this.outerContext = outerContext || null, this.parentContext = parentContext || null, 
    this.expression = expression || null, this.receiver = receiver || null, this.variables = new VariableFrame(), 
    this.outerContext && (this.variables.parentFrame = this.outerContext.variables, 
    this.receiver = this.outerContext.receiver), this.inputs = [], this.pc = 0, this.startTime = null, 
    this.activeAudio = null, this.activeNote = null, this.isCustomBlock = !1, this.emptySlots = 0, 
    this.tag = null;
}

Context.prototype.toString = function() {
    var expr = this.expression;
    return expr instanceof Array && expr.length > 0 && (expr = "[" + expr[0] + "]"), 
    "Context >> " + expr + " " + this.variables;
}, Context.prototype.image = function() {
    var block, cont, ring = new RingMorph();
    return this.expression instanceof Morph ? (block = this.expression.fullCopy(), this.isContinuation && (cont = detect(block.allInputs(), function(inp) {
        return 1 === inp.bindingID;
    })) && block.revertToDefaultInput(cont, !0), ring.embed(block, this.inputs), ring.fullImage()) : this.expression instanceof Array ? (block = this.expression[this.pc].fullCopy()) instanceof RingMorph && !block.contents() ? block.fullImage() : (ring.embed(block, this.isContinuation ? [] : this.inputs), 
    ring.fullImage()) : (ring.color = SpriteMorph.prototype.blockColor.other, ring.setSpec("%rc %ringparms"), 
    this.isContinuation || this.inputs.forEach(function(inp) {
        ring.parts()[1].addInput(inp);
    }), ring.fullImage());
}, Context.prototype.continuation = function() {
    var cont;
    if (this.expression instanceof Array) cont = this; else {
        if (!this.parentContext) return new Context(null, "doYield");
        cont = this.parentContext;
    }
    return (cont = cont.copyForContinuation()).tag = null, cont.isContinuation = !0, 
    cont;
}, Context.prototype.copyForContinuation = function() {
    var cpy = copy(this), cur = cpy;
    if (!(this.expression instanceof Array || isString(this.expression))) for (cur.prepareContinuationForBinding(); cur.parentContext; ) cur.parentContext = copy(cur.parentContext), 
    (cur = cur.parentContext).inputs = [];
    return cpy;
}, Context.prototype.copyForContinuationCall = function() {
    var cpy = copy(this), cur = cpy;
    if (!(this.expression instanceof Array || isString(this.expression))) for (this.expression = this.expression.fullCopy(), 
    this.inputs = []; cur.parentContext; ) cur.parentContext = copy(cur.parentContext), 
    (cur = cur.parentContext).inputs = [];
    return cpy;
}, Context.prototype.prepareContinuationForBinding = function() {
    var slot, pos = this.inputs.length;
    this.expression = this.expression.fullCopy(), (slot = this.expression.inputs()[pos]) && (this.inputs = [], 
    slot.bindingID = 1, this.emptySlots = 1);
}, Context.prototype.addInput = function(input) {
    this.inputs.push(input);
}, Context.prototype.stopMusic = function() {
    this.activeNote && (this.activeNote.stop(), this.activeNote = null);
}, Context.prototype.stackSize = function() {
    return this.parentContext ? 1 + this.parentContext.stackSize() : 1;
};

function Variable(value) {
    this.value = value;
}

Variable.prototype.toString = function() {
    return "a Variable [" + this.value + "]";
}, Variable.prototype.copy = function() {
    return new Variable(this.value);
};

function VariableFrame(parentFrame, owner) {
    this.vars = {}, this.parentFrame = parentFrame || null, this.owner = owner || null;
}

VariableFrame.prototype.toString = function() {
    return "a VariableFrame {" + this.names() + "}";
}, VariableFrame.prototype.copy = function() {
    var frame = new VariableFrame(this.parentFrame), myself = this;
    return this.names().forEach(function(vName) {
        frame.addVar(vName, myself.getVar(vName));
    }), frame;
}, VariableFrame.prototype.deepCopy = function() {
    var frame;
    return (frame = this.parentFrame ? new VariableFrame(this.parentFrame.deepCopy()) : new VariableFrame(this.parentFrame)).vars = copy(this.vars), 
    frame;
}, VariableFrame.prototype.find = function(name) {
    var frame = this.silentFind(name);
    if (frame) return frame;
    throw new Error(localize("a variable of name '") + name + localize("'\ndoes not exist in this context"));
}, VariableFrame.prototype.silentFind = function(name) {
    return void 0 !== this.vars[name] ? this : this.parentFrame ? this.parentFrame.silentFind(name) : null;
}, VariableFrame.prototype.setVar = function(name, value) {
    var frame = this.find(name);
    frame && (frame.vars[name].value = value);
}, VariableFrame.prototype.changeVar = function(name, delta) {
    var value, frame = this.find(name);
    frame && (value = parseFloat(frame.vars[name].value), isNaN(value) ? frame.vars[name].value = delta : frame.vars[name].value = value + parseFloat(delta));
}, VariableFrame.prototype.getVar = function(name) {
    var value, frame = this.silentFind(name);
    if (frame) return 0 === (value = frame.vars[name].value) ? 0 : !1 !== value && ("" === value ? "" : value || 0);
    if ("number" == typeof name) return "";
    throw new Error(localize("a variable of name '") + name + localize("'\ndoes not exist in this context"));
}, VariableFrame.prototype.addVar = function(name, value) {
    this.vars[name] = new Variable(0 === value ? 0 : !1 !== value && ("" === value ? "" : value || 0));
}, VariableFrame.prototype.deleteVar = function(name) {
    var frame = this.find(name);
    frame && delete frame.vars[name];
}, VariableFrame.prototype.names = function() {
    var each, names = [];
    for (each in this.vars) Object.prototype.hasOwnProperty.call(this.vars, each) && names.push(each);
    return names;
}, VariableFrame.prototype.allNamesDict = function() {
    var dict = {}, current = this;
    function addKeysToDict(srcDict, trgtDict) {
        var eachKey;
        for (eachKey in srcDict) Object.prototype.hasOwnProperty.call(srcDict, eachKey) && (trgtDict[eachKey] = eachKey);
    }
    for (;current; ) addKeysToDict(current.vars, dict), current = current.parentFrame;
    return dict;
}, VariableFrame.prototype.allNames = function() {
    var each, answer = [], dict = this.allNamesDict();
    for (each in dict) Object.prototype.hasOwnProperty.call(dict, each) && answer.push(each);
    return answer;
}, modules.objects = "2015-January-28";

var SpriteMorph, StageMorph, SpriteBubbleMorph, Costume, SVG_Costume, CostumeEditorMorph, Sound, Note, CellMorph, WatcherMorph, StagePrompterMorph, Note, SpriteHighlightMorph;

SpriteMorph.prototype = new PenMorph(), SpriteMorph.prototype.constructor = SpriteMorph, 
SpriteMorph.uber = PenMorph.prototype, SpriteMorph.prototype.categories = [ "motion", "control", "looks", "sensing", "sound", "operators", "pen", "variables", "lists", "other" ], 
SpriteMorph.prototype.blockColor = {
    motion: new Color(74, 108, 212),
    looks: new Color(143, 86, 227),
    sound: new Color(207, 74, 217),
    pen: new Color(0, 161, 120),
    control: new Color(230, 168, 34),
    sensing: new Color(4, 148, 220),
    operators: new Color(98, 194, 19),
    variables: new Color(243, 118, 29),
    lists: new Color(217, 77, 17),
    other: new Color(150, 150, 150)
}, SpriteMorph.prototype.paletteColor = new Color(55, 55, 55), SpriteMorph.prototype.paletteTextColor = new Color(230, 230, 230), 
SpriteMorph.prototype.sliderColor = SpriteMorph.prototype.paletteColor.lighter(30), 
SpriteMorph.prototype.isCachingPrimitives = !0, SpriteMorph.prototype.enableNesting = !0, 
SpriteMorph.prototype.useFlatLineEnds = !1, SpriteMorph.prototype.highlightColor = new Color(250, 200, 130), 
SpriteMorph.prototype.highlightBorder = 8, SpriteMorph.prototype.bubbleColor = new Color(255, 255, 255), 
SpriteMorph.prototype.bubbleFontSize = 14, SpriteMorph.prototype.bubbleFontIsBold = !0, 
SpriteMorph.prototype.bubbleCorner = 10, SpriteMorph.prototype.bubbleBorder = 3, 
SpriteMorph.prototype.bubbleBorderColor = new Color(190, 190, 190), SpriteMorph.prototype.bubbleMaxTextWidth = 130, 
SpriteMorph.prototype.initBlocks = function() {
    SpriteMorph.prototype.blocks = {
        forward: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "move %n steps",
            defaults: [ 10 ]
        },
        turn: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "turn %clockwise %n degrees",
            defaults: [ 15 ]
        },
        turnLeft: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "turn %counterclockwise %n degrees",
            defaults: [ 15 ]
        },
        setHeading: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "point in direction %dir"
        },
        doFaceTowards: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "point towards %dst"
        },
        gotoXY: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "go to x: %n y: %n",
            defaults: [ 0, 0 ]
        },
        doGotoObject: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "go to %dst"
        },
        doGlide: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "glide %n secs to x: %n y: %n",
            defaults: [ 1, 0, 0 ]
        },
        changeXPosition: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "change x by %n",
            defaults: [ 10 ]
        },
        setXPosition: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "set x to %n",
            defaults: [ 0 ]
        },
        changeYPosition: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "change y by %n",
            defaults: [ 10 ]
        },
        setYPosition: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "set y to %n",
            defaults: [ 0 ]
        },
        bounceOffEdge: {
            only: SpriteMorph,
            type: "command",
            category: "motion",
            spec: "if on edge, bounce"
        },
        xPosition: {
            only: SpriteMorph,
            type: "reporter",
            category: "motion",
            spec: "x position"
        },
        yPosition: {
            only: SpriteMorph,
            type: "reporter",
            category: "motion",
            spec: "y position"
        },
        direction: {
            only: SpriteMorph,
            type: "reporter",
            category: "motion",
            spec: "direction"
        },
        doSwitchToCostume: {
            type: "command",
            category: "looks",
            spec: "switch to costume %cst"
        },
        doWearNextCostume: {
            type: "command",
            category: "looks",
            spec: "next costume"
        },
        getCostumeIdx: {
            type: "reporter",
            category: "looks",
            spec: "costume #"
        },
        doSayFor: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "say %s for %n secs",
            defaults: [ localize("Hello!"), 2 ]
        },
        bubble: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "say %s",
            defaults: [ localize("Hello!") ]
        },
        doThinkFor: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "think %s for %n secs",
            defaults: [ localize("Hmm..."), 2 ]
        },
        doThink: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "think %s",
            defaults: [ localize("Hmm...") ]
        },
        changeEffect: {
            type: "command",
            category: "looks",
            spec: "change %eff effect by %n",
            defaults: [ null, 25 ]
        },
        setEffect: {
            type: "command",
            category: "looks",
            spec: "set %eff effect to %n",
            defaults: [ null, 0 ]
        },
        clearEffects: {
            type: "command",
            category: "looks",
            spec: "clear graphic effects"
        },
        changeScale: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "change size by %n",
            defaults: [ 10 ]
        },
        setScale: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "set size to %n %",
            defaults: [ 100 ]
        },
        getScale: {
            only: SpriteMorph,
            type: "reporter",
            category: "looks",
            spec: "size"
        },
        show: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "show"
        },
        hide: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "hide"
        },
        comeToFront: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "go to front"
        },
        goBack: {
            only: SpriteMorph,
            type: "command",
            category: "looks",
            spec: "go back %n layers",
            defaults: [ 1 ]
        },
        doScreenshot: {
            type: "command",
            category: "looks",
            spec: "save %imgsource as costume named %s",
            defaults: [ [ "pen trails" ], localize("screenshot") ]
        },
        reportCostumes: {
            dev: !0,
            type: "reporter",
            category: "looks",
            spec: "wardrobe"
        },
        alert: {
            dev: !0,
            type: "command",
            category: "looks",
            spec: "alert %mult%s"
        },
        log: {
            dev: !0,
            type: "command",
            category: "looks",
            spec: "console log %mult%s"
        },
        playSound: {
            type: "command",
            category: "sound",
            spec: "play sound %snd"
        },
        doPlaySoundUntilDone: {
            type: "command",
            category: "sound",
            spec: "play sound %snd until done"
        },
        doStopAllSounds: {
            type: "command",
            category: "sound",
            spec: "stop all sounds"
        },
        doRest: {
            type: "command",
            category: "sound",
            spec: "rest for %n beats",
            defaults: [ .2 ]
        },
        doPlayNote: {
            type: "command",
            category: "sound",
            spec: "play note %n for %n beats",
            defaults: [ 60, .5 ]
        },
        doChangeTempo: {
            type: "command",
            category: "sound",
            spec: "change tempo by %n",
            defaults: [ 20 ]
        },
        doSetTempo: {
            type: "command",
            category: "sound",
            spec: "set tempo to %n bpm",
            defaults: [ 60 ]
        },
        getTempo: {
            type: "reporter",
            category: "sound",
            spec: "tempo"
        },
        reportSounds: {
            dev: !0,
            type: "reporter",
            category: "sound",
            spec: "jukebox"
        },
        clear: {
            type: "command",
            category: "pen",
            spec: "clear"
        },
        down: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "pen down"
        },
        up: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "pen up"
        },
        setColor: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "set pen color to %clr"
        },
        changeHue: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "change pen color by %n",
            defaults: [ 10 ]
        },
        setHue: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "set pen color to %n",
            defaults: [ 0 ]
        },
        changeBrightness: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "change pen shade by %n",
            defaults: [ 10 ]
        },
        setBrightness: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "set pen shade to %n",
            defaults: [ 100 ]
        },
        changeSize: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "change pen size by %n",
            defaults: [ 1 ]
        },
        setSize: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "set pen size to %n",
            defaults: [ 1 ]
        },
        doStamp: {
            only: SpriteMorph,
            type: "command",
            category: "pen",
            spec: "stamp"
        },
        receiveGo: {
            type: "hat",
            category: "control",
            spec: "when %greenflag clicked"
        },
        receiveKey: {
            type: "hat",
            category: "control",
            spec: "when %keyHat key pressed"
        },
        receiveClick: {
            type: "hat",
            category: "control",
            spec: "when I am clicked"
        },
        receiveMessage: {
            type: "hat",
            category: "control",
            spec: "when I receive %msgHat"
        },
        doBroadcast: {
            type: "command",
            category: "control",
            spec: "broadcast %msg"
        },
        doBroadcastAndWait: {
            type: "command",
            category: "control",
            spec: "broadcast %msg and wait"
        },
        getLastMessage: {
            type: "reporter",
            category: "control",
            spec: "message"
        },
        doWait: {
            type: "command",
            category: "control",
            spec: "wait %n secs",
            defaults: [ 1 ]
        },
        doWaitUntil: {
            type: "command",
            category: "control",
            spec: "wait until %b"
        },
        doForever: {
            type: "command",
            category: "control",
            spec: "forever %c"
        },
        doRepeat: {
            type: "command",
            category: "control",
            spec: "repeat %n %c",
            defaults: [ 10 ]
        },
        doUntil: {
            type: "command",
            category: "control",
            spec: "repeat until %b %c"
        },
        doIf: {
            type: "command",
            category: "control",
            spec: "if %b %c"
        },
        doIfElse: {
            type: "command",
            category: "control",
            spec: "if %b %c else %c"
        },
        doStopThis: {
            type: "command",
            category: "control",
            spec: "stop %stopChoices"
        },
        doStopOthers: {
            type: "command",
            category: "control",
            spec: "stop %stopOthersChoices"
        },
        doRun: {
            type: "command",
            category: "control",
            spec: "run %cmdRing %inputs"
        },
        fork: {
            type: "command",
            category: "control",
            spec: "launch %cmdRing %inputs"
        },
        evaluate: {
            type: "reporter",
            category: "control",
            spec: "call %repRing %inputs"
        },
        doReport: {
            type: "command",
            category: "control",
            spec: "report %s"
        },
        doCallCC: {
            type: "command",
            category: "control",
            spec: "run %cmdRing w/continuation"
        },
        reportCallCC: {
            type: "reporter",
            category: "control",
            spec: "call %cmdRing w/continuation"
        },
        doWarp: {
            type: "command",
            category: "other",
            spec: "warp %c"
        },
        receiveOnClone: {
            type: "hat",
            category: "control",
            spec: "when I start as a clone"
        },
        createClone: {
            type: "command",
            category: "control",
            spec: "create a clone of %cln"
        },
        removeClone: {
            type: "command",
            category: "control",
            spec: "delete this clone"
        },
        doPauseAll: {
            type: "command",
            category: "control",
            spec: "pause all %pause"
        },
        reportTouchingObject: {
            only: SpriteMorph,
            type: "predicate",
            category: "sensing",
            spec: "touching %col ?"
        },
        reportTouchingColor: {
            only: SpriteMorph,
            type: "predicate",
            category: "sensing",
            spec: "touching %clr ?"
        },
        reportColorIsTouchingColor: {
            only: SpriteMorph,
            type: "predicate",
            category: "sensing",
            spec: "color %clr is touching %clr ?"
        },
        colorFiltered: {
            dev: !0,
            type: "reporter",
            category: "sensing",
            spec: "filtered for %clr"
        },
        reportStackSize: {
            dev: !0,
            type: "reporter",
            category: "sensing",
            spec: "stack size"
        },
        reportFrameCount: {
            dev: !0,
            type: "reporter",
            category: "sensing",
            spec: "frames"
        },
        reportThreadCount: {
            dev: !0,
            type: "reporter",
            category: "sensing",
            spec: "processes"
        },
        doAsk: {
            type: "command",
            category: "sensing",
            spec: "ask %s and wait",
            defaults: [ localize("what's your name?") ]
        },
        reportLastAnswer: {
            dev: !0,
            type: "reporter",
            category: "sensing",
            spec: "answer"
        },
        getLastAnswer: {
            type: "reporter",
            category: "sensing",
            spec: "answer"
        },
        reportMouseX: {
            type: "reporter",
            category: "sensing",
            spec: "mouse x"
        },
        reportMouseY: {
            type: "reporter",
            category: "sensing",
            spec: "mouse y"
        },
        reportMouseDown: {
            type: "predicate",
            category: "sensing",
            spec: "mouse down?"
        },
        reportKeyPressed: {
            type: "predicate",
            category: "sensing",
            spec: "key %key pressed?"
        },
        reportDistanceTo: {
            type: "reporter",
            category: "sensing",
            spec: "distance to %dst"
        },
        doResetTimer: {
            type: "command",
            category: "sensing",
            spec: "reset timer"
        },
        reportTimer: {
            dev: !0,
            type: "reporter",
            category: "sensing",
            spec: "timer"
        },
        getTimer: {
            type: "reporter",
            category: "sensing",
            spec: "timer"
        },
        reportAttributeOf: {
            type: "reporter",
            category: "sensing",
            spec: "%att of %spr",
            defaults: [ [ "costume #" ] ]
        },
        reportURL: {
            type: "reporter",
            category: "sensing",
            spec: "http:// %s",
            defaults: [ "snap.berkeley.edu" ]
        },
        reportIsFastTracking: {
            type: "predicate",
            category: "sensing",
            spec: "turbo mode?"
        },
        doSetFastTracking: {
            type: "command",
            category: "sensing",
            spec: "set turbo mode to %b"
        },
        reportDate: {
            type: "reporter",
            category: "sensing",
            spec: "current %dates"
        },
        reifyScript: {
            type: "ring",
            category: "other",
            spec: "%rc %ringparms"
        },
        reifyReporter: {
            type: "ring",
            category: "other",
            spec: "%rr %ringparms"
        },
        reifyPredicate: {
            type: "ring",
            category: "other",
            spec: "%rp %ringparms"
        },
        reportSum: {
            type: "reporter",
            category: "operators",
            spec: "%n + %n"
        },
        reportDifference: {
            type: "reporter",
            category: "operators",
            spec: "%n − %n"
        },
        reportProduct: {
            type: "reporter",
            category: "operators",
            spec: "%n × %n"
        },
        reportQuotient: {
            type: "reporter",
            category: "operators",
            spec: "%n / %n"
        },
        reportRound: {
            type: "reporter",
            category: "operators",
            spec: "round %n"
        },
        reportMonadic: {
            type: "reporter",
            category: "operators",
            spec: "%fun of %n",
            defaults: [ null, 10 ]
        },
        reportModulus: {
            type: "reporter",
            category: "operators",
            spec: "%n mod %n"
        },
        reportRandom: {
            type: "reporter",
            category: "operators",
            spec: "pick random %n to %n",
            defaults: [ 1, 10 ]
        },
        reportLessThan: {
            type: "predicate",
            category: "operators",
            spec: "%s < %s"
        },
        reportEquals: {
            type: "predicate",
            category: "operators",
            spec: "%s = %s"
        },
        reportGreaterThan: {
            type: "predicate",
            category: "operators",
            spec: "%s > %s"
        },
        reportAnd: {
            type: "predicate",
            category: "operators",
            spec: "%b and %b"
        },
        reportOr: {
            type: "predicate",
            category: "operators",
            spec: "%b or %b"
        },
        reportNot: {
            type: "predicate",
            category: "operators",
            spec: "not %b"
        },
        reportTrue: {
            type: "predicate",
            category: "operators",
            spec: "true"
        },
        reportFalse: {
            type: "predicate",
            category: "operators",
            spec: "false"
        },
        reportJoinWords: {
            type: "reporter",
            category: "operators",
            spec: "join %words",
            defaults: [ localize("hello") + " ", localize("world") ]
        },
        reportLetter: {
            type: "reporter",
            category: "operators",
            spec: "letter %n of %s",
            defaults: [ 1, localize("world") ]
        },
        reportStringSize: {
            type: "reporter",
            category: "operators",
            spec: "length of %s",
            defaults: [ localize("world") ]
        },
        reportUnicode: {
            type: "reporter",
            category: "operators",
            spec: "unicode of %s",
            defaults: [ "a" ]
        },
        reportUnicodeAsLetter: {
            type: "reporter",
            category: "operators",
            spec: "unicode %n as letter",
            defaults: [ 65 ]
        },
        reportIsA: {
            type: "predicate",
            category: "operators",
            spec: "is %s a %typ ?",
            defaults: [ 5 ]
        },
        reportIsIdentical: {
            type: "predicate",
            category: "operators",
            spec: "is %s identical to %s ?"
        },
        reportTextSplit: {
            type: "reporter",
            category: "operators",
            spec: "split %s by %delim",
            defaults: [ localize("hello") + " " + localize("world"), " " ]
        },
        reportJSFunction: {
            type: "reporter",
            category: "operators",
            spec: "JavaScript function ( %mult%s ) { %code }"
        },
        reportTypeOf: {
            dev: !0,
            type: "reporter",
            category: "operators",
            spec: "type of %s",
            defaults: [ 5 ]
        },
        reportTextFunction: {
            dev: !0,
            type: "reporter",
            category: "operators",
            spec: "%txtfun of %s",
            defaults: [ null, "Abelson & Sussman" ]
        },
        doSetVar: {
            type: "command",
            category: "variables",
            spec: "set %var to %s",
            defaults: [ null, 0 ]
        },
        doChangeVar: {
            type: "command",
            category: "variables",
            spec: "change %var by %n",
            defaults: [ null, 1 ]
        },
        doShowVar: {
            type: "command",
            category: "variables",
            spec: "show variable %var"
        },
        doHideVar: {
            type: "command",
            category: "variables",
            spec: "hide variable %var"
        },
        doDeclareVariables: {
            type: "command",
            category: "other",
            spec: "script variables %scriptVars"
        },
        reportNewList: {
            type: "reporter",
            category: "lists",
            spec: "list %exp"
        },
        reportCONS: {
            type: "reporter",
            category: "lists",
            spec: "%s in front of %l"
        },
        reportListItem: {
            type: "reporter",
            category: "lists",
            spec: "item %idx of %l",
            defaults: [ 1 ]
        },
        reportCDR: {
            type: "reporter",
            category: "lists",
            spec: "all but first of %l"
        },
        reportListLength: {
            type: "reporter",
            category: "lists",
            spec: "length of %l"
        },
        reportListContainsItem: {
            type: "predicate",
            category: "lists",
            spec: "%l contains %s",
            defaults: [ null, localize("thing") ]
        },
        doAddToList: {
            type: "command",
            category: "lists",
            spec: "add %s to %l",
            defaults: [ localize("thing") ]
        },
        doDeleteFromList: {
            type: "command",
            category: "lists",
            spec: "delete %ida of %l",
            defaults: [ 1 ]
        },
        doInsertInList: {
            type: "command",
            category: "lists",
            spec: "insert %s at %idx of %l",
            defaults: [ localize("thing"), 1 ]
        },
        doReplaceInList: {
            type: "command",
            category: "lists",
            spec: "replace item %idx of %l with %s",
            defaults: [ 1, null, localize("thing") ]
        },
        reportMap: {
            dev: !0,
            type: "reporter",
            category: "lists",
            spec: "map %repRing over %l"
        },
        doForEach: {
            dev: !0,
            type: "command",
            category: "lists",
            spec: "for %upvar in %l %cs",
            defaults: [ localize("each item") ]
        },
        doMapCodeOrHeader: {
            type: "command",
            category: "other",
            spec: "map %cmdRing to %codeKind %code"
        },
        doMapStringCode: {
            type: "command",
            category: "other",
            spec: "map String to code %code",
            defaults: [ "<#1>" ]
        },
        doMapListCode: {
            type: "command",
            category: "other",
            spec: "map %codeListPart of %codeListKind to code %code"
        },
        reportMappedCode: {
            type: "reporter",
            category: "other",
            spec: "code of %cmdRing"
        },
        mearmOpenGrip: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "open grip"
        },
        mearmCloseGrip: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "close grip"
        },
        mearmMoveBaseTo: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "move base to %n degrees",
            defaults: [ 0 ]
        },
        mearmMoveLowerTo: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "move lower to %n degrees",
            defaults: [ 0 ]
        },
        mearmMoveUpperTo: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "move upper to %n degrees",
            defaults: [ 0 ]
        },
        mearmMoveGripTo: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "move grip to %n degrees",
            defaults: [ 0 ]
        },
        mearmStop: {
            only: Process,
            type: "command",
            category: "mearm",
            spec: "stop"
        }
    };
}, SpriteMorph.prototype.initBlocks(), SpriteMorph.prototype.initBlockMigrations = function() {
    SpriteMorph.prototype.blockMigrations = {
        doStopAll: {
            selector: "doStopThis",
            inputs: [ [ "all" ] ]
        },
        doStop: {
            selector: "doStopThis",
            inputs: [ [ "this script" ] ]
        },
        doStopBlock: {
            selector: "doStopThis",
            inputs: [ [ "this block" ] ]
        }
    };
}, SpriteMorph.prototype.initBlockMigrations(), SpriteMorph.prototype.blockAlternatives = {
    turn: [ "turnLeft" ],
    turnLeft: [ "turn" ],
    changeXPosition: [ "changeYPosition", "setXPosition", "setYPosition" ],
    setXPosition: [ "setYPosition", "changeXPosition", "changeYPosition" ],
    changeYPosition: [ "changeXPosition", "setYPosition", "setXPosition" ],
    setYPosition: [ "setXPosition", "changeYPosition", "changeXPosition" ],
    xPosition: [ "yPosition" ],
    yPosition: [ "xPosition" ],
    doSayFor: [ "doThinkFor", "bubble", "doThink", "doAsk" ],
    doThinkFor: [ "doSayFor", "doThink", "bubble", "doAsk" ],
    bubble: [ "doThink", "doAsk", "doSayFor", "doThinkFor" ],
    doThink: [ "bubble", "doAsk", "doSayFor", "doThinkFor" ],
    show: [ "hide" ],
    hide: [ "show" ],
    changeEffect: [ "setEffect" ],
    setEffect: [ "changeEffect" ],
    changeScale: [ "setScale" ],
    setScale: [ "changeScale" ],
    playSound: [ "doPlaySoundUntilDone" ],
    doPlaySoundUntilDone: [ "playSound" ],
    doChangeTempo: [ "doSetTempo" ],
    doSetTempo: [ "doChangeTempo" ],
    clear: [ "down", "up", "doStamp" ],
    down: [ "up", "clear", "doStamp" ],
    up: [ "down", "clear", "doStamp" ],
    doStamp: [ "clear", "down", "up" ],
    changeHue: [ "setHue", "changeBrightness", "setBrightness" ],
    setHue: [ "changeHue", "changeBrightness", "setBrightness" ],
    changeBrightness: [ "setBrightness", "setHue", "changeHue" ],
    setBrightness: [ "changeBrightness", "setHue", "changeHue" ],
    changeSize: [ "setSize" ],
    setSize: [ "changeSize" ],
    receiveGo: [ "receiveClick" ],
    receiveClick: [ "receiveGo" ],
    doBroadcast: [ "doBroadcastAndWait" ],
    doBroadcastAndWait: [ "doBroadcast" ],
    doIf: [ "doIfElse", "doUntil" ],
    doIfElse: [ "doIf", "doUntil" ],
    doRepeat: [ "doUntil" ],
    doUntil: [ "doRepeat", "doIf" ],
    doAsk: [ "bubble", "doThink", "doSayFor", "doThinkFor" ],
    getLastAnswer: [ "getTimer" ],
    getTimer: [ "getLastAnswer" ],
    reportMouseX: [ "reportMouseY" ],
    reportMouseY: [ "reportMouseX" ],
    reportSum: [ "reportDifference", "reportProduct", "reportQuotient" ],
    reportDifference: [ "reportSum", "reportProduct", "reportQuotient" ],
    reportProduct: [ "reportDifference", "reportSum", "reportQuotient" ],
    reportQuotient: [ "reportDifference", "reportProduct", "reportSum" ],
    reportLessThan: [ "reportEquals", "reportGreaterThan" ],
    reportEquals: [ "reportLessThan", "reportGreaterThan" ],
    reportGreaterThan: [ "reportEquals", "reportLessThan" ],
    reportAnd: [ "reportOr" ],
    reportOr: [ "reportAnd" ],
    reportTrue: [ "reportFalse" ],
    reportFalse: [ "reportTrue" ],
    doSetVar: [ "doChangeVar" ],
    doChangeVar: [ "doSetVar" ],
    doShowVar: [ "doHideVar" ],
    doHideVar: [ "doShowVar" ]
};

function SpriteMorph(globals) {
    this.init(globals);
}

SpriteMorph.prototype.init = function(globals) {
    this.name = localize("Sprite"), this.variables = new VariableFrame(globals || null, this), 
    this.scripts = new ScriptsMorph(this), this.customBlocks = [], this.costumes = new List(), 
    this.costume = null, this.sounds = new List(), this.normalExtent = new Point(60, 60), 
    this.scale = 1, this.rotationStyle = 1, this.version = Date.now(), this.isClone = !1, 
    this.cloneOriginName = "", this.parts = [], this.anchor = null, this.nestingScale = 1, 
    this.rotatesWithAnchor = !0, this.layers = null, this.blocksCache = {}, this.paletteCache = {}, 
    this.rotationOffset = new Point(), this.idx = 0, this.wasWarped = !1, this.graphicsValues = {
        negative: 0,
        fisheye: 0,
        whirl: 0,
        pixelate: 0,
        mosaic: 0,
        brightness: 0,
        color: 0,
        comic: 0,
        duplicate: 0,
        confetti: 0
    }, SpriteMorph.uber.init.call(this), this.isDraggable = !0, this.isDown = !1, this.heading = 90, 
    this.changed(), this.drawNew(), this.changed();
}, SpriteMorph.prototype.fullCopy = function() {
    var dp, cb, c = SpriteMorph.uber.fullCopy.call(this), myself = this, arr = [];
    return c.stopTalking(), c.color = this.color.copy(), c.blocksCache = {}, c.paletteCache = {}, 
    c.scripts = this.scripts.fullCopy(), c.scripts.owner = c, c.variables = this.variables.copy(), 
    c.variables.owner = c, c.customBlocks = [], this.customBlocks.forEach(function(def) {
        cb = def.copyAndBindTo(c), c.customBlocks.push(cb), c.allBlockInstances(def).forEach(function(block) {
            block.definition = cb;
        });
    }), this.costumes.asArray().forEach(function(costume) {
        var cst = costume.copy();
        arr.push(cst), costume === myself.costume && (c.costume = cst);
    }), c.costumes = new List(arr), arr = [], this.sounds.asArray().forEach(function(sound) {
        arr.push(sound);
    }), c.sounds = new List(arr), c.nestingScale = 1, c.rotatesWithAnchor = !0, c.anchor = null, 
    c.parts = [], this.parts.forEach(function(part) {
        (dp = part.fullCopy()).nestingScale = part.nestingScale, dp.rotatesWithAnchor = part.rotatesWithAnchor, 
        c.attachPart(dp);
    }), c;
}, SpriteMorph.prototype.appearIn = function(ide) {
    this.name = ide.newSpriteName(this.name), ide.stage.add(this), ide.sprites.add(this), 
    ide.corral.addSprite(this), this.parts.forEach(function(part) {
        part.appearIn(ide);
    });
}, SpriteMorph.prototype.setName = function(string) {
    this.name = string || this.name, this.version = Date.now();
}, SpriteMorph.prototype.drawNew = function() {
    var facing, isFlipped, cst, pic, newX, origin, shift, corner, costumeExtent, ctx, handle, myself = this, currentCenter = this.center(), isLoadingCostume = this.costume && "function" == typeof this.costume.loaded, stageScale = this.parent instanceof StageMorph ? this.parent.scale : 1, corners = [];
    if (this.isWarped) this.wantsRedraw = !0; else {
        if (facing = this.rotationStyle ? this.heading : 90, 2 === this.rotationStyle && (facing = 90, 
        (this.heading > 180 && this.heading < 360 || this.heading < 0 && this.heading > -180) && (isFlipped = !0)), 
        this.costume && !isLoadingCostume) corners = (pic = isFlipped ? this.costume.flipped() : this.costume).bounds().corners().map(function(point) {
            return point.rotateBy(radians(facing - 90), myself.costume.center());
        }), origin = corners[0], corner = corners[0], corners.forEach(function(point) {
            origin = origin.min(point), corner = corner.max(point);
        }), costumeExtent = origin.corner(corner).extent().multiplyBy(this.scale * stageScale), 
        shift = new Point(0, 0).rotateBy(radians(-(facing - 90)), pic.center()).subtract(origin), 
        this.image = newCanvas(costumeExtent), this.silentSetExtent(costumeExtent), (ctx = this.image.getContext("2d")).scale(this.scale * stageScale, this.scale * stageScale), 
        ctx.translate(shift.x, shift.y), ctx.rotate(radians(facing - 90)), ctx.drawImage(pic.contents, 0, 0), 
        this.image = this.applyGraphicsEffects(this.image), this.setCenter(currentCenter, !0), 
        this.rotationOffset = shift.translateBy(pic.rotationCenter).rotateBy(radians(-(facing - 90)), shift).scaleBy(this.scale * stageScale); else if (facing = isFlipped ? -90 : facing, 
        newX = Math.min(Math.max(this.normalExtent.x * this.scale * stageScale, 5), 1e3), 
        this.silentSetExtent(new Point(newX, newX)), this.image = newCanvas(this.extent()), 
        this.setCenter(currentCenter, !0), SpriteMorph.uber.drawNew.call(this, facing), 
        this.rotationOffset = this.extent().divideBy(2), this.image = this.applyGraphicsEffects(this.image), 
        isLoadingCostume) return cst = this.costume, handle = setInterval(function() {
            myself.wearCostume(cst), clearInterval(handle);
        }, 100), myself.wearCostume(null);
        this.version = Date.now();
    }
}, SpriteMorph.prototype.endWarp = function() {
    if (this.isWarped = !1, this.wantsRedraw) {
        var x = this.xPosition(), y = this.yPosition();
        this.drawNew(), this.silentGotoXY(x, y, !0), this.wantsRedraw = !1;
    }
    this.parent.changed();
}, SpriteMorph.prototype.rotationCenter = function() {
    return this.position().add(this.rotationOffset);
}, SpriteMorph.prototype.colorFiltered = function(aColor) {
    var ctx, src, i, dta, morph = new Morph(), ext = this.extent();
    for (src = this.image.getContext("2d").getImageData(0, 0, ext.x, ext.y), morph.image = newCanvas(ext), 
    morph.bounds = this.bounds.copy(), dta = (ctx = morph.image.getContext("2d")).createImageData(ext.x, ext.y), 
    i = 0; i < ext.x * ext.y * 4; i += 4) new Color(src.data[i], src.data[i + 1], src.data[i + 2]).eq(aColor) && (dta.data[i] = src.data[i], 
    dta.data[i + 1] = src.data[i + 1], dta.data[i + 2] = src.data[i + 2], dta.data[i + 3] = 255);
    return ctx.putImageData(dta, 0, 0), morph;
}, SpriteMorph.prototype.blockForSelector = function(selector, setDefaults) {
    var migration, info, block, defaults, inputs, i;
    if (migration = this.blockMigrations[selector], !(info = this.blocks[migration ? migration.selector : selector])) return null;
    if ((block = "command" === info.type ? new CommandBlockMorph() : "hat" === info.type ? new HatBlockMorph() : "ring" === info.type ? new RingMorph() : new ReporterBlockMorph("predicate" === info.type)).color = this.blockColor[info.category], 
    block.category = info.category, block.selector = selector, contains([ "reifyReporter", "reifyPredicate" ], block.selector) && (block.isStatic = !0), 
    block.setSpec(localize(info.spec)), setDefaults && info.defaults || migration && migration.inputs) if (defaults = migration ? migration.inputs : info.defaults, 
    block.defaults = defaults, (inputs = block.inputs())[0] instanceof MultiArgMorph) inputs[0].setContents(defaults), 
    inputs[0].defaults = defaults; else for (i = 0; i < defaults.length; i += 1) null !== defaults[i] && inputs[i].setContents(defaults[i]);
    return block;
}, SpriteMorph.prototype.variableBlock = function(varName) {
    var block = new ReporterBlockMorph(!1);
    return block.selector = "reportGetVar", block.color = this.blockColor.variables, 
    block.category = "variables", block.setSpec(varName), block.isDraggable = !0, block;
}, SpriteMorph.prototype.blockTemplates = function(category) {
    var varNames, button, txt, blocks = [], myself = this, cat = category || "motion";
    function block(selector) {
        if (StageMorph.prototype.hiddenPrimitives[selector]) return null;
        var newBlock = SpriteMorph.prototype.blockForSelector(selector, !0);
        return newBlock.isTemplate = !0, newBlock;
    }
    function watcherToggle(selector) {
        if (StageMorph.prototype.hiddenPrimitives[selector]) return null;
        var info = SpriteMorph.prototype.blocks[selector];
        return new ToggleMorph("checkbox", this, function() {
            myself.toggleWatcher(selector, localize(info.spec), myself.blockColor[info.category]);
        }, null, function() {
            return myself.showingWatcher(selector);
        }, null);
    }
    function helpMenu() {
        var menu = new MenuMorph(this);
        return menu.addItem("help...", "showHelp"), menu;
    }
    function addVar(pair) {
        pair && (myself.variables.silentFind(pair[0]) ? myself.inform("that name is already in use") : (myself.addVariable(pair[0], pair[1]), 
        myself.toggleVariableWatcher(pair[0], pair[1]), myself.blocksCache[cat] = null, 
        myself.paletteCache[cat] = null, myself.parentThatIsA(IDE_Morph).refreshPalette()));
    }
    return "motion" === cat ? (blocks.push(block("forward")), blocks.push(block("turn")), 
    blocks.push(block("turnLeft")), blocks.push("-"), blocks.push(block("setHeading")), 
    blocks.push(block("doFaceTowards")), blocks.push("-"), blocks.push(block("gotoXY")), 
    blocks.push(block("doGotoObject")), blocks.push(block("doGlide")), blocks.push("-"), 
    blocks.push(block("changeXPosition")), blocks.push(block("setXPosition")), blocks.push(block("changeYPosition")), 
    blocks.push(block("setYPosition")), blocks.push("-"), blocks.push(block("bounceOffEdge")), 
    blocks.push("-"), blocks.push(watcherToggle("xPosition")), blocks.push(block("xPosition")), 
    blocks.push(watcherToggle("yPosition")), blocks.push(block("yPosition")), blocks.push(watcherToggle("direction")), 
    blocks.push(block("direction"))) : "looks" === cat ? (blocks.push(block("doSwitchToCostume")), 
    blocks.push(block("doWearNextCostume")), blocks.push(watcherToggle("getCostumeIdx")), 
    blocks.push(block("getCostumeIdx")), blocks.push("-"), blocks.push(block("doSayFor")), 
    blocks.push(block("bubble")), blocks.push(block("doThinkFor")), blocks.push(block("doThink")), 
    blocks.push("-"), blocks.push(block("changeEffect")), blocks.push(block("setEffect")), 
    blocks.push(block("clearEffects")), blocks.push("-"), blocks.push(block("changeScale")), 
    blocks.push(block("setScale")), blocks.push(watcherToggle("getScale")), blocks.push(block("getScale")), 
    blocks.push("-"), blocks.push(block("show")), blocks.push(block("hide")), blocks.push("-"), 
    blocks.push(block("comeToFront")), blocks.push(block("goBack")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportCostumes")), 
    blocks.push("-"), blocks.push(block("log")), blocks.push(block("alert")), blocks.push("-"), 
    blocks.push(block("doScreenshot")))) : "sound" === cat ? (blocks.push(block("playSound")), 
    blocks.push(block("doPlaySoundUntilDone")), blocks.push(block("doStopAllSounds")), 
    blocks.push("-"), blocks.push(block("doRest")), blocks.push("-"), blocks.push(block("doPlayNote")), 
    blocks.push("-"), blocks.push(block("doChangeTempo")), blocks.push(block("doSetTempo")), 
    blocks.push(watcherToggle("getTempo")), blocks.push(block("getTempo")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportSounds")))) : "pen" === cat ? (blocks.push(block("clear")), 
    blocks.push("-"), blocks.push(block("down")), blocks.push(block("up")), blocks.push("-"), 
    blocks.push(block("setColor")), blocks.push(block("changeHue")), blocks.push(block("setHue")), 
    blocks.push("-"), blocks.push(block("changeBrightness")), blocks.push(block("setBrightness")), 
    blocks.push("-"), blocks.push(block("changeSize")), blocks.push(block("setSize")), 
    blocks.push("-"), blocks.push(block("doStamp"))) : "control" === cat ? (blocks.push(block("receiveGo")), 
    blocks.push(block("receiveKey")), blocks.push(block("receiveClick")), blocks.push(block("receiveMessage")), 
    blocks.push("-"), blocks.push(block("doBroadcast")), blocks.push(block("doBroadcastAndWait")), 
    blocks.push(watcherToggle("getLastMessage")), blocks.push(block("getLastMessage")), 
    blocks.push("-"), blocks.push(block("doWait")), blocks.push(block("doWaitUntil")), 
    blocks.push("-"), blocks.push(block("doForever")), blocks.push(block("doRepeat")), 
    blocks.push(block("doUntil")), blocks.push("-"), blocks.push(block("doIf")), blocks.push(block("doIfElse")), 
    blocks.push("-"), blocks.push(block("doStopThis")), blocks.push(block("doStopOthers")), 
    blocks.push("-"), blocks.push(block("receiveOnClone")), blocks.push(block("createClone")), 
    blocks.push(block("removeClone")), blocks.push("-"), blocks.push(block("doPauseAll"))) : "sensing" === cat ? (blocks.push(block("reportTouchingObject")), 
    blocks.push(block("reportTouchingColor")), blocks.push(block("reportColorIsTouchingColor")), 
    blocks.push("-"), blocks.push(block("doAsk")), blocks.push(watcherToggle("getLastAnswer")), 
    blocks.push(block("getLastAnswer")), blocks.push("-"), blocks.push(watcherToggle("reportMouseX")), 
    blocks.push(block("reportMouseX")), blocks.push(watcherToggle("reportMouseY")), 
    blocks.push(block("reportMouseY")), blocks.push(block("reportMouseDown")), blocks.push("-"), 
    blocks.push(block("reportKeyPressed")), blocks.push("-"), blocks.push(block("reportDistanceTo")), 
    blocks.push("-"), blocks.push(block("doResetTimer")), blocks.push(watcherToggle("getTimer")), 
    blocks.push(block("getTimer")), blocks.push("-"), blocks.push(block("reportAttributeOf")), 
    blocks.push("-"), blocks.push(block("reportURL")), blocks.push("-"), blocks.push(block("reportIsFastTracking")), 
    blocks.push(block("doSetFastTracking")), blocks.push("-"), blocks.push(block("reportDate")), 
    this.world().isDevMode && (blocks.push("-"), (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(watcherToggle("reportThreadCount")), 
    blocks.push(block("reportThreadCount")), blocks.push(block("colorFiltered")), blocks.push(block("reportStackSize")), 
    blocks.push(block("reportFrameCount")))) : "operators" === cat ? (blocks.push(block("reifyScript")), 
    blocks.push(block("reifyReporter")), blocks.push(block("reifyPredicate")), blocks.push("#"), 
    blocks.push("-"), blocks.push(block("reportSum")), blocks.push(block("reportDifference")), 
    blocks.push(block("reportProduct")), blocks.push(block("reportQuotient")), blocks.push("-"), 
    blocks.push(block("reportModulus")), blocks.push(block("reportRound")), blocks.push(block("reportMonadic")), 
    blocks.push(block("reportRandom")), blocks.push("-"), blocks.push(block("reportLessThan")), 
    blocks.push(block("reportEquals")), blocks.push(block("reportGreaterThan")), blocks.push("-"), 
    blocks.push(block("reportAnd")), blocks.push(block("reportOr")), blocks.push(block("reportNot")), 
    blocks.push("-"), blocks.push(block("reportTrue")), blocks.push(block("reportFalse")), 
    blocks.push("-"), blocks.push(block("reportJoinWords")), blocks.push(block("reportTextSplit")), 
    blocks.push(block("reportLetter")), blocks.push(block("reportStringSize")), blocks.push("-"), 
    blocks.push(block("reportIsA")), blocks.push(block("reportIsIdentical")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph("development mode \ndebugging primitives:")).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportTypeOf")), 
    blocks.push(block("reportTextFunction")))) : "variables" === cat ? ((button = new PushButtonMorph(null, function() {
        new VariableDialogMorph(null, addVar, myself).prompt("Variable name", null, myself.world());
    }, "Make a variable")).userMenu = helpMenu, button.selector = "addVariable", button.showHelp = BlockMorph.prototype.showHelp, 
    blocks.push(button), this.variables.allNames().length > 0 && ((button = new PushButtonMorph(null, function() {
        var menu = new MenuMorph(myself.deleteVariable, null, myself);
        myself.variables.allNames().forEach(function(name) {
            menu.addItem(name, name);
        }), menu.popUpAtHand(myself.world());
    }, "Delete a variable")).userMenu = helpMenu, button.selector = "deleteVariable", 
    button.showHelp = BlockMorph.prototype.showHelp, blocks.push(button)), blocks.push("-"), 
    (varNames = this.variables.allNames()).length > 0 && (varNames.forEach(function(name) {
        blocks.push(function(varName) {
            return new ToggleMorph("checkbox", this, function() {
                myself.toggleVariableWatcher(varName);
            }, null, function() {
                return myself.showingVariableWatcher(varName);
            }, null);
        }(name)), blocks.push(function(varName) {
            var newBlock = SpriteMorph.prototype.variableBlock(varName);
            return newBlock.isDraggable = !1, newBlock.isTemplate = !0, newBlock;
        }(name));
    }), blocks.push("-")), blocks.push(block("doSetVar")), blocks.push(block("doChangeVar")), 
    blocks.push(block("doShowVar")), blocks.push(block("doHideVar")), blocks.push("="), 
    blocks.push(block("reportNewList")), blocks.push("-"), blocks.push(block("reportCONS")), 
    blocks.push(block("reportListItem")), blocks.push(block("reportCDR")), blocks.push("-"), 
    blocks.push(block("reportListLength")), blocks.push(block("reportListContainsItem")), 
    blocks.push("-"), blocks.push(block("doAddToList")), blocks.push(block("doDeleteFromList")), 
    blocks.push(block("doInsertInList")), blocks.push(block("doReplaceInList")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportMap")), 
    blocks.push("-"), blocks.push(block("doForEach"))), blocks.push("="), StageMorph.prototype.enableCodeMapping && (blocks.push(block("doMapCodeOrHeader")), 
    blocks.push(block("doMapStringCode")), blocks.push(block("doMapListCode")), blocks.push("-"), 
    blocks.push(block("reportMappedCode")), blocks.push("=")), (button = new PushButtonMorph(null, function() {
        var ide = myself.parentThatIsA(IDE_Morph), stage = myself.parentThatIsA(StageMorph);
        new BlockDialogMorph(null, function(definition) {
            "" !== definition.spec && (definition.isGlobal ? stage.globalBlocks.push(definition) : myself.customBlocks.push(definition), 
            ide.flushPaletteCache(), ide.refreshPalette(), new BlockEditorMorph(definition, myself).popUp());
        }, myself).prompt("Make a block", null, myself.world());
    }, "Make a block")).userMenu = helpMenu, button.selector = "addCustomBlock", button.showHelp = BlockMorph.prototype.showHelp, 
    blocks.push(button)) : "mearm" === cat && (blocks.push(block("mearmOpenGrip")), 
    blocks.push(block("mearmCloseGrip")), blocks.push(block("mearmMoveBaseTo")), blocks.push(block("mearmMoveLowerTo")), 
    blocks.push(block("mearmMoveUpperTo")), blocks.push(block("mearmMoveGripTo")), blocks.push(block("mearmStop"))), 
    blocks;
}, SpriteMorph.prototype.palette = function(category) {
    return this.paletteCache[category] || (this.paletteCache[category] = this.freshPalette(category)), 
    this.paletteCache[category];
}, SpriteMorph.prototype.freshPalette = function(category) {
    var blocks, palette = new ScrollFrameMorph(null, null, this.sliderColor), unit = SyntaxElementMorph.prototype.fontSize, x = 0, y = 5, ry = 0, hideNextSpace = !1, myself = this, stage = this.parentThatIsA(StageMorph), oldFlag = Morph.prototype.trackChanges;
    return Morph.prototype.trackChanges = !1, palette.owner = this, palette.padding = unit / 2, 
    palette.color = this.paletteColor, palette.growth = new Point(0, MorphicPreferences.scrollBarSize), 
    palette.userMenu = function() {
        var menu = new MenuMorph(), ide = this.parentThatIsA(IDE_Morph), more = {
            operators: [ "reifyScript", "reifyReporter", "reifyPredicate" ],
            control: [ "doWarp" ],
            variables: [ "doDeclareVariables", "reportNewList", "reportCONS", "reportListItem", "reportCDR", "reportListLength", "reportListContainsItem", "doAddToList", "doDeleteFromList", "doInsertInList", "doReplaceInList" ]
        };
        return menu.addItem("find blocks...", function() {
            myself.searchBlocks();
        }), palette.contents.children.some(function(any) {
            return contains(Object.keys(SpriteMorph.prototype.blocks), any.selector);
        }) && menu.addItem("hide primitives", function() {
            var defs = SpriteMorph.prototype.blocks;
            Object.keys(defs).forEach(function(sel) {
                defs[sel].category === category && (StageMorph.prototype.hiddenPrimitives[sel] = !0);
            }), (more[category] || []).forEach(function(sel) {
                StageMorph.prototype.hiddenPrimitives[sel] = !0;
            }), ide.flushBlocksCache(category), ide.refreshPalette();
        }), function() {
            var defs = SpriteMorph.prototype.blocks, hiddens = StageMorph.prototype.hiddenPrimitives;
            return Object.keys(hiddens).some(function(any) {
                return !isNil(defs[any]) && (defs[any].category === category || contains(more[category] || [], any));
            });
        }() && menu.addItem("show primitives", function() {
            var hiddens = StageMorph.prototype.hiddenPrimitives, defs = SpriteMorph.prototype.blocks;
            Object.keys(hiddens).forEach(function(sel) {
                defs[sel] && defs[sel].category === category && delete StageMorph.prototype.hiddenPrimitives[sel];
            }), (more[category] || []).forEach(function(sel) {
                delete StageMorph.prototype.hiddenPrimitives[sel];
            }), ide.flushBlocksCache(category), ide.refreshPalette();
        }), menu;
    }, (blocks = this.blocksCache[category]) || (blocks = myself.blockTemplates(category), 
    this.isCachingPrimitives && (myself.blocksCache[category] = blocks)), blocks.forEach(function(block) {
        if (null !== block) if ("-" === block) {
            if (hideNextSpace) return;
            y += .8 * unit, hideNextSpace = !0;
        } else if ("=" === block) {
            if (hideNextSpace) return;
            y += 1.6 * unit, hideNextSpace = !0;
        } else "#" === block ? (x = 0, y = ry) : (hideNextSpace = !1, 0 === x && (y += .3 * unit), 
        block.setPosition(new Point(x, y)), palette.addContents(block), block instanceof ToggleMorph || block instanceof RingMorph ? (x = block.right() + unit / 2, 
        ry = block.bottom()) : (block.fixLayout && block.fixLayout(), x = 0, y += block.height()));
    }), stage && (y += 1.6 * unit, stage.globalBlocks.forEach(function(definition) {
        var block;
        (definition.category === category || "variables" === category && contains([ "lists", "other" ], definition.category)) && (block = definition.templateInstance(), 
        y += .3 * unit, block.setPosition(new Point(x, y)), palette.addContents(block), 
        x = 0, y += block.height());
    })), y += 1.6 * unit, this.customBlocks.forEach(function(definition) {
        var block;
        (definition.category === category || "variables" === category && contains([ "lists", "other" ], definition.category)) && (block = definition.templateInstance(), 
        y += .3 * unit, block.setPosition(new Point(x, y)), palette.addContents(block), 
        x = 0, y += block.height());
    }), palette.scrollX(palette.padding), palette.scrollY(palette.padding), Morph.prototype.trackChanges = oldFlag, 
    palette;
}, SpriteMorph.prototype.blocksMatching = function(searchString, strictly) {
    var blocksDict, blocks = [], myself = this, search = searchString.toLowerCase(), stage = this.parentThatIsA(StageMorph);
    function labelOf(aBlockSpec) {
        return BlockMorph.prototype.parseSpec(aBlockSpec).filter(function(each) {
            return 0 !== each.indexOf("%");
        }).join(" ");
    }
    function relevance(aBlockLabel, aSearchString) {
        var atWord, lbl = " " + aBlockLabel, idx = lbl.indexOf(aSearchString);
        return -1 === idx ? -1 : (atWord = " " === lbl.charAt(idx - 1), strictly && !atWord ? -1 : (atWord ? "1" : "2") + function(anInt, totalDigits, fillChar) {
            for (var ans = String(anInt); ans.length < totalDigits; ) ans = fillChar + ans;
            return ans;
        }(idx, 4, "0"));
    }
    return [ this.customBlocks, stage.globalBlocks ].forEach(function(blocksList) {
        blocksList.forEach(function(definition) {
            var rel = relevance(labelOf(localize(definition.blockSpec()).toLowerCase()), search);
            -1 !== rel && blocks.push([ definition.templateInstance(), rel + "1" ]);
        });
    }), blocksDict = SpriteMorph.prototype.blocks, Object.keys(blocksDict).forEach(function(selector) {
        if (!StageMorph.prototype.hiddenPrimitives[selector]) {
            var block = blocksDict[selector], rel = relevance(labelOf(localize(block.spec).toLowerCase()), search);
            -1 === rel || block.dev || block.only && block.only !== myself.constructor || blocks.push([ function(selector) {
                var newBlock = SpriteMorph.prototype.blockForSelector(selector, !0);
                return newBlock.isTemplate = !0, newBlock;
            }(selector), rel + "2" ]);
        }
    }), blocks.sort(function(x, y) {
        return x[1] < y[1] ? -1 : 1;
    }), blocks.map(function(each) {
        return each[0];
    });
}, SpriteMorph.prototype.searchBlocks = function() {
    var myself = this, unit = SyntaxElementMorph.prototype.fontSize, ide = this.parentThatIsA(IDE_Morph), oldSearch = "", searchBar = new InputFieldMorph(""), searchPane = ide.createPalette("forSearch");
    function show(blocks) {
        var oldFlag = Morph.prototype.trackChanges, x = searchPane.contents.left() + 5, y = searchBar.bottom() + unit;
        Morph.prototype.trackChanges = !1, searchPane.contents.children = [ searchPane.contents.children[0] ], 
        blocks.forEach(function(block) {
            block.setPosition(new Point(x, y)), searchPane.addContents(block), y += block.height(), 
            y += .3 * unit;
        }), Morph.prototype.trackChanges = oldFlag, searchPane.changed();
    }
    searchPane.owner = this, searchPane.color = myself.paletteColor, searchPane.contents.color = myself.paletteColor, 
    searchPane.addContents(searchBar), searchBar.drawNew(), searchBar.setWidth(ide.logo.width() - 30), 
    searchBar.contrast = 90, searchBar.setPosition(searchPane.contents.topLeft().add(new Point(10, 10))), 
    searchBar.drawNew(), searchPane.accept = function() {
        var search = searchBar.getValue();
        search.length > 0 && show(myself.blocksMatching(search));
    }, searchPane.reactToKeystroke = function() {
        var search = searchBar.getValue();
        search !== oldSearch && (oldSearch = search, show(myself.blocksMatching(search, search.length < 2)));
    }, searchBar.cancel = function() {
        ide.refreshPalette(), ide.palette.adjustScrollBars();
    }, ide.fixLayout("refreshPalette"), searchBar.edit();
}, SpriteMorph.prototype.addVariable = function(name, isGlobal) {
    var ide = this.parentThatIsA(IDE_Morph);
    isGlobal ? (this.variables.parentFrame.addVar(name), ide && ide.flushBlocksCache("variables")) : (this.variables.addVar(name), 
    this.blocksCache.variables = null);
}, SpriteMorph.prototype.deleteVariable = function(varName) {
    var ide = this.parentThatIsA(IDE_Morph);
    this.deleteVariableWatcher(varName), this.variables.deleteVar(varName), ide && (ide.flushBlocksCache("variables"), 
    ide.refreshPalette());
}, SpriteMorph.prototype.addCostume = function(costume) {
    costume.name || (costume.name = "costume" + (this.costumes.length() + 1)), this.costumes.add(costume);
}, SpriteMorph.prototype.wearCostume = function(costume) {
    var x = this.xPosition ? this.xPosition() : null, y = this.yPosition ? this.yPosition() : null, isWarped = this.isWarped;
    isWarped && this.endWarp(), this.changed(), this.costume = costume, this.drawNew(), 
    this.changed(), isWarped && this.startWarp(), null !== x && this.silentGotoXY(x, y, !0), 
    this.positionTalkBubble && this.positionTalkBubble(), this.version = Date.now();
}, SpriteMorph.prototype.getCostumeIdx = function() {
    return this.costumes.asArray().indexOf(this.costume) + 1;
}, SpriteMorph.prototype.doWearNextCostume = function() {
    var idx, arr = this.costumes.asArray();
    arr.length > 1 && (idx = arr.indexOf(this.costume)) > -1 && ((idx += 1) > arr.length - 1 && (idx = 0), 
    this.wearCostume(arr[idx]));
}, SpriteMorph.prototype.doWearPreviousCostume = function() {
    var idx, arr = this.costumes.asArray();
    arr.length > 1 && (idx = arr.indexOf(this.costume)) > -1 && ((idx -= 1) < 0 && (idx = arr.length - 1), 
    this.wearCostume(arr[idx]));
}, SpriteMorph.prototype.doSwitchToCostume = function(id) {
    if (id instanceof Costume) this.wearCostume(id); else {
        var num, costume, arr = this.costumes.asArray();
        if (contains([ localize("Turtle"), localize("Empty") ], id instanceof Array ? id[0] : null)) costume = null; else {
            if (-1 === id) return void this.doWearPreviousCostume();
            null === (costume = detect(arr, function(cst) {
                return cst.name === id;
            })) && (costume = 0 === (num = parseFloat(id)) ? null : arr[num - 1] || null);
        }
        this.wearCostume(costume);
    }
}, SpriteMorph.prototype.reportCostumes = function() {
    return this.costumes;
}, SpriteMorph.prototype.addSound = function(audio, name) {
    this.sounds.add(new Sound(audio, name));
}, SpriteMorph.prototype.playSound = function(name) {
    var active, stage = this.parentThatIsA(StageMorph), sound = detect(this.sounds.asArray(), function(s) {
        return s.name === name;
    });
    if (sound) return active = sound.play(), stage && (stage.activeSounds.push(active), 
    stage.activeSounds = stage.activeSounds.filter(function(aud) {
        return !aud.ended && !aud.terminated;
    })), active;
}, SpriteMorph.prototype.reportSounds = function() {
    return this.sounds;
}, SpriteMorph.prototype.userMenu = function() {
    var ide = this.parentThatIsA(IDE_Morph), menu = new MenuMorph(this);
    return ide && ide.isAppMode ? menu : (menu.addItem("duplicate", "duplicate"), menu.addItem("delete", "remove"), 
    menu.addItem("move", "move"), this.isClone || menu.addItem("edit", "edit"), menu.addLine(), 
    this.anchor && menu.addItem(localize("detach from") + " " + this.anchor.name, "detachFromAnchor"), 
    this.parts.length && menu.addItem("detach all parts", "detachAllParts"), menu.addItem("export...", "exportSprite"), 
    menu);
}, SpriteMorph.prototype.exportSprite = function() {
    if (!this.isCoone) {
        var ide = this.parentThatIsA(IDE_Morph);
        ide && ide.exportSprite(this);
    }
}, SpriteMorph.prototype.edit = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    ide && !ide.isAppMode && ide.selectSprite(this);
}, SpriteMorph.prototype.showOnStage = function() {
    var stage = this.parentThatIsA(StageMorph);
    stage && (this.keepWithin(stage), stage.add(this)), this.show();
}, SpriteMorph.prototype.duplicate = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    ide && ide.duplicateSprite(this);
}, SpriteMorph.prototype.remove = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    ide && ide.removeSprite(this);
}, SpriteMorph.prototype.createClone = function() {
    var stage = this.parentThatIsA(StageMorph);
    stage && stage.cloneCount <= 300 && this.fullCopy().clonify(stage);
}, SpriteMorph.prototype.clonify = function(stage) {
    this.parts.forEach(function(part) {
        part.clonify(stage);
    }), stage.cloneCount += 1, this.cloneOriginName = this.isClone ? this.cloneOriginName : this.name, 
    this.isClone = !0, this.name = "", stage.add(this), this.allHatBlocksFor("__clone__init__").forEach(function(block) {
        stage.threads.startProcess(block, stage.isThreadSafe);
    });
}, SpriteMorph.prototype.removeClone = function() {
    this.isClone && (this.parent.threads.stopAllForReceiver(this), this.destroy(), this.parent.cloneCount -= 1);
}, SpriteMorph.prototype.hide = function() {
    SpriteMorph.uber.hide.call(this), this.parts.forEach(function(part) {
        part.hide();
    });
}, SpriteMorph.prototype.show = function() {
    SpriteMorph.uber.show.call(this), this.parts.forEach(function(part) {
        part.show();
    });
}, SpriteMorph.prototype.setColor = function(aColor) {
    var x = this.xPosition(), y = this.yPosition();
    this.color.eq(aColor) || (this.color = aColor.copy(), this.drawNew(), this.gotoXY(x, y));
}, SpriteMorph.prototype.getHue = function() {
    return 100 * this.color.hsv()[0];
}, SpriteMorph.prototype.setHue = function(num) {
    var hsv = this.color.hsv(), x = this.xPosition(), y = this.yPosition();
    hsv[0] = Math.max(Math.min(+num || 0, 100), 0) / 100, hsv[1] = 1, this.color.set_hsv.apply(this.color, hsv), 
    this.costume || (this.drawNew(), this.changed()), this.gotoXY(x, y);
}, SpriteMorph.prototype.changeHue = function(delta) {
    this.setHue(this.getHue() + (+delta || 0));
}, SpriteMorph.prototype.getBrightness = function() {
    return 100 * this.color.hsv()[2];
}, SpriteMorph.prototype.setBrightness = function(num) {
    var hsv = this.color.hsv(), x = this.xPosition(), y = this.yPosition();
    hsv[1] = 1, hsv[2] = Math.max(Math.min(+num || 0, 100), 0) / 100, this.color.set_hsv.apply(this.color, hsv), 
    this.costume || (this.drawNew(), this.changed()), this.gotoXY(x, y);
}, SpriteMorph.prototype.changeBrightness = function(delta) {
    this.setBrightness(this.getBrightness() + (+delta || 0));
}, SpriteMorph.prototype.comeToFront = function() {
    this.parent && (this.parent.add(this), this.changed());
}, SpriteMorph.prototype.goBack = function(layers) {
    var layer, newLayer = +layers || 0;
    return this.parent ? (layer = this.parent.children.indexOf(this)) < newLayer ? null : (this.parent.removeChild(this), 
    this.parent.children.splice(layer - newLayer, null, this), void this.parent.changed()) : null;
}, SpriteMorph.prototype.overlappingImage = function(otherSprite) {
    var oRect = this.bounds.intersect(otherSprite.bounds), oImg = newCanvas(oRect.extent()), ctx = oImg.getContext("2d");
    return oRect.width() < 1 || oRect.height() < 1 ? newCanvas(new Point(1, 1)) : (ctx.drawImage(this.image, this.left() - oRect.left(), this.top() - oRect.top()), 
    ctx.globalCompositeOperation = "source-in", ctx.drawImage(otherSprite.image, otherSprite.left() - oRect.left(), otherSprite.top() - oRect.top()), 
    oImg);
}, SpriteMorph.prototype.doStamp = function() {
    var stage = this.parent, context = stage.penTrails().getContext("2d"), isWarped = this.isWarped;
    isWarped && this.endWarp(), context.save(), context.scale(1 / stage.scale, 1 / stage.scale), 
    context.drawImage(this.image, this.left() - stage.left(), this.top() - stage.top()), 
    context.restore(), this.changed(), isWarped && this.startWarp();
}, SpriteMorph.prototype.clear = function() {
    this.parent.clearPenTrails();
}, SpriteMorph.prototype.setSize = function(size) {
    isNaN(size) || (this.size = Math.min(Math.max(+size, 1e-4), 1e3));
}, SpriteMorph.prototype.changeSize = function(delta) {
    this.setSize(this.size + (+delta || 0));
}, SpriteMorph.prototype.getScale = function() {
    return 100 * this.scale;
}, SpriteMorph.prototype.setScale = function(percentage) {
    var realScale, growth, x = this.xPosition(), y = this.yPosition(), isWarped = this.isWarped;
    isWarped && this.endWarp(), growth = (realScale = (+percentage || 0) / 100) / this.nestingScale, 
    this.nestingScale = realScale, this.scale = Math.max(realScale, .01), this.changed(), 
    this.drawNew(), this.changed(), isWarped && this.startWarp(), this.silentGotoXY(x, y, !0), 
    this.positionTalkBubble(), this.parts.forEach(function(part) {
        var xDist = part.xPosition() - x, yDist = part.yPosition() - y;
        part.setScale(100 * part.scale * growth), part.silentGotoXY(x + xDist * growth, y + yDist * growth);
    });
}, SpriteMorph.prototype.changeScale = function(delta) {
    this.setScale(this.getScale() + (+delta || 0));
}, SpriteMorph.prototype.graphicsChanged = function() {
    var myself = this;
    return Object.keys(this.graphicsValues).some(function(any) {
        return myself.graphicsValues[any] < 0 || myself.graphicsValues[any] > 0;
    });
}, SpriteMorph.prototype.applyGraphicsEffects = function(canvas) {
    var ctx, imagedata, pixels, newimagedata;
    return this.graphicsChanged() && (pixels = function(p, value) {
        var i;
        if (0 !== value) for (i = 0; i < p.length; i += 1) p[i] = 127 * Math.sin(value * p[i]) + p[i];
        return p;
    }(pixels = function(p, value) {
        var i;
        if (0 !== value) for (i = 0; i < p.length; i += 4) p[i] = p[i * value], p[i + 1] = p[i * value + 1], 
        p[i + 2] = p[i * value + 2], p[i + 3] = p[i * value + 3];
        return p;
    }(pixels = function(p, value) {
        var i;
        if (0 !== value) for (i = 0; i < p.length; i += 4) p[i] += 127 * Math.sin(i * value) + 128, 
        p[i + 1] += 127 * Math.sin(i * value) + 128, p[i + 2] += 127 * Math.sin(i * value) + 128;
        return p;
    }(pixels = function(p, value) {
        var i;
        if (0 !== value) for (i = 0; i < p.length; i += 4) p[i] += value, p[i + 1] += value, 
        p[i + 2] += value;
        return p;
    }(pixels = function(p, value) {
        var i, rcom, gcom, bcom;
        if (0 !== value) for (i = 0; i < p.length; i += 4) rcom = 255 - p[i], gcom = 255 - p[i + 1], 
        bcom = 255 - p[i + 2], p[i] < rcom ? p[i] += value : p[i] > rcom && (p[i] -= value), 
        p[i + 1] < gcom ? p[i + 1] += value : p[i + 1] > gcom && (p[i + 1] -= value), p[i + 2] < bcom ? p[i + 2] += value : p[i + 2] > bcom && (p[i + 2] -= value);
        return p;
    }(pixels = (imagedata = (ctx = canvas.getContext("2d")).getImageData(0, 0, canvas.width, canvas.height)).data, this.graphicsValues.negative), this.graphicsValues.brightness), this.graphicsValues.comic), this.graphicsValues.duplicate), this.graphicsValues.confetti), 
    (newimagedata = ctx.createImageData(imagedata)).data.set(pixels), ctx.putImageData(newimagedata, 0, 0)), 
    canvas;
}, SpriteMorph.prototype.setEffect = function(effect, value) {
    var eff = effect instanceof Array ? effect[0] : null;
    "ghost" === eff ? this.alpha = 1 - Math.min(Math.max(+value || 0, 0), 100) / 100 : this.graphicsValues[eff] = value, 
    this.drawNew(), this.changed();
}, SpriteMorph.prototype.getGhostEffect = function() {
    return 100 * (1 - this.alpha);
}, SpriteMorph.prototype.changeEffect = function(effect, value) {
    var eff = effect instanceof Array ? effect[0] : null;
    "ghost" === eff ? this.setEffect(effect, this.getGhostEffect() + (+value || 0)) : this.setEffect(effect, this.graphicsValues[eff] + value);
}, SpriteMorph.prototype.clearEffects = function() {
    var effect;
    for (effect in this.graphicsValues) this.graphicsValues.hasOwnProperty(effect) && this.setEffect([ effect ], 0);
    this.setEffect([ "ghost" ], 0);
}, SpriteMorph.prototype.stopTalking = function() {
    var bubble = this.talkBubble();
    bubble && bubble.destroy();
}, SpriteMorph.prototype.doThink = function(data) {
    this.bubble(data, !0);
}, SpriteMorph.prototype.bubble = function(data, isThought, isQuestion) {
    var bubble, stage = this.parentThatIsA(StageMorph);
    this.stopTalking(), "" === data || isNil(data) || (bubble = new SpriteBubbleMorph(data, stage ? stage.scale : 1, isThought, isQuestion), 
    this.add(bubble), this.positionTalkBubble());
}, SpriteMorph.prototype.talkBubble = function() {
    return detect(this.children, function(morph) {
        return morph instanceof SpeechBubbleMorph;
    });
}, SpriteMorph.prototype.positionTalkBubble = function() {
    var stage = this.parentThatIsA(StageMorph), stageScale = stage ? stage.scale : 1, bubble = this.talkBubble(), middle = this.center().y;
    if (!bubble) return null;
    for (bubble.show(), bubble.isPointingRight || (bubble.isPointingRight = !0, bubble.drawNew(), 
    bubble.changed()), bubble.setLeft(this.right()), bubble.setBottom(this.top()); !this.isTouching(bubble) && bubble.bottom() < middle; ) bubble.silentMoveBy(new Point(-1, 1).scaleBy(stageScale));
    if (!stage) return null;
    bubble.right() > stage.right() && (bubble.isPointingRight = !1, bubble.drawNew(), 
    bubble.setRight(this.center().x)), bubble.keepWithin(stage), bubble.changed();
}, SpriteMorph.prototype.prepareToBeGrabbed = function(hand) {
    this.removeShadow(), this.recordLayers(), this.bounds.containsPoint(hand.position()) || this.setCenter(hand.position()), 
    this.addShadow();
}, SpriteMorph.prototype.justDropped = function() {
    this.restoreLayers(), this.positionTalkBubble();
}, SpriteMorph.prototype.drawLine = function(start, dest) {
    var stagePos = this.parent.bounds.origin, stageScale = this.parent.scale, context = this.parent.penTrails().getContext("2d"), from = start.subtract(stagePos).divideBy(stageScale), to = dest.subtract(stagePos).divideBy(stageScale), damagedFrom = from.multiplyBy(stageScale).add(stagePos), damagedTo = to.multiplyBy(stageScale).add(stagePos), damaged = damagedFrom.rectangle(damagedTo).expandBy(Math.max(this.size * stageScale / 2, 1)).intersect(this.parent.visibleBounds()).spread();
    this.isDown && (context.lineWidth = this.size, context.strokeStyle = this.color.toString(), 
    this.useFlatLineEnds ? (context.lineCap = "butt", context.lineJoin = "miter") : (context.lineCap = "round", 
    context.lineJoin = "round"), context.beginPath(), context.moveTo(from.x, from.y), 
    context.lineTo(to.x, to.y), context.stroke(), !1 === this.isWarped && this.world().broken.push(damaged));
}, SpriteMorph.prototype.moveBy = function(delta, justMe) {
    var start = this.isDown && !justMe && this.parent ? this.rotationCenter() : null;
    SpriteMorph.uber.moveBy.call(this, delta), start && this.drawLine(start, this.rotationCenter()), 
    justMe || this.parts.forEach(function(part) {
        part.moveBy(delta);
    });
}, SpriteMorph.prototype.slideBackTo = function(situation, inSteps) {
    var steps = inSteps || 5, pos = situation.origin.position().add(situation.position), xStep = -(this.left() - pos.x) / steps, yStep = -(this.top() - pos.y) / steps, stepCount = 0, oldStep = this.step, oldFps = this.fps, myself = this;
    this.fps = 0, this.step = function() {
        myself.moveBy(new Point(xStep, yStep)), (stepCount += 1) === steps && (situation.origin.add(myself), 
        situation.origin.reactToDropOf && situation.origin.reactToDropOf(myself), myself.step = oldStep, 
        myself.fps = oldFps);
    };
}, SpriteMorph.prototype.setCenter = function(aPoint, justMe) {
    var delta = aPoint.subtract(this.center());
    this.moveBy(delta, justMe);
}, SpriteMorph.prototype.nestingBounds = function() {
    var result = this.bounds;
    return !this.costume && this.penBounds && (result = this.penBounds.translateBy(this.position())), 
    this.parts.forEach(function(part) {
        part.isVisible && (result = result.merge(part.nestingBounds()));
    }), result;
}, Morph.prototype.setPosition = function(aPoint, justMe) {
    var delta = aPoint.subtract(this.topLeft());
    0 === delta.x && 0 === delta.y || this.moveBy(delta, justMe);
}, SpriteMorph.prototype.forward = function(steps) {
    var dest, dist = steps * this.parent.scale || 0;
    dest = dist >= 0 ? this.position().distanceAngle(dist, this.heading) : this.position().distanceAngle(Math.abs(dist), this.heading - 180), 
    this.setPosition(dest), this.positionTalkBubble();
}, SpriteMorph.prototype.setHeading = function(degrees) {
    var x = this.xPosition(), y = this.yPosition(), dir = +degrees || 0, turn = dir - this.heading;
    this.changed(), SpriteMorph.uber.setHeading.call(this, dir), this.silentGotoXY(x, y, !0), 
    this.positionTalkBubble(), this.parts.forEach(function(part) {
        var trg = new Point(part.xPosition(), part.yPosition()).rotateBy(radians(turn), new Point(x, y));
        part.rotatesWithAnchor && part.turn(turn), part.gotoXY(trg.x, trg.y);
    });
}, SpriteMorph.prototype.faceToXY = function(x, y) {
    var deltaX = (x - this.xPosition()) * this.parent.scale, deltaY = (y - this.yPosition()) * this.parent.scale, angle = Math.abs(deltaX) < .001 ? deltaY < 0 ? 90 : 270 : Math.round((deltaX >= 0 ? 0 : 180) - 57.2957795131 * Math.atan(deltaY / deltaX));
    this.setHeading(angle + 90);
}, SpriteMorph.prototype.turn = function(degrees) {
    this.setHeading(this.heading + (+degrees || 0));
}, SpriteMorph.prototype.turnLeft = function(degrees) {
    this.setHeading(this.heading - (+degrees || 0));
}, SpriteMorph.prototype.xPosition = function() {
    var stage = this.parentThatIsA(StageMorph);
    return !stage && this.parent.grabOrigin && (stage = this.parent.grabOrigin.origin), 
    stage ? (this.rotationCenter().x - stage.center().x) / stage.scale : this.rotationCenter().x;
}, SpriteMorph.prototype.yPosition = function() {
    var stage = this.parentThatIsA(StageMorph);
    return !stage && this.parent.grabOrigin && (stage = this.parent.grabOrigin.origin), 
    stage ? (stage.center().y - this.rotationCenter().y) / stage.scale : this.rotationCenter().y;
}, SpriteMorph.prototype.direction = function() {
    return this.heading;
}, SpriteMorph.prototype.penSize = function() {
    return this.size;
}, SpriteMorph.prototype.gotoXY = function(x, y, justMe) {
    var newX, newY, dest, stage = this.parentThatIsA(StageMorph);
    newX = stage.center().x + (+x || 0) * stage.scale, newY = stage.center().y - (+y || 0) * stage.scale, 
    dest = this.costume ? new Point(newX, newY).subtract(this.rotationOffset) : new Point(newX, newY).subtract(this.extent().divideBy(2)), 
    this.setPosition(dest, justMe), this.positionTalkBubble();
}, SpriteMorph.prototype.silentGotoXY = function(x, y, justMe) {
    var penState = this.isDown;
    this.isDown = !1, this.gotoXY(x, y, justMe), this.isDown = penState;
}, SpriteMorph.prototype.setXPosition = function(num) {
    this.gotoXY(+num || 0, this.yPosition());
}, SpriteMorph.prototype.changeXPosition = function(delta) {
    this.setXPosition(this.xPosition() + (+delta || 0));
}, SpriteMorph.prototype.setYPosition = function(num) {
    this.gotoXY(this.xPosition(), +num || 0);
}, SpriteMorph.prototype.changeYPosition = function(delta) {
    this.setYPosition(this.yPosition() + (+delta || 0));
}, SpriteMorph.prototype.glide = function(duration, endX, endY, elapsed, startPoint) {
    var fraction, endPoint, rPos;
    endPoint = new Point(endX, endY), fraction = Math.max(Math.min(elapsed / duration, 1), 0), 
    rPos = startPoint.add(endPoint.subtract(startPoint).multiplyBy(fraction)), this.gotoXY(rPos.x, rPos.y);
}, SpriteMorph.prototype.bounceOffEdge = function() {
    var dirX, dirY, stage = this.parentThatIsA(StageMorph), fb = this.nestingBounds();
    return stage ? stage.bounds.containsRectangle(fb) ? null : (dirX = Math.cos(radians(this.heading - 90)), 
    dirY = -Math.sin(radians(this.heading - 90)), fb.left() < stage.left() && (dirX = Math.abs(dirX)), 
    fb.right() > stage.right() && (dirX = -Math.abs(dirX)), fb.top() < stage.top() && (dirY = -Math.abs(dirY)), 
    fb.bottom() > stage.bottom() && (dirY = Math.abs(dirY)), this.setHeading(degrees(Math.atan2(-dirY, dirX)) + 90), 
    this.setPosition(this.position().add(fb.amountToTranslateWithin(stage.bounds))), 
    void this.positionTalkBubble()) : null;
}, SpriteMorph.prototype.allMessageNames = function() {
    var msgs = [];
    return this.scripts.allChildren().forEach(function(morph) {
        var txt;
        morph.selector && contains([ "receiveMessage", "doBroadcast", "doBroadcastAndWait" ], morph.selector) && isString(txt = morph.inputs()[0].evaluate()) && "" !== txt && (contains(msgs, txt) || msgs.push(txt));
    }), msgs;
}, SpriteMorph.prototype.allHatBlocksFor = function(message) {
    return "number" == typeof message && (message = message.toString()), this.scripts.children.filter(function(morph) {
        var event;
        if (morph.selector) {
            if ("receiveMessage" === morph.selector) return (event = morph.inputs()[0].evaluate()) === message || event instanceof Array;
            if ("receiveGo" === morph.selector) return "__shout__go__" === message;
            if ("receiveOnClone" === morph.selector) return "__clone__init__" === message;
            if ("receiveClick" === morph.selector) return "__click__" === message;
        }
        return !1;
    });
}, SpriteMorph.prototype.allHatBlocksForKey = function(key) {
    return this.scripts.children.filter(function(morph) {
        return !(!morph.selector || "receiveKey" !== morph.selector) && morph.inputs()[0].evaluate()[0] === key;
    });
}, SpriteMorph.prototype.mouseClickLeft = function() {
    var stage = this.parentThatIsA(StageMorph), procs = [];
    return this.allHatBlocksFor("__click__").forEach(function(block) {
        procs.push(stage.threads.startProcess(block, stage.isThreadSafe));
    }), procs;
}, SpriteMorph.prototype.mouseDoubleClick = function() {
    this.isClone || this.edit();
}, SpriteMorph.prototype.getTimer = function() {
    var stage = this.parentThatIsA(StageMorph);
    return stage ? stage.getTimer() : 0;
}, SpriteMorph.prototype.getTempo = function() {
    var stage = this.parentThatIsA(StageMorph);
    return stage ? stage.getTempo() : 0;
}, SpriteMorph.prototype.getLastMessage = function() {
    var stage = this.parentThatIsA(StageMorph);
    return stage ? stage.getLastMessage() : "";
}, SpriteMorph.prototype.getLastAnswer = function() {
    return this.parentThatIsA(StageMorph).lastAnswer;
}, SpriteMorph.prototype.reportMouseX = function() {
    var stage = this.parentThatIsA(StageMorph);
    return stage ? stage.reportMouseX() : 0;
}, SpriteMorph.prototype.reportMouseY = function() {
    var stage = this.parentThatIsA(StageMorph);
    return stage ? stage.reportMouseY() : 0;
}, SpriteMorph.prototype.reportThreadCount = function() {
    var stage = this.parentThatIsA(StageMorph);
    return stage ? stage.threads.processes.length : 0;
}, SpriteMorph.prototype.findVariableWatcher = function(varName) {
    var stage = this.parentThatIsA(StageMorph), myself = this;
    return null === stage ? null : detect(stage.children, function(morph) {
        return morph instanceof WatcherMorph && (morph.target === myself.variables || morph.target === myself.variables.parentFrame) && morph.getter === varName;
    });
}, SpriteMorph.prototype.toggleVariableWatcher = function(varName, isGlobal) {
    var watcher, others, stage = this.parentThatIsA(StageMorph);
    if (null === stage) return null;
    null === (watcher = this.findVariableWatcher(varName)) ? (isNil(isGlobal) && (isGlobal = contains(this.variables.parentFrame.names(), varName)), 
    (watcher = new WatcherMorph(varName, this.blockColor.variables, isGlobal ? this.variables.parentFrame : this.variables, varName)).setPosition(stage.position().add(10)), 
    (others = stage.watchers(watcher.left())).length > 0 && watcher.setTop(others[others.length - 1].bottom()), 
    stage.add(watcher), watcher.fixLayout(), watcher.keepWithin(stage)) : watcher.isVisible ? watcher.hide() : (watcher.show(), 
    watcher.fixLayout(), watcher.keepWithin(stage));
}, SpriteMorph.prototype.showingVariableWatcher = function(varName) {
    var watcher;
    return null !== this.parentThatIsA(StageMorph) && (!!(watcher = this.findVariableWatcher(varName)) && watcher.isVisible);
}, SpriteMorph.prototype.deleteVariableWatcher = function(varName) {
    var watcher;
    if (null === this.parentThatIsA(StageMorph)) return null;
    null !== (watcher = this.findVariableWatcher(varName)) && watcher.destroy();
}, SpriteMorph.prototype.toggleWatcher = function(selector, label, color) {
    var watcher, others, stage = this.parentThatIsA(StageMorph);
    stage && ((watcher = this.watcherFor(stage, selector)) ? watcher.isVisible ? watcher.hide() : (watcher.show(), 
    watcher.fixLayout(), watcher.keepWithin(stage)) : ((watcher = new WatcherMorph(label, color, WatcherMorph.prototype.isGlobal(selector) ? stage : this, selector)).setPosition(stage.position().add(10)), 
    (others = stage.watchers(watcher.left())).length > 0 && watcher.setTop(others[others.length - 1].bottom()), 
    stage.add(watcher), watcher.fixLayout(), watcher.keepWithin(stage)));
}, SpriteMorph.prototype.showingWatcher = function(selector) {
    var watcher, stage = this.parentThatIsA(StageMorph);
    return null !== stage && (!!(watcher = this.watcherFor(stage, selector)) && watcher.isVisible);
}, SpriteMorph.prototype.watcherFor = function(stage, selector) {
    var myself = this;
    return detect(stage.children, function(morph) {
        return morph instanceof WatcherMorph && morph.getter === selector && morph.target === (morph.isGlobal(selector) ? stage : myself);
    });
}, SpriteMorph.prototype.deleteAllBlockInstances = function(definition) {
    this.allBlockInstances(definition).forEach(function(each) {
        each.deleteBlock();
    }), this.customBlocks.forEach(function(def) {
        def.body && def.body.expression.isCorpse && (def.body = null);
    });
}, SpriteMorph.prototype.allBlockInstances = function(definition) {
    var stage, objects, inDefinitions, blocks = [];
    return definition.isGlobal ? ((objects = (stage = this.parentThatIsA(StageMorph)).children.filter(function(morph) {
        return morph instanceof SpriteMorph;
    })).push(stage), objects.forEach(function(sprite) {
        blocks = blocks.concat(sprite.allLocalBlockInstances(definition));
    }), inDefinitions = [], stage.globalBlocks.forEach(function(def) {
        def.body && def.body.expression.allChildren().forEach(function(c) {
            c.definition && c.definition === definition && inDefinitions.push(c);
        });
    }), blocks.concat(inDefinitions)) : this.allLocalBlockInstances(definition);
}, SpriteMorph.prototype.allLocalBlockInstances = function(definition) {
    var inScripts, inDefinitions, inBlockEditors, inPalette, result;
    return inScripts = this.scripts.allChildren().filter(function(c) {
        return c.definition && c.definition === definition;
    }), inDefinitions = [], this.customBlocks.forEach(function(def) {
        def.body && def.body.expression.allChildren().forEach(function(c) {
            c.definition && c.definition === definition && inDefinitions.push(c);
        });
    }), inBlockEditors = this.allEditorBlockInstances(definition), inPalette = this.paletteBlockInstance(definition), 
    result = inScripts.concat(inDefinitions).concat(inBlockEditors), inPalette && result.push(inPalette), 
    result;
}, SpriteMorph.prototype.allEditorBlockInstances = function(definition) {
    var inBlockEditors = [];
    return this.world() ? (this.world().children.forEach(function(morph) {
        morph instanceof BlockEditorMorph && morph.body.contents.allChildren().forEach(function(block) {
            block.isPrototype || block instanceof PrototypeHatBlockMorph || block.definition !== definition || inBlockEditors.push(block);
        });
    }), inBlockEditors) : [];
}, SpriteMorph.prototype.paletteBlockInstance = function(definition) {
    var ide = this.parentThatIsA(IDE_Morph);
    return ide ? detect(ide.palette.contents.children, function(block) {
        return block.definition === definition;
    }) : null;
}, SpriteMorph.prototype.usesBlockInstance = function(definition) {
    var inDefinitions;
    return !!detect(this.scripts.allChildren(), function(c) {
        return c.definition && c.definition === definition;
    }) || (inDefinitions = [], this.customBlocks.forEach(function(def) {
        def.body && def.body.expression.allChildren().forEach(function(c) {
            c.definition && c.definition === definition && inDefinitions.push(c);
        });
    }), inDefinitions.length > 0);
}, SpriteMorph.prototype.doubleDefinitionsFor = function(definition) {
    var blockList, idx, stage, spec = definition.blockSpec();
    if (definition.isGlobal) {
        if (!(stage = this.parentThatIsA(StageMorph))) return [];
        blockList = stage.globalBlocks;
    } else blockList = this.customBlocks;
    return -1 === (idx = blockList.indexOf(definition)) ? [] : blockList.filter(function(def, i) {
        return def.blockSpec() === spec && i !== idx;
    });
}, SpriteMorph.prototype.replaceDoubleDefinitionsFor = function(definition) {
    var stage, ide, doubles = this.doubleDefinitionsFor(definition), myself = this;
    doubles.forEach(function(double) {
        myself.allBlockInstances(double).forEach(function(block) {
            block.definition = definition, block.refresh();
        });
    }), definition.isGlobal ? (stage = this.parentThatIsA(StageMorph)).globalBlocks = stage.globalBlocks.filter(function(def) {
        return !contains(doubles, def);
    }) : this.customBlocks = this.customBlocks.filter(function(def) {
        return !contains(doubles, def);
    }), (ide = this.parentThatIsA(IDE_Morph)) && (ide.flushPaletteCache(), ide.refreshPalette());
}, SpriteMorph.prototype.thumbnail = function(extentPoint) {
    var src = this.image, scale = Math.min(extentPoint.x / src.width, extentPoint.y / src.height), xOffset = (extentPoint.x - src.width * scale) / 2, yOffset = (extentPoint.y - src.height * scale) / 2, trg = newCanvas(extentPoint), ctx = trg.getContext("2d");
    return ctx.save(), src.width && src.height && (ctx.scale(scale, scale), ctx.drawImage(src, Math.floor(xOffset / scale), Math.floor(yOffset / scale))), 
    trg;
}, SpriteMorph.prototype.fullThumbnail = function(extentPoint) {
    var thumb = this.thumbnail(extentPoint), ctx = thumb.getContext("2d"), ext = extentPoint.divideBy(3), i = 0;
    for (ctx.restore(), this.anchor && ctx.drawImage(this.anchor.thumbnail(ext), 0, 0), 
    i = 0; i < 3; i += 1) this.parts[i] && ctx.drawImage(this.parts[i].thumbnail(ext), i * ext.x, extentPoint.y - ext.y);
    return thumb;
}, SpriteMorph.prototype.booleanMorph = function(bool) {
    var block = new ReporterBlockMorph(!0);
    return block.color = SpriteMorph.prototype.blockColor.operators, block.setSpec(localize(bool.toString())), 
    block;
}, SpriteMorph.prototype.attachPart = function(aSprite) {
    var v = Date.now();
    aSprite.anchor && aSprite.anchor.detachPart(aSprite), this.parts.push(aSprite), 
    this.version = v, aSprite.anchor = this, this.allParts().forEach(function(part) {
        part.nestingScale = part.scale;
    }), aSprite.version = v;
}, SpriteMorph.prototype.detachPart = function(aSprite) {
    var v, idx = this.parts.indexOf(aSprite);
    -1 !== idx && (v = Date.now(), this.parts.splice(idx, 1), this.version = v, aSprite.anchor = null, 
    aSprite.version = v);
}, SpriteMorph.prototype.detachAllParts = function() {
    var v = Date.now();
    this.parts.forEach(function(part) {
        part.anchor = null, part.version = v;
    }), this.parts = [], this.version = v;
}, SpriteMorph.prototype.detachFromAnchor = function() {
    this.anchor && this.anchor.detachPart(this);
}, SpriteMorph.prototype.allParts = function() {
    var result = [ this ];
    return this.parts.forEach(function(part) {
        result = result.concat(part.allParts());
    }), result;
}, SpriteMorph.prototype.allAnchors = function() {
    var result = [ this ];
    return null !== this.anchor && (result = result.concat(this.anchor.allAnchors())), 
    result;
}, SpriteMorph.prototype.recordLayers = function() {
    var stage = this.parentThatIsA(StageMorph);
    stage ? (this.layers = this.allParts(), this.layers.forEach(function(part) {
        var bubble = part.talkBubble();
        bubble && bubble.hide();
    }), this.layers.sort(function(x, y) {
        return stage.children.indexOf(x) < stage.children.indexOf(y) ? -1 : 1;
    })) : this.layerCache = null;
}, SpriteMorph.prototype.restoreLayers = function() {
    this.layers && this.layers.length > 1 && this.layers.forEach(function(sprite) {
        sprite.comeToFront(), sprite.positionTalkBubble();
    }), this.layers = null;
}, SpriteMorph.prototype.addHighlight = function(oldHighlight) {
    var highlight, isHidden = !this.isVisible;
    return isHidden && this.show(), highlight = this.highlight(oldHighlight ? oldHighlight.color : this.highlightColor, this.highlightBorder), 
    this.addBack(highlight), this.fullChanged(), isHidden && this.hide(), highlight;
}, SpriteMorph.prototype.removeHighlight = function() {
    var highlight = this.getHighlight();
    return null !== highlight && (this.fullChanged(), this.removeChild(highlight)), 
    highlight;
}, SpriteMorph.prototype.toggleHighlight = function() {
    this.getHighlight() ? this.removeHighlight() : this.addHighlight();
}, SpriteMorph.prototype.highlight = function(color, border) {
    var ctx, highlight = new SpriteHighlightMorph(), fb = this.bounds, edge = border;
    return highlight.setExtent(fb.extent().add(2 * edge)), highlight.color = color, 
    highlight.image = this.highlightImage(color, border), (ctx = highlight.image.getContext("2d")).drawImage(this.highlightImage(new Color(255, 255, 255), 4), border - 4, border - 4), 
    ctx.drawImage(this.highlightImage(new Color(50, 50, 50), 2), border - 2, border - 2), 
    ctx.drawImage(this.highlightImage(new Color(255, 255, 255), 1), border - 1, border - 1), 
    highlight.setPosition(fb.origin.subtract(new Point(edge, edge))), highlight;
}, SpriteMorph.prototype.highlightImage = function(color, border) {
    var fb, img, hi, ctx, out;
    return fb = this.extent(), img = this.image, (ctx = (hi = newCanvas(fb.add(2 * border))).getContext("2d")).drawImage(img, 0, 0), 
    ctx.drawImage(img, border, 0), ctx.drawImage(img, 2 * border, 0), ctx.drawImage(img, 2 * border, border), 
    ctx.drawImage(img, 2 * border, 2 * border), ctx.drawImage(img, border, 2 * border), 
    ctx.drawImage(img, 0, 2 * border), ctx.drawImage(img, 0, border), ctx.globalCompositeOperation = "destination-out", 
    ctx.drawImage(img, border, border), (ctx = (out = newCanvas(fb.add(2 * border))).getContext("2d")).drawImage(hi, 0, 0), 
    ctx.globalCompositeOperation = "source-atop", ctx.fillStyle = color.toString(), 
    ctx.fillRect(0, 0, out.width, out.height), out;
}, SpriteMorph.prototype.getHighlight = function() {
    var highlights;
    return 0 !== (highlights = this.children.slice(0).reverse().filter(function(child) {
        return child instanceof SpriteHighlightMorph;
    })).length ? highlights[0] : null;
}, SpriteMorph.prototype.mouseEnterDragging = function() {
    var obj;
    this.enableNesting && (obj = this.world().hand.children[0], this.wantsDropOf(obj) && this.addHighlight());
}, SpriteMorph.prototype.mouseLeave = function() {
    this.enableNesting && this.removeHighlight();
}, SpriteMorph.prototype.wantsDropOf = function(morph) {
    return this.enableNesting && morph instanceof SpriteIconMorph && !contains(morph.object.allParts(), this);
}, SpriteMorph.prototype.reactToDropOf = function(morph, hand) {
    this.removeHighlight(), this.attachPart(morph.object), this.world().add(morph), 
    morph.slideBackTo(hand.grabOrigin);
}, SpriteMorph.prototype.newCostumeName = function(name, ignoredCostume) {
    for (var ix = name.indexOf("("), stem = ix < 0 ? name : name.substring(0, ix), count = 1, newName = stem, all = this.costumes.asArray().filter(function(each) {
        return each !== ignoredCostume;
    }).map(function(each) {
        return each.name;
    }); contains(all, newName); ) newName = stem + "(" + (count += 1) + ")";
    return newName;
}, SpriteMorph.prototype.doScreenshot = function(imgSource, data) {
    var canvas, costume, stage = this.parentThatIsA(StageMorph);
    data = this.newCostumeName(data), void 0 !== imgSource[0] && ("pen trails" === imgSource[0] ? (canvas = stage.trailsCanvas, 
    costume = new Costume(canvas, data).copy()) : "stage image" === imgSource[0] && (canvas = stage.fullImageClassic(), 
    costume = new Costume(canvas, data)), this.addCostume(costume));
}, SpriteHighlightMorph.prototype = new Morph(), SpriteHighlightMorph.prototype.constructor = SpriteHighlightMorph, 
SpriteHighlightMorph.uber = Morph.prototype;

function SpriteHighlightMorph() {
    this.init();
}

StageMorph.prototype = new FrameMorph(), StageMorph.prototype.constructor = StageMorph, 
StageMorph.uber = FrameMorph.prototype, StageMorph.prototype.dimensions = new Point(480, 360), 
StageMorph.prototype.frameRate = 0, StageMorph.prototype.isCachingPrimitives = SpriteMorph.prototype.isCachingPrimitives, 
StageMorph.prototype.sliderColor = SpriteMorph.prototype.sliderColor, StageMorph.prototype.paletteTextColor = SpriteMorph.prototype.paletteTextColor, 
StageMorph.prototype.hiddenPrimitives = {}, StageMorph.prototype.codeMappings = {}, 
StageMorph.prototype.codeHeaders = {}, StageMorph.prototype.enableCodeMapping = !1;

function StageMorph(globals) {
    this.init(globals);
}

StageMorph.prototype.init = function(globals) {
    this.name = localize("Stage"), this.threads = new ThreadManager(), this.variables = new VariableFrame(globals || null, this), 
    this.scripts = new ScriptsMorph(this), this.customBlocks = [], this.globalBlocks = [], 
    this.costumes = new List(), this.costume = null, this.sounds = new List(), this.version = Date.now(), 
    this.isFastTracked = !1, this.cloneCount = 0, this.timerStart = Date.now(), this.tempo = 60, 
    this.lastMessage = "", this.watcherUpdateFrequency = 2, this.lastWatcherUpdate = Date.now(), 
    this.scale = 1, this.keysPressed = {}, this.blocksCache = {}, this.paletteCache = {}, 
    this.lastAnswer = "", this.activeSounds = [], this.trailsCanvas = null, this.isThreadSafe = !1, 
    this.graphicsValues = {
        negative: 0,
        fisheye: 0,
        whirl: 0,
        pixelate: 0,
        mosaic: 0,
        brightness: 0,
        color: 0,
        comic: 0,
        duplicate: 0,
        confetti: 0
    }, StageMorph.uber.init.call(this), this.acceptsDrops = !1, this.setColor(new Color(255, 255, 255)), 
    this.fps = this.frameRate;
}, StageMorph.prototype.setScale = function(number) {
    var relativePos, bubble, delta = number / this.scale, pos = this.position(), oldFlag = Morph.prototype.trackChanges, myself = this;
    1 !== delta && (Morph.prototype.trackChanges = !1, this.scale = number, this.setExtent(this.dimensions.multiplyBy(number)), 
    this.children.forEach(function(morph) {
        relativePos = morph.position().subtract(pos), morph.drawNew(), morph.setPosition(relativePos.multiplyBy(delta).add(pos), !0), 
        morph instanceof SpriteMorph ? (bubble = morph.talkBubble()) && (bubble.setScale(number), 
        morph.positionTalkBubble()) : morph instanceof StagePrompterMorph && (myself.scale < 1 ? morph.setWidth(myself.width() - 10) : morph.setWidth(myself.dimensions.x - 20), 
        morph.fixLayout(), morph.setCenter(myself.center()), morph.setBottom(myself.bottom()));
    }), Morph.prototype.trackChanges = oldFlag, this.changed());
}, StageMorph.prototype.drawNew = function() {
    var ctx;
    StageMorph.uber.drawNew.call(this), this.costume && ((ctx = this.image.getContext("2d")).scale(this.scale, this.scale), 
    ctx.drawImage(this.costume.contents, (this.width() / this.scale - this.costume.width()) / 2, (this.height() / this.scale - this.costume.height()) / 2), 
    this.image = this.applyGraphicsEffects(this.image));
}, StageMorph.prototype.drawOn = function(aCanvas, aRect) {
    var area, delta, src, context, w, h, sl, st, ws, hs;
    if (!this.isVisible) return null;
    if ((area = (aRect || this.bounds).intersect(this.bounds).round()).extent().gt(new Point(0, 0))) {
        if (delta = this.position().neg(), src = area.copy().translateBy(delta).round(), 
        (context = aCanvas.getContext("2d")).globalAlpha = this.alpha, sl = src.left(), 
        st = src.top(), w = Math.min(src.width(), this.image.width - sl), h = Math.min(src.height(), this.image.height - st), 
        w < 1 || h < 1) return null;
        context.drawImage(this.image, src.left(), src.top(), w, h, area.left(), area.top(), w, h), 
        ws = w / this.scale, hs = h / this.scale, context.save(), context.scale(this.scale, this.scale);
        try {
            context.drawImage(this.penTrails(), src.left() / this.scale, src.top() / this.scale, ws, hs, area.left() / this.scale, area.top() / this.scale, ws, hs);
        } catch (err) {
            context.restore(), context.drawImage(this.penTrails(), 0, 0, this.dimensions.x, this.dimensions.y, this.left(), this.top(), this.dimensions.x * this.scale, this.dimensions.y * this.scale);
        }
        context.restore();
    }
}, StageMorph.prototype.clearPenTrails = function() {
    this.trailsCanvas = newCanvas(this.dimensions), this.changed();
}, StageMorph.prototype.penTrails = function() {
    return this.trailsCanvas || (this.trailsCanvas = newCanvas(this.dimensions)), this.trailsCanvas;
}, StageMorph.prototype.penTrailsMorph = function() {
    var morph = new Morph(), trails = this.penTrails();
    return morph.bounds = this.bounds.copy(), morph.image = newCanvas(this.extent()), 
    morph.image.getContext("2d").drawImage(trails, 0, 0, trails.width, trails.height, 0, 0, this.image.width, this.image.height), 
    morph;
}, StageMorph.prototype.colorFiltered = function(aColor, excludedSprite) {
    var ctx, src, i, dta, morph = new Morph(), ext = this.extent();
    for (src = this.thumbnail(ext, excludedSprite).getContext("2d").getImageData(0, 0, ext.x, ext.y), 
    morph.bounds = this.bounds.copy(), morph.image = newCanvas(ext), dta = (ctx = morph.image.getContext("2d")).createImageData(ext.x, ext.y), 
    i = 0; i < ext.x * ext.y * 4; i += 4) new Color(src.data[i], src.data[i + 1], src.data[i + 2]).eq(aColor) && (dta.data[i] = src.data[i], 
    dta.data[i + 1] = src.data[i + 1], dta.data[i + 2] = src.data[i + 2], dta.data[i + 3] = 255);
    return ctx.putImageData(dta, 0, 0), morph;
}, StageMorph.prototype.watchers = function(leftPos) {
    return this.children.filter(function(morph) {
        return morph instanceof WatcherMorph && (leftPos ? morph.left() === leftPos : morph.isVisible);
    });
}, StageMorph.prototype.resetTimer = function() {
    this.timerStart = Date.now();
}, StageMorph.prototype.getTimer = function() {
    return Math.floor((Date.now() - this.timerStart) / 100) / 10;
}, StageMorph.prototype.setTempo = function(bpm) {
    this.tempo = Math.max(20, +bpm || 0);
}, StageMorph.prototype.changeTempo = function(delta) {
    this.setTempo(this.getTempo() + (+delta || 0));
}, StageMorph.prototype.getTempo = function() {
    return +this.tempo;
}, StageMorph.prototype.getLastMessage = function() {
    return this.lastMessage || "";
}, StageMorph.prototype.reportMouseX = function() {
    var world = this.world();
    return world ? (world.hand.position().x - this.center().x) / this.scale : 0;
}, StageMorph.prototype.reportMouseY = function() {
    var world = this.world();
    return world ? (this.center().y - world.hand.position().y) / this.scale : 0;
}, StageMorph.prototype.wantsDropOf = function(aMorph) {
    return aMorph instanceof SpriteMorph || aMorph instanceof WatcherMorph || aMorph instanceof ListWatcherMorph || aMorph instanceof SpriteIconMorph;
}, StageMorph.prototype.reactToDropOf = function(morph, hand) {
    morph instanceof SpriteIconMorph && (morph.object.anchor && morph.object.anchor.detachPart(morph.object), 
    this.world().add(morph), morph.slideBackTo(hand.grabOrigin));
}, StageMorph.prototype.step = function() {
    var elapsed, world = this.world();
    if (null === world.keyboardReceiver && (world.keyboardReceiver = this), null === world.currentKey && (this.keyPressed = null), 
    this.isFastTracked && this.threads.processes.length) {
        for (this.children.forEach(function(morph) {
            morph instanceof SpriteMorph && (morph.wasWarped = morph.isWarped, morph.isWarped || morph.startWarp());
        }); Date.now() - this.lastTime < 100; ) this.threads.step();
        this.children.forEach(function(morph) {
            morph instanceof SpriteMorph && (morph.wasWarped || morph.endWarp());
        }), this.changed();
    } else this.threads.step();
    elapsed = Date.now() - this.lastWatcherUpdate, 1e3 / this.watcherUpdateFrequency - elapsed < 1 && (this.watchers().forEach(function(w) {
        w.update();
    }), this.lastWatcherUpdate = Date.now());
}, StageMorph.prototype.developersMenu = function() {
    var myself = this, menu = StageMorph.uber.developersMenu.call(this);
    return menu.addItem("stop", function() {
        myself.threads.stopAll();
    }, "terminate all running threads"), menu;
}, StageMorph.prototype.processKeyDown = function(event) {
    this.processKeyEvent(event, this.fireKeyEvent);
}, StageMorph.prototype.processKeyUp = function(event) {
    this.processKeyEvent(event, this.removePressedKey);
}, StageMorph.prototype.processKeyEvent = function(event, action) {
    var keyName;
    switch (event.keyCode) {
      case 13:
        keyName = "enter", (event.ctrlKey || event.metaKey) && (keyName = "ctrl enter");
        break;

      case 27:
        keyName = "esc";
        break;

      case 32:
        keyName = "space";
        break;

      case 37:
        keyName = "left arrow";
        break;

      case 39:
        keyName = "right arrow";
        break;

      case 38:
        keyName = "up arrow";
        break;

      case 40:
        keyName = "down arrow";
        break;

      default:
        keyName = String.fromCharCode(event.keyCode || event.charCode), (event.ctrlKey || event.metaKey) && (keyName = "ctrl " + (event.shiftKey ? "shift " : "") + keyName);
    }
    action.call(this, keyName);
}, StageMorph.prototype.fireKeyEvent = function(key) {
    var evt = key.toLowerCase(), hats = [], procs = [], ide = this.parentThatIsA(IDE_Morph), myself = this;
    if (this.keysPressed[evt] = !0, "ctrl enter" === evt) return this.fireGreenFlagEvent();
    if ("ctrl f" !== evt) if ("ctrl n" !== evt) if ("ctrl o" !== evt) if ("ctrl s" !== evt) {
        if ("ctrl shift s" !== evt) return "esc" === evt ? this.fireStopAllEvent() : (this.children.concat(this).forEach(function(morph) {
            (morph instanceof SpriteMorph || morph instanceof StageMorph) && (hats = hats.concat(morph.allHatBlocksForKey(evt)));
        }), hats.forEach(function(block) {
            procs.push(myself.threads.startProcess(block, myself.isThreadSafe));
        }), procs);
        if (!ide.isAppMode) return ide.saveProjectsBrowser();
    } else ide.isAppMode || ide.save(); else ide.isAppMode || ide.openProjectsBrowser(); else ide.isAppMode || ide.createNewProject(); else ide.isAppMode || ide.currentSprite.searchBlocks();
}, StageMorph.prototype.removePressedKey = function(key) {
    delete this.keysPressed[key.toLowerCase()];
}, StageMorph.prototype.processKeyPress = function(event) {
    nop(event);
}, StageMorph.prototype.inspectKeyEvent = CursorMorph.prototype.inspectKeyEvent, 
StageMorph.prototype.fireGreenFlagEvent = function() {
    var procs = [], hats = [], ide = this.parentThatIsA(IDE_Morph), myself = this;
    return this.children.concat(this).forEach(function(morph) {
        (morph instanceof SpriteMorph || morph instanceof StageMorph) && (hats = hats.concat(morph.allHatBlocksFor("__shout__go__")));
    }), hats.forEach(function(block) {
        procs.push(myself.threads.startProcess(block, myself.isThreadSafe));
    }), ide && ide.controlBar.pauseButton.refresh(), procs;
}, StageMorph.prototype.fireStopAllEvent = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    this.threads.resumeAll(this.stage), this.keysPressed = {}, this.threads.stopAll(), 
    this.stopAllActiveSounds(), this.children.forEach(function(morph) {
        morph.stopTalking && morph.stopTalking();
    }), this.removeAllClones(), ide && ide.nextSteps([ nop, function() {
        ide.controlBar.pauseButton.refresh();
    } ]);
}, StageMorph.prototype.removeAllClones = function() {
    var myself = this;
    this.children.filter(function(morph) {
        return morph.isClone;
    }).forEach(function(clone) {
        myself.threads.stopAllForReceiver(clone), clone.destroy();
    }), this.cloneCount = 0;
}, StageMorph.prototype.blockTemplates = function(category) {
    var varNames, button, txt, blocks = [], myself = this, cat = category || "motion";
    function block(selector) {
        if (myself.hiddenPrimitives[selector]) return null;
        var newBlock = SpriteMorph.prototype.blockForSelector(selector, !0);
        return newBlock.isTemplate = !0, newBlock;
    }
    function watcherToggle(selector) {
        if (myself.hiddenPrimitives[selector]) return null;
        var info = SpriteMorph.prototype.blocks[selector];
        return new ToggleMorph("checkbox", this, function() {
            myself.toggleWatcher(selector, localize(info.spec), myself.blockColor[info.category]);
        }, null, function() {
            return myself.showingWatcher(selector);
        }, null);
    }
    function addVar(pair) {
        pair && (myself.variables.silentFind(pair[0]) ? myself.inform("that name is already in use") : (myself.addVariable(pair[0], pair[1]), 
        myself.toggleVariableWatcher(pair[0], pair[1]), myself.blocksCache[cat] = null, 
        myself.paletteCache[cat] = null, myself.parentThatIsA(IDE_Morph).refreshPalette()));
    }
    return "motion" === cat ? ((txt = new TextMorph(localize("Stage selected:\nno motion primitives"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt)) : "looks" === cat ? (blocks.push(block("doSwitchToCostume")), 
    blocks.push(block("doWearNextCostume")), blocks.push(watcherToggle("getCostumeIdx")), 
    blocks.push(block("getCostumeIdx")), blocks.push("-"), blocks.push(block("changeEffect")), 
    blocks.push(block("setEffect")), blocks.push(block("clearEffects")), blocks.push("-"), 
    blocks.push(block("show")), blocks.push(block("hide")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportCostumes")), 
    blocks.push("-"), blocks.push(block("log")), blocks.push(block("alert")), blocks.push("-"), 
    blocks.push(block("doScreenshot")))) : "sound" === cat ? (blocks.push(block("playSound")), 
    blocks.push(block("doPlaySoundUntilDone")), blocks.push(block("doStopAllSounds")), 
    blocks.push("-"), blocks.push(block("doRest")), blocks.push("-"), blocks.push(block("doPlayNote")), 
    blocks.push("-"), blocks.push(block("doChangeTempo")), blocks.push(block("doSetTempo")), 
    blocks.push(watcherToggle("getTempo")), blocks.push(block("getTempo")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportSounds")))) : "pen" === cat ? blocks.push(block("clear")) : "control" === cat ? (blocks.push(block("receiveGo")), 
    blocks.push(block("receiveKey")), blocks.push(block("receiveClick")), blocks.push(block("receiveMessage")), 
    blocks.push("-"), blocks.push(block("doBroadcast")), blocks.push(block("doBroadcastAndWait")), 
    blocks.push(watcherToggle("getLastMessage")), blocks.push(block("getLastMessage")), 
    blocks.push("-"), blocks.push(block("doWait")), blocks.push(block("doWaitUntil")), 
    blocks.push("-"), blocks.push(block("doForever")), blocks.push(block("doRepeat")), 
    blocks.push(block("doUntil")), blocks.push("-"), blocks.push(block("doIf")), blocks.push(block("doIfElse")), 
    blocks.push("-"), blocks.push(block("doStopThis")), blocks.push(block("doStopOthers")), 
    blocks.push("-"), blocks.push(block("createClone")), blocks.push("-"), blocks.push(block("doPauseAll"))) : "sensing" === cat ? (blocks.push(block("doAsk")), 
    blocks.push(watcherToggle("getLastAnswer")), blocks.push(block("getLastAnswer")), 
    blocks.push("-"), blocks.push(watcherToggle("reportMouseX")), blocks.push(block("reportMouseX")), 
    blocks.push(watcherToggle("reportMouseY")), blocks.push(block("reportMouseY")), 
    blocks.push(block("reportMouseDown")), blocks.push("-"), blocks.push(block("reportKeyPressed")), 
    blocks.push("-"), blocks.push(block("doResetTimer")), blocks.push(watcherToggle("getTimer")), 
    blocks.push(block("getTimer")), blocks.push("-"), blocks.push(block("reportAttributeOf")), 
    blocks.push("-"), blocks.push(block("reportURL")), blocks.push("-"), blocks.push(block("reportIsFastTracking")), 
    blocks.push(block("doSetFastTracking")), blocks.push("-"), blocks.push(block("reportDate")), 
    this.world().isDevMode && (blocks.push("-"), (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(watcherToggle("reportThreadCount")), 
    blocks.push(block("reportThreadCount")), blocks.push(block("colorFiltered")), blocks.push(block("reportStackSize")), 
    blocks.push(block("reportFrameCount")))) : "operators" === cat ? (blocks.push(block("reifyScript")), 
    blocks.push(block("reifyReporter")), blocks.push(block("reifyPredicate")), blocks.push("#"), 
    blocks.push("-"), blocks.push(block("reportSum")), blocks.push(block("reportDifference")), 
    blocks.push(block("reportProduct")), blocks.push(block("reportQuotient")), blocks.push("-"), 
    blocks.push(block("reportModulus")), blocks.push(block("reportRound")), blocks.push(block("reportMonadic")), 
    blocks.push(block("reportRandom")), blocks.push("-"), blocks.push(block("reportLessThan")), 
    blocks.push(block("reportEquals")), blocks.push(block("reportGreaterThan")), blocks.push("-"), 
    blocks.push(block("reportAnd")), blocks.push(block("reportOr")), blocks.push(block("reportNot")), 
    blocks.push("-"), blocks.push(block("reportTrue")), blocks.push(block("reportFalse")), 
    blocks.push("-"), blocks.push(block("reportJoinWords")), blocks.push(block("reportTextSplit")), 
    blocks.push(block("reportLetter")), blocks.push(block("reportStringSize")), blocks.push("-"), 
    blocks.push(block("reportIsA")), blocks.push(block("reportIsIdentical")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph("development mode \ndebugging primitives:")).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportTypeOf")), 
    blocks.push(block("reportTextFunction")))) : "variables" === cat ? (button = new PushButtonMorph(null, function() {
        new VariableDialogMorph(null, addVar, myself).prompt("Variable name", null, myself.world());
    }, "Make a variable"), blocks.push(button), this.variables.allNames().length > 0 && (button = new PushButtonMorph(null, function() {
        var menu = new MenuMorph(myself.deleteVariable, null, myself);
        myself.variables.allNames().forEach(function(name) {
            menu.addItem(name, name);
        }), menu.popUpAtHand(myself.world());
    }, "Delete a variable"), blocks.push(button)), blocks.push("-"), (varNames = this.variables.allNames()).length > 0 && (varNames.forEach(function(name) {
        blocks.push(function(varName) {
            return new ToggleMorph("checkbox", this, function() {
                myself.toggleVariableWatcher(varName);
            }, null, function() {
                return myself.showingVariableWatcher(varName);
            }, null);
        }(name)), blocks.push(function(varName) {
            var newBlock = SpriteMorph.prototype.variableBlock(varName);
            return newBlock.isDraggable = !1, newBlock.isTemplate = !0, newBlock;
        }(name));
    }), blocks.push("-")), blocks.push(block("doSetVar")), blocks.push(block("doChangeVar")), 
    blocks.push(block("doShowVar")), blocks.push(block("doHideVar")), blocks.push(block("doDeclareVariables")), 
    blocks.push("="), blocks.push(block("reportNewList")), blocks.push("-"), blocks.push(block("reportCONS")), 
    blocks.push(block("reportListItem")), blocks.push(block("reportCDR")), blocks.push("-"), 
    blocks.push(block("reportListLength")), blocks.push(block("reportListContainsItem")), 
    blocks.push("-"), blocks.push(block("doAddToList")), blocks.push(block("doDeleteFromList")), 
    blocks.push(block("doInsertInList")), blocks.push(block("doReplaceInList")), this.world().isDevMode && (blocks.push("-"), 
    (txt = new TextMorph(localize("development mode \ndebugging primitives:"))).fontSize = 9, 
    txt.setColor(this.paletteTextColor), blocks.push(txt), blocks.push("-"), blocks.push(block("reportMap")), 
    blocks.push("-"), blocks.push(block("doForEach"))), blocks.push("="), StageMorph.prototype.enableCodeMapping && (blocks.push(block("doMapCodeOrHeader")), 
    blocks.push(block("doMapStringCode")), blocks.push(block("doMapListCode")), blocks.push("-"), 
    blocks.push(block("reportMappedCode")), blocks.push("=")), button = new PushButtonMorph(null, function() {
        var ide = myself.parentThatIsA(IDE_Morph);
        new BlockDialogMorph(null, function(definition) {
            "" !== definition.spec && (definition.isGlobal ? myself.globalBlocks.push(definition) : myself.customBlocks.push(definition), 
            ide.flushPaletteCache(), ide.refreshPalette(), new BlockEditorMorph(definition, myself).popUp());
        }, myself).prompt("Make a block", null, myself.world());
    }, "Make a block"), blocks.push(button)) : "mearm" === cat && (blocks.push(block("mearmOpenGrip")), 
    blocks.push(block("mearmCloseGrip")), blocks.push(block("mearmMoveBaseTo")), blocks.push(block("mearmMoveLowerTo")), 
    blocks.push(block("mearmMoveUpperTo")), blocks.push(block("mearmMoveGripTo")), blocks.push(block("mearmStop"))), 
    blocks;
}, StageMorph.prototype.clear = function() {
    this.clearPenTrails();
}, StageMorph.prototype.userMenu = function() {
    var ide = this.parentThatIsA(IDE_Morph), menu = new MenuMorph(this), shiftClicked = 16 === this.world().currentKey, myself = this;
    return ide && ide.isAppMode ? menu : (menu.addItem("edit", "edit"), menu.addItem("show all", "showAll"), 
    menu.addItem("pic...", function() {
        window.open(myself.fullImageClassic().toDataURL());
    }, "open a new window\nwith a picture of the stage"), shiftClicked && (menu.addLine(), 
    menu.addItem("turn pen trails into new costume...", function() {
        var costume = new Costume(myself.trailsCanvas, Date.now().toString()).copy();
        ide.currentSprite.addCostume(costume), ide.currentSprite.wearCostume(costume), ide.hasChangedMedia = !0;
    }, "turn all pen trails and stamps\ninto a new costume for the\ncurrently selected sprite", new Color(100, 0, 0))), 
    menu);
}, StageMorph.prototype.showAll = function() {
    var myself = this;
    this.children.forEach(function(m) {
        m.show(), m.keepWithin(myself), m.fixLayout && m.fixLayout();
    });
}, StageMorph.prototype.edit = SpriteMorph.prototype.edit, StageMorph.prototype.thumbnail = function(extentPoint, excludedSprite) {
    var fb, fimg, myself = this, src = this.image, scale = Math.min(extentPoint.x / src.width, extentPoint.y / src.height), trg = newCanvas(extentPoint), ctx = trg.getContext("2d");
    return ctx.scale(scale, scale), ctx.drawImage(src, 0, 0), ctx.drawImage(this.penTrails(), 0, 0, this.dimensions.x * this.scale, this.dimensions.y * this.scale), 
    this.children.forEach(function(morph) {
        morph.isVisible && morph !== excludedSprite && (fb = morph.fullBounds(), (fimg = morph.fullImage()).width && fimg.height && ctx.drawImage(morph.fullImage(), fb.origin.x - myself.bounds.origin.x, fb.origin.y - myself.bounds.origin.y));
    }), trg;
}, StageMorph.prototype.hide = function() {
    this.isVisible = !1, this.changed();
}, StageMorph.prototype.show = function() {
    this.isVisible = !0, this.changed();
}, StageMorph.prototype.createClone = nop, StageMorph.prototype.categories = SpriteMorph.prototype.categories, 
StageMorph.prototype.blockColor = SpriteMorph.prototype.blockColor, StageMorph.prototype.paletteColor = SpriteMorph.prototype.paletteColor, 
StageMorph.prototype.setName = SpriteMorph.prototype.setName, StageMorph.prototype.palette = SpriteMorph.prototype.palette, 
StageMorph.prototype.freshPalette = SpriteMorph.prototype.freshPalette, StageMorph.prototype.blocksMatching = SpriteMorph.prototype.blocksMatching, 
StageMorph.prototype.searchBlocks = SpriteMorph.prototype.searchBlocks, StageMorph.prototype.showingWatcher = SpriteMorph.prototype.showingWatcher, 
StageMorph.prototype.addVariable = SpriteMorph.prototype.addVariable, StageMorph.prototype.deleteVariable = SpriteMorph.prototype.deleteVariable, 
StageMorph.prototype.doScreenshot = SpriteMorph.prototype.doScreenshot, StageMorph.prototype.newCostumeName = SpriteMorph.prototype.newCostumeName, 
StageMorph.prototype.blockForSelector = SpriteMorph.prototype.blockForSelector, 
StageMorph.prototype.findVariableWatcher = SpriteMorph.prototype.findVariableWatcher, 
StageMorph.prototype.toggleVariableWatcher = SpriteMorph.prototype.toggleVariableWatcher, 
StageMorph.prototype.showingVariableWatcher = SpriteMorph.prototype.showingVariableWatcher, 
StageMorph.prototype.deleteVariableWatcher = SpriteMorph.prototype.deleteVariableWatcher, 
StageMorph.prototype.addCostume = SpriteMorph.prototype.addCostume, StageMorph.prototype.wearCostume = SpriteMorph.prototype.wearCostume, 
StageMorph.prototype.getCostumeIdx = SpriteMorph.prototype.getCostumeIdx, StageMorph.prototype.doWearNextCostume = SpriteMorph.prototype.doWearNextCostume, 
StageMorph.prototype.doWearPreviousCostume = SpriteMorph.prototype.doWearPreviousCostume, 
StageMorph.prototype.doSwitchToCostume = SpriteMorph.prototype.doSwitchToCostume, 
StageMorph.prototype.reportCostumes = SpriteMorph.prototype.reportCostumes, StageMorph.prototype.graphicsChanged = SpriteMorph.prototype.graphicsChanged, 
StageMorph.prototype.applyGraphicsEffects = SpriteMorph.prototype.applyGraphicsEffects, 
StageMorph.prototype.setEffect = SpriteMorph.prototype.setEffect, StageMorph.prototype.getGhostEffect = SpriteMorph.prototype.getGhostEffect, 
StageMorph.prototype.changeEffect = SpriteMorph.prototype.changeEffect, StageMorph.prototype.clearEffects = SpriteMorph.prototype.clearEffects, 
StageMorph.prototype.addSound = SpriteMorph.prototype.addSound, StageMorph.prototype.playSound = SpriteMorph.prototype.playSound, 
StageMorph.prototype.stopAllActiveSounds = function() {
    this.activeSounds.forEach(function(audio) {
        audio.pause();
    }), this.activeSounds = [];
}, StageMorph.prototype.pauseAllActiveSounds = function() {
    this.activeSounds.forEach(function(audio) {
        audio.pause();
    });
}, StageMorph.prototype.resumeAllActiveSounds = function() {
    this.activeSounds.forEach(function(audio) {
        audio.play();
    });
}, StageMorph.prototype.reportSounds = SpriteMorph.prototype.reportSounds, StageMorph.prototype.toggleWatcher = SpriteMorph.prototype.toggleWatcher, 
StageMorph.prototype.showingWatcher = SpriteMorph.prototype.showingWatcher, StageMorph.prototype.watcherFor = SpriteMorph.prototype.watcherFor, 
StageMorph.prototype.getLastAnswer = SpriteMorph.prototype.getLastAnswer, StageMorph.prototype.reportThreadCount = SpriteMorph.prototype.reportThreadCount, 
StageMorph.prototype.allMessageNames = SpriteMorph.prototype.allMessageNames, StageMorph.prototype.allHatBlocksFor = SpriteMorph.prototype.allHatBlocksFor, 
StageMorph.prototype.allHatBlocksForKey = SpriteMorph.prototype.allHatBlocksForKey, 
StageMorph.prototype.mouseClickLeft = SpriteMorph.prototype.mouseClickLeft, StageMorph.prototype.deleteAllBlockInstances = SpriteMorph.prototype.deleteAllBlockInstances, 
StageMorph.prototype.allBlockInstances = SpriteMorph.prototype.allBlockInstances, 
StageMorph.prototype.allLocalBlockInstances = SpriteMorph.prototype.allLocalBlockInstances, 
StageMorph.prototype.allEditorBlockInstances = SpriteMorph.prototype.allEditorBlockInstances, 
StageMorph.prototype.paletteBlockInstance = SpriteMorph.prototype.paletteBlockInstance, 
StageMorph.prototype.usesBlockInstance = SpriteMorph.prototype.usesBlockInstance, 
StageMorph.prototype.doubleDefinitionsFor = SpriteMorph.prototype.doubleDefinitionsFor, 
StageMorph.prototype.replaceDoubleDefinitionsFor = SpriteMorph.prototype.replaceDoubleDefinitionsFor, 
SpriteBubbleMorph.prototype = new SpeechBubbleMorph(), SpriteBubbleMorph.prototype.constructor = SpriteBubbleMorph, 
SpriteBubbleMorph.uber = SpeechBubbleMorph.prototype;

function SpriteBubbleMorph(data, scale, isThought, isQuestion) {
    this.init(data, scale, isThought, isQuestion);
}

SpriteBubbleMorph.prototype.init = function(data, scale, isThought, isQuestion) {
    var sprite = SpriteMorph.prototype;
    this.scale = scale || 1, this.data = data, this.isQuestion = isQuestion, SpriteBubbleMorph.uber.init.call(this, this.dataAsMorph(data), sprite.bubbleColor, null, null, isQuestion ? sprite.blockColor.sensing : sprite.bubbleBorderColor, null, isThought);
}, SpriteBubbleMorph.prototype.dataAsMorph = function(data) {
    var contents, isText, img, scaledImg, width, sprite = SpriteMorph.prototype;
    return data instanceof Morph ? contents = data : isString(data) ? (isText = !0, 
    contents = new TextMorph(data, sprite.bubbleFontSize * this.scale, null, sprite.bubbleFontIsBold, !1, "center")) : "boolean" == typeof data ? (img = sprite.booleanMorph(data).fullImage(), 
    (contents = new Morph()).silentSetWidth(img.width), contents.silentSetHeight(img.height), 
    contents.image = img) : data instanceof Costume ? (img = data.thumbnail(new Point(40, 40)), 
    (contents = new Morph()).silentSetWidth(img.width), contents.silentSetHeight(img.height), 
    contents.image = img) : data instanceof HTMLCanvasElement ? ((contents = new Morph()).silentSetWidth(data.width), 
    contents.silentSetHeight(data.height), contents.image = data) : data instanceof List ? ((contents = new ListWatcherMorph(data)).isDraggable = !1, 
    contents.update(!0), contents.step = contents.update) : data instanceof Context ? (img = data.image(), 
    (contents = new Morph()).silentSetWidth(img.width), contents.silentSetHeight(img.height), 
    contents.image = img) : contents = new TextMorph(data.toString(), sprite.bubbleFontSize * this.scale, null, sprite.bubbleFontIsBold, !1, "center"), 
    contents instanceof TextMorph ? (width = Math.max(contents.width(), 2 * sprite.bubbleCorner * this.scale), 
    isText && (width = Math.min(width, sprite.bubbleMaxTextWidth * this.scale)), contents.setWidth(width)) : data instanceof List || ((scaledImg = newCanvas(contents.extent().multiplyBy(this.scale))).getContext("2d").drawImage(contents.image, 0, 0, scaledImg.width, scaledImg.height), 
    contents.image = scaledImg, contents.bounds = contents.bounds.scaleBy(this.scale)), 
    contents;
}, SpriteBubbleMorph.prototype.setScale = function(scale) {
    this.scale = scale, this.changed(), this.drawNew(), this.changed();
}, SpriteBubbleMorph.prototype.drawNew = function() {
    var sprite = SpriteMorph.prototype;
    this.edge = sprite.bubbleCorner * this.scale, this.border = sprite.bubbleBorder * this.scale, 
    this.padding = sprite.bubbleCorner / 2 * this.scale, this.contentsMorph && this.contentsMorph.destroy(), 
    this.contentsMorph = this.dataAsMorph(this.data), this.add(this.contentsMorph), 
    this.silentSetWidth(this.contentsMorph.width() + (this.padding ? 2 * this.padding : 2 * this.edge)), 
    this.silentSetHeight(this.contentsMorph.height() + this.edge + 2 * this.border + 2 * this.padding + 2), 
    SpeechBubbleMorph.uber.drawNew.call(this), this.contentsMorph.setPosition(this.position().add(new Point(this.padding || this.edge, this.border + this.padding + 1)));
}, SpriteBubbleMorph.prototype.fixLayout = function() {
    var sprite = SpriteMorph.prototype;
    this.changed(), this.edge = sprite.bubbleCorner * this.scale, this.border = sprite.bubbleBorder * this.scale, 
    this.padding = sprite.bubbleCorner / 2 * this.scale, this.silentSetWidth(this.contentsMorph.width() + (this.padding ? 2 * this.padding : 2 * this.edge)), 
    this.silentSetHeight(this.contentsMorph.height() + this.edge + 2 * this.border + 2 * this.padding + 2), 
    SpeechBubbleMorph.uber.drawNew.call(this), this.contentsMorph.setPosition(this.position().add(new Point(this.padding || this.edge, this.border + this.padding + 1))), 
    this.changed();
};

function Costume(canvas, name, rotationCenter) {
    this.contents = canvas || newCanvas(), this.shrinkToFit(this.maxExtent()), this.name = name || null, 
    this.rotationCenter = rotationCenter || this.center(), this.version = Date.now(), 
    this.loaded = null;
}

Costume.prototype.maxExtent = function() {
    return StageMorph.prototype.dimensions;
}, Costume.prototype.toString = function() {
    return "a Costume(" + this.name + ")";
}, Costume.prototype.extent = function() {
    return new Point(this.contents.width, this.contents.height);
}, Costume.prototype.center = function() {
    return this.extent().divideBy(2);
}, Costume.prototype.width = function() {
    return this.contents.width;
}, Costume.prototype.height = function() {
    return this.contents.height;
}, Costume.prototype.bounds = function() {
    return new Rectangle(0, 0, this.width(), this.height());
}, Costume.prototype.shrinkWrap = function() {
    var bb = this.boundingBox(), ext = bb.extent(), pic = newCanvas(ext);
    pic.getContext("2d").drawImage(this.contents, bb.origin.x, bb.origin.y, ext.x, ext.y, 0, 0, ext.x, ext.y), 
    this.rotationCenter = this.rotationCenter.subtract(bb.origin), this.contents = pic, 
    this.version = Date.now();
}, Costume.prototype.boundingBox = function() {
    var row, col, pic = this.contents, w = pic.width, h = pic.height, dta = pic.getContext("2d").getImageData(0, 0, w, h);
    function getAlpha(x, y) {
        return dta.data[y * w * 4 + 4 * x + 3];
    }
    return new Rectangle(function() {
        for (col = 0; col <= w; col += 1) for (row = 0; row <= h; row += 1) if (getAlpha(col, row)) return col;
        return 0;
    }(), function() {
        for (row = 0; row <= h; row += 1) for (col = 0; col <= h; col += 1) if (getAlpha(col, row)) return row;
        return 0;
    }(), function() {
        for (col = w; col >= 0; col -= 1) for (row = h; row >= 0; row -= 1) if (getAlpha(col, row)) return Math.min(col + 1, w);
        return w;
    }(), function() {
        for (row = h; row >= 0; row -= 1) for (col = w; col >= 0; col -= 1) if (getAlpha(col, row)) return Math.min(row + 1, h);
        return h;
    }());
}, Costume.prototype.copy = function() {
    var cpy, canvas = newCanvas(this.extent());
    return canvas.getContext("2d").drawImage(this.contents, 0, 0), (cpy = new Costume(canvas, this.name ? copy(this.name) : null)).rotationCenter = this.rotationCenter.copy(), 
    cpy;
}, Costume.prototype.flipped = function() {
    var canvas = newCanvas(this.extent()), ctx = canvas.getContext("2d");
    return ctx.translate(this.width(), 0), ctx.scale(-1, 1), ctx.drawImage(this.contents, 0, 0), 
    new Costume(canvas, new Point(this.width() - this.rotationCenter.x, this.rotationCenter.y));
}, Costume.prototype.edit = function(aWorld, anIDE, isnew, oncancel, onsubmit) {
    var myself = this, editor = new PaintEditorMorph();
    editor.oncancel = oncancel || nop, editor.openIn(aWorld, isnew ? newCanvas(StageMorph.prototype.dimensions) : this.contents, isnew ? new Point(240, 180) : this.rotationCenter, function(img, rc) {
        myself.contents = img, myself.rotationCenter = rc, anIDE.currentSprite instanceof SpriteMorph && myself.shrinkWrap(), 
        myself.version = Date.now(), aWorld.changed(), anIDE && (anIDE.currentSprite.wearCostume(myself), 
        anIDE.hasChangedMedia = !0), (onsubmit || nop)();
    });
}, Costume.prototype.editRotationPointOnly = function(aWorld) {
    var dialog, txt, editor = new CostumeEditorMorph(this);
    dialog = new DialogBoxMorph(this, function() {
        editor.accept();
    }), txt = new TextMorph(localize("click or drag crosshairs to move the rotation center"), dialog.fontSize, dialog.fontStyle, !0, !1, "center", null, null, new Point(1, 1), new Color(255, 255, 255)), 
    dialog.labelString = "Costume Editor", dialog.createLabel(), dialog.setPicture(editor), 
    dialog.addBody(txt), dialog.addButton("ok", "Ok"), dialog.addButton("cancel", "Cancel"), 
    dialog.fixLayout(), dialog.drawNew(), dialog.fixLayout(), dialog.popUp(aWorld);
}, Costume.prototype.shrinkToFit = function(extentPoint) {
    (extentPoint.x < this.width() || extentPoint.y < this.height()) && (this.contents = this.thumbnail(extentPoint));
}, Costume.prototype.thumbnail = function(extentPoint) {
    var src = this.contents, scale = Math.min(extentPoint.x / src.width, extentPoint.y / src.height), xOffset = (extentPoint.x - src.width * scale) / 2, yOffset = (extentPoint.y - src.height * scale) / 2, trg = newCanvas(extentPoint), ctx = trg.getContext("2d");
    return src && src.width + src.height !== 0 ? (ctx.scale(scale, scale), ctx.drawImage(src, Math.floor(xOffset / scale), Math.floor(yOffset / scale)), 
    trg) : trg;
}, Costume.prototype.isTainted = function() {
    try {
        this.contents.getContext("2d").getImageData(0, 0, this.contents.width, this.contents.height);
    } catch (err) {
        return !0;
    }
    return !1;
}, SVG_Costume.prototype = new Costume(), SVG_Costume.prototype.constructor = SVG_Costume, 
SVG_Costume.uber = Costume.prototype;

function SVG_Costume(svgImage, name, rotationCenter) {
    this.contents = svgImage, this.shrinkToFit(this.maxExtent()), this.name = name || null, 
    this.rotationCenter = rotationCenter || this.center(), this.version = Date.now(), 
    this.loaded = null;
}

SVG_Costume.prototype.toString = function() {
    return "an SVG_Costume(" + this.name + ")";
}, SVG_Costume.prototype.copy = function() {
    var cpy, img = new Image();
    return img.src = this.contents.src, (cpy = new SVG_Costume(img, this.name ? copy(this.name) : null)).rotationCenter = this.rotationCenter.copy(), 
    cpy;
}, SVG_Costume.prototype.shrinkToFit = function(extentPoint) {
    nop(extentPoint);
}, CostumeEditorMorph.prototype = new Morph(), CostumeEditorMorph.prototype.constructor = CostumeEditorMorph, 
CostumeEditorMorph.uber = Morph.prototype, CostumeEditorMorph.prototype.size = Costume.prototype.maxExtent();

function CostumeEditorMorph(costume) {
    this.init(costume);
}

CostumeEditorMorph.prototype.init = function(costume) {
    this.costume = costume || new Costume(), this.rotationCenter = this.costume.rotationCenter.copy(), 
    this.margin = new Point(0, 0), CostumeEditorMorph.uber.init.call(this), this.noticesTransparentClick = !0;
}, CostumeEditorMorph.prototype.accept = function() {
    this.costume.rotationCenter = this.rotationCenter.copy(), this.costume.version = Date.now();
}, CostumeEditorMorph.prototype.drawNew = function() {
    var rp, ctx;
    this.margin = this.size.subtract(this.costume.extent()).divideBy(2), rp = this.rotationCenter.add(this.margin), 
    this.silentSetExtent(this.size), this.image = newCanvas(this.extent()), this.cachedTexture || (this.cachedTexture = this.createTexture()), 
    this.drawCachedTexture(), (ctx = this.image.getContext("2d")).drawImage(this.costume.contents, this.margin.x, this.margin.y), 
    ctx.globalAlpha = .5, ctx.fillStyle = "white", ctx.beginPath(), ctx.arc(rp.x, rp.y, 20, radians(0), radians(360), !1), 
    ctx.closePath(), ctx.fill(), ctx.stroke(), ctx.beginPath(), ctx.arc(rp.x, rp.y, 10, radians(0), radians(360), !1), 
    ctx.stroke(), ctx.beginPath(), ctx.moveTo(0, rp.y), ctx.lineTo(this.costume.width() + 2 * this.margin.x, rp.y), 
    ctx.stroke(), ctx.beginPath(), ctx.moveTo(rp.x, 0), ctx.lineTo(rp.x, this.costume.height() + 2 * this.margin.y), 
    ctx.stroke();
}, CostumeEditorMorph.prototype.createTexture = function() {
    var texture = newCanvas(new Point(10, 10)), ctx = texture.getContext("2d"), grey = new Color(230, 230, 230);
    return ctx.fillStyle = "white", ctx.fillRect(0, 0, 10, 10), ctx.fillStyle = grey.toString(), 
    ctx.fillRect(0, 0, 5, 5), ctx.fillRect(5, 5, 5, 5), texture;
}, CostumeEditorMorph.prototype.mouseDownLeft = function(pos) {
    this.rotationCenter = pos.subtract(this.position().add(this.margin)), this.drawNew(), 
    this.changed();
}, CostumeEditorMorph.prototype.mouseMove = CostumeEditorMorph.prototype.mouseDownLeft;

function Sound(audio, name) {
    this.audio = audio, this.name = name || "Sound";
}

Sound.prototype.play = function() {
    var aud = document.createElement("audio");
    return aud.src = this.audio.src, aud.play(), aud;
}, Sound.prototype.copy = function() {
    var snd = document.createElement("audio");
    return snd.src = this.audio.src, new Sound(snd, this.name ? copy(this.name) : null);
}, Sound.prototype.toDataURL = function() {
    return this.audio.src;
};

function Note(pitch) {
    this.pitch = 0 === pitch ? 0 : pitch || 69, this.setupContext(), this.oscillator = null;
}

Note.prototype.audioContext = null, Note.prototype.gainNode = null, Note.prototype.setupContext = function() {
    if (!this.audioContext) {
        var AudioContext = function() {
            var ctx = window.AudioContext || window.mozAudioContext || window.msAudioContext || window.oAudioContext || window.webkitAudioContext;
            return ctx.prototype.hasOwnProperty("createGain") || (ctx.prototype.createGain = ctx.prototype.createGainNode), 
            ctx;
        }();
        if (!AudioContext) throw new Error("Web Audio API is not supported\nin this browser");
        Note.prototype.audioContext = new AudioContext(), Note.prototype.gainNode = Note.prototype.audioContext.createGain(), 
        Note.prototype.gainNode.gain.value = .25;
    }
}, Note.prototype.play = function() {
    this.oscillator = this.audioContext.createOscillator(), this.oscillator.start || (this.oscillator.start = this.oscillator.noteOn), 
    this.oscillator.stop || (this.oscillator.stop = this.oscillator.noteOff), this.oscillator.type = 0, 
    this.oscillator.frequency.value = 440 * Math.pow(2, (this.pitch - 69) / 12), this.oscillator.connect(this.gainNode), 
    this.gainNode.connect(this.audioContext.destination), this.oscillator.start(0);
}, Note.prototype.stop = function() {
    this.oscillator && (this.oscillator.stop(0), this.oscillator = null);
}, CellMorph.prototype = new BoxMorph(), CellMorph.prototype.constructor = CellMorph, 
CellMorph.uber = BoxMorph.prototype;

function CellMorph(contents, color, idx, parentCell) {
    this.init(contents, color, idx, parentCell);
}

CellMorph.prototype.init = function(contents, color, idx, parentCell) {
    this.contents = 0 === contents ? 0 : !1 !== contents && (contents || ""), this.isEditable = !isNil(idx), 
    this.idx = idx || null, this.parentCell = parentCell || null, CellMorph.uber.init.call(this, SyntaxElementMorph.prototype.corner, 1.000001, new Color(255, 255, 255)), 
    this.color = color || new Color(255, 140, 0), this.isBig = !1, this.drawNew();
}, CellMorph.prototype.big = function() {
    this.isBig = !0, this.changed(), this.drawNew(), this.changed();
}, CellMorph.prototype.normal = function() {
    this.isBig = !1, this.changed(), this.drawNew(), this.changed();
}, CellMorph.prototype.isCircular = function(list) {
    return !!this.parentCell && (list instanceof List ? this.contents === list || this.parentCell.isCircular(list) : this.parentCell.isCircular(this.contents));
}, CellMorph.prototype.fixLayout = function() {
    var listwatcher;
    this.changed(), this.drawNew(), this.changed(), this.parent && this.parent.fixLayout ? this.parent.fixLayout() : (listwatcher = this.parentThatIsA(ListWatcherMorph)) && listwatcher.fixLayout();
}, CellMorph.prototype.drawNew = function() {
    var context, txt, img, fontSize = SyntaxElementMorph.prototype.fontSize, isSameList = this.contentsMorph instanceof ListWatcherMorph && this.contentsMorph.list === this.contents;
    if (this.isBig && (fontSize *= 1.5), this.contentsMorph && !isSameList && this.contentsMorph.destroy(), 
    isSameList || (this.contents instanceof Morph ? this.contentsMorph = this.contents : isString(this.contents) ? (txt = this.contents.length > 500 ? this.contents.slice(0, 500) + "..." : this.contents, 
    this.contentsMorph = new TextMorph(txt, fontSize, null, !0, !1, "left"), this.isEditable && (this.contentsMorph.isEditable = !0, 
    this.contentsMorph.enableSelecting()), this.contentsMorph.setColor(new Color(255, 255, 255))) : "boolean" == typeof this.contents ? (img = SpriteMorph.prototype.booleanMorph.call(null, this.contents).fullImage(), 
    this.contentsMorph = new Morph(), this.contentsMorph.silentSetWidth(img.width), 
    this.contentsMorph.silentSetHeight(img.height), this.contentsMorph.image = img) : this.contents instanceof HTMLCanvasElement ? (this.contentsMorph = new Morph(), 
    this.contentsMorph.silentSetWidth(this.contents.width), this.contentsMorph.silentSetHeight(this.contents.height), 
    this.contentsMorph.image = this.contents) : this.contents instanceof Context ? (img = this.contents.image(), 
    this.contentsMorph = new Morph(), this.contentsMorph.silentSetWidth(img.width), 
    this.contentsMorph.silentSetHeight(img.height), this.contentsMorph.image = img) : this.contents instanceof Costume ? (img = this.contents.thumbnail(new Point(40, 40)), 
    this.contentsMorph = new Morph(), this.contentsMorph.silentSetWidth(img.width), 
    this.contentsMorph.silentSetHeight(img.height), this.contentsMorph.image = img) : this.contents instanceof List ? this.isCircular() ? (this.contentsMorph = new TextMorph("(...)", fontSize, null, !1, !0, "center"), 
    this.contentsMorph.setColor(new Color(255, 255, 255))) : (this.contentsMorph = new ListWatcherMorph(this.contents, this), 
    this.contentsMorph.isDraggable = !1) : (this.contentsMorph = new TextMorph(isNil(this.contents) ? "" : this.contents.toString(), fontSize, null, !0, !1, "center"), 
    this.isEditable && (this.contentsMorph.isEditable = !0, this.contentsMorph.enableSelecting()), 
    this.contentsMorph.setColor(new Color(255, 255, 255))), this.add(this.contentsMorph)), 
    this.silentSetHeight(this.contentsMorph.height() + this.edge + 2 * this.border), 
    this.silentSetWidth(Math.max(this.contentsMorph.width() + 2 * this.edge, this.contents instanceof Context || this.contents instanceof List ? 0 : 3.5 * SyntaxElementMorph.prototype.fontSize)), 
    this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 0 === this.edge && 0 === this.border) return BoxMorph.uber.drawNew.call(this), 
    null;
    context.fillStyle = this.color.toString(), context.beginPath(), this.outlinePath(context, Math.max(this.edge - this.border, 0), this.border), 
    context.closePath(), context.fill(), this.border > 0 && !MorphicPreferences.isFlat && (context.lineWidth = this.border, 
    context.strokeStyle = this.borderColor.toString(), context.beginPath(), this.outlinePath(context, this.edge, this.border / 2), 
    context.closePath(), context.stroke(), context.shadowOffsetX = this.border, context.shadowOffsetY = this.border, 
    context.shadowBlur = this.border, context.shadowColor = this.color.darker(80).toString(), 
    this.drawShadow(context, this.edge, this.border / 2)), isSameList || this.contentsMorph.setCenter(this.center());
}, CellMorph.prototype.drawShadow = function(context, radius, inset) {
    var offset = radius + inset, w = this.width(), h = this.height();
    context.beginPath(), context.moveTo(0, h - offset), context.lineTo(0, offset), context.stroke(), 
    context.beginPath(), context.arc(offset, offset, radius, radians(-180), radians(-90), !1), 
    context.stroke(), context.beginPath(), context.moveTo(offset, 0), context.lineTo(w - offset, 0), 
    context.stroke();
}, CellMorph.prototype.layoutChanged = function() {
    SyntaxElementMorph.prototype.fontSize;
    var context, listWatcher = this.parentThatIsA(ListWatcherMorph);
    if (this.isBig && 1.5, this.silentSetHeight(this.contentsMorph.height() + this.edge + 2 * this.border), 
    this.silentSetWidth(Math.max(this.contentsMorph.width() + 2 * this.edge, this.contents instanceof Context || this.contents instanceof List ? 0 : 2 * this.height())), 
    this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), 0 === this.edge && 0 === this.border) return BoxMorph.uber.drawNew.call(this), 
    null;
    context.fillStyle = this.color.toString(), context.beginPath(), this.outlinePath(context, Math.max(this.edge - this.border, 0), this.border), 
    context.closePath(), context.fill(), this.border > 0 && !MorphicPreferences.isFlat && (context.lineWidth = this.border, 
    context.strokeStyle = this.borderColor.toString(), context.beginPath(), this.outlinePath(context, this.edge, this.border / 2), 
    context.closePath(), context.stroke(), context.shadowOffsetX = this.border, context.shadowOffsetY = this.border, 
    context.shadowBlur = this.border, context.shadowColor = this.color.darker(80).toString(), 
    this.drawShadow(context, this.edge, this.border / 2)), this.contentsMorph.setCenter(this.center()), 
    listWatcher && listWatcher.fixLayout();
}, CellMorph.prototype.reactToEdit = function(textMorph) {
    var listWatcher;
    isNil(this.idx) || (listWatcher = this.parentThatIsA(ListWatcherMorph)) && listWatcher.list.put(textMorph.text, this.idx);
}, CellMorph.prototype.mouseClickLeft = function(pos) {
    this.isEditable && this.contentsMorph instanceof TextMorph ? this.contentsMorph.selectAllAndEdit() : this.escalateEvent("mouseClickLeft", pos);
}, WatcherMorph.prototype = new BoxMorph(), WatcherMorph.prototype.constructor = WatcherMorph, 
WatcherMorph.uber = BoxMorph.prototype;

function WatcherMorph(label, color, target, getter, isHidden) {
    this.init(label, color, target, getter, isHidden);
}

WatcherMorph.prototype.init = function(label, color, target, getter, isHidden) {
    this.labelText = label || "", this.version = null, this.objName = "", WatcherMorph.uber.init.call(this, SyntaxElementMorph.prototype.rounding, 1.000001, new Color(120, 120, 120)), 
    this.color = new Color(220, 220, 220), this.readoutColor = color, this.style = "normal", 
    this.target = target || null, this.getter = getter || null, this.currentValue = null, 
    this.labelMorph = null, this.sliderMorph = null, this.cellMorph = null, this.isDraggable = !0, 
    this.fixLayout(), this.update(), isHidden && this.hide();
}, WatcherMorph.prototype.isTemporary = function() {
    var stage = this.parentThatIsA(StageMorph);
    return this.target instanceof VariableFrame && ((!stage || this.target !== stage.variables.parentFrame) && null === this.target.owner);
}, WatcherMorph.prototype.object = function() {
    return this.target instanceof VariableFrame ? this.target.owner : this.target;
}, WatcherMorph.prototype.isGlobal = function(selector) {
    return contains([ "getLastAnswer", "getLastMessage", "getTempo", "getTimer", "reportMouseX", "reportMouseY", "reportThreadCount" ], selector);
}, WatcherMorph.prototype.setSliderMin = function(num) {
    this.target instanceof VariableFrame && (this.sliderMorph.setSize(1), this.sliderMorph.setStart(num), 
    this.sliderMorph.setSize(this.sliderMorph.rangeSize() / 5));
}, WatcherMorph.prototype.setSliderMax = function(num) {
    this.target instanceof VariableFrame && (this.sliderMorph.setSize(1), this.sliderMorph.setStop(num), 
    this.sliderMorph.setSize(this.sliderMorph.rangeSize() / 5));
}, WatcherMorph.prototype.update = function() {
    var newValue;
    this.target && this.getter && (this.updateLabel(), "" === (newValue = this.target instanceof VariableFrame ? this.target.vars[this.getter] ? this.target.vars[this.getter].value : void 0 : this.target[this.getter]()) || isNil(newValue) || "boolean" == typeof newValue || isNaN(+newValue) || (newValue = Math.round(1e9 * newValue) / 1e9), 
    newValue !== this.currentValue && (this.changed(), this.cellMorph.contents = newValue, 
    this.cellMorph.drawNew(), isNaN(newValue) || (this.sliderMorph.value = newValue, 
    this.sliderMorph.drawNew()), this.fixLayout(), this.currentValue = newValue)), this.cellMorph.contentsMorph instanceof ListWatcherMorph && this.cellMorph.contentsMorph.update();
}, WatcherMorph.prototype.updateLabel = function() {
    var obj = this.object();
    obj && !this.isGlobal(this.getter) && obj.version !== this.version && (this.objName = obj.name ? obj.name + " " : " ", 
    this.labelMorph && (this.labelMorph.destroy(), this.labelMorph = null, this.fixLayout()));
}, WatcherMorph.prototype.fixLayout = function() {
    var isList, fontSize = SyntaxElementMorph.prototype.fontSize, myself = this;
    if (this.changed(), null === this.labelMorph && (this.labelMorph = new StringMorph(this.objName + this.labelText, fontSize, null, !0, !1, !1, MorphicPreferences.isFlat ? new Point() : new Point(1, 1), new Color(255, 255, 255)), 
    this.add(this.labelMorph)), null === this.cellMorph && (this.cellMorph = new CellMorph("", this.readoutColor), 
    this.add(this.cellMorph)), null === this.sliderMorph && (this.sliderMorph = new SliderMorph(0, 100, 0, 20, "horizontal"), 
    this.sliderMorph.alpha = 1, this.sliderMorph.button.color = this.color.darker(), 
    this.sliderMorph.color = this.color.lighter(60), this.sliderMorph.button.highlightColor = this.color.darker(), 
    this.sliderMorph.button.highlightColor.b += 50, this.sliderMorph.button.pressColor = this.color.darker(), 
    this.sliderMorph.button.pressColor.b += 100, this.sliderMorph.setHeight(fontSize), 
    this.sliderMorph.action = function(num) {
        myself.target.vars[myself.getter].value = Math.round(num);
    }, this.add(this.sliderMorph)), (isList = this.cellMorph.contents instanceof List) && (this.style = "normal"), 
    "large" === this.style) return this.labelMorph.hide(), this.sliderMorph.hide(), 
    this.cellMorph.big(), this.cellMorph.setPosition(this.position()), void this.setExtent(this.cellMorph.extent().subtract(1));
    this.labelMorph.show(), this.sliderMorph.show(), this.cellMorph.normal(), this.labelMorph.setPosition(this.position().add(new Point(this.edge, this.border + SyntaxElementMorph.prototype.typeInPadding))), 
    isList ? this.cellMorph.setPosition(this.labelMorph.bottomLeft().add(new Point(0, SyntaxElementMorph.prototype.typeInPadding))) : (this.cellMorph.setPosition(this.labelMorph.topRight().add(new Point(fontSize / 3, 0))), 
    this.labelMorph.setTop(this.cellMorph.top() + (this.cellMorph.height() - this.labelMorph.height()) / 2)), 
    "slider" === this.style ? (this.sliderMorph.silentSetPosition(new Point(this.labelMorph.left(), this.cellMorph.bottom() + SyntaxElementMorph.prototype.typeInPadding)), 
    this.sliderMorph.setWidth(this.cellMorph.right() - this.labelMorph.left()), this.silentSetHeight(this.cellMorph.height() + this.sliderMorph.height() + 2 * this.border + 3 * SyntaxElementMorph.prototype.typeInPadding)) : (this.sliderMorph.hide(), 
    this.bounds.corner.y = this.cellMorph.bottom() + this.border + SyntaxElementMorph.prototype.typeInPadding), 
    this.bounds.corner.x = Math.max(this.cellMorph.right(), this.labelMorph.right()) + this.edge + SyntaxElementMorph.prototype.typeInPadding, 
    this.drawNew(), this.changed();
}, WatcherMorph.prototype.userMenu = function() {
    var myself = this, menu = new MenuMorph(this);
    return menu.addItem(("normal" === this.style ? "●" : "○") + " " + localize("normal"), "styleNormal"), 
    menu.addItem(("large" === this.style ? "●" : "○") + " " + localize("large"), "styleLarge"), 
    this.target instanceof VariableFrame && (menu.addItem(("slider" === this.style ? "●" : "○") + " " + localize("slider"), "styleSlider"), 
    menu.addLine(), menu.addItem("slider min...", "userSetSliderMin"), menu.addItem("slider max...", "userSetSliderMax"), 
    menu.addLine(), menu.addItem("import...", function() {
        var inp = document.createElement("input"), ide = myself.parentThatIsA(IDE_Morph);
        ide.filePicker && (document.body.removeChild(ide.filePicker), ide.filePicker = null), 
        inp.type = "file", inp.style.color = "transparent", inp.style.backgroundColor = "transparent", 
        inp.style.border = "none", inp.style.outline = "none", inp.style.position = "absolute", 
        inp.style.top = "0px", inp.style.left = "0px", inp.style.width = "0px", inp.style.height = "0px", 
        inp.addEventListener("change", function() {
            document.body.removeChild(inp), ide.filePicker = null, inp.files.length > 0 && function(aFile) {
                var frd = new FileReader();
                frd.onloadend = function(e) {
                    myself.target.setVar(myself.getter, e.target.result);
                }, 0 === aFile.type.indexOf("text") ? frd.readAsText(aFile) : (ftype = aFile.type, 
                ide.inform("Unable to import", 'Snap! can only import "text" files.\nYou selected a file of type "' + ftype + '".'));
                var ftype;
            }(inp.files[inp.files.length - 1]);
        }, !1), document.body.appendChild(inp), ide.filePicker = inp, inp.click();
    }), !this.currentValue || !isString(this.currentValue) && isNaN(+this.currentValue) || menu.addItem("export...", function() {
        window.open("data:text/plain;charset=utf-8," + encodeURIComponent(this.currentValue.toString()));
    })), menu;
}, WatcherMorph.prototype.setStyle = function(style) {
    this.style = style, this.fixLayout();
}, WatcherMorph.prototype.styleNormal = function() {
    this.setStyle("normal");
}, WatcherMorph.prototype.styleLarge = function() {
    this.setStyle("large");
}, WatcherMorph.prototype.styleSlider = function() {
    this.setStyle("slider");
}, WatcherMorph.prototype.userSetSliderMin = function() {
    new DialogBoxMorph(this, this.setSliderMin, this).prompt("Slider minimum value", this.sliderMorph.start.toString(), this.world(), null, null, null, !0);
}, WatcherMorph.prototype.userSetSliderMax = function() {
    new DialogBoxMorph(this, this.setSliderMax, this).prompt("Slider maximum value", this.sliderMorph.stop.toString(), this.world(), null, null, null, !0);
}, WatcherMorph.prototype.drawNew = function() {
    var context, gradient;
    this.image = newCanvas(this.extent()), context = this.image.getContext("2d"), MorphicPreferences.isFlat || 0 === this.edge && 0 === this.border ? BoxMorph.uber.drawNew.call(this) : ((gradient = context.createLinearGradient(0, 0, 0, this.height())).addColorStop(0, this.color.lighter().toString()), 
    gradient.addColorStop(1, this.color.darker().toString()), context.fillStyle = gradient, 
    context.beginPath(), this.outlinePath(context, Math.max(this.edge - this.border, 0), this.border), 
    context.closePath(), context.fill(), this.border > 0 && ((gradient = context.createLinearGradient(0, 0, 0, this.height())).addColorStop(0, this.borderColor.lighter().toString()), 
    gradient.addColorStop(1, this.borderColor.darker().toString()), context.lineWidth = this.border, 
    context.strokeStyle = gradient, context.beginPath(), this.outlinePath(context, this.edge, this.border / 2), 
    context.closePath(), context.stroke()));
}, StagePrompterMorph.prototype = new BoxMorph(), StagePrompterMorph.prototype.constructor = StagePrompterMorph, 
StagePrompterMorph.uber = BoxMorph.prototype;

function StagePrompterMorph(question) {
    this.init(question);
}

StagePrompterMorph.prototype.init = function(question) {
    var myself = this;
    this.isDone = !1, this.label = question ? new StringMorph(question, SpriteMorph.prototype.bubbleFontSize, null, SpriteMorph.prototype.bubbleFontIsBold, !1, "left") : null, 
    this.inputField = new InputFieldMorph(), this.button = new PushButtonMorph(null, function() {
        myself.accept();
    }, "✓"), StagePrompterMorph.uber.init.call(this, SyntaxElementMorph.prototype.rounding, SpriteMorph.prototype.bubbleBorder, SpriteMorph.prototype.blockColor.sensing), 
    this.color = new Color(255, 255, 255), this.label && this.add(this.label), this.add(this.inputField), 
    this.add(this.button), this.setWidth(StageMorph.prototype.dimensions.x - 20), this.fixLayout();
}, StagePrompterMorph.prototype.fixLayout = function() {
    var y = 0;
    this.label && (this.label.setPosition(new Point(this.left() + this.edge, this.top() + this.edge)), 
    y = this.label.bottom() - this.top()), this.inputField.setPosition(new Point(this.left() + this.edge, this.top() + y + this.edge)), 
    this.inputField.setWidth(this.width() - 2 * this.edge - this.button.width() - this.border), 
    this.button.setCenter(this.inputField.center()), this.button.setLeft(this.inputField.right() + this.border), 
    this.setHeight(this.inputField.bottom() - this.top() + this.edge);
}, StagePrompterMorph.prototype.mouseClickLeft = function() {
    this.inputField.edit();
}, StagePrompterMorph.prototype.accept = function() {
    this.isDone = !0;
}, modules.gui = "2015-January-21";

var IDE_Morph, ProjectDialogMorph, SpriteIconMorph, CostumeIconMorph, TurtleIconMorph, WardrobeMorph, SoundIconMorph, JukeboxMorph;

IDE_Morph.prototype = new Morph(), IDE_Morph.prototype.constructor = IDE_Morph, 
IDE_Morph.uber = Morph.prototype, IDE_Morph.prototype.setDefaultDesign = function() {
    MorphicPreferences.isFlat = !1, SpriteMorph.prototype.paletteColor = new Color(55, 55, 55), 
    SpriteMorph.prototype.paletteTextColor = new Color(230, 230, 230), StageMorph.prototype.paletteTextColor = SpriteMorph.prototype.paletteTextColor, 
    StageMorph.prototype.paletteColor = SpriteMorph.prototype.paletteColor, SpriteMorph.prototype.sliderColor = SpriteMorph.prototype.paletteColor.lighter(30), 
    IDE_Morph.prototype.buttonContrast = 30, IDE_Morph.prototype.backgroundColor = new Color(40, 40, 40), 
    IDE_Morph.prototype.frameColor = SpriteMorph.prototype.paletteColor, IDE_Morph.prototype.groupColor = SpriteMorph.prototype.paletteColor.lighter(8), 
    IDE_Morph.prototype.sliderColor = SpriteMorph.prototype.sliderColor, IDE_Morph.prototype.buttonLabelColor = new Color(255, 255, 255), 
    IDE_Morph.prototype.tabColors = [ IDE_Morph.prototype.groupColor.darker(40), IDE_Morph.prototype.groupColor.darker(60), IDE_Morph.prototype.groupColor ], 
    IDE_Morph.prototype.rotationStyleColors = IDE_Morph.prototype.tabColors, IDE_Morph.prototype.appModeColor = new Color(), 
    IDE_Morph.prototype.scriptsPaneTexture = this.scriptsTexture(), IDE_Morph.prototype.padding = 5, 
    SpriteIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor, CostumeIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor, 
    SoundIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor, TurtleIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor;
}, IDE_Morph.prototype.setFlatDesign = function() {
    MorphicPreferences.isFlat = !0, SpriteMorph.prototype.paletteColor = new Color(255, 255, 255), 
    SpriteMorph.prototype.paletteTextColor = new Color(70, 70, 70), StageMorph.prototype.paletteTextColor = SpriteMorph.prototype.paletteTextColor, 
    StageMorph.prototype.paletteColor = SpriteMorph.prototype.paletteColor, SpriteMorph.prototype.sliderColor = SpriteMorph.prototype.paletteColor, 
    IDE_Morph.prototype.buttonContrast = 30, IDE_Morph.prototype.backgroundColor = new Color(200, 200, 200), 
    IDE_Morph.prototype.frameColor = new Color(255, 255, 255), IDE_Morph.prototype.groupColor = new Color(230, 230, 230), 
    IDE_Morph.prototype.sliderColor = SpriteMorph.prototype.sliderColor, IDE_Morph.prototype.buttonLabelColor = new Color(70, 70, 70), 
    IDE_Morph.prototype.tabColors = [ IDE_Morph.prototype.groupColor.lighter(60), IDE_Morph.prototype.groupColor.darker(10), IDE_Morph.prototype.groupColor ], 
    IDE_Morph.prototype.rotationStyleColors = [ IDE_Morph.prototype.groupColor, IDE_Morph.prototype.groupColor.darker(10), IDE_Morph.prototype.groupColor.darker(30) ], 
    IDE_Morph.prototype.appModeColor = IDE_Morph.prototype.frameColor, IDE_Morph.prototype.scriptsPaneTexture = null, 
    IDE_Morph.prototype.padding = 1, SpriteIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor, 
    CostumeIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor, SoundIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor, 
    TurtleIconMorph.prototype.labelColor = IDE_Morph.prototype.buttonLabelColor;
}, IDE_Morph.prototype.scriptsTexture = function() {
    var i, pic = newCanvas(new Point(100, 100)), ctx = pic.getContext("2d");
    for (i = 0; i < 100; i += 4) ctx.fillStyle = this.frameColor.toString(), ctx.fillRect(i, 0, 1, 100), 
    ctx.fillStyle = this.groupColor.lighter(6).toString(), ctx.fillRect(i + 1, 0, 1, 100), 
    ctx.fillRect(i + 3, 0, 1, 100), ctx.fillStyle = this.groupColor.toString(), ctx.fillRect(i + 2, 0, 1, 100);
    return pic;
}, IDE_Morph.prototype.setDefaultDesign();

function IDE_Morph(isAutoFill) {
    this.init(isAutoFill);
}

IDE_Morph.prototype.init = function(isAutoFill) {
    MorphicPreferences.globalFontFamily = "Helvetica, Arial", this.userLanguage = null, 
    this.applySavedSettings(), this.cloudMsg = null, this.source = "local", this.serializer = new SnapSerializer(), 
    this.globalVariables = new VariableFrame(), this.currentSprite = new SpriteMorph(this.globalVariables), 
    this.sprites = new List([ this.currentSprite ]), this.currentCategory = "motion", 
    this.currentTab = "scripts", this.projectName = "", this.projectNotes = "", this.logo = null, 
    this.controlBar = null, this.categories = null, this.palette = null, this.spriteBar = null, 
    this.spriteEditor = null, this.stage = null, this.corralBar = null, this.corral = null, 
    this.isAutoFill = isAutoFill || !0, this.isAppMode = !1, this.isSmallStage = !1, 
    this.filePicker = null, this.hasChangedMedia = !1, this.isAnimating = !0, this.stageRatio = 1, 
    this.loadNewProject = !1, this.shield = null, IDE_Morph.uber.init.call(this), this.color = this.backgroundColor;
}, IDE_Morph.prototype.openIn = function(world) {
    var hash, usr, myself = this, urlLanguage = null;
    localStorage && (usr = localStorage["-snap-user"]) && (usr = SnapCloud.parseResponse(usr)[0]) && (SnapCloud.username = usr.username || null, 
    SnapCloud.password = usr.password || null, SnapCloud.username && (this.source = "cloud")), 
    this.buildPanes(), world.add(this), world.userMenu = this.userMenu, SnapCloud.message = function(string) {
        var intervalHandle, m = new MenuMorph(null, string);
        m.popUpCenteredInWorld(world), intervalHandle = setInterval(function() {
            m.destroy(), clearInterval(intervalHandle);
        }, 2e3);
    }, world.reactToDropOf = function(morph) {
        morph instanceof DialogBoxMorph || (world.hand.grabOrigin ? morph.slideBackTo(world.hand.grabOrigin) : world.hand.grab(morph));
    }, this.reactToWorldResize(world.bounds);
    function getURL(url) {
        try {
            var request = new XMLHttpRequest();
            if (request.open("GET", url, !1), request.send(), 200 === request.status) return request.responseText;
            throw new Error("unable to retrieve " + url);
        } catch (err) {
            return;
        }
    }
    function interpretUrlAnchors() {
        var dict;
        "#open:" === location.hash.substr(0, 6) ? (("%" === (hash = location.hash.substr(6)).charAt(0) || hash.search(/\%(?:[0-9a-f]{2})/i) > -1) && (hash = decodeURIComponent(hash)), 
        contains([ "project", "blocks", "sprites", "snapdata" ].map(function(each) {
            return hash.substr(0, 8).indexOf(each);
        }), 1) ? this.droppedText(hash) : this.droppedText(getURL(hash))) : "#run:" === location.hash.substr(0, 5) ? (("%" === (hash = location.hash.substr(5)).charAt(0) || hash.search(/\%(?:[0-9a-f]{2})/i) > -1) && (hash = decodeURIComponent(hash)), 
        "<project>" === hash.substr(0, 8) ? this.rawOpenProjectString(hash) : this.rawOpenProjectString(getURL(hash)), 
        this.toggleAppMode(!0), this.runScripts()) : "#present:" === location.hash.substr(0, 9) ? (this.shield = new Morph(), 
        this.shield.color = this.color, this.shield.setExtent(this.parent.extent()), this.parent.add(this.shield), 
        myself.showMessage("Fetching project\nfrom the cloud..."), (dict = SnapCloud.parseDict(location.hash.substr(9))).Username = dict.Username.toLowerCase(), 
        SnapCloud.getPublicProject(SnapCloud.encodeDict(dict), function(projectData) {
            var msg;
            myself.nextSteps([ function() {
                msg = myself.showMessage("Opening project...");
            }, function() {
                nop();
            }, function() {
                0 === projectData.indexOf("<snapdata") ? myself.rawOpenCloudDataString(projectData) : 0 === projectData.indexOf("<project") && myself.rawOpenProjectString(projectData), 
                myself.hasChangedMedia = !0;
            }, function() {
                myself.shield.destroy(), myself.shield = null, msg.destroy(), myself.toggleAppMode(!0), 
                myself.runScripts();
            } ]);
        }, this.cloudError())) : "#lang:" === location.hash.substr(0, 6) ? (urlLanguage = location.hash.substr(6), 
        this.setLanguage(urlLanguage), this.loadNewProject = !0) : "#signup" === location.hash.substr(0, 7) && this.createCloudAccount();
    }
    this.userLanguage ? this.setLanguage(this.userLanguage, interpretUrlAnchors) : interpretUrlAnchors.call(this);
}, IDE_Morph.prototype.buildPanes = function() {
    this.createLogo(), this.createControlBar(), this.createCategories(), this.createPalette(), 
    this.createStage(), this.createSpriteBar(), this.createSpriteEditor(), this.createCorralBar(), 
    this.createCorral();
}, IDE_Morph.prototype.createLogo = function() {
    var myself = this;
    this.logo && this.logo.destroy(), this.logo = new Morph(), this.logo.texture = "/assets/apps/snap/snap_logo_sm.png", 
    this.logo.drawNew = function() {
        this.image = newCanvas(this.extent());
        var context = this.image.getContext("2d"), gradient = context.createLinearGradient(0, 0, this.width(), 0);
        gradient.addColorStop(0, "black"), gradient.addColorStop(.5, myself.frameColor.toString()), 
        context.fillStyle = MorphicPreferences.isFlat ? myself.frameColor.toString() : gradient, 
        context.fillRect(0, 0, this.width(), this.height()), this.texture && this.drawTexture(this.texture);
    }, this.logo.drawCachedTexture = function() {
        this.image.getContext("2d").drawImage(this.cachedTexture, 5, Math.round((this.height() - this.cachedTexture.height) / 2)), 
        this.changed();
    }, this.logo.mouseClickLeft = function() {
        myself.snapMenu();
    }, this.logo.color = new Color(), this.logo.setExtent(new Point(200, 28)), this.add(this.logo);
}, IDE_Morph.prototype.createControlBar = function() {
    var button, stopButton, pauseButton, startButton, projectButton, settingsButton, stageSizeButton, appModeButton, x, colors = [ this.groupColor, this.frameColor.darker(50), this.frameColor.darker(50) ], myself = this;
    this.controlBar && this.controlBar.destroy(), this.controlBar = new Morph(), this.controlBar.color = this.frameColor, 
    this.controlBar.setHeight(this.logo.height()), this.controlBar.mouseClickLeft = function() {
        this.world().fillPage();
    }, this.add(this.controlBar), (button = new ToggleButtonMorph(null, myself, "toggleStageSize", [ new SymbolMorph("smallStage", 14), new SymbolMorph("normalStage", 14) ], function() {
        return myself.isSmallStage;
    })).corner = 12, button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = this.buttonLabelColor, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), button.refresh(), 
    stageSizeButton = button, this.controlBar.add(stageSizeButton), this.controlBar.stageSizeButton = button, 
    (button = new ToggleButtonMorph(null, myself, "toggleAppMode", [ new SymbolMorph("fullScreen", 14), new SymbolMorph("normalScreen", 14) ], function() {
        return myself.isAppMode;
    })).corner = 12, button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = this.buttonLabelColor, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), button.refresh(), 
    appModeButton = button, this.controlBar.add(appModeButton), this.controlBar.appModeButton = appModeButton, 
    (button = new PushButtonMorph(this, "stopAllScripts", new SymbolMorph("octagon", 14))).corner = 12, 
    button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = new Color(200, 0, 0), button.contrast = this.buttonContrast, 
    button.drawNew(), button.fixLayout(), stopButton = button, this.controlBar.add(stopButton), 
    (button = new ToggleButtonMorph(null, myself, "togglePauseResume", [ new SymbolMorph("pause", 12), new SymbolMorph("pointRight", 14) ], function() {
        return myself.isPaused();
    })).corner = 12, button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = new Color(255, 220, 0), 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), button.refresh(), 
    pauseButton = button, this.controlBar.add(pauseButton), this.controlBar.pauseButton = pauseButton, 
    (button = new PushButtonMorph(this, "pressStart", new SymbolMorph("flag", 14))).corner = 12, 
    button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = new Color(0, 200, 0), button.contrast = this.buttonContrast, 
    button.drawNew(), button.fixLayout(), startButton = button, this.controlBar.add(startButton), 
    this.controlBar.startButton = startButton, (button = new PushButtonMorph(this, "projectMenu", new SymbolMorph("file", 14))).corner = 12, 
    button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = this.buttonLabelColor, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), projectButton = button, 
    this.controlBar.add(projectButton), this.controlBar.projectButton = projectButton, 
    (button = new PushButtonMorph(this, "settingsMenu", new SymbolMorph("gears", 14))).corner = 12, 
    button.color = colors[0], button.highlightColor = colors[1], button.pressColor = colors[2], 
    button.labelMinExtent = new Point(36, 18), button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = this.buttonLabelColor, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), settingsButton = button, 
    this.controlBar.add(settingsButton), this.controlBar.settingsButton = settingsButton, 
    this.controlBar.fixLayout = function() {
        x = this.right() - 5, [ stopButton, pauseButton, startButton ].forEach(function(button) {
            button.setCenter(myself.controlBar.center()), button.setRight(x), x -= button.width(), 
            x -= 5;
        }), x = Math.min(startButton.left() - (15 + 2 * stageSizeButton.width()), myself.right() - StageMorph.prototype.dimensions.x * (myself.isSmallStage ? myself.stageRatio : 1)), 
        [ stageSizeButton, appModeButton ].forEach(function(button) {
            x += 5, button.setCenter(myself.controlBar.center()), button.setLeft(x), x += button.width();
        }), settingsButton.setCenter(myself.controlBar.center()), settingsButton.setLeft(this.left()), 
        projectButton.setCenter(myself.controlBar.center()), projectButton.setRight(settingsButton.left() - 5), 
        this.updateLabel();
    }, this.controlBar.updateLabel = function() {
        var suffix = myself.world().isDevMode ? " - " + localize("development mode") : "";
        this.label && this.label.destroy(), myself.isAppMode || (this.label = new StringMorph((myself.projectName || localize("untitled")) + suffix, 14, "sans-serif", !0, !1, !1, MorphicPreferences.isFlat ? null : new Point(2, 1), myself.frameColor.darker(myself.buttonContrast)), 
        this.label.color = myself.buttonLabelColor, this.label.drawNew(), this.add(this.label), 
        this.label.setCenter(this.center()), this.label.setLeft(this.settingsButton.right() + 5));
    };
}, IDE_Morph.prototype.createCategories = function() {
    var myself = this;
    this.categories && this.categories.destroy(), this.categories = new Morph(), this.categories.color = this.groupColor, 
    this.categories.silentSetWidth(this.logo.width());
    SpriteMorph.prototype.categories.forEach(function(cat) {
        contains([ "lists", "other" ], cat) || function(category) {
            var button, colors = [ myself.frameColor, myself.frameColor.darker(50), SpriteMorph.prototype.blockColor[category] ];
            (button = new ToggleButtonMorph(colors, myself, function() {
                myself.currentCategory = category, myself.categories.children.forEach(function(each) {
                    each.refresh();
                }), myself.refreshPalette(!0);
            }, category[0].toUpperCase().concat(category.slice(1)), function() {
                return myself.currentCategory === category;
            }, null, null, null, 75, !0)).corner = 8, button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
            button.labelShadowColor = colors[1], button.labelColor = myself.buttonLabelColor, 
            button.fixLayout(), button.refresh(), myself.categories.add(button);
        }(cat);
    }), function() {
        var row, col, buttonWidth = myself.categories.children[0].width(), buttonHeight = myself.categories.children[0].height(), rows = Math.ceil(myself.categories.children.length / 2), xPadding = (myself.categories.width() - 3 - 2 * buttonWidth) / 3, l = myself.categories.left(), t = myself.categories.top(), i = 0;
        myself.categories.children.forEach(function(button) {
            i += 1, row = Math.ceil(i / 2), col = 2 - i % 2, button.setPosition(new Point(l + (col * xPadding + (col - 1) * buttonWidth), t + (2 * row + (row - 1) * buttonHeight + 3)));
        }), myself.categories.setHeight(2 * (rows + 1) + rows * buttonHeight + 6);
    }(), this.add(this.categories);
}, IDE_Morph.prototype.createPalette = function(forSearching) {
    var myself = this;
    return this.palette && this.palette.destroy(), this.palette = forSearching ? new ScrollFrameMorph(null, null, this.currentSprite.sliderColor) : this.currentSprite.palette(this.currentCategory), 
    this.palette.isDraggable = !1, this.palette.acceptsDrops = !0, this.palette.contents.acceptsDrops = !1, 
    this.palette.reactToDropOf = function(droppedMorph) {
        droppedMorph instanceof DialogBoxMorph ? myself.world().add(droppedMorph) : droppedMorph instanceof SpriteMorph ? myself.removeSprite(droppedMorph) : droppedMorph instanceof SpriteIconMorph ? (droppedMorph.destroy(), 
        myself.removeSprite(droppedMorph.object)) : droppedMorph instanceof CostumeIconMorph ? (myself.currentSprite.wearCostume(null), 
        droppedMorph.destroy()) : droppedMorph.destroy();
    }, this.palette.setWidth(this.logo.width()), this.add(this.palette), this.palette;
}, IDE_Morph.prototype.createStage = function() {
    this.stage && this.stage.destroy(), StageMorph.prototype.frameRate = 0, this.stage = new StageMorph(this.globalVariables), 
    this.stage.setExtent(this.stage.dimensions), this.currentSprite instanceof SpriteMorph && (this.currentSprite.setPosition(this.stage.center().subtract(this.currentSprite.extent().divideBy(2))), 
    this.stage.add(this.currentSprite)), this.add(this.stage);
}, IDE_Morph.prototype.createSpriteBar = function() {
    var nameField, padlock, thumbnail, tab, rotationStyleButtons = [], thumbSize = new Point(45, 45), tabColors = this.tabColors, tabBar = new AlignmentMorph("row", -30), symbols = [ "→", "↻", "↔" ], labels = [ "don't rotate", "can rotate", "only face left/right" ], myself = this;
    this.spriteBar && this.spriteBar.destroy(), this.spriteBar = new Morph(), this.spriteBar.color = this.frameColor, 
    this.add(this.spriteBar);
    function addRotationStyleButton(rotationStyle) {
        var button, colors = myself.rotationStyleColors;
        return (button = new ToggleButtonMorph(colors, myself, function() {
            myself.currentSprite instanceof SpriteMorph && (myself.currentSprite.rotationStyle = rotationStyle, 
            myself.currentSprite.changed(), myself.currentSprite.drawNew(), myself.currentSprite.changed()), 
            rotationStyleButtons.forEach(function(each) {
                each.refresh();
            });
        }, symbols[rotationStyle], function() {
            return myself.currentSprite instanceof SpriteMorph && myself.currentSprite.rotationStyle === rotationStyle;
        }, null, localize(labels[rotationStyle]))).corner = 8, button.labelMinExtent = new Point(11, 11), 
        button.padding = 0, button.labelShadowOffset = new Point(-1, -1), button.labelShadowColor = colors[1], 
        button.labelColor = myself.buttonLabelColor, button.fixLayout(), button.refresh(), 
        rotationStyleButtons.push(button), button.setPosition(myself.spriteBar.position().add(2)), 
        button.setTop(button.top() + (rotationStyleButtons.length - 1) * (button.height() + 2)), 
        myself.spriteBar.add(button), myself.currentSprite instanceof StageMorph && button.hide(), 
        button;
    }
    addRotationStyleButton(1), addRotationStyleButton(2), addRotationStyleButton(0), 
    this.rotationStyleButtons = rotationStyleButtons, (thumbnail = new Morph()).setExtent(thumbSize), 
    thumbnail.image = this.currentSprite.thumbnail(thumbSize), thumbnail.setPosition(rotationStyleButtons[0].topRight().add(new Point(5, 3))), 
    this.spriteBar.add(thumbnail), thumbnail.fps = 3, thumbnail.step = function() {
        thumbnail.version !== myself.currentSprite.version && (thumbnail.image = myself.currentSprite.thumbnail(thumbSize), 
        thumbnail.changed(), thumbnail.version = myself.currentSprite.version);
    }, (nameField = new InputFieldMorph(this.currentSprite.name)).setWidth(100), nameField.contrast = 90, 
    nameField.setPosition(thumbnail.topRight().add(new Point(10, 3))), this.spriteBar.add(nameField), 
    nameField.drawNew(), nameField.accept = function() {
        var newName = nameField.getValue();
        myself.currentSprite.setName(myself.newSpriteName(newName, myself.currentSprite)), 
        nameField.setContents(myself.currentSprite.name);
    }, this.spriteBar.reactToEdit = nameField.accept, (padlock = new ToggleMorph("checkbox", null, function() {
        myself.currentSprite.isDraggable = !myself.currentSprite.isDraggable;
    }, localize("draggable"), function() {
        return myself.currentSprite.isDraggable;
    })).label.isBold = !1, padlock.label.setColor(this.buttonLabelColor), padlock.color = tabColors[2], 
    padlock.highlightColor = tabColors[0], padlock.pressColor = tabColors[1], padlock.tick.shadowOffset = MorphicPreferences.isFlat ? new Point() : new Point(-1, -1), 
    padlock.tick.shadowColor = new Color(), padlock.tick.color = this.buttonLabelColor, 
    padlock.tick.isBold = !1, padlock.tick.drawNew(), padlock.setPosition(nameField.bottomLeft().add(2)), 
    padlock.drawNew(), this.spriteBar.add(padlock), this.currentSprite instanceof StageMorph && padlock.hide(), 
    tabBar.tabTo = function(tabString) {
        var active;
        myself.currentTab = tabString, this.children.forEach(function(each) {
            each.refresh(), each.state && (active = each);
        }), active.refresh(), myself.createSpriteEditor(), myself.fixLayout("tabEditor");
    }, (tab = new TabMorph(tabColors, null, function() {
        tabBar.tabTo("scripts");
    }, localize("Scripts"), function() {
        return "scripts" === myself.currentTab;
    })).padding = 3, tab.corner = 15, tab.edge = 1, tab.labelShadowOffset = new Point(-1, -1), 
    tab.labelShadowColor = tabColors[1], tab.labelColor = this.buttonLabelColor, tab.drawNew(), 
    tab.fixLayout(), tabBar.add(tab), (tab = new TabMorph(tabColors, null, function() {
        tabBar.tabTo("costumes");
    }, localize("Costumes"), function() {
        return "costumes" === myself.currentTab;
    })).padding = 3, tab.corner = 15, tab.edge = 1, tab.labelShadowOffset = new Point(-1, -1), 
    tab.labelShadowColor = tabColors[1], tab.labelColor = this.buttonLabelColor, tab.drawNew(), 
    tab.fixLayout(), tabBar.add(tab), (tab = new TabMorph(tabColors, null, function() {
        tabBar.tabTo("sounds");
    }, localize("Sounds"), function() {
        return "sounds" === myself.currentTab;
    })).padding = 3, tab.corner = 15, tab.edge = 1, tab.labelShadowOffset = new Point(-1, -1), 
    tab.labelShadowColor = tabColors[1], tab.labelColor = this.buttonLabelColor, tab.drawNew(), 
    tab.fixLayout(), tabBar.add(tab), tabBar.fixLayout(), tabBar.children.forEach(function(each) {
        each.refresh();
    }), this.spriteBar.tabBar = tabBar, this.spriteBar.add(this.spriteBar.tabBar), this.spriteBar.fixLayout = function() {
        this.tabBar.setLeft(this.left()), this.tabBar.setBottom(this.bottom());
    };
}, IDE_Morph.prototype.createSpriteEditor = function() {
    var scripts = this.currentSprite.scripts, myself = this;
    this.spriteEditor && this.spriteEditor.destroy(), "scripts" === this.currentTab ? (scripts.isDraggable = !1, 
    scripts.color = this.groupColor, scripts.cachedTexture = this.scriptsPaneTexture, 
    this.spriteEditor = new ScrollFrameMorph(scripts, null, this.sliderColor), this.spriteEditor.padding = 10, 
    this.spriteEditor.growth = 50, this.spriteEditor.isDraggable = !1, this.spriteEditor.acceptsDrops = !1, 
    this.spriteEditor.contents.acceptsDrops = !0, scripts.scrollFrame = this.spriteEditor, 
    this.add(this.spriteEditor), this.spriteEditor.scrollX(this.spriteEditor.padding), 
    this.spriteEditor.scrollY(this.spriteEditor.padding)) : "costumes" === this.currentTab ? (this.spriteEditor = new WardrobeMorph(this.currentSprite, this.sliderColor), 
    this.spriteEditor.color = this.groupColor, this.add(this.spriteEditor), this.spriteEditor.updateSelection(), 
    this.spriteEditor.acceptsDrops = !1, this.spriteEditor.contents.acceptsDrops = !1) : "sounds" === this.currentTab ? (this.spriteEditor = new JukeboxMorph(this.currentSprite, this.sliderColor), 
    this.spriteEditor.color = this.groupColor, this.add(this.spriteEditor), this.spriteEditor.updateSelection(), 
    this.spriteEditor.acceptDrops = !1, this.spriteEditor.contents.acceptsDrops = !1) : (this.spriteEditor = new Morph(), 
    this.spriteEditor.color = this.groupColor, this.spriteEditor.acceptsDrops = !0, 
    this.spriteEditor.reactToDropOf = function(droppedMorph) {
        droppedMorph instanceof DialogBoxMorph ? myself.world().add(droppedMorph) : droppedMorph instanceof SpriteMorph ? myself.removeSprite(droppedMorph) : droppedMorph.destroy();
    }, this.add(this.spriteEditor));
}, IDE_Morph.prototype.createCorralBar = function() {
    var newbutton, paintbutton, colors = [ this.groupColor, this.frameColor.darker(50), this.frameColor.darker(50) ];
    this.corralBar && this.corralBar.destroy(), this.corralBar = new Morph(), this.corralBar.color = this.frameColor, 
    this.corralBar.setHeight(this.logo.height()), this.add(this.corralBar), (newbutton = new PushButtonMorph(this, "addNewSprite", new SymbolMorph("turtle", 14))).corner = 12, 
    newbutton.color = colors[0], newbutton.highlightColor = colors[1], newbutton.pressColor = colors[2], 
    newbutton.labelMinExtent = new Point(36, 18), newbutton.padding = 0, newbutton.labelShadowOffset = new Point(-1, -1), 
    newbutton.labelShadowColor = colors[1], newbutton.labelColor = this.buttonLabelColor, 
    newbutton.contrast = this.buttonContrast, newbutton.drawNew(), newbutton.hint = "add a new Turtle sprite", 
    newbutton.fixLayout(), newbutton.setCenter(this.corralBar.center()), newbutton.setLeft(this.corralBar.left() + 5), 
    this.corralBar.add(newbutton), (paintbutton = new PushButtonMorph(this, "paintNewSprite", new SymbolMorph("brush", 15))).corner = 12, 
    paintbutton.color = colors[0], paintbutton.highlightColor = colors[1], paintbutton.pressColor = colors[2], 
    paintbutton.labelMinExtent = new Point(36, 18), paintbutton.padding = 0, paintbutton.labelShadowOffset = new Point(-1, -1), 
    paintbutton.labelShadowColor = colors[1], paintbutton.labelColor = this.buttonLabelColor, 
    paintbutton.contrast = this.buttonContrast, paintbutton.drawNew(), paintbutton.hint = "paint a new sprite", 
    paintbutton.fixLayout(), paintbutton.setCenter(this.corralBar.center()), paintbutton.setLeft(this.corralBar.left() + 5 + newbutton.width() + 5), 
    this.corralBar.add(paintbutton);
}, IDE_Morph.prototype.createCorral = function() {
    var frame, template, myself = this;
    this.corral && this.corral.destroy(), this.corral = new Morph(), this.corral.color = this.groupColor, 
    this.add(this.corral), this.corral.stageIcon = new SpriteIconMorph(this.stage), 
    this.corral.stageIcon.isDraggable = !1, this.corral.add(this.corral.stageIcon), 
    (frame = new ScrollFrameMorph(null, null, this.sliderColor)).acceptsDrops = !1, 
    frame.contents.acceptsDrops = !1, frame.contents.wantsDropOf = function(morph) {
        return morph instanceof SpriteIconMorph;
    }, frame.contents.reactToDropOf = function(spriteIcon) {
        myself.corral.reactToDropOf(spriteIcon);
    }, frame.alpha = 0, this.sprites.asArray().forEach(function(morph) {
        template = new SpriteIconMorph(morph, template), frame.contents.add(template);
    }), this.corral.frame = frame, this.corral.add(frame), this.corral.fixLayout = function() {
        this.stageIcon.setCenter(this.center()), this.stageIcon.setLeft(this.left() + 5), 
        this.frame.setLeft(this.stageIcon.right() + 5), this.frame.setExtent(new Point(this.right() - this.frame.left(), this.height())), 
        this.arrangeIcons(), this.refresh();
    }, this.corral.arrangeIcons = function() {
        var x = this.frame.left(), y = this.frame.top(), max = this.frame.right(), start = this.frame.left();
        this.frame.contents.children.forEach(function(icon) {
            var w = icon.width();
            x + w > max && (x = start, y += icon.height()), icon.setPosition(new Point(x, y)), 
            x += w;
        }), this.frame.contents.adjustBounds();
    }, this.corral.addSprite = function(sprite) {
        this.frame.contents.add(new SpriteIconMorph(sprite)), this.fixLayout();
    }, this.corral.refresh = function() {
        this.stageIcon.refresh(), this.frame.contents.children.forEach(function(icon) {
            icon.refresh();
        });
    }, this.corral.wantsDropOf = function(morph) {
        return morph instanceof SpriteIconMorph;
    }, this.corral.reactToDropOf = function(spriteIcon) {
        var idx = 1, pos = spriteIcon.position();
        spriteIcon.destroy(), this.frame.contents.children.forEach(function(icon) {
            (pos.gt(icon.position()) || pos.y > icon.bottom()) && (idx += 1);
        }), myself.sprites.add(spriteIcon.object, idx), myself.createCorral(), myself.fixLayout();
    };
}, IDE_Morph.prototype.fixLayout = function(situation) {
    var padding = this.padding;
    Morph.prototype.trackChanges = !1, "refreshPalette" !== situation && (this.controlBar.setPosition(this.logo.topRight()), 
    this.controlBar.setWidth(this.right() - this.controlBar.left()), this.controlBar.fixLayout(), 
    this.categories.setLeft(this.logo.left()), this.categories.setTop(this.logo.bottom())), 
    this.palette.setLeft(this.logo.left()), this.palette.setTop(this.categories.bottom()), 
    this.palette.setHeight(this.bottom() - this.palette.top()), "refreshPalette" !== situation && (this.isAppMode ? (this.stage.setScale(Math.floor(10 * Math.min((this.width() - 2 * padding) / this.stage.dimensions.x, (this.height() - 2 * this.controlBar.height() - 2 * padding) / this.stage.dimensions.y)) / 10), 
    this.stage.setCenter(this.center())) : (this.stage.setScale(this.isSmallStage ? this.stageRatio : 1), 
    this.stage.setTop(this.logo.bottom() + padding), this.stage.setRight(this.right())), 
    this.spriteBar.setPosition(this.logo.bottomRight().add(padding)), this.spriteBar.setExtent(new Point(Math.max(0, this.stage.left() - padding - this.spriteBar.left()), this.categories.bottom() - this.spriteBar.top() - padding)), 
    this.spriteBar.fixLayout(), this.spriteEditor.isVisible && (this.spriteEditor.setPosition(this.spriteBar.bottomLeft()), 
    this.spriteEditor.setExtent(new Point(this.spriteBar.width(), this.bottom() - this.spriteEditor.top()))), 
    this.corralBar.setLeft(this.stage.left()), this.corralBar.setTop(this.stage.bottom() + padding), 
    this.corralBar.setWidth(this.stage.width()), contains([ "selectSprite", "tabEditor" ], situation) || (this.corral.setPosition(this.corralBar.bottomLeft()), 
    this.corral.setWidth(this.stage.width()), this.corral.setHeight(this.bottom() - this.corral.top()), 
    this.corral.fixLayout())), Morph.prototype.trackChanges = !0, this.changed();
}, IDE_Morph.prototype.setProjectName = function(string) {
    this.projectName = string.replace(/['"]/g, ""), this.hasChangedMedia = !0, this.controlBar.updateLabel();
}, IDE_Morph.prototype.setExtent = function(point) {
    var minExt, ext, padding = new Point(430, 110);
    minExt = this.isAppMode ? StageMorph.prototype.dimensions.add(this.controlBar.height() + 10) : this.isSmallStage ? padding.add(StageMorph.prototype.dimensions.divideBy(2)) : padding.add(StageMorph.prototype.dimensions), 
    ext = point.max(minExt), IDE_Morph.uber.setExtent.call(this, ext), this.fixLayout();
}, IDE_Morph.prototype.reactToWorldResize = function(rect) {
    this.isAutoFill && (this.setPosition(rect.origin), this.setExtent(rect.extent())), 
    this.filePicker && (document.body.removeChild(this.filePicker), this.filePicker = null);
}, IDE_Morph.prototype.droppedImage = function(aCanvas, name) {
    var costume = new Costume(aCanvas, this.currentSprite.newCostumeName(name ? name.split(".")[0] : ""));
    costume.isTainted() ? this.inform("Unable to import this image", "The picture you wish to import has been\ntainted by a restrictive cross-origin policy\nmaking it unusable for costumes in Snap!. \n\nTry downloading this picture first to your\ncomputer, and import it from there.") : (this.currentSprite.addCostume(costume), 
    this.currentSprite.wearCostume(costume), this.spriteBar.tabBar.tabTo("costumes"), 
    this.hasChangedMedia = !0);
}, IDE_Morph.prototype.droppedSVG = function(anImage, name) {
    var costume = new SVG_Costume(anImage, name.split(".")[0]);
    this.currentSprite.addCostume(costume), this.currentSprite.wearCostume(costume), 
    this.spriteBar.tabBar.tabTo("costumes"), this.hasChangedMedia = !0, this.showMessage("SVG costumes are\nnot yet fully supported\nin every browser", 2);
}, IDE_Morph.prototype.droppedAudio = function(anAudio, name) {
    this.currentSprite.addSound(anAudio, name.split(".")[0]), this.spriteBar.tabBar.tabTo("sounds"), 
    this.hasChangedMedia = !0;
}, IDE_Morph.prototype.droppedText = function(aString, name) {
    var lbl = name ? name.split(".")[0] : "";
    return 0 === aString.indexOf("<project") ? this.openProjectString(aString) : 0 === aString.indexOf("<snapdata") ? this.openCloudDataString(aString) : 0 === aString.indexOf("<blocks") ? this.openBlocksString(aString, lbl, !0) : 0 === aString.indexOf("<sprites") ? this.openSpritesString(aString) : 0 === aString.indexOf("<media") ? this.openMediaString(aString) : void 0;
}, IDE_Morph.prototype.droppedBinary = function(anArrayBuffer, name) {
    var ypr = document.getElementById("ypr"), myself = this;
    "ypr" === name.substring(name.length - 3).toLowerCase() && (ypr ? loadYPR(anArrayBuffer, name) : ((ypr = document.createElement("script")).id = "ypr", 
    ypr.onload = function() {
        loadYPR(anArrayBuffer, name);
    }, document.head.appendChild(ypr), ypr.src = "ypr.js"));
    function loadYPR(buffer, lbl) {
        var reader = new sb.Reader(), pname = lbl.split(".")[0];
        reader.onload = function(info) {
            myself.droppedText(new sb.XMLWriter().write(pname, info));
        }, reader.readYPR(new Uint8Array(buffer));
    }
}, IDE_Morph.prototype.refreshPalette = function(shouldIgnorePosition) {
    var oldTop = this.palette.contents.top();
    this.createPalette(), this.fixLayout("refreshPalette"), shouldIgnorePosition || this.palette.contents.setTop(oldTop);
}, IDE_Morph.prototype.pressStart = function() {
    16 === this.world().currentKey ? this.toggleFastTracking() : this.runScripts();
}, IDE_Morph.prototype.toggleFastTracking = function() {
    this.stage.isFastTracked ? this.stopFastTracking() : this.startFastTracking();
}, IDE_Morph.prototype.toggleVariableFrameRate = function() {
    StageMorph.prototype.frameRate ? (StageMorph.prototype.frameRate = 0, this.stage.fps = 0) : (StageMorph.prototype.frameRate = 30, 
    this.stage.fps = 30);
}, IDE_Morph.prototype.startFastTracking = function() {
    this.stage.isFastTracked = !0, this.stage.fps = 0, this.controlBar.startButton.labelString = new SymbolMorph("flash", 14), 
    this.controlBar.startButton.drawNew(), this.controlBar.startButton.fixLayout();
}, IDE_Morph.prototype.stopFastTracking = function() {
    this.stage.isFastTracked = !1, this.stage.fps = this.stage.frameRate, this.controlBar.startButton.labelString = new SymbolMorph("flag", 14), 
    this.controlBar.startButton.drawNew(), this.controlBar.startButton.fixLayout();
}, IDE_Morph.prototype.runScripts = function() {
    this.stage.fireGreenFlagEvent();
}, IDE_Morph.prototype.togglePauseResume = function() {
    this.stage.threads.isPaused() ? this.stage.threads.resumeAll(this.stage) : this.stage.threads.pauseAll(this.stage), 
    this.controlBar.pauseButton.refresh();
}, IDE_Morph.prototype.isPaused = function() {
    return !!this.stage && this.stage.threads.isPaused();
}, IDE_Morph.prototype.stopAllScripts = function() {
    this.stage.fireStopAllEvent();
}, IDE_Morph.prototype.selectSprite = function(sprite) {
    this.currentSprite = sprite, this.createPalette(), this.createSpriteBar(), this.createSpriteEditor(), 
    this.corral.refresh(), this.fixLayout("selectSprite"), this.currentSprite.scripts.fixMultiArgs();
}, IDE_Morph.prototype.defaultDesign = function() {
    this.setDefaultDesign(), this.refreshIDE(), this.removeSetting("design");
}, IDE_Morph.prototype.flatDesign = function() {
    this.setFlatDesign(), this.refreshIDE(), this.saveSetting("design", "flat");
}, IDE_Morph.prototype.refreshIDE = function() {
    var projectData;
    if (Process.prototype.isCatchingErrors) try {
        projectData = this.serializer.serialize(this.stage);
    } catch (err) {
        this.showMessage("Serialization failed: " + err);
    } else projectData = this.serializer.serialize(this.stage);
    SpriteMorph.prototype.initBlocks(), this.buildPanes(), this.fixLayout(), this.loadNewProject ? this.newProject() : this.openProjectString(projectData);
}, IDE_Morph.prototype.applySavedSettings = function() {
    var design = this.getSetting("design"), zoom = this.getSetting("zoom"), language = this.getSetting("language"), click = this.getSetting("click"), longform = this.getSetting("longform"), plainprototype = this.getSetting("plainprototype");
    "flat" === design ? this.setFlatDesign() : this.setDefaultDesign(), zoom && (SyntaxElementMorph.prototype.setScale(Math.min(zoom, 12)), 
    CommentMorph.prototype.refreshScale(), SpriteMorph.prototype.initBlocks()), this.userLanguage = language && "en" !== language ? language : null, 
    click && !BlockMorph.prototype.snapSound && BlockMorph.prototype.toggleSnapSound(), 
    longform && (InputSlotDialogMorph.prototype.isLaunchingExpanded = !0), plainprototype && (BlockLabelPlaceHolderMorph.prototype.plainLabel = !0);
}, IDE_Morph.prototype.saveSetting = function(key, value) {
    localStorage && (localStorage["-snap-setting-" + key] = value);
}, IDE_Morph.prototype.getSetting = function(key) {
    return localStorage ? localStorage["-snap-setting-" + key] : null;
}, IDE_Morph.prototype.removeSetting = function(key) {
    localStorage && delete localStorage["-snap-setting-" + key];
}, IDE_Morph.prototype.addNewSprite = function() {
    var sprite = new SpriteMorph(this.globalVariables), rnd = Process.prototype.reportRandom;
    sprite.name = this.newSpriteName(sprite.name), sprite.setCenter(this.stage.center()), 
    this.stage.add(sprite), sprite.setHue(rnd.call(this, 0, 100)), sprite.setBrightness(rnd.call(this, 50, 100)), 
    sprite.turn(rnd.call(this, 1, 360)), sprite.setXPosition(rnd.call(this, -220, 220)), 
    sprite.setYPosition(rnd.call(this, -160, 160)), this.sprites.add(sprite), this.corral.addSprite(sprite), 
    this.selectSprite(sprite);
}, IDE_Morph.prototype.paintNewSprite = function() {
    var sprite = new SpriteMorph(this.globalVariables), cos = new Costume(), myself = this;
    sprite.name = this.newSpriteName(sprite.name), sprite.setCenter(this.stage.center()), 
    this.stage.add(sprite), this.sprites.add(sprite), this.corral.addSprite(sprite), 
    this.selectSprite(sprite), cos.edit(this.world(), this, !0, function() {
        myself.removeSprite(sprite);
    }, function() {
        sprite.addCostume(cos), sprite.wearCostume(cos);
    });
}, IDE_Morph.prototype.duplicateSprite = function(sprite) {
    var duplicate = sprite.fullCopy();
    duplicate.setPosition(this.world().hand.position()), duplicate.appearIn(this), duplicate.keepWithin(this.stage), 
    this.selectSprite(duplicate);
}, IDE_Morph.prototype.removeSprite = function(sprite) {
    var idx, myself = this;
    sprite.parts.forEach(function(part) {
        myself.removeSprite(part);
    }), idx = this.sprites.asArray().indexOf(sprite) + 1, this.stage.threads.stopAllForReceiver(sprite), 
    sprite.destroy(), this.stage.watchers().forEach(function(watcher) {
        watcher.object() === sprite && watcher.destroy();
    }), idx > 0 && this.sprites.remove(idx), this.createCorral(), this.fixLayout(), 
    this.currentSprite = detect(this.stage.children, function(morph) {
        return morph instanceof SpriteMorph;
    }) || this.stage, this.selectSprite(this.currentSprite);
}, IDE_Morph.prototype.newSpriteName = function(name, ignoredSprite) {
    for (var ix = name.indexOf("("), stem = ix < 0 ? name : name.substring(0, ix), count = 1, newName = stem, all = this.sprites.asArray().concat(this.stage).filter(function(each) {
        return each !== ignoredSprite;
    }).map(function(each) {
        return each.name;
    }); contains(all, newName); ) newName = stem + "(" + (count += 1) + ")";
    return newName;
}, IDE_Morph.prototype.userMenu = function() {
    return new MenuMorph(this);
}, IDE_Morph.prototype.snapMenu = function() {
    var menu, world = this.world();
    (menu = new MenuMorph(this)).addItem("About...", "aboutSnap"), menu.addLine(), menu.addItem("Reference manual", function() {
        window.open("https://snap.berkeley.edu/SnapManual.pdf", "SnapReferenceManual");
    }), menu.addItem("Snap! website", function() {
        window.open("http://snap.berkeley.edu/", "SnapWebsite");
    }), menu.addItem("Download source", function() {
        window.open("http://snap.berkeley.edu/snapsource/snap.zip", "SnapSource");
    }), world.isDevMode ? (menu.addLine(), menu.addItem("Switch back to user mode", "switchToUserMode", "disable deep-Morphic\ncontext menus\nand show user-friendly ones", new Color(0, 100, 0))) : 16 === world.currentKey && (menu.addLine(), 
    menu.addItem("Switch to dev mode", "switchToDevMode", "enable Morphic\ncontext menus\nand inspectors,\nnot user-friendly!", new Color(100, 0, 0))), 
    menu.popup(world, this.logo.bottomLeft());
}, IDE_Morph.prototype.cloudMenu = function() {
    var menu, myself = this, world = this.world(), pos = this.controlBar.cloudButton.bottomLeft(), shiftClicked = 16 === world.currentKey;
    menu = new MenuMorph(this), shiftClicked && (menu.addItem("url...", "setCloudURL", null, new Color(100, 0, 0)), 
    menu.addLine()), SnapCloud.username ? (menu.addItem(localize("Logout") + " " + SnapCloud.username, "logout"), 
    menu.addItem("Change Password...", "changeCloudPassword")) : (menu.addItem("Login...", "initializeCloud"), 
    menu.addItem("Signup...", "createCloudAccount"), menu.addItem("Reset Password...", "resetCloudPassword")), 
    shiftClicked && (menu.addLine(), menu.addItem("export project media only...", function() {
        myself.projectName ? myself.exportProjectMedia(myself.projectName) : myself.prompt("Export Project As...", function(name) {
            myself.exportProjectMedia(name);
        }, null, "exportProject");
    }, null, this.hasChangedMedia ? new Color(100, 0, 0) : new Color(0, 100, 0)), menu.addItem("export project without media...", function() {
        myself.projectName ? myself.exportProjectNoMedia(myself.projectName) : myself.prompt("Export Project As...", function(name) {
            myself.exportProjectNoMedia(name);
        }, null, "exportProject");
    }, null, new Color(100, 0, 0)), menu.addItem("export project as cloud data...", function() {
        myself.projectName ? myself.exportProjectAsCloudData(myself.projectName) : myself.prompt("Export Project As...", function(name) {
            myself.exportProjectAsCloudData(name);
        }, null, "exportProject");
    }, null, new Color(100, 0, 0)), menu.addLine(), menu.addItem("open shared project from cloud...", function() {
        myself.prompt("Author name…", function(usr) {
            myself.prompt("Project name...", function(prj) {
                var id = "Username=" + encodeURIComponent(usr.toLowerCase()) + "&ProjectName=" + encodeURIComponent(prj);
                myself.showMessage("Fetching project\nfrom the cloud..."), SnapCloud.getPublicProject(id, function(projectData) {
                    var msg;
                    Process.prototype.isCatchingErrors || window.open("data:text/xml," + projectData), 
                    myself.nextSteps([ function() {
                        msg = myself.showMessage("Opening project...");
                    }, function() {
                        nop();
                    }, function() {
                        myself.rawOpenCloudDataString(projectData);
                    }, function() {
                        msg.destroy();
                    } ]);
                }, myself.cloudError());
            }, null, "project");
        }, null, "project");
    }, null, new Color(100, 0, 0))), menu.popup(world, pos);
}, IDE_Morph.prototype.settingsMenu = function() {
    this.stage;
    var menu, world = this.world(), myself = this, pos = this.controlBar.settingsButton.bottomLeft(), shiftClicked = 16 === world.currentKey;
    function addPreference(label, toggle, test, onHint, offHint, hide) {
        hide && !shiftClicked || menu.addItem((test ? "☑ " : "☐ ") + localize(label), toggle, test ? onHint : offHint, hide ? new Color(100, 0, 0) : null);
    }
    (menu = new MenuMorph(this)).addItem("Zoom blocks...", "userSetBlocksScale"), menu.addLine(), 
    addPreference("Blurred shadows", "toggleBlurredShadows", useBlurredShadows, "uncheck to use solid drop\nshadows and highlights", "check to use blurred drop\nshadows and highlights", !0), 
    addPreference("Zebra coloring", "toggleZebraColoring", BlockMorph.prototype.zebraContrast, "uncheck to disable alternating\ncolors for nested block", "check to enable alternating\ncolors for nested blocks", !0), 
    addPreference("Dynamic input labels", "toggleDynamicInputLabels", SyntaxElementMorph.prototype.dynamicInputLabels, "uncheck to disable dynamic\nlabels for variadic inputs", "check to enable dynamic\nlabels for variadic inputs", !0), 
    addPreference("Prefer empty slot drops", "togglePreferEmptySlotDrops", ScriptsMorph.prototype.isPreferringEmptySlots, "uncheck to allow dropped\nreporters to kick out others", "settings menu prefer empty slots hint", !0), 
    addPreference("Virtual keyboard", "toggleVirtualKeyboard", MorphicPreferences.useVirtualKeyboard, "uncheck to disable\nvirtual keyboard support\nfor mobile devices", "check to enable\nvirtual keyboard support\nfor mobile devices", !0), 
    addPreference("Input sliders", "toggleInputSliders", MorphicPreferences.useSliderForInput, "uncheck to disable\ninput sliders for\nentry fields", "check to enable\ninput sliders for\nentry fields"), 
    MorphicPreferences.useSliderForInput && addPreference("Execute on slider change", "toggleSliderExecute", InputSlotMorph.prototype.executeOnSliderEdit, "uncheck to supress\nrunning scripts\nwhen moving the slider", "check to run\nthe edited script\nwhen moving the slider"), 
    addPreference("Clicking sound", function() {
        BlockMorph.prototype.toggleSnapSound(), BlockMorph.prototype.snapSound ? myself.saveSetting("click", !0) : myself.removeSetting("click");
    }, BlockMorph.prototype.snapSound, "uncheck to turn\nblock clicking\nsound off", "check to turn\nblock clicking\nsound on"), 
    addPreference("Animations", function() {
        myself.isAnimating = !myself.isAnimating;
    }, myself.isAnimating, "uncheck to disable\nIDE animations", "check to enable\nIDE animations", !0), 
    addPreference("Turbo mode", "toggleFastTracking", this.stage.isFastTracked, "uncheck to run scripts\nat normal speed", "check to prioritize\nscript execution"), 
    addPreference("Rasterize SVGs", function() {
        MorphicPreferences.rasterizeSVGs = !MorphicPreferences.rasterizeSVGs;
    }, MorphicPreferences.rasterizeSVGs, "uncheck for smooth\nscaling of vector costumes", "check to rasterize\nSVGs on import", !0), 
    addPreference("Sprite Nesting", function() {
        SpriteMorph.prototype.enableNesting = !SpriteMorph.prototype.enableNesting;
    }, SpriteMorph.prototype.enableNesting, "uncheck to disable\nsprite composition", "check to enable\nsprite composition", !0), 
    menu.addLine(), addPreference("Prefer smooth animations", "toggleVariableFrameRate", StageMorph.prototype.frameRate, "uncheck for greater speed\nat variable frame rates", "check for smooth, predictable\nanimations across computers"), 
    addPreference("Flat line ends", function() {
        SpriteMorph.prototype.useFlatLineEnds = !SpriteMorph.prototype.useFlatLineEnds;
    }, SpriteMorph.prototype.useFlatLineEnds, "uncheck for round ends of lines", "check for flat ends of lines"), 
    menu.popup(world, pos);
}, IDE_Morph.prototype.projectMenu = function() {
    var menu, myself = this, world = this.world(), pos = this.controlBar.projectButton.bottomLeft(), graphicsName = this.currentSprite instanceof SpriteMorph ? "Costumes" : "Backgrounds";
    world.currentKey;
    (menu = new MenuMorph(this)).addItem(localize(graphicsName) + "...", function() {
        var dir = "/assets/apps/snap/" + graphicsName, names = myself.getCostumesList(dir), libMenu = new MenuMorph(myself, localize("Import") + " " + localize(graphicsName));
        names.forEach(function(line) {
            line.length > 0 && libMenu.addItem(line, function() {
                !function(name) {
                    var url = dir + "/" + name, img = new Image();
                    img.onload = function() {
                        var canvas = newCanvas(new Point(img.width, img.height));
                        canvas.getContext("2d").drawImage(img, 0, 0), myself.droppedImage(canvas, name);
                    }, img.src = url;
                }(line);
            });
        }), libMenu.popup(world, pos);
    }, "Select a costume from the media library"), menu.addItem(localize("Sounds") + "...", function() {
        var names = this.getCostumesList("/assets/apps/snap/Sounds/"), libMenu = new MenuMorph(this, "Import sound");
        names.forEach(function(line) {
            line.length > 0 && libMenu.addItem(line, function() {
                !function(name) {
                    var url = "/assets/apps/snap/Sounds/" + name, audio = new Audio();
                    audio.src = url, audio.load(), myself.droppedAudio(audio, name);
                }(line);
            });
        }), libMenu.popup(world, pos);
    }, "Select a sound from the media library"), menu.popup(world, pos);
}, IDE_Morph.prototype.getCostumesList = function(dirname) {
    var costumes = [];
    return this.getURL(dirname).split("\n").forEach(function(line) {
        var endIdx, name, startIdx = line.search(new RegExp('href="[^./?].*"'));
        startIdx > 0 && (endIdx = (name = line.substring(startIdx + 6)).search(new RegExp('"')), 
        name = name.substring(0, endIdx), costumes.push(name));
    }), costumes.sort(function(x, y) {
        return x < y ? -1 : 1;
    }), costumes;
}, IDE_Morph.prototype.aboutSnap = function() {
    var dlg, aboutTxt, noticeTxt, creditsTxt, translations, module, btn1, btn2, btn3, btn4, licenseBtn, translatorsBtn, versions = "", world = this.world();
    aboutTxt = "Snap! 4.0\nBuild Your Own Blocks\n\n--- beta ---\n\nCopyright Ⓒ 2015 Jens Mönig and Brian Harvey\njens@moenig.org, bh@cs.berkeley.edu\n\nSnap! is developed by the University of California, Berkeley\n          with support from the National Science Foundation, MioSoft,     \nand the Communications Design Group at SAP Labs. \nThe design of Snap! is influenced and inspired by Scratch,\nfrom the Lifelong Kindergarten group at the MIT Media Lab\n\nfor more information see http://snap.berkeley.edu\nand http://scratch.mit.edu", 
    noticeTxt = localize("License") + "\n\nSnap! is free software: you can redistribute it and/or modify\nit under the terms of the GNU Affero General Public License as\npublished by the Free Software Foundation, either version 3 of\nthe License, or (at your option) any later version.\n\nThis program is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the\nGNU Affero General Public License for more details.\n\nYou should have received a copy of the\nGNU Affero General Public License along with this program.\nIf not, see http://www.gnu.org/licenses/", 
    creditsTxt = localize("Contributors") + '\n\nNathan Dinsmore: Saving/Loading, Snap-Logo Design, countless bugfixes\nKartik Chandra: Paint Editor\nMichael Ball: Time/Date UI, many bugfixes\n"Ava" Yuan Yuan: Graphic Effects\nKyle Hotchkiss: Block search design\nIan Reynolds: UI Design, Event Bindings, Sound primitives\nIvan Motyashov: Initial Squeak Porting\nDavide Della Casa: Morphic Optimizations\nAchal Dave: Web Audio\nJoe Otto: Morphic Testing and Debugging';
    for (module in modules) Object.prototype.hasOwnProperty.call(modules, module) && (versions += "\n" + module + " (" + modules[module] + ")");
    "" !== versions && (versions = localize("current module versions:") + " \n\nmorphic (" + morphicVersion + ")" + versions), 
    translations = localize("Translations") + "\n" + SnapTranslator.credits(), (dlg = new DialogBoxMorph()).inform("About Snap", aboutTxt, world), 
    btn1 = dlg.buttons.children[0], translatorsBtn = dlg.addButton(function() {
        dlg.body.text = translations, dlg.body.drawNew(), btn1.show(), btn2.show(), btn3.hide(), 
        btn4.hide(), licenseBtn.hide(), translatorsBtn.hide(), dlg.fixLayout(), dlg.drawNew(), 
        dlg.setCenter(world.center());
    }, "Translators..."), (btn2 = dlg.addButton(function() {
        dlg.body.text = aboutTxt, dlg.body.drawNew(), btn1.show(), btn2.hide(), btn3.show(), 
        btn4.show(), licenseBtn.show(), translatorsBtn.hide(), dlg.fixLayout(), dlg.drawNew(), 
        dlg.setCenter(world.center());
    }, "Back...")).hide(), licenseBtn = dlg.addButton(function() {
        dlg.body.text = noticeTxt, dlg.body.drawNew(), btn1.show(), btn2.show(), btn3.hide(), 
        btn4.hide(), licenseBtn.hide(), translatorsBtn.hide(), dlg.fixLayout(), dlg.drawNew(), 
        dlg.setCenter(world.center());
    }, "License..."), btn3 = dlg.addButton(function() {
        dlg.body.text = versions, dlg.body.drawNew(), btn1.show(), btn2.show(), btn3.hide(), 
        btn4.hide(), licenseBtn.hide(), translatorsBtn.hide(), dlg.fixLayout(), dlg.drawNew(), 
        dlg.setCenter(world.center());
    }, "Modules..."), btn4 = dlg.addButton(function() {
        dlg.body.text = creditsTxt, dlg.body.drawNew(), btn1.show(), btn2.show(), translatorsBtn.show(), 
        btn3.hide(), btn4.hide(), licenseBtn.hide(), dlg.fixLayout(), dlg.drawNew(), dlg.setCenter(world.center());
    }, "Credits..."), translatorsBtn.hide(), dlg.fixLayout(), dlg.drawNew();
}, IDE_Morph.prototype.editProjectNotes = function() {
    var dialog = new DialogBoxMorph().withKey("projectNotes"), frame = new ScrollFrameMorph(), text = new TextMorph(this.projectNotes || ""), ok = dialog.ok, myself = this, world = this.world();
    frame.padding = 6, frame.setWidth(250), frame.acceptsDrops = !1, frame.contents.acceptsDrops = !1, 
    text.setWidth(250 - 2 * frame.padding), text.setPosition(frame.topLeft().add(frame.padding)), 
    text.enableSelecting(), text.isEditable = !0, frame.setHeight(250), frame.fixLayout = nop, 
    frame.edge = InputFieldMorph.prototype.edge, frame.fontSize = InputFieldMorph.prototype.fontSize, 
    frame.typeInPadding = InputFieldMorph.prototype.typeInPadding, frame.contrast = InputFieldMorph.prototype.contrast, 
    frame.drawNew = InputFieldMorph.prototype.drawNew, frame.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, 
    frame.addContents(text), text.drawNew(), dialog.ok = function() {
        myself.projectNotes = text.text, ok.call(this);
    }, dialog.justDropped = function() {
        text.edit();
    }, dialog.labelString = "Project Notes", dialog.createLabel(), dialog.addBody(frame), 
    frame.drawNew(), dialog.addButton("ok", "OK"), dialog.addButton("cancel", "Cancel"), 
    dialog.fixLayout(), dialog.drawNew(), dialog.popUp(world), dialog.setCenter(world.center()), 
    text.edit();
}, IDE_Morph.prototype.newProject = function() {
    this.source = SnapCloud.username ? "cloud" : "local", this.stage && this.stage.destroy(), 
    "#lang:" !== location.hash.substr(0, 6) && (location.hash = ""), this.globalVariables = new VariableFrame(), 
    this.currentSprite = new SpriteMorph(this.globalVariables), this.sprites = new List([ this.currentSprite ]), 
    StageMorph.prototype.dimensions = new Point(480, 360), StageMorph.prototype.hiddenPrimitives = {}, 
    StageMorph.prototype.codeMappings = {}, StageMorph.prototype.codeHeaders = {}, StageMorph.prototype.enableCodeMapping = !1, 
    SpriteMorph.prototype.useFlatLineEnds = !1, this.setProjectName(""), this.projectNotes = "", 
    this.createStage(), this.add(this.stage), this.createCorral(), this.selectSprite(this.stage.children[0]), 
    this.fixLayout();
}, IDE_Morph.prototype.save = function() {
    "examples" === this.source && (this.source = "local"), this.projectName ? "local" === this.source ? this.saveProject(this.projectName) : this.saveProjectToCloud(this.projectName) : this.saveProjectsBrowser();
}, IDE_Morph.prototype.saveProject = function(name) {
    var myself = this;
    this.nextSteps([ function() {
        myself.showMessage("Saving...");
    }, function() {
        myself.rawSaveProject(name);
    } ]);
}, IDE_Morph.prototype.rawSaveProject = function(name) {
    if (name) if (this.setProjectName(name), Process.prototype.isCatchingErrors) try {
        localStorage["-snap-project-" + name] = this.serializer.serialize(this.stage), this.showMessage("Saved!", 1);
    } catch (err) {
        this.showMessage("Save failed: " + err);
    } else localStorage["-snap-project-" + name] = this.serializer.serialize(this.stage), 
    this.showMessage("Saved!", 1);
}, IDE_Morph.prototype.saveProjectToDisk = function() {
    var data, link = document.createElement("a");
    if (Process.prototype.isCatchingErrors) try {
        data = this.serializer.serialize(this.stage), link.setAttribute("href", "data:text/xml," + data), 
        link.setAttribute("download", this.projectName + ".xml"), document.body.appendChild(link), 
        link.click(), document.body.removeChild(link);
    } catch (err) {
        this.showMessage("Saving failed: " + err);
    } else data = this.serializer.serialize(this.stage), link.setAttribute("href", "data:text/xml," + data), 
    link.setAttribute("download", this.projectName + ".xml"), document.body.appendChild(link), 
    link.click(), document.body.removeChild(link);
}, IDE_Morph.prototype.exportProject = function(name, plain) {
    var menu, str;
    if (name) if (this.setProjectName(name), Process.prototype.isCatchingErrors) try {
        menu = this.showMessage("Exporting"), str = encodeURIComponent(this.serializer.serialize(this.stage)), 
        window.open("data:text/" + (plain ? "plain," + str : "xml," + str)), menu.destroy(), 
        this.showMessage("Exported!", 1);
    } catch (err) {
        this.showMessage("Export failed: " + err);
    } else menu = this.showMessage("Exporting"), str = encodeURIComponent(this.serializer.serialize(this.stage)), 
    window.open("data:text/" + (plain ? "plain," + str : "xml," + str)), menu.destroy(), 
    this.showMessage("Exported!", 1);
}, IDE_Morph.prototype.exportGlobalBlocks = function() {
    this.stage.globalBlocks.length > 0 ? new BlockExportDialogMorph(this.serializer, this.stage.globalBlocks).popUp(this.world()) : this.inform("Export blocks", "this project doesn't have any\ncustom global blocks yet");
}, IDE_Morph.prototype.exportSprite = function(sprite) {
    var str = this.serializer.serialize(sprite.allParts());
    window.open('data:text/xml,<sprites app="' + this.serializer.app + '" version="' + this.serializer.version + '">' + str + "</sprites>");
}, IDE_Morph.prototype.exportScriptsPicture = function() {
    var pic, ctx, pics = [], w = 0, h = 0, y = 0;
    this.sprites.asArray().forEach(function(sprite) {
        pics.push(sprite.image), pics.push(sprite.scripts.scriptsPicture()), sprite.customBlocks.forEach(function(def) {
            pics.push(def.scriptsPicture());
        });
    }), pics.push(this.stage.image), pics.push(this.stage.scripts.scriptsPicture()), 
    this.stage.customBlocks.forEach(function(def) {
        pics.push(def.scriptsPicture());
    }), this.stage.globalBlocks.forEach(function(def) {
        pics.push(def.scriptsPicture());
    }), (pics = pics.filter(function(each) {
        return !isNil(each);
    })).forEach(function(each) {
        w = Math.max(w, each.width), h += each.height, h += 20;
    }), pic = newCanvas(new Point(w, h -= 20)), ctx = pic.getContext("2d"), pics.forEach(function(each) {
        ctx.drawImage(each, 0, y), y += 20, y += each.height;
    }), window.open(pic.toDataURL());
}, IDE_Morph.prototype.openProjectString = function(str) {
    var msg, myself = this;
    this.nextSteps([ function() {
        msg = myself.showMessage("Opening project...");
    }, function() {
        nop();
    }, function() {
        myself.rawOpenProjectString(str);
    }, function() {
        msg.destroy();
    } ]);
}, IDE_Morph.prototype.rawOpenProjectString = function(str) {
    if (this.toggleAppMode(!1), this.spriteBar.tabBar.tabTo("scripts"), StageMorph.prototype.hiddenPrimitives = {}, 
    StageMorph.prototype.codeMappings = {}, StageMorph.prototype.codeHeaders = {}, StageMorph.prototype.enableCodeMapping = !1, 
    Process.prototype.isCatchingErrors) try {
        this.serializer.openProject(this.serializer.load(str, this), this);
    } catch (err) {
        this.showMessage("Load failed: " + err);
    } else this.serializer.openProject(this.serializer.load(str, this), this);
    this.stopFastTracking();
}, IDE_Morph.prototype.openCloudDataString = function(str) {
    var msg, myself = this;
    this.nextSteps([ function() {
        msg = myself.showMessage("Opening project...");
    }, function() {
        nop();
    }, function() {
        myself.rawOpenCloudDataString(str);
    }, function() {
        msg.destroy();
    } ]);
}, IDE_Morph.prototype.rawOpenCloudDataString = function(str) {
    var model;
    if (StageMorph.prototype.hiddenPrimitives = {}, StageMorph.prototype.codeMappings = {}, 
    StageMorph.prototype.codeHeaders = {}, StageMorph.prototype.enableCodeMapping = !1, 
    Process.prototype.isCatchingErrors) try {
        model = this.serializer.parse(str), this.serializer.loadMediaModel(model.childNamed("media")), 
        this.serializer.openProject(this.serializer.loadProjectModel(model.childNamed("project"), this), this);
    } catch (err) {
        this.showMessage("Load failed: " + err);
    } else model = this.serializer.parse(str), this.serializer.loadMediaModel(model.childNamed("media")), 
    this.serializer.openProject(this.serializer.loadProjectModel(model.childNamed("project"), this), this);
    this.stopFastTracking();
}, IDE_Morph.prototype.openBlocksString = function(str, name, silently) {
    var msg, myself = this;
    this.nextSteps([ function() {
        msg = myself.showMessage("Opening blocks...");
    }, function() {
        nop();
    }, function() {
        myself.rawOpenBlocksString(str, name, silently);
    }, function() {
        msg.destroy();
    } ]);
}, IDE_Morph.prototype.rawOpenBlocksString = function(str, name, silently) {
    var blocks, myself = this;
    if (Process.prototype.isCatchingErrors) try {
        blocks = this.serializer.loadBlocks(str, myself.stage);
    } catch (err) {
        this.showMessage("Load failed: " + err);
    } else blocks = this.serializer.loadBlocks(str, myself.stage);
    silently ? (blocks.forEach(function(def) {
        def.receiver = myself.stage, myself.stage.globalBlocks.push(def), myself.stage.replaceDoubleDefinitionsFor(def);
    }), this.flushPaletteCache(), this.refreshPalette(), this.showMessage("Imported Blocks Module" + (name ? ": " + name : "") + ".", 2)) : new BlockImportDialogMorph(blocks, this.stage, name).popUp();
}, IDE_Morph.prototype.openSpritesString = function(str) {
    var msg, myself = this;
    this.nextSteps([ function() {
        msg = myself.showMessage("Opening sprite...");
    }, function() {
        nop();
    }, function() {
        myself.rawOpenSpritesString(str);
    }, function() {
        msg.destroy();
    } ]);
}, IDE_Morph.prototype.rawOpenSpritesString = function(str) {
    if (Process.prototype.isCatchingErrors) try {
        this.serializer.loadSprites(str, this);
    } catch (err) {
        this.showMessage("Load failed: " + err);
    } else this.serializer.loadSprites(str, this);
}, IDE_Morph.prototype.openMediaString = function(str) {
    if (Process.prototype.isCatchingErrors) try {
        this.serializer.loadMedia(str);
    } catch (err) {
        this.showMessage("Load failed: " + err);
    } else this.serializer.loadMedia(str);
    this.showMessage("Imported Media Module.", 2);
}, IDE_Morph.prototype.openProject = function(name) {
    var str;
    name && (this.showMessage("opening project\n" + name), this.setProjectName(name), 
    str = localStorage["-snap-project-" + name], this.openProjectString(str));
}, IDE_Morph.prototype.switchToUserMode = function() {
    var world = this.world();
    world.isDevMode = !1, Process.prototype.isCatchingErrors = !0, this.controlBar.updateLabel(), 
    this.isAutoFill = !0, this.isDraggable = !1, this.reactToWorldResize(world.bounds.copy()), 
    this.siblings().forEach(function(morph) {
        morph instanceof DialogBoxMorph ? world.add(morph) : morph.destroy();
    }), this.flushBlocksCache(), this.refreshPalette(), world.reactToDropOf = function(morph) {
        morph instanceof DialogBoxMorph || world.hand.grab(morph);
    }, this.showMessage("entering user mode", 1);
}, IDE_Morph.prototype.switchToDevMode = function() {
    var world = this.world();
    world.isDevMode = !0, Process.prototype.isCatchingErrors = !1, this.controlBar.updateLabel(), 
    this.isAutoFill = !1, this.isDraggable = !0, this.setExtent(world.extent().subtract(100)), 
    this.setPosition(world.position().add(20)), this.flushBlocksCache(), this.refreshPalette(), 
    delete world.reactToDropOf, this.showMessage("entering development mode.\n\nerror catching is turned off,\nuse the browser's web console\nto see error messages.");
}, IDE_Morph.prototype.flushBlocksCache = function(category) {
    category ? (this.stage.blocksCache[category] = null, this.stage.children.forEach(function(m) {
        m instanceof SpriteMorph && (m.blocksCache[category] = null);
    })) : (this.stage.blocksCache = {}, this.stage.children.forEach(function(m) {
        m instanceof SpriteMorph && (m.blocksCache = {});
    })), this.flushPaletteCache(category);
}, IDE_Morph.prototype.flushPaletteCache = function(category) {
    category ? (this.stage.paletteCache[category] = null, this.stage.children.forEach(function(m) {
        m instanceof SpriteMorph && (m.paletteCache[category] = null);
    })) : (this.stage.paletteCache = {}, this.stage.children.forEach(function(m) {
        m instanceof SpriteMorph && (m.paletteCache = {});
    }));
}, IDE_Morph.prototype.toggleZebraColoring = function() {
    var scripts = [];
    BlockMorph.prototype.zebraContrast ? BlockMorph.prototype.zebraContrast = 0 : BlockMorph.prototype.zebraContrast = 40, 
    this.stage.children.concat(this.stage).forEach(function(morph) {
        (morph instanceof SpriteMorph || morph instanceof StageMorph) && (scripts = scripts.concat(morph.scripts.children.filter(function(morph) {
            return morph instanceof BlockMorph;
        })));
    }), scripts.forEach(function(topBlock) {
        topBlock.fixBlockColor(null, !0);
    });
}, IDE_Morph.prototype.toggleDynamicInputLabels = function() {
    var projectData;
    if (SyntaxElementMorph.prototype.dynamicInputLabels = !SyntaxElementMorph.prototype.dynamicInputLabels, 
    Process.prototype.isCatchingErrors) try {
        projectData = this.serializer.serialize(this.stage);
    } catch (err) {
        this.showMessage("Serialization failed: " + err);
    } else projectData = this.serializer.serialize(this.stage);
    SpriteMorph.prototype.initBlocks(), this.spriteBar.tabBar.tabTo("scripts"), this.createCategories(), 
    this.createCorralBar(), this.openProjectString(projectData);
}, IDE_Morph.prototype.toggleBlurredShadows = function() {
    window.useBlurredShadows = !useBlurredShadows;
}, IDE_Morph.prototype.toggleLongFormInputDialog = function() {
    InputSlotDialogMorph.prototype.isLaunchingExpanded = !InputSlotDialogMorph.prototype.isLaunchingExpanded, 
    InputSlotDialogMorph.prototype.isLaunchingExpanded ? this.saveSetting("longform", !0) : this.removeSetting("longform");
}, IDE_Morph.prototype.togglePlainPrototypeLabels = function() {
    BlockLabelPlaceHolderMorph.prototype.plainLabel = !BlockLabelPlaceHolderMorph.prototype.plainLabel, 
    BlockLabelPlaceHolderMorph.prototype.plainLabel ? this.saveSetting("plainprototype", !0) : this.removeSetting("plainprototype");
}, IDE_Morph.prototype.togglePreferEmptySlotDrops = function() {
    ScriptsMorph.prototype.isPreferringEmptySlots = !ScriptsMorph.prototype.isPreferringEmptySlots;
}, IDE_Morph.prototype.toggleVirtualKeyboard = function() {
    MorphicPreferences.useVirtualKeyboard = !MorphicPreferences.useVirtualKeyboard;
}, IDE_Morph.prototype.toggleInputSliders = function() {
    MorphicPreferences.useSliderForInput = !MorphicPreferences.useSliderForInput;
}, IDE_Morph.prototype.toggleSliderExecute = function() {
    InputSlotMorph.prototype.executeOnSliderEdit = !InputSlotMorph.prototype.executeOnSliderEdit;
}, IDE_Morph.prototype.toggleAppMode = function(appMode) {
    var world = this.world(), elements = [ this.logo, this.controlBar.projectButton, this.controlBar.settingsButton, this.controlBar.stageSizeButton, this.corral, this.corralBar, this.spriteEditor, this.spriteBar, this.palette, this.categories ];
    this.isAppMode = isNil(appMode) ? !this.isAppMode : appMode, Morph.prototype.trackChanges = !1, 
    this.isAppMode ? (this.setColor(this.appModeColor), this.controlBar.setColor(this.color), 
    this.controlBar.appModeButton.refresh(), elements.forEach(function(e) {
        e.hide();
    }), world.children.forEach(function(morph) {
        morph instanceof DialogBoxMorph && morph.hide();
    })) : (this.setColor(this.backgroundColor), this.controlBar.setColor(this.frameColor), 
    elements.forEach(function(e) {
        e.show();
    }), this.stage.setScale(1), world.children.forEach(function(morph) {
        morph instanceof DialogBoxMorph && morph.show();
    }), world.allChildren().filter(function(c) {
        return c instanceof ScrollFrameMorph;
    }).forEach(function(s) {
        s.adjustScrollBars();
    }), this.currentSprite === this.stage && this.spriteBar.children.forEach(function(child) {
        child instanceof PushButtonMorph && child.hide();
    })), this.setExtent(this.world().extent());
}, IDE_Morph.prototype.toggleStageSize = function(isSmall) {
    var myself = this, smallRatio = .5, world = this.world();
    function toggle() {
        myself.isSmallStage = isNil(isSmall) ? !myself.isSmallStage : isSmall;
    }
    16 === world.currentKey ? (smallRatio = 3 * SpriteIconMorph.prototype.thumbSize.x / this.stage.dimensions.x, 
    this.isSmallStage && smallRatio !== this.stageRatio || toggle()) : toggle(), this.isAnimating ? this.isSmallStage ? myself.step = function() {
        myself.stageRatio -= (myself.stageRatio - smallRatio) / 2, myself.setExtent(world.extent()), 
        myself.stageRatio < smallRatio + .1 && (myself.stageRatio = smallRatio, myself.setExtent(world.extent()), 
        delete myself.step);
    } : (myself.isSmallStage = !0, myself.step = function() {
        myself.stageRatio += (1 - myself.stageRatio) / 2, myself.setExtent(world.extent()), 
        myself.stageRatio > .9 && (myself.stageRatio = 1, myself.isSmallStage = !1, myself.setExtent(world.extent()), 
        myself.controlBar.stageSizeButton.refresh(), delete myself.step);
    }) : (this.isSmallStage && (this.stageRatio = smallRatio), this.setExtent(world.extent()));
}, IDE_Morph.prototype.createNewProject = function() {
    var myself = this;
    this.confirm("Replace the current project with a new one?", "New Project", function() {
        myself.newProject();
    });
}, IDE_Morph.prototype.openProjectsBrowser = function() {
    new ProjectDialogMorph(this, "open").popUp();
}, IDE_Morph.prototype.saveProjectsBrowser = function() {
    "examples" === this.source && (this.source = "local"), new ProjectDialogMorph(this, "save").popUp();
}, IDE_Morph.prototype.languageMenu = function() {
    var menu = new MenuMorph(this), world = this.world(), pos = this.controlBar.settingsButton.bottomLeft(), myself = this;
    SnapTranslator.languages().forEach(function(lang) {
        menu.addItem((SnapTranslator.language === lang ? "✓ " : "    ") + SnapTranslator.languageName(lang), function() {
            myself.setLanguage(lang);
        });
    }), menu.popup(world, pos);
}, IDE_Morph.prototype.setLanguage = function(lang, callback) {
    var translation = document.getElementById("language"), src = "/assets/apps/snap/lang-" + lang + ".js", myself = this;
    if (SnapTranslator.unload(), translation && document.head.removeChild(translation), 
    "en" === lang) return this.reflectLanguage("en", callback);
    (translation = document.createElement("script")).id = "language", translation.onload = function() {
        myself.reflectLanguage(lang, callback);
    }, document.head.appendChild(translation), translation.src = src;
}, IDE_Morph.prototype.reflectLanguage = function(lang, callback) {
    var projectData;
    if (SnapTranslator.language = lang, !this.loadNewProject) if (Process.prototype.isCatchingErrors) try {
        projectData = this.serializer.serialize(this.stage);
    } catch (err) {
        this.showMessage("Serialization failed: " + err);
    } else projectData = this.serializer.serialize(this.stage);
    SpriteMorph.prototype.initBlocks(), this.spriteBar.tabBar.tabTo("scripts"), this.createCategories(), 
    this.createCorralBar(), this.fixLayout(), this.loadNewProject ? this.newProject() : this.openProjectString(projectData), 
    this.saveSetting("language", lang), callback && callback.call(this);
}, IDE_Morph.prototype.userSetBlocksScale = function() {
    var scrpt, blck, shield, sample, action, myself = this;
    (scrpt = new CommandBlockMorph()).color = SpriteMorph.prototype.blockColor.motion, 
    scrpt.setSpec(localize("build")), (blck = new CommandBlockMorph()).color = SpriteMorph.prototype.blockColor.sound, 
    blck.setSpec(localize("your own")), scrpt.nextBlock(blck), (blck = new CommandBlockMorph()).color = SpriteMorph.prototype.blockColor.operators, 
    blck.setSpec(localize("blocks")), scrpt.bottomBlock().nextBlock(blck), (sample = new FrameMorph()).acceptsDrops = !1, 
    sample.color = IDE_Morph.prototype.groupColor, sample.cachedTexture = this.scriptsPaneTexture, 
    sample.setExtent(new Point(250, 180)), scrpt.setPosition(sample.position().add(10)), 
    sample.add(scrpt), (shield = new Morph()).alpha = 0, shield.setExtent(sample.extent()), 
    shield.setPosition(sample.position()), sample.add(shield), action = function(num) {
        scrpt.blockSequence().forEach(function(block) {
            block.setScale(num), block.drawNew(), block.setSpec(block.blockSpec);
        });
    }, new DialogBoxMorph(null, function(num) {
        myself.setBlocksScale(Math.min(num, 12));
    }).withKey("zoomBlocks").prompt("Zoom blocks", SyntaxElementMorph.prototype.scale.toString(), this.world(), sample, {
        "normal (1x)": 1,
        "demo (1.2x)": 1.2,
        "presentation (1.4x)": 1.4,
        "big (2x)": 2,
        "huge (4x)": 4,
        "giant (8x)": 8,
        "monstrous (10x)": 10
    }, !1, !0, 1, 12, action);
}, IDE_Morph.prototype.setBlocksScale = function(num) {
    var projectData;
    if (Process.prototype.isCatchingErrors) try {
        projectData = this.serializer.serialize(this.stage);
    } catch (err) {
        this.showMessage("Serialization failed: " + err);
    } else projectData = this.serializer.serialize(this.stage);
    SyntaxElementMorph.prototype.setScale(num), CommentMorph.prototype.refreshScale(), 
    SpriteMorph.prototype.initBlocks(), this.spriteBar.tabBar.tabTo("scripts"), this.createCategories(), 
    this.createCorralBar(), this.fixLayout(), this.openProjectString(projectData), this.saveSetting("zoom", num);
}, IDE_Morph.prototype.userSetStageSize = function() {
    new DialogBoxMorph(this, this.setStageExtent, this).promptVector("Stage size", StageMorph.prototype.dimensions, new Point(480, 360), "Stage width", "Stage height", this.world(), null, null);
}, IDE_Morph.prototype.setStageExtent = function(aPoint) {
    var myself = this, world = this.world(), ext = aPoint.max(new Point(480, 180));
    this.stageRatio = 1, this.isSmallStage = !1, this.controlBar.stageSizeButton.refresh(), 
    this.setExtent(world.extent()), this.isAnimating ? myself.step = function() {
        var delta = ext.subtract(StageMorph.prototype.dimensions).divideBy(2);
        delta.abs().lt(new Point(5, 5)) ? (StageMorph.prototype.dimensions = ext, delete myself.step) : StageMorph.prototype.dimensions = StageMorph.prototype.dimensions.add(delta), 
        myself.stage.setExtent(StageMorph.prototype.dimensions), myself.stage.clearPenTrails(), 
        myself.fixLayout(), this.setExtent(world.extent());
    } : (StageMorph.prototype.dimensions = ext, this.stage.setExtent(StageMorph.prototype.dimensions), 
    this.stage.clearPenTrails(), this.fixLayout(), this.setExtent(world.extent()));
}, IDE_Morph.prototype.initializeCloud = function() {
    var myself = this, world = this.world();
    new DialogBoxMorph(null, function(user) {
        var str, pwh = hex_sha512(user.password);
        SnapCloud.login(user.username, pwh, function() {
            user.choice && (str = SnapCloud.encodeDict({
                username: user.username,
                password: pwh
            }), localStorage["-snap-user"] = str), myself.source = "cloud", myself.showMessage("now connected.", 2);
        }, myself.cloudError());
    }).withKey("cloudlogin").promptCredentials("Sign in", "login", null, null, null, null, "stay signed in on this computer\nuntil logging out", world, myself.cloudIcon(), myself.cloudMsg);
}, IDE_Morph.prototype.createCloudAccount = function() {
    var myself = this, world = this.world();
    new DialogBoxMorph(null, function(user) {
        SnapCloud.signup(user.username, user.email, function(txt, title) {
            new DialogBoxMorph().inform(title, txt + ".\n\nAn e-mail with your password\nhas been sent to the address provided", world, myself.cloudIcon(null, new Color(0, 180, 0)));
        }, myself.cloudError());
    }).withKey("cloudsignup").promptCredentials("Sign up", "signup", "http://snap.berkeley.edu/tos.html", "Terms of Service...", "http://snap.berkeley.edu/privacy.html", "Privacy...", "I have read and agree\nto the Terms of Service", world, myself.cloudIcon(), myself.cloudMsg);
}, IDE_Morph.prototype.resetCloudPassword = function() {
    var myself = this, world = this.world();
    new DialogBoxMorph(null, function(user) {
        SnapCloud.resetPassword(user.username, function(txt, title) {
            new DialogBoxMorph().inform(title, txt + ".\n\nAn e-mail with a link to\nreset your password\nhas been sent to the address provided", world, myself.cloudIcon(null, new Color(0, 180, 0)));
        }, myself.cloudError());
    }).withKey("cloudresetpassword").promptCredentials("Reset password", "resetPassword", null, null, null, null, null, world, myself.cloudIcon(), myself.cloudMsg);
}, IDE_Morph.prototype.changeCloudPassword = function() {
    var myself = this, world = this.world();
    new DialogBoxMorph(null, function(user) {
        SnapCloud.changePassword(user.oldpassword, user.password, function() {
            myself.logout(), myself.showMessage("password has been changed.", 2);
        }, myself.cloudError());
    }).withKey("cloudpassword").promptCredentials("Change Password", "changePassword", null, null, null, null, null, world, myself.cloudIcon(), myself.cloudMsg);
}, IDE_Morph.prototype.logout = function() {
    var myself = this;
    delete localStorage["-snap-user"], SnapCloud.logout(function() {
        SnapCloud.clear(), myself.showMessage("disconnected.", 2);
    }, function() {
        SnapCloud.clear(), myself.showMessage("disconnected.", 2);
    });
}, IDE_Morph.prototype.saveProjectToCloud = function(name) {
    var myself = this;
    name && (this.showMessage("Saving project\nto the cloud..."), this.setProjectName(name), 
    SnapCloud.saveProject(this, function() {
        myself.showMessage("saved.", 2);
    }, this.cloudError()));
}, IDE_Morph.prototype.exportProjectMedia = function(name) {
    var menu, media;
    if (this.serializer.isCollectingMedia = !0, name) if (this.setProjectName(name), 
    Process.prototype.isCatchingErrors) try {
        menu = this.showMessage("Exporting"), encodeURIComponent(this.serializer.serialize(this.stage)), 
        media = encodeURIComponent(this.serializer.mediaXML(name)), window.open("data:text/xml," + media), 
        menu.destroy(), this.showMessage("Exported!", 1);
    } catch (err) {
        this.serializer.isCollectingMedia = !1, this.showMessage("Export failed: " + err);
    } else menu = this.showMessage("Exporting"), encodeURIComponent(this.serializer.serialize(this.stage)), 
    media = encodeURIComponent(this.serializer.mediaXML()), window.open("data:text/xml," + media), 
    menu.destroy(), this.showMessage("Exported!", 1);
    this.serializer.isCollectingMedia = !1, this.serializer.flushMedia();
}, IDE_Morph.prototype.exportProjectNoMedia = function(name) {
    var menu, str;
    if (this.serializer.isCollectingMedia = !0, name) if (this.setProjectName(name), 
    Process.prototype.isCatchingErrors) try {
        menu = this.showMessage("Exporting"), str = encodeURIComponent(this.serializer.serialize(this.stage)), 
        window.open("data:text/xml," + str), menu.destroy(), this.showMessage("Exported!", 1);
    } catch (err) {
        this.serializer.isCollectingMedia = !1, this.showMessage("Export failed: " + err);
    } else menu = this.showMessage("Exporting"), str = encodeURIComponent(this.serializer.serialize(this.stage)), 
    window.open("data:text/xml," + str), menu.destroy(), this.showMessage("Exported!", 1);
    this.serializer.isCollectingMedia = !1, this.serializer.flushMedia();
}, IDE_Morph.prototype.exportProjectAsCloudData = function(name) {
    var menu, str, media, dta;
    if (this.serializer.isCollectingMedia = !0, name) if (this.setProjectName(name), 
    Process.prototype.isCatchingErrors) try {
        menu = this.showMessage("Exporting"), str = encodeURIComponent(this.serializer.serialize(this.stage)), 
        media = encodeURIComponent(this.serializer.mediaXML(name)), dta = encodeURIComponent("<snapdata>") + str + media + encodeURIComponent("</snapdata>"), 
        window.open("data:text/xml," + dta), menu.destroy(), this.showMessage("Exported!", 1);
    } catch (err) {
        this.serializer.isCollectingMedia = !1, this.showMessage("Export failed: " + err);
    } else menu = this.showMessage("Exporting"), str = encodeURIComponent(this.serializer.serialize(this.stage)), 
    media = encodeURIComponent(this.serializer.mediaXML()), dta = encodeURIComponent("<snapdata>") + str + media + encodeURIComponent("</snapdata>"), 
    window.open("data:text/xml," + dta), menu.destroy(), this.showMessage("Exported!", 1);
    this.serializer.isCollectingMedia = !1, this.serializer.flushMedia();
}, IDE_Morph.prototype.cloudAcknowledge = function() {
    var myself = this;
    return function(responseText, url) {
        nop(responseText), new DialogBoxMorph().inform("Cloud Connection", "Successfully connected to:\nhttp://" + url, myself.world(), myself.cloudIcon(null, new Color(0, 180, 0)));
    };
}, IDE_Morph.prototype.cloudResponse = function() {
    var myself = this;
    return function(responseText, url) {
        var response = responseText;
        response.length > 50 && (response = response.substring(0, 50) + "..."), new DialogBoxMorph().inform("Snap!Cloud", "http://" + url + ":\n\nresponds:\n" + response, myself.world(), myself.cloudIcon(null, new Color(0, 180, 0)));
    };
}, IDE_Morph.prototype.cloudError = function() {
    var myself = this;
    return function(responseText, url) {
        var response = responseText;
        myself.shield && (myself.shield.destroy(), myself.shield = null), response.length > 50 && (response = response.substring(0, 50) + "..."), 
        new DialogBoxMorph().inform("Snap!Cloud", (url ? url + "\n" : "") + response, myself.world(), myself.cloudIcon(null, new Color(180, 0, 0)));
    };
}, IDE_Morph.prototype.cloudIcon = function(height, color) {
    var clr = color || DialogBoxMorph.prototype.titleBarColor, isFlat = MorphicPreferences.isFlat, icon = new SymbolMorph(isFlat ? "cloud" : "cloudGradient", height || 50, clr, isFlat ? null : new Point(-1, -1), clr.darker(50));
    return isFlat || icon.addShadow(new Point(1, 1), 1, clr.lighter(95)), icon;
}, IDE_Morph.prototype.setCloudURL = function() {
    new DialogBoxMorph(null, function(url) {
        SnapCloud.url = url;
    }).withKey("cloudURL").prompt("Cloud URL", SnapCloud.url, this.world(), null, {
        "Snap!Cloud": "https://snap.apps.miosoft.com/SnapCloud"
    });
}, IDE_Morph.prototype.getURL = function(url) {
    var request = new XMLHttpRequest(), myself = this;
    try {
        if (request.open("GET", url, !1), request.send(), 200 === request.status) return request.responseText;
        throw new Error("unable to retrieve " + url);
    } catch (err) {
        return void myself.showMessage(err);
    }
}, IDE_Morph.prototype.getURLsbeOrRelative = function(url) {
    var request = new XMLHttpRequest(), myself = this;
    try {
        return request.open("GET", "http://snap.berkeley.edu/snapsource/" + url, !1), request.send(), 
        200 === request.status ? request.responseText : myself.getURL(url);
    } catch (err) {
        return void myself.showMessage(err);
    }
}, IDE_Morph.prototype.showMessage = function(message, secs) {
    var intervalHandle, m = new MenuMorph(null, message);
    return m.popUpCenteredInWorld(this.world()), secs && (intervalHandle = setInterval(function() {
        m.destroy(), clearInterval(intervalHandle);
    }, 1e3 * secs)), m;
}, IDE_Morph.prototype.inform = function(title, message) {
    new DialogBoxMorph().inform(title, localize(message), this.world());
}, IDE_Morph.prototype.confirm = function(message, title, action) {
    new DialogBoxMorph(null, action).askYesNo(title, localize(message), this.world());
}, IDE_Morph.prototype.prompt = function(message, callback, choices, key) {
    new DialogBoxMorph(null, callback).withKey(key).prompt(message, "", this.world(), null, choices);
}, ProjectDialogMorph.prototype = new DialogBoxMorph(), ProjectDialogMorph.prototype.constructor = ProjectDialogMorph, 
ProjectDialogMorph.uber = DialogBoxMorph.prototype;

function ProjectDialogMorph(ide, label) {
    this.init(ide, label);
}

ProjectDialogMorph.prototype.init = function(ide, task) {
    var myself = this;
    this.ide = ide, this.task = task || "open", this.source = ide.source || "local", 
    this.projectList = [], this.handle = null, this.srcBar = null, this.nameField = null, 
    this.listField = null, this.preview = null, this.notesText = null, this.notesField = null, 
    this.deleteButton = null, this.shareButton = null, this.unshareButton = null, ProjectDialogMorph.uber.init.call(this, this, null, null), 
    this.labelString = "save" === this.task ? "Save Project" : "Open Project", this.createLabel(), 
    this.key = "project" + task, this.buildContents(), this.onNextStep = function() {
        myself.setSource(myself.source);
    };
}, ProjectDialogMorph.prototype.buildContents = function() {
    var thumbnail, notification;
    this.addBody(new Morph()), this.body.color = this.color, this.srcBar = new AlignmentMorph("column", this.padding / 2), 
    this.ide.cloudMsg && ((notification = new TextMorph(this.ide.cloudMsg, 10, null, !1, null, null, null, null, new Point(1, 1), new Color(255, 255, 255))).refresh = nop, 
    this.srcBar.add(notification)), this.addSourceButton("cloud", localize("Cloud"), "cloud"), 
    this.addSourceButton("local", localize("Browser"), "storage"), "open" === this.task && this.addSourceButton("examples", localize("Examples"), "poster"), 
    this.srcBar.fixLayout(), this.body.add(this.srcBar), "save" === this.task && (this.nameField = new InputFieldMorph(this.ide.projectName), 
    this.body.add(this.nameField)), this.listField = new ListMorph([]), this.fixListFieldItemColors(), 
    this.listField.fixLayout = nop, this.listField.edge = InputFieldMorph.prototype.edge, 
    this.listField.fontSize = InputFieldMorph.prototype.fontSize, this.listField.typeInPadding = InputFieldMorph.prototype.typeInPadding, 
    this.listField.contrast = InputFieldMorph.prototype.contrast, this.listField.drawNew = InputFieldMorph.prototype.drawNew, 
    this.listField.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, this.body.add(this.listField), 
    this.preview = new Morph(), this.preview.fixLayout = nop, this.preview.edge = InputFieldMorph.prototype.edge, 
    this.preview.fontSize = InputFieldMorph.prototype.fontSize, this.preview.typeInPadding = InputFieldMorph.prototype.typeInPadding, 
    this.preview.contrast = InputFieldMorph.prototype.contrast, this.preview.drawNew = function() {
        InputFieldMorph.prototype.drawNew.call(this), this.texture && this.drawTexture(this.texture);
    }, this.preview.drawCachedTexture = function() {
        this.image.getContext("2d").drawImage(this.cachedTexture, this.edge, this.edge), 
        this.changed();
    }, this.preview.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, this.preview.setExtent(this.ide.serializer.thumbnailSize.add(2 * this.preview.edge)), 
    this.body.add(this.preview), this.preview.drawNew(), "save" === this.task && (thumbnail = this.ide.stage.thumbnail(SnapSerializer.prototype.thumbnailSize), 
    this.preview.texture = null, this.preview.cachedTexture = thumbnail, this.preview.drawCachedTexture()), 
    this.notesField = new ScrollFrameMorph(), this.notesField.fixLayout = nop, this.notesField.edge = InputFieldMorph.prototype.edge, 
    this.notesField.fontSize = InputFieldMorph.prototype.fontSize, this.notesField.typeInPadding = InputFieldMorph.prototype.typeInPadding, 
    this.notesField.contrast = InputFieldMorph.prototype.contrast, this.notesField.drawNew = InputFieldMorph.prototype.drawNew, 
    this.notesField.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, this.notesField.acceptsDrops = !1, 
    this.notesField.contents.acceptsDrops = !1, "open" === this.task ? this.notesText = new TextMorph("") : (this.notesText = new TextMorph(this.ide.projectNotes), 
    this.notesText.isEditable = !0, this.notesText.enableSelecting()), this.notesField.isTextLineWrapping = !0, 
    this.notesField.padding = 3, this.notesField.setContents(this.notesText), this.notesField.setWidth(this.preview.width()), 
    this.body.add(this.notesField), "open" === this.task ? (this.addButton("openProject", "Open"), 
    this.action = "openProject") : (this.addButton("saveProject", "Save"), this.action = "saveProject"), 
    this.shareButton = this.addButton("shareProject", "Share"), this.unshareButton = this.addButton("unshareProject", "Unshare"), 
    this.shareButton.hide(), this.unshareButton.hide(), this.deleteButton = this.addButton("deleteProject", "Delete"), 
    this.addButton("cancel", "Cancel"), notification ? this.setExtent(new Point(455, 335).add(notification.extent())) : this.setExtent(new Point(455, 335)), 
    this.fixLayout();
}, ProjectDialogMorph.prototype.popUp = function(wrrld) {
    var world = wrrld || this.ide.world();
    world && (ProjectDialogMorph.uber.popUp.call(this, world), this.handle = new HandleMorph(this, 350, 300, this.corner, this.corner));
}, ProjectDialogMorph.prototype.addSourceButton = function(source, label, symbol) {
    var button, myself = this, lbl1 = new StringMorph(label, 10, null, !0, null, null, new Point(1, 1), new Color(255, 255, 255)), lbl2 = new StringMorph(label, 10, null, !0, null, null, new Point(-1, -1), this.titleBarColor.darker(50), new Color(255, 255, 255)), l1 = new Morph(), l2 = new Morph();
    lbl1.add(new SymbolMorph(symbol, 24, this.titleBarColor.darker(20), new Point(1, 1), this.titleBarColor.darker(50))), 
    lbl1.children[0].setCenter(lbl1.center()), lbl1.children[0].setBottom(lbl1.top() - this.padding / 2), 
    l1.image = lbl1.fullImage(), l1.bounds = lbl1.fullBounds(), lbl2.add(new SymbolMorph(symbol, 24, new Color(255, 255, 255), new Point(-1, -1), this.titleBarColor.darker(50))), 
    lbl2.children[0].setCenter(lbl2.center()), lbl2.children[0].setBottom(lbl2.top() - this.padding / 2), 
    l2.image = lbl2.fullImage(), l2.bounds = lbl2.fullBounds(), (button = new ToggleButtonMorph(null, myself, function() {
        myself.setSource(source);
    }, [ l1, l2 ], function() {
        return myself.source === source;
    })).corner = this.buttonCorner, button.edge = this.buttonEdge, button.outline = this.buttonOutline, 
    button.outlineColor = this.buttonOutlineColor, button.outlineGradient = this.buttonOutlineGradient, 
    button.labelMinExtent = new Point(60, 0), button.padding = this.buttonPadding, button.contrast = this.buttonContrast, 
    button.pressColor = this.titleBarColor.darker(20), button.drawNew(), button.fixLayout(), 
    button.refresh(), this.srcBar.add(button);
}, ProjectDialogMorph.prototype.fixListFieldItemColors = function() {
    var myself = this;
    this.listField.contents.children[0].alpha = 0, this.listField.contents.children[0].children.forEach(function(item) {
        item.pressColor = myself.titleBarColor.darker(20), item.color = new Color(0, 0, 0, 0), 
        item.noticesTransparentClick = !0;
    });
}, ProjectDialogMorph.prototype.setSource = function(source) {
    var msg, myself = this;
    switch (this.source = source, this.srcBar.children.forEach(function(button) {
        button.refresh();
    }), this.source) {
      case "cloud":
        return msg = myself.ide.showMessage("Updating\nproject list..."), this.projectList = [], 
        void SnapCloud.getProjectList(function(projectList) {
            myself.installCloudProjectList(projectList), msg.destroy();
        }, function(err, lbl) {
            msg.destroy(), myself.ide.cloudError().call(null, err, lbl);
        });

      case "examples":
        this.projectList = this.getExamplesProjectList();
        break;

      case "local":
        this.projectList = this.getLocalProjectList();
    }
    this.listField.destroy(), this.listField = new ListMorph(this.projectList, this.projectList.length > 0 ? function(element) {
        return element.name;
    } : null, null, function() {
        myself.ok();
    }), this.fixListFieldItemColors(), this.listField.fixLayout = nop, this.listField.edge = InputFieldMorph.prototype.edge, 
    this.listField.fontSize = InputFieldMorph.prototype.fontSize, this.listField.typeInPadding = InputFieldMorph.prototype.typeInPadding, 
    this.listField.contrast = InputFieldMorph.prototype.contrast, this.listField.drawNew = InputFieldMorph.prototype.drawNew, 
    this.listField.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, "local" === this.source ? this.listField.action = function(item) {
        var src, xml;
        void 0 !== item && (myself.nameField && myself.nameField.setContents(item.name || ""), 
        "open" === myself.task && (src = localStorage["-snap-project-" + item.name], xml = myself.ide.serializer.parse(src), 
        myself.notesText.text = xml.childNamed("notes").contents || "", myself.notesText.drawNew(), 
        myself.notesField.contents.adjustBounds(), myself.preview.texture = xml.childNamed("thumbnail").contents || null, 
        myself.preview.cachedTexture = null, myself.preview.drawNew()), myself.edit());
    } : this.listField.action = function(item) {
        var src, xml;
        void 0 !== item && (myself.nameField && myself.nameField.setContents(item.name || ""), 
        src = myself.ide.getURL("http://snap.berkeley.edu/snapsource/Examples/" + item.name + ".xml"), 
        xml = myself.ide.serializer.parse(src), myself.notesText.text = xml.childNamed("notes").contents || "", 
        myself.notesText.drawNew(), myself.notesField.contents.adjustBounds(), myself.preview.texture = xml.childNamed("thumbnail").contents || null, 
        myself.preview.cachedTexture = null, myself.preview.drawNew(), myself.edit());
    }, this.body.add(this.listField), this.shareButton.hide(), this.unshareButton.hide(), 
    "local" === this.source ? this.deleteButton.show() : this.deleteButton.hide(), this.buttons.fixLayout(), 
    this.fixLayout(), "open" === this.task && this.clearDetails();
}, ProjectDialogMorph.prototype.getLocalProjectList = function() {
    var stored, dta, projects = [];
    for (stored in localStorage) Object.prototype.hasOwnProperty.call(localStorage, stored) && "-snap-project-" === stored.substr(0, 14) && (dta = {
        name: stored.substr(14),
        thumb: null,
        notes: null
    }, projects.push(dta));
    return projects.sort(function(x, y) {
        return x.name < y.name ? -1 : 1;
    }), projects;
}, ProjectDialogMorph.prototype.getExamplesProjectList = function() {
    var projects = [];
    return this.ide.getURL("http://snap.berkeley.edu/snapsource/Examples/").split("\n").forEach(function(line) {
        var endIdx, dta, startIdx = line.search(new RegExp('href=".*xml"'));
        startIdx > 0 && (endIdx = line.search(new RegExp(".xml")), dta = {
            name: line.substring(startIdx + 6, endIdx),
            thumb: null,
            notes: null
        }, projects.push(dta));
    }), projects.sort(function(x, y) {
        return x.name < y.name ? -1 : 1;
    }), projects;
}, ProjectDialogMorph.prototype.installCloudProjectList = function(pl) {
    var myself = this;
    this.projectList = pl || [], this.projectList.sort(function(x, y) {
        return x.ProjectName < y.ProjectName ? -1 : 1;
    }), this.listField.destroy(), this.listField = new ListMorph(this.projectList, this.projectList.length > 0 ? function(element) {
        return element.ProjectName;
    } : null, [ [ "bold", function(proj) {
        return "true" === proj.Public;
    } ] ], function() {
        myself.ok();
    }), this.fixListFieldItemColors(), this.listField.fixLayout = nop, this.listField.edge = InputFieldMorph.prototype.edge, 
    this.listField.fontSize = InputFieldMorph.prototype.fontSize, this.listField.typeInPadding = InputFieldMorph.prototype.typeInPadding, 
    this.listField.contrast = InputFieldMorph.prototype.contrast, this.listField.drawNew = InputFieldMorph.prototype.drawNew, 
    this.listField.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, this.listField.action = function(item) {
        void 0 !== item && (myself.nameField && myself.nameField.setContents(item.ProjectName || ""), 
        "open" === myself.task && (myself.notesText.text = item.Notes || "", myself.notesText.drawNew(), 
        myself.notesField.contents.adjustBounds(), myself.preview.texture = item.Thumbnail || null, 
        myself.preview.cachedTexture = null, myself.preview.drawNew(), new SpeechBubbleMorph(new TextMorph(localize("last changed") + "\n" + item.Updated, null, null, null, null, "center")).popUp(myself.world(), myself.preview.rightCenter().add(new Point(2, 0)))), 
        "true" === item.Public ? (myself.shareButton.hide(), myself.unshareButton.show()) : (myself.unshareButton.hide(), 
        myself.shareButton.show()), myself.buttons.fixLayout(), myself.fixLayout(), myself.edit());
    }, this.body.add(this.listField), this.shareButton.show(), this.unshareButton.hide(), 
    this.deleteButton.show(), this.buttons.fixLayout(), this.fixLayout(), "open" === this.task && this.clearDetails();
}, ProjectDialogMorph.prototype.clearDetails = function() {
    this.notesText.text = "", this.notesText.drawNew(), this.notesField.contents.adjustBounds(), 
    this.preview.texture = null, this.preview.cachedTexture = null, this.preview.drawNew();
}, ProjectDialogMorph.prototype.openProject = function() {
    var src, proj = this.listField.selected;
    proj && (this.ide.source = this.source, "cloud" === this.source ? this.openCloudProject(proj) : "examples" === this.source ? (src = this.ide.getURL("http://snap.berkeley.edu/snapsource/Examples/" + proj.name + ".xml"), 
    this.ide.openProjectString(src), this.destroy()) : (this.ide.openProject(proj.name), 
    this.destroy()));
}, ProjectDialogMorph.prototype.openCloudProject = function(project) {
    var myself = this;
    myself.ide.nextSteps([ function() {
        myself.ide.showMessage("Fetching project\nfrom the cloud...");
    }, function() {
        myself.rawOpenCloudProject(project);
    } ]);
}, ProjectDialogMorph.prototype.rawOpenCloudProject = function(proj) {
    var myself = this;
    SnapCloud.reconnect(function() {
        SnapCloud.callService("getProject", function(response) {
            SnapCloud.disconnect(), myself.ide.source = "cloud", myself.ide.droppedText(response[0].SourceCode), 
            "true" === proj.Public && (location.hash = "#present:Username=" + encodeURIComponent(SnapCloud.username) + "&ProjectName=" + encodeURIComponent(proj.ProjectName));
        }, myself.ide.cloudError(), [ proj.ProjectName ]);
    }, myself.ide.cloudError()), this.destroy();
}, ProjectDialogMorph.prototype.saveProject = function() {
    var name = this.nameField.contents().text.text, notes = this.notesText.text, myself = this;
    this.ide.projectNotes = notes || this.ide.projectNotes, name && ("cloud" === this.source ? detect(this.projectList, function(item) {
        return item.ProjectName === name;
    }) ? this.ide.confirm(localize("Are you sure you want to replace") + '\n"' + name + '"?', "Replace Project", function() {
        myself.ide.setProjectName(name), myself.saveCloudProject();
    }) : (this.ide.setProjectName(name), myself.saveCloudProject()) : detect(this.projectList, function(item) {
        return item.name === name;
    }) ? this.ide.confirm(localize("Are you sure you want to replace") + '\n"' + name + '"?', "Replace Project", function() {
        myself.ide.setProjectName(name), myself.ide.source = "local", myself.ide.saveProject(name), 
        myself.destroy();
    }) : (this.ide.setProjectName(name), myself.ide.source = "local", this.ide.saveProject(name), 
    this.destroy()));
}, ProjectDialogMorph.prototype.saveCloudProject = function() {
    var myself = this;
    this.ide.showMessage("Saving project\nto the cloud..."), SnapCloud.saveProject(this.ide, function() {
        myself.ide.source = "cloud", myself.ide.showMessage("saved.", 2);
    }, this.ide.cloudError()), this.destroy();
}, ProjectDialogMorph.prototype.deleteProject = function() {
    var proj, idx, name, myself = this;
    "cloud" === this.source ? (proj = this.listField.selected) && this.ide.confirm(localize("Are you sure you want to delete") + '\n"' + proj.ProjectName + '"?', "Delete Project", function() {
        SnapCloud.reconnect(function() {
            SnapCloud.callService("deleteProject", function() {
                SnapCloud.disconnect(), myself.ide.hasChangedMedia = !0, idx = myself.projectList.indexOf(proj), 
                myself.projectList.splice(idx, 1), myself.installCloudProjectList(myself.projectList);
            }, myself.ide.cloudError(), [ proj.ProjectName ]);
        }, myself.ide.cloudError());
    }) : this.listField.selected && (name = this.listField.selected.name, this.ide.confirm(localize("Are you sure you want to delete") + '\n"' + name + '"?', "Delete Project", function() {
        delete localStorage["-snap-project-" + name], myself.setSource(myself.source);
    }));
}, ProjectDialogMorph.prototype.shareProject = function() {
    var myself = this, proj = this.listField.selected, entry = this.listField.active;
    proj && this.ide.confirm(localize("Are you sure you want to publish") + '\n"' + proj.ProjectName + '"?', "Share Project", function() {
        myself.ide.showMessage("sharing\nproject..."), SnapCloud.reconnect(function() {
            SnapCloud.callService("publishProject", function() {
                SnapCloud.disconnect(), proj.Public = "true", myself.unshareButton.show(), myself.shareButton.hide(), 
                entry.label.isBold = !0, entry.label.drawNew(), entry.label.changed(), myself.buttons.fixLayout(), 
                myself.drawNew(), myself.ide.showMessage("shared.", 2);
            }, myself.ide.cloudError(), [ proj.ProjectName ]);
        }, myself.ide.cloudError());
    });
}, ProjectDialogMorph.prototype.unshareProject = function() {
    var myself = this, proj = this.listField.selected, entry = this.listField.active;
    proj && this.ide.confirm(localize("Are you sure you want to unpublish") + '\n"' + proj.ProjectName + '"?', "Unshare Project", function() {
        myself.ide.showMessage("unsharing\nproject..."), SnapCloud.reconnect(function() {
            SnapCloud.callService("unpublishProject", function() {
                SnapCloud.disconnect(), proj.Public = "false", myself.shareButton.show(), myself.unshareButton.hide(), 
                entry.label.isBold = !1, entry.label.drawNew(), entry.label.changed(), myself.buttons.fixLayout(), 
                myself.drawNew(), myself.ide.showMessage("unshared.", 2);
            }, myself.ide.cloudError(), [ proj.ProjectName ]);
        }, myself.ide.cloudError());
    });
}, ProjectDialogMorph.prototype.edit = function() {
    this.nameField && this.nameField.edit();
}, ProjectDialogMorph.prototype.fixLayout = function() {
    var th = fontHeight(this.titleFontSize) + 2 * this.titlePadding, thin = this.padding / 2, oldFlag = Morph.prototype.trackChanges;
    Morph.prototype.trackChanges = !1, this.buttons && this.buttons.children.length > 0 && this.buttons.fixLayout(), 
    this.body && (this.body.setPosition(this.position().add(new Point(this.padding, th + this.padding))), 
    this.body.setExtent(new Point(this.width() - 2 * this.padding, this.height() - 3 * this.padding - th - this.buttons.height())), 
    this.srcBar.setPosition(this.body.position()), this.nameField && (this.nameField.setWidth(this.body.width() - this.srcBar.width() - 6 * this.padding), 
    this.nameField.setLeft(this.srcBar.right() + 3 * this.padding), this.nameField.setTop(this.srcBar.top()), 
    this.nameField.drawNew()), this.listField.setLeft(this.srcBar.right() + this.padding), 
    this.listField.setWidth(this.body.width() - this.srcBar.width() - this.preview.width() - this.padding - thin), 
    this.listField.contents.children[0].adjustWidths(), this.nameField ? (this.listField.setTop(this.nameField.bottom() + this.padding), 
    this.listField.setHeight(this.body.height() - this.nameField.height() - this.padding)) : (this.listField.setTop(this.body.top()), 
    this.listField.setHeight(this.body.height())), this.preview.setRight(this.body.right()), 
    this.nameField ? this.preview.setTop(this.nameField.bottom() + this.padding) : this.preview.setTop(this.body.top()), 
    this.notesField.setTop(this.preview.bottom() + thin), this.notesField.setLeft(this.preview.left()), 
    this.notesField.setHeight(this.body.bottom() - this.preview.bottom() - thin)), this.label && (this.label.setCenter(this.center()), 
    this.label.setTop(this.top() + (th - this.label.height()) / 2)), this.buttons && this.buttons.children.length > 0 && (this.buttons.setCenter(this.center()), 
    this.buttons.setBottom(this.bottom() - this.padding)), Morph.prototype.trackChanges = oldFlag, 
    this.changed();
}, SpriteIconMorph.prototype = new ToggleButtonMorph(), SpriteIconMorph.prototype.constructor = SpriteIconMorph, 
SpriteIconMorph.uber = ToggleButtonMorph.prototype, SpriteIconMorph.prototype.thumbSize = new Point(40, 40), 
SpriteIconMorph.prototype.labelShadowOffset = null, SpriteIconMorph.prototype.labelShadowColor = null, 
SpriteIconMorph.prototype.labelColor = new Color(255, 255, 255), SpriteIconMorph.prototype.fontSize = 9;

function SpriteIconMorph(aSprite, aTemplate) {
    this.init(aSprite, aTemplate);
}

SpriteIconMorph.prototype.init = function(aSprite, aTemplate) {
    var colors, action, query, myself = this;
    aTemplate || (colors = [ IDE_Morph.prototype.groupColor, IDE_Morph.prototype.frameColor, IDE_Morph.prototype.frameColor ]), 
    action = function() {
        var ide = myself.parentThatIsA(IDE_Morph);
        ide && ide.selectSprite(myself.object);
    }, query = function() {
        var ide = myself.parentThatIsA(IDE_Morph);
        return !!ide && ide.currentSprite === myself.object;
    }, this.object = aSprite || new SpriteMorph(), this.version = this.object.version, 
    this.thumbnail = null, this.rotationButton = null, SpriteIconMorph.uber.init.call(this, colors, null, action, this.object.name, query, null, null, aTemplate), 
    this.isDraggable = !0, this.createThumbnail(), this.padding = 2, this.corner = 8, 
    this.fixLayout(), this.fps = 1;
}, SpriteIconMorph.prototype.createThumbnail = function() {
    this.thumbnail && this.thumbnail.destroy(), this.thumbnail = new Morph(), this.thumbnail.setExtent(this.thumbSize), 
    this.object instanceof SpriteMorph ? (this.thumbnail.image = this.object.fullThumbnail(this.thumbSize), 
    this.createRotationButton()) : this.thumbnail.image = this.object.thumbnail(this.thumbSize), 
    this.add(this.thumbnail);
}, SpriteIconMorph.prototype.createLabel = function() {
    var txt;
    this.label && this.label.destroy(), txt = new StringMorph(this.object.name, this.fontSize, this.fontStyle, !0, !1, !1, this.labelShadowOffset, this.labelShadowColor, this.labelColor), 
    this.label = new FrameMorph(), this.label.acceptsDrops = !1, this.label.alpha = 0, 
    this.label.setExtent(txt.extent()), txt.setPosition(this.label.position()), this.label.add(txt), 
    this.add(this.label);
}, SpriteIconMorph.prototype.createRotationButton = function() {
    var button, myself = this;
    this.rotationButton && (this.rotationButton.destroy(), this.roationButton = null), 
    this.object.anchor && ((button = new ToggleButtonMorph(null, null, function() {
        myself.object.rotatesWithAnchor = !myself.object.rotatesWithAnchor;
    }, [ "→", "↻" ], function() {
        return myself.object.rotatesWithAnchor;
    })).corner = 8, button.labelMinExtent = new Point(11, 11), button.padding = 0, button.pressColor = button.color, 
    button.drawNew(), button.fixLayout(), button.refresh(), button.changed(), this.rotationButton = button, 
    this.add(this.rotationButton));
}, SpriteIconMorph.prototype.step = function() {
    this.version !== this.object.version && (this.createThumbnail(), this.createLabel(), 
    this.fixLayout(), this.version = this.object.version, this.refresh());
}, SpriteIconMorph.prototype.fixLayout = function() {
    if (!this.thumbnail || !this.label) return null;
    this.setWidth(this.thumbnail.width() + 2 * this.outline + 2 * this.edge + 2 * this.padding), 
    this.setHeight(this.thumbnail.height() + 2 * this.outline + 2 * this.edge + 3 * this.padding + this.label.height()), 
    this.thumbnail.setCenter(this.center()), this.thumbnail.setTop(this.top() + this.outline + this.edge + this.padding), 
    this.rotationButton && (this.rotationButton.setTop(this.top()), this.rotationButton.setRight(this.right())), 
    this.label.setWidth(Math.min(this.label.children[0].width(), this.thumbnail.width())), 
    this.label.setCenter(this.center()), this.label.setTop(this.thumbnail.bottom() + this.padding);
}, SpriteIconMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this), myself = this;
    return this.object instanceof StageMorph ? (menu.addItem("pic...", function() {
        window.open(myself.object.fullImageClassic().toDataURL());
    }, "open a new window\nwith a picture of the stage"), menu) : this.object instanceof SpriteMorph ? (menu.addItem("show", "showSpriteOnStage"), 
    menu.addLine(), menu.addItem("duplicate", "duplicateSprite"), menu.addItem("delete", "removeSprite"), 
    menu.addLine(), this.object.anchor && menu.addItem(localize("detach from") + " " + this.object.anchor.name, function() {
        myself.object.detachFromAnchor();
    }), this.object.parts.length && menu.addItem("detach all parts", function() {
        myself.object.detachAllParts();
    }), menu.addItem("export...", "exportSprite"), menu) : null;
}, SpriteIconMorph.prototype.duplicateSprite = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    ide && ide.duplicateSprite(this.object);
}, SpriteIconMorph.prototype.removeSprite = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    ide && ide.removeSprite(this.object);
}, SpriteIconMorph.prototype.exportSprite = function() {
    this.object.exportSprite();
}, SpriteIconMorph.prototype.showSpriteOnStage = function() {
    this.object.showOnStage();
}, SpriteIconMorph.prototype.createBackgrounds = function() {
    var context, ext = this.extent();
    if (this.template) return this.image = this.template.image, this.normalImage = this.template.normalImage, 
    this.highlightImage = this.template.highlightImage, this.pressImage = this.template.pressImage, 
    null;
    this.normalImage = newCanvas(ext), context = this.normalImage.getContext("2d"), 
    this.drawBackground(context, this.color), this.highlightImage = newCanvas(ext), 
    context = this.highlightImage.getContext("2d"), this.drawBackground(context, this.highlightColor), 
    this.pressImage = newCanvas(ext), context = this.pressImage.getContext("2d"), this.drawOutline(context), 
    this.drawBackground(context, this.pressColor), this.drawEdges(context, this.pressColor, this.pressColor.lighter(this.contrast), this.pressColor.darker(this.contrast)), 
    this.image = this.normalImage;
}, SpriteIconMorph.prototype.prepareToBeGrabbed = function() {
    var idx, ide = this.parentThatIsA(IDE_Morph);
    this.mouseClickLeft(), ide && (idx = ide.sprites.asArray().indexOf(this.object), 
    ide.sprites.remove(idx + 1), ide.createCorral(), ide.fixLayout());
}, SpriteIconMorph.prototype.wantsDropOf = function(morph) {
    return morph instanceof BlockMorph || morph instanceof CostumeIconMorph || morph instanceof SoundIconMorph;
}, SpriteIconMorph.prototype.reactToDropOf = function(morph, hand) {
    morph instanceof BlockMorph ? this.copyStack(morph) : morph instanceof CostumeIconMorph ? this.copyCostume(morph.object) : morph instanceof SoundIconMorph && this.copySound(morph.object), 
    this.world().add(morph), morph.slideBackTo(hand.grabOrigin);
}, SpriteIconMorph.prototype.copyStack = function(block) {
    var dup = block.fullCopy(), y = Math.max(this.object.scripts.children.map(function(stack) {
        return stack.fullBounds().bottom();
    }).concat([ this.object.scripts.top() ]));
    dup.setPosition(new Point(this.object.scripts.left() + 20, y + 20)), this.object.scripts.add(dup), 
    dup.allComments().forEach(function(comment) {
        comment.align(dup);
    }), this.object.scripts.adjustBounds(), dup.allChildren().forEach(function(morph) {
        morph.definition && !morph.definition.isGlobal && morph.deleteBlock();
    });
}, SpriteIconMorph.prototype.copyCostume = function(costume) {
    var dup = costume.copy();
    dup.name = this.object.newCostumeName(dup.name), this.object.addCostume(dup), this.object.wearCostume(dup);
}, SpriteIconMorph.prototype.copySound = function(sound) {
    var dup = sound.copy();
    this.object.addSound(dup.audio, dup.name);
}, CostumeIconMorph.prototype = new ToggleButtonMorph(), CostumeIconMorph.prototype.constructor = CostumeIconMorph, 
CostumeIconMorph.uber = ToggleButtonMorph.prototype, CostumeIconMorph.prototype.thumbSize = new Point(80, 60), 
CostumeIconMorph.prototype.labelShadowOffset = null, CostumeIconMorph.prototype.labelShadowColor = null, 
CostumeIconMorph.prototype.labelColor = new Color(255, 255, 255), CostumeIconMorph.prototype.fontSize = 9;

function CostumeIconMorph(aCostume, aTemplate) {
    this.init(aCostume, aTemplate);
}

CostumeIconMorph.prototype.init = function(aCostume, aTemplate) {
    var colors, action, query, myself = this;
    aTemplate || (colors = [ IDE_Morph.prototype.groupColor, IDE_Morph.prototype.frameColor, IDE_Morph.prototype.frameColor ]), 
    action = function() {
        var ide = myself.parentThatIsA(IDE_Morph), wardrobe = myself.parentThatIsA(WardrobeMorph);
        ide && ide.currentSprite.wearCostume(myself.object), wardrobe && wardrobe.updateSelection();
    }, query = function() {
        var ide = myself.parentThatIsA(IDE_Morph);
        return !!ide && ide.currentSprite.costume === myself.object;
    }, this.object = aCostume || new Costume(), this.version = this.object.version, 
    this.thumbnail = null, CostumeIconMorph.uber.init.call(this, colors, null, action, this.object.name, query, null, null, aTemplate), 
    this.isDraggable = !0, this.createThumbnail(), this.padding = 2, this.corner = 8, 
    this.fixLayout(), this.fps = 1;
}, CostumeIconMorph.prototype.createThumbnail = SpriteIconMorph.prototype.createThumbnail, 
CostumeIconMorph.prototype.createLabel = SpriteIconMorph.prototype.createLabel, 
CostumeIconMorph.prototype.step = SpriteIconMorph.prototype.step, CostumeIconMorph.prototype.fixLayout = SpriteIconMorph.prototype.fixLayout, 
CostumeIconMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this);
    return this.object instanceof Costume ? (menu.addItem("edit", "editCostume"), 16 === this.world().currentKey && menu.addItem("edit rotation point only...", "editRotationPointOnly", null, new Color(100, 0, 0)), 
    menu.addItem("rename", "renameCostume"), menu.addLine(), menu.addItem("duplicate", "duplicateCostume"), 
    menu.addItem("delete", "removeCostume"), menu.addLine(), menu.addItem("export", "exportCostume"), 
    menu) : null;
}, CostumeIconMorph.prototype.editCostume = function() {
    this.object instanceof SVG_Costume ? this.object.editRotationPointOnly(this.world()) : this.object.edit(this.world(), this.parentThatIsA(IDE_Morph));
}, CostumeIconMorph.prototype.editRotationPointOnly = function() {
    var ide = this.parentThatIsA(IDE_Morph);
    this.object.editRotationPointOnly(this.world()), ide.hasChangedMedia = !0;
}, CostumeIconMorph.prototype.renameCostume = function() {
    var costume = this.object, wardrobe = this.parentThatIsA(WardrobeMorph), ide = this.parentThatIsA(IDE_Morph);
    new DialogBoxMorph(null, function(answer) {
        answer && answer !== costume.name && (costume.name = wardrobe.sprite.newCostumeName(answer, costume), 
        costume.version = Date.now(), ide.hasChangedMedia = !0);
    }).prompt("rename costume", costume.name, this.world());
}, CostumeIconMorph.prototype.duplicateCostume = function() {
    var wardrobe = this.parentThatIsA(WardrobeMorph), ide = this.parentThatIsA(IDE_Morph), newcos = this.object.copy();
    newcos.name = wardrobe.sprite.newCostumeName(newcos.name), wardrobe.sprite.addCostume(newcos), 
    wardrobe.updateList(), ide && ide.currentSprite.wearCostume(newcos);
}, CostumeIconMorph.prototype.removeCostume = function() {
    var wardrobe = this.parentThatIsA(WardrobeMorph), idx = this.parent.children.indexOf(this), ide = this.parentThatIsA(IDE_Morph);
    wardrobe.removeCostumeAt(idx - 2), ide.currentSprite.costume === this.object && ide.currentSprite.wearCostume(null);
}, CostumeIconMorph.prototype.exportCostume = function() {
    this.object instanceof SVG_Costume ? window.open(this.object.contents.src) : window.open(this.object.contents.toDataURL());
}, CostumeIconMorph.prototype.createBackgrounds = SpriteIconMorph.prototype.createBackgrounds, 
CostumeIconMorph.prototype.prepareToBeGrabbed = function() {
    this.mouseClickLeft(), this.removeCostume();
}, TurtleIconMorph.prototype = new ToggleButtonMorph(), TurtleIconMorph.prototype.constructor = TurtleIconMorph, 
TurtleIconMorph.uber = ToggleButtonMorph.prototype, TurtleIconMorph.prototype.thumbSize = new Point(80, 60), 
TurtleIconMorph.prototype.labelShadowOffset = null, TurtleIconMorph.prototype.labelShadowColor = null, 
TurtleIconMorph.prototype.labelColor = new Color(255, 255, 255), TurtleIconMorph.prototype.fontSize = 9;

function TurtleIconMorph(aSpriteOrStage, aTemplate) {
    this.init(aSpriteOrStage, aTemplate);
}

TurtleIconMorph.prototype.init = function(aSpriteOrStage, aTemplate) {
    var colors, action, query, myself = this;
    aTemplate || (colors = [ IDE_Morph.prototype.groupColor, IDE_Morph.prototype.frameColor, IDE_Morph.prototype.frameColor ]), 
    action = function() {
        var ide = myself.parentThatIsA(IDE_Morph), wardrobe = myself.parentThatIsA(WardrobeMorph);
        ide && ide.currentSprite.wearCostume(null), wardrobe && wardrobe.updateSelection();
    }, query = function() {
        var ide = myself.parentThatIsA(IDE_Morph);
        return !!ide && null === ide.currentSprite.costume;
    }, this.object = aSpriteOrStage, this.version = this.object.version, this.thumbnail = null, 
    TurtleIconMorph.uber.init.call(this, colors, null, action, "default", query, null, null, aTemplate), 
    this.isDraggable = !1, this.createThumbnail(), this.padding = 2, this.corner = 8, 
    this.fixLayout();
}, TurtleIconMorph.prototype.createThumbnail = function() {
    var isFlat = MorphicPreferences.isFlat;
    this.thumbnail && this.thumbnail.destroy(), this.object instanceof SpriteMorph ? this.thumbnail = new SymbolMorph("turtle", this.thumbSize.y, this.labelColor, isFlat ? null : new Point(-1, -1), new Color(0, 0, 0)) : this.thumbnail = new SymbolMorph("stage", this.thumbSize.y, this.labelColor, isFlat ? null : new Point(-1, -1), new Color(0, 0, 0)), 
    this.add(this.thumbnail);
}, TurtleIconMorph.prototype.createLabel = function() {
    var txt;
    this.label && this.label.destroy(), txt = new StringMorph(localize(this.object instanceof SpriteMorph ? "Turtle" : "Empty"), this.fontSize, this.fontStyle, !0, !1, !1, this.labelShadowOffset, this.labelShadowColor, this.labelColor), 
    this.label = new FrameMorph(), this.label.acceptsDrops = !1, this.label.alpha = 0, 
    this.label.setExtent(txt.extent()), txt.setPosition(this.label.position()), this.label.add(txt), 
    this.add(this.label);
}, TurtleIconMorph.prototype.fixLayout = SpriteIconMorph.prototype.fixLayout, TurtleIconMorph.prototype.createBackgrounds = SpriteIconMorph.prototype.createBackgrounds, 
TurtleIconMorph.prototype.userMenu = function() {
    var myself = this, menu = new MenuMorph(this, "pen");
    return this.object instanceof StageMorph ? null : (menu.addItem(("tip" === this.object.penPoint ? "●" : "○") + " " + localize("tip"), function() {
        myself.object.penPoint = "tip", myself.object.changed(), myself.object.drawNew(), 
        myself.object.changed();
    }), menu.addItem(("middle" === this.object.penPoint ? "●" : "○") + " " + localize("middle"), function() {
        myself.object.penPoint = "middle", myself.object.changed(), myself.object.drawNew(), 
        myself.object.changed();
    }), menu);
}, WardrobeMorph.prototype = new ScrollFrameMorph(), WardrobeMorph.prototype.constructor = WardrobeMorph, 
WardrobeMorph.uber = ScrollFrameMorph.prototype;

function WardrobeMorph(aSprite, sliderColor) {
    this.init(aSprite, sliderColor);
}

WardrobeMorph.prototype.init = function(aSprite, sliderColor) {
    this.sprite = aSprite || new SpriteMorph(), this.costumesVersion = null, this.spriteVersion = null, 
    WardrobeMorph.uber.init.call(this, null, null, sliderColor), this.fps = 2, this.updateList();
}, WardrobeMorph.prototype.updateList = function() {
    var icon, template, txt, paintbutton, myself = this, x = this.left() + 5, y = this.top() + 5, oldFlag = Morph.prototype.trackChanges, oldPos = this.contents.position();
    this.changed(), oldFlag = Morph.prototype.trackChanges, Morph.prototype.trackChanges = !1, 
    this.contents.destroy(), this.contents = new FrameMorph(this), this.contents.acceptsDrops = !1, 
    this.contents.reactToDropOf = function(icon) {
        myself.reactToDropOf(icon);
    }, this.addBack(this.contents), (icon = new TurtleIconMorph(this.sprite)).setPosition(new Point(x, y)), 
    myself.addContents(icon), y = icon.bottom() + 4, (paintbutton = new PushButtonMorph(this, "paintNew", new SymbolMorph("brush", 15))).padding = 0, 
    paintbutton.corner = 12, paintbutton.color = IDE_Morph.prototype.groupColor, paintbutton.highlightColor = IDE_Morph.prototype.frameColor.darker(50), 
    paintbutton.pressColor = paintbutton.highlightColor, paintbutton.labelMinExtent = new Point(36, 18), 
    paintbutton.labelShadowOffset = new Point(-1, -1), paintbutton.labelShadowColor = paintbutton.highlightColor, 
    paintbutton.labelColor = TurtleIconMorph.prototype.labelColor, paintbutton.contrast = this.buttonContrast, 
    paintbutton.drawNew(), paintbutton.hint = "Paint a new costume", paintbutton.setPosition(new Point(x, y)), 
    paintbutton.fixLayout(), paintbutton.setCenter(icon.center()), paintbutton.setLeft(icon.right() + 16), 
    this.addContents(paintbutton), (txt = new TextMorph(localize("costumes tab help"))).fontSize = 9, 
    txt.setColor(SpriteMorph.prototype.paletteTextColor), txt.setPosition(new Point(x, y)), 
    this.addContents(txt), y = txt.bottom() + 4, this.sprite.costumes.asArray().forEach(function(costume) {
        template = icon = new CostumeIconMorph(costume, template), icon.setPosition(new Point(x, y)), 
        myself.addContents(icon), y = icon.bottom() + 4;
    }), this.costumesVersion = this.sprite.costumes.lastChanged, this.contents.setPosition(oldPos), 
    this.adjustScrollBars(), Morph.prototype.trackChanges = oldFlag, this.changed(), 
    this.updateSelection();
}, WardrobeMorph.prototype.updateSelection = function() {
    this.contents.children.forEach(function(morph) {
        morph.refresh && morph.refresh();
    }), this.spriteVersion = this.sprite.version;
}, WardrobeMorph.prototype.step = function() {
    this.costumesVersion !== this.sprite.costumes.lastChanged && this.updateList(), 
    this.spriteVersion !== this.sprite.version && this.updateSelection();
}, WardrobeMorph.prototype.removeCostumeAt = function(idx) {
    this.sprite.costumes.remove(idx), this.updateList();
}, WardrobeMorph.prototype.paintNew = function() {
    var cos = new Costume(newCanvas(), this.sprite.newCostumeName(localize("Untitled"))), ide = this.parentThatIsA(IDE_Morph), myself = this;
    cos.edit(this.world(), ide, !0, null, function() {
        myself.sprite.addCostume(cos), myself.updateList(), ide && ide.currentSprite.wearCostume(cos);
    });
}, WardrobeMorph.prototype.wantsDropOf = function(morph) {
    return morph instanceof CostumeIconMorph;
}, WardrobeMorph.prototype.reactToDropOf = function(icon) {
    var idx = 0, costume = icon.object, top = icon.top();
    icon.destroy(), this.contents.children.forEach(function(item) {
        item instanceof CostumeIconMorph && item.top() < top - 4 && (idx += 1);
    }), this.sprite.costumes.add(costume, idx + 1), this.updateList(), icon.mouseClickLeft();
}, SoundIconMorph.prototype = new ToggleButtonMorph(), SoundIconMorph.prototype.constructor = SoundIconMorph, 
SoundIconMorph.uber = ToggleButtonMorph.prototype, SoundIconMorph.prototype.thumbSize = new Point(80, 60), 
SoundIconMorph.prototype.labelShadowOffset = null, SoundIconMorph.prototype.labelShadowColor = null, 
SoundIconMorph.prototype.labelColor = new Color(255, 255, 255), SoundIconMorph.prototype.fontSize = 9;

function SoundIconMorph(aSound, aTemplate) {
    this.init(aSound, aTemplate);
}

SoundIconMorph.prototype.init = function(aSound, aTemplate) {
    var colors, action, query;
    aTemplate || (colors = [ IDE_Morph.prototype.groupColor, IDE_Morph.prototype.frameColor, IDE_Morph.prototype.frameColor ]), 
    action = function() {
        nop();
    }, query = function() {
        return !1;
    }, this.object = aSound, this.version = this.object.version, this.thumbnail = null, 
    SoundIconMorph.uber.init.call(this, colors, null, action, this.object.name, query, null, null, aTemplate), 
    this.isDraggable = !0, this.createThumbnail(), this.padding = 2, this.corner = 8, 
    this.fixLayout(), this.fps = 1;
}, SoundIconMorph.prototype.createThumbnail = function() {
    var label;
    this.thumbnail && this.thumbnail.destroy(), this.thumbnail = new Morph(), this.thumbnail.setExtent(this.thumbSize), 
    this.add(this.thumbnail), label = new StringMorph(this.createInfo(), "16", "", !0, !1, !1, this.labelShadowOffset, this.labelShadowColor, new Color(200, 200, 200)), 
    this.thumbnail.add(label), label.setCenter(new Point(40, 15)), this.button = new PushButtonMorph(this, "toggleAudioPlaying", this.object.previewAudio ? "Stop" : "Play"), 
    this.button.drawNew(), this.button.hint = "Play sound", this.button.fixLayout(), 
    this.thumbnail.add(this.button), this.button.setCenter(new Point(40, 40));
}, SoundIconMorph.prototype.createInfo = function() {
    var dur = Math.round(this.object.audio.duration || 0), mod = dur % 60;
    return Math.floor(dur / 60).toString() + ":" + (mod < 10 ? "0" : "") + mod.toString();
}, SoundIconMorph.prototype.toggleAudioPlaying = function() {
    var myself = this;
    this.object.previewAudio ? (this.button.labelString = "Play", this.button.hint = "Play sound", 
    this.object.previewAudio.pause(), this.object.previewAudio.terminated = !0, this.object.previewAudio = null) : (this.button.labelString = "Stop", 
    this.button.hint = "Stop sound", this.object.previewAudio = this.object.play(), 
    this.object.previewAudio.addEventListener("ended", function() {
        myself.audioHasEnded();
    }, !1)), this.button.createLabel();
}, SoundIconMorph.prototype.audioHasEnded = function() {
    this.button.trigger(), this.button.mouseLeave();
}, SoundIconMorph.prototype.createLabel = SpriteIconMorph.prototype.createLabel, 
SoundIconMorph.prototype.fixLayout = SpriteIconMorph.prototype.fixLayout, SoundIconMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this);
    return this.object instanceof Sound ? (menu.addItem("rename", "renameSound"), menu.addItem("delete", "removeSound"), 
    menu) : null;
}, SoundIconMorph.prototype.renameSound = function() {
    var sound = this.object, ide = this.parentThatIsA(IDE_Morph), myself = this;
    new DialogBoxMorph(null, function(answer) {
        answer && answer !== sound.name && (sound.name = answer, sound.version = Date.now(), 
        myself.createLabel(), myself.fixLayout(), ide.hasChangedMedia = !0);
    }).prompt("rename sound", sound.name, this.world());
}, SoundIconMorph.prototype.removeSound = function() {
    var jukebox = this.parentThatIsA(JukeboxMorph), idx = this.parent.children.indexOf(this);
    jukebox.removeSound(idx);
}, SoundIconMorph.prototype.createBackgrounds = SpriteIconMorph.prototype.createBackgrounds, 
SoundIconMorph.prototype.createLabel = SpriteIconMorph.prototype.createLabel, SoundIconMorph.prototype.prepareToBeGrabbed = function() {
    this.removeSound();
}, JukeboxMorph.prototype = new ScrollFrameMorph(), JukeboxMorph.prototype.constructor = JukeboxMorph, 
JukeboxMorph.uber = ScrollFrameMorph.prototype;

function JukeboxMorph(aSprite, sliderColor) {
    this.init(aSprite, sliderColor);
}

JukeboxMorph.prototype.init = function(aSprite, sliderColor) {
    this.sprite = aSprite || new SpriteMorph(), this.costumesVersion = null, this.spriteVersion = null, 
    JukeboxMorph.uber.init.call(this, null, null, sliderColor), this.acceptsDrops = !1, 
    this.fps = 2, this.updateList();
}, JukeboxMorph.prototype.updateList = function() {
    var icon, template, txt, myself = this, x = this.left() + 5, y = this.top() + 5, oldFlag = Morph.prototype.trackChanges;
    this.changed(), oldFlag = Morph.prototype.trackChanges, Morph.prototype.trackChanges = !1, 
    this.contents.destroy(), this.contents = new FrameMorph(this), this.contents.acceptsDrops = !1, 
    this.contents.reactToDropOf = function(icon) {
        myself.reactToDropOf(icon);
    }, this.addBack(this.contents), (txt = new TextMorph(localize("import a sound from your computer\nby dragging it into here"))).fontSize = 9, 
    txt.setColor(SpriteMorph.prototype.paletteTextColor), txt.setPosition(new Point(x, y)), 
    this.addContents(txt), y = txt.bottom() + 4, this.sprite.sounds.asArray().forEach(function(sound) {
        template = icon = new SoundIconMorph(sound, template), icon.setPosition(new Point(x, y)), 
        myself.addContents(icon), y = icon.bottom() + 4;
    }), Morph.prototype.trackChanges = oldFlag, this.changed(), this.updateSelection();
}, JukeboxMorph.prototype.updateSelection = function() {
    this.contents.children.forEach(function(morph) {
        morph.refresh && morph.refresh();
    }), this.spriteVersion = this.sprite.version;
}, JukeboxMorph.prototype.removeSound = function(idx) {
    this.sprite.sounds.remove(idx), this.updateList();
}, JukeboxMorph.prototype.wantsDropOf = function(morph) {
    return morph instanceof SoundIconMorph;
}, JukeboxMorph.prototype.reactToDropOf = function(icon) {
    var idx = 0, costume = icon.object, top = icon.top();
    icon.destroy(), this.contents.children.forEach(function(item) {
        item.top() < top - 4 && (idx += 1);
    }), this.sprite.sounds.add(costume, idx), this.updateList();
}, modules.paint = "2014-September-29";

var PaintEditorMorph, PaintCanvasMorph, PaintColorPickerMorph;

PaintEditorMorph.prototype = new DialogBoxMorph(), PaintEditorMorph.prototype.constructor = PaintEditorMorph, 
PaintEditorMorph.uber = DialogBoxMorph.prototype, PaintEditorMorph.prototype.padding = 10;

function PaintEditorMorph() {
    this.init();
}

PaintEditorMorph.prototype.init = function() {
    this.paper = null, this.oncancel = null, PaintEditorMorph.uber.init.call(this), 
    this.labelString = "Paint Editor", this.createLabel(), this.buildContents();
}, PaintEditorMorph.prototype.buildContents = function() {
    var myself = this;
    this.paper = new PaintCanvasMorph(function() {
        return myself.shift;
    }), this.paper.setExtent(StageMorph.prototype.dimensions), this.addBody(new AlignmentMorph("row", this.padding)), 
    this.controls = new AlignmentMorph("column", this.padding / 2), this.controls.alignment = "left", 
    this.edits = new AlignmentMorph("row", this.padding / 2), this.buildEdits(), this.controls.add(this.edits), 
    this.body.color = this.color, this.body.add(this.controls), this.body.add(this.paper), 
    this.toolbox = new BoxMorph(), this.toolbox.color = SpriteMorph.prototype.paletteColor.lighter(8), 
    this.toolbox.borderColor = this.toolbox.color.lighter(40), MorphicPreferences.isFlat && (this.toolbox.edge = 0), 
    this.buildToolbox(), this.controls.add(this.toolbox), this.scaleBox = new AlignmentMorph("row", this.padding / 2), 
    this.buildScaleBox(), this.controls.add(this.scaleBox), this.propertiesControls = {
        colorpicker: null,
        penSizeSlider: null,
        penSizeField: null,
        primaryColorButton: null,
        primaryColorViewer: null,
        constrain: null
    }, this.populatePropertiesMenu(), this.addButton("ok", "OK"), this.addButton("cancel", "Cancel"), 
    this.refreshToolButtons(), this.fixLayout(), this.drawNew();
}, PaintEditorMorph.prototype.buildToolbox = function() {
    var tools = {
        brush: "Paintbrush tool\n(free draw)",
        rectangle: "Stroked Rectangle\n(shift: square)",
        circle: "Stroked Ellipse\n(shift: circle)",
        eraser: "Eraser tool",
        crosshairs: "Set the rotation center",
        line: "Line tool\n(shift: vertical/horizontal)",
        rectangleSolid: "Filled Rectangle\n(shift: square)",
        circleSolid: "Filled Ellipse\n(shift: circle)",
        paintbucket: "Fill a region",
        pipette: "Pipette tool\n(pick a color anywhere)"
    }, myself = this, left = this.toolbox.left(), top = this.toolbox.top(), x = 0, y = 0;
    Object.keys(tools).forEach(function(tool) {
        var btn = myself.toolButton(tool, tools[tool]);
        btn.setPosition(new Point(left + x, top + y)), x += btn.width() + 2, "crosshairs" === tool && (x = 0, 
        y += btn.height() + 2, myself.paper.drawcrosshair()), myself.toolbox[tool] = btn, 
        myself.toolbox.add(btn);
    }), this.toolbox.bounds = this.toolbox.fullBounds().expandBy(10), this.toolbox.drawNew();
}, PaintEditorMorph.prototype.buildEdits = function() {
    var paper = this.paper;
    this.edits.add(this.pushButton("undo", function() {
        paper.undo();
    })), this.edits.add(this.pushButton("clear", function() {
        paper.clearCanvas();
    })), this.edits.fixLayout();
}, PaintEditorMorph.prototype.buildScaleBox = function() {
    var paper = this.paper;
    this.scaleBox.add(this.pushButton("grow", function() {
        paper.scale(.05, .05);
    })), this.scaleBox.add(this.pushButton("shrink", function() {
        paper.scale(-.05, -.05);
    })), this.scaleBox.add(this.pushButton("flip ↔", function() {
        paper.scale(-2, 0);
    })), this.scaleBox.add(this.pushButton("flip ↕", function() {
        paper.scale(0, -2);
    })), this.scaleBox.fixLayout();
}, PaintEditorMorph.prototype.openIn = function(world, oldim, oldrc, callback) {
    this.oldim = oldim, this.oldrc = oldrc.copy(), this.callback = callback || nop, 
    this.processKeyUp = function() {
        this.shift = !1, this.propertiesControls.constrain.refresh();
    }, this.processKeyDown = function() {
        this.shift = 16 === this.world().currentKey, this.propertiesControls.constrain.refresh();
    }, this.oldim && (this.paper.centermerge(this.oldim, this.paper.paper), this.paper.rotationCenter = this.oldrc.add(new Point((this.paper.paper.width - this.oldim.width) / 2, (this.paper.paper.height - this.oldim.height) / 2)), 
    this.paper.drawNew()), this.key = "paint", this.popUp(world);
}, PaintEditorMorph.prototype.fixLayout = function() {
    var oldFlag = Morph.prototype.trackChanges;
    this.changed(), oldFlag = Morph.prototype.trackChanges, Morph.prototype.trackChanges = !1, 
    this.paper && (this.paper.buildContents(), this.paper.drawNew()), this.controls && this.controls.fixLayout(), 
    this.body && this.body.fixLayout(), PaintEditorMorph.uber.fixLayout.call(this), 
    Morph.prototype.trackChanges = oldFlag, this.changed();
}, PaintEditorMorph.prototype.refreshToolButtons = function() {
    this.toolbox.children.forEach(function(toggle) {
        toggle.refresh();
    });
}, PaintEditorMorph.prototype.ok = function() {
    this.callback(this.paper.paper, this.paper.rotationCenter), this.destroy();
}, PaintEditorMorph.prototype.cancel = function() {
    this.oncancel && this.oncancel(), this.destroy();
}, PaintEditorMorph.prototype.populatePropertiesMenu = function() {
    var c = this.controls, myself = this, pc = this.propertiesControls, alpen = new AlignmentMorph("row", this.padding);
    pc.primaryColorViewer = new Morph(), pc.primaryColorViewer.setExtent(new Point(180, 50)), 
    pc.primaryColorViewer.color = new Color(0, 0, 0), pc.colorpicker = new PaintColorPickerMorph(new Point(180, 100), function(color) {
        var i, j, ni = newCanvas(pc.primaryColorViewer.extent()), ctx = ni.getContext("2d");
        if (myself.paper.settings.primarycolor = color, "transparent" === color) for (i = 0; i < 180; i += 5) for (j = 0; j < 15; j += 5) ctx.fillStyle = (j + i) / 5 % 2 == 0 ? "rgba(0, 0, 0, 0.2)" : "rgba(0, 0, 0, 0.5)", 
        ctx.fillRect(i, j, 5, 5); else ctx.fillStyle = color.toString(), ctx.fillRect(0, 0, 180, 15);
        ctx.strokeStyle = "black", ctx.lineWidth = Math.min(myself.paper.settings.linewidth, 20), 
        ctx.beginPath(), ctx.lineCap = "round", ctx.moveTo(20, 30), ctx.lineTo(160, 30), 
        ctx.stroke(), pc.primaryColorViewer.image = ni, pc.primaryColorViewer.changed();
    }), pc.colorpicker.action(new Color(0, 0, 0)), pc.penSizeSlider = new SliderMorph(0, 20, 5, 5), 
    pc.penSizeSlider.orientation = "horizontal", pc.penSizeSlider.setHeight(15), pc.penSizeSlider.setWidth(150), 
    pc.penSizeSlider.action = function(num) {
        pc.penSizeField && pc.penSizeField.setContents(num), myself.paper.settings.linewidth = num, 
        pc.colorpicker.action(myself.paper.settings.primarycolor);
    }, pc.penSizeField = new InputFieldMorph("5", !0, null, !1), pc.penSizeField.contents().minWidth = 20, 
    pc.penSizeField.setWidth(25), pc.penSizeField.accept = function() {
        var val = parseFloat(pc.penSizeField.getValue());
        pc.penSizeSlider.value = val, pc.penSizeSlider.drawNew(), pc.penSizeSlider.updateValue(), 
        this.setContents(val), myself.paper.settings.linewidth = val, this.world().keyboardReceiver = myself, 
        pc.colorpicker.action(myself.paper.settings.primarycolor);
    }, alpen.add(pc.penSizeSlider), alpen.add(pc.penSizeField), alpen.color = myself.color, 
    alpen.fixLayout(), pc.penSizeField.drawNew(), pc.constrain = new ToggleMorph("checkbox", this, function() {
        myself.shift = !myself.shift;
    }, "Constrain proportions of shapes?\n(you can also hold shift)", function() {
        return myself.shift;
    }), c.add(pc.colorpicker), c.add(pc.primaryColorViewer), c.add(new TextMorph(localize("Brush size"))), 
    c.add(alpen), c.add(pc.constrain);
}, PaintEditorMorph.prototype.toolButton = function(icon, hint) {
    var button, myself = this;
    return (button = new ToggleButtonMorph(null, this, function() {
        myself.paper.currentTool = icon, myself.paper.toolChanged(icon), myself.refreshToolButtons(), 
        "pipette" === icon && myself.getUserColor();
    }, new SymbolMorph(icon, 18), function() {
        return myself.paper.currentTool === icon;
    })).hint = hint, button.drawNew(), button.fixLayout(), button;
}, PaintEditorMorph.prototype.pushButton = function(title, action, hint) {
    return new PushButtonMorph(this, action, title, null, hint);
}, PaintEditorMorph.prototype.getUserColor = function() {
    var myself = this, world = this.world(), hand = world.hand, posInDocument = getDocumentPositionOf(world.worldCanvas), mouseMoveBak = hand.processMouseMove, mouseDownBak = hand.processMouseDown, mouseUpBak = hand.processMouseUp;
    hand.processMouseMove = function(event) {
        var color;
        hand.setPosition(new Point(event.pageX - posInDocument.x, event.pageY - posInDocument.y)), 
        (color = world.getGlobalPixelColor(hand.position())).a = 255, myself.propertiesControls.colorpicker.action(color);
    }, hand.processMouseDown = nop, hand.processMouseUp = function() {
        myself.paper.currentTool = "brush", myself.paper.toolChanged("brush"), myself.refreshToolButtons(), 
        hand.processMouseMove = mouseMoveBak, hand.processMouseDown = mouseDownBak, hand.processMouseUp = mouseUpBak;
    };
}, PaintColorPickerMorph.prototype = new Morph(), PaintColorPickerMorph.prototype.constructor = PaintColorPickerMorph, 
PaintColorPickerMorph.uber = Morph.prototype;

function PaintColorPickerMorph(extent, action) {
    this.init(extent, action);
}

PaintColorPickerMorph.prototype.init = function(extent, action) {
    this.setExtent(extent || new Point(200, 100)), this.action = action || nop, this.drawNew();
}, PaintColorPickerMorph.prototype.drawNew = function() {
    var colorselection, r, x = 0, y = 0, can = newCanvas(this.extent()), ctx = can.getContext("2d");
    for (x = 0; x < this.width(); x += 1) for (y = 0; y < this.height() - 20; y += 1) ctx.fillStyle = "hsl(" + 360 * x / this.width() + ",100%," + 100 * y / (this.height() - 20) + "%)", 
    ctx.fillRect(x, y, 1, 1);
    for (x = 0; x < this.width(); x += 1) r = Math.floor(255 * x / this.width()), ctx.fillStyle = "rgb(" + r + ", " + r + ", " + r + ")", 
    ctx.fillRect(x, this.height() - 20, 1, 10);
    for (colorselection = [ "black", "white", "gray" ], x = 0; x < colorselection.length; x += 1) ctx.fillStyle = colorselection[x], 
    ctx.fillRect(x * this.width() / colorselection.length, this.height() - 10, this.width() / colorselection.length, 10);
    for (x = 2 * this.width() / 3; x < this.width(); x += 2) for (y = this.height() - 10; y < this.height(); y += 2) (x + y) / 2 % 2 == 0 && (ctx.fillStyle = "#DDD", 
    ctx.fillRect(x, y, 2, 2));
    this.image = can;
}, PaintColorPickerMorph.prototype.mouseDownLeft = function(pos) {
    pos.subtract(this.position()).x > 2 * this.width() / 3 && pos.subtract(this.position()).y > this.height() - 10 ? this.action("transparent") : this.action(this.getPixelColor(pos));
}, PaintColorPickerMorph.prototype.mouseMove = PaintColorPickerMorph.prototype.mouseDownLeft, 
PaintCanvasMorph.prototype = new Morph(), PaintCanvasMorph.prototype.constructor = PaintCanvasMorph, 
PaintCanvasMorph.uber = Morph.prototype;

function PaintCanvasMorph(shift) {
    this.init(shift);
}

PaintCanvasMorph.prototype.init = function(shift) {
    this.rotationCenter = new Point(240, 180), this.dragRect = null, this.previousDragPoint = null, 
    this.currentTool = "brush", this.dragRect = new Rectangle(), this.mask = newCanvas(this.extent()), 
    this.paper = newCanvas(this.extent()), this.erasermask = newCanvas(this.extent()), 
    this.background = newCanvas(this.extent()), this.settings = {
        primarycolor: new Color(0, 0, 0, 255),
        secondarycolor: new Color(0, 0, 0, 255),
        linewidth: 3
    }, this.brushBuffer = [], this.undoBuffer = [], this.isShiftPressed = shift || function() {
        return 16 === this.world().currentKey;
    }, this.buildContents();
}, PaintCanvasMorph.prototype.scale = function(x, y) {
    this.mask = newCanvas(this.extent());
    var c = newCanvas(this.extent());
    c.getContext("2d").save(), c.getContext("2d").translate(this.rotationCenter.x, this.rotationCenter.y), 
    c.getContext("2d").scale(1 + x, 1 + y), c.getContext("2d").drawImage(this.paper, -this.rotationCenter.x, -this.rotationCenter.y), 
    c.getContext("2d").restore(), this.paper = c, this.drawNew(), this.changed();
}, PaintCanvasMorph.prototype.cacheUndo = function() {
    var cachecan = newCanvas(this.extent());
    this.merge(this.paper, cachecan), this.undoBuffer.push(cachecan);
}, PaintCanvasMorph.prototype.undo = function() {
    this.undoBuffer.length > 0 && (this.paper = newCanvas(this.extent()), this.mask.width = this.mask.width + 1 - 1, 
    this.merge(this.undoBuffer.pop(), this.paper), this.drawNew(), this.changed());
}, PaintCanvasMorph.prototype.merge = function(a, b) {
    b.getContext("2d").drawImage(a, 0, 0);
}, PaintCanvasMorph.prototype.centermerge = function(a, b) {
    b.getContext("2d").drawImage(a, (b.width - a.width) / 2, (b.height - a.height) / 2);
}, PaintCanvasMorph.prototype.clearCanvas = function() {
    this.buildContents(), this.drawNew(), this.changed();
}, PaintCanvasMorph.prototype.toolChanged = function(tool) {
    this.mask = newCanvas(this.extent()), "crosshairs" === tool && this.drawcrosshair(), 
    this.drawNew(), this.changed();
}, PaintCanvasMorph.prototype.drawcrosshair = function(context) {
    var ctx = context || this.mask.getContext("2d"), rp = this.rotationCenter;
    ctx.lineWidth = 1, ctx.strokeStyle = "black", ctx.clearRect(0, 0, this.mask.width, this.mask.height), 
    ctx.globalAlpha = .5, ctx.fillStyle = "white", ctx.beginPath(), ctx.arc(rp.x, rp.y, 20, radians(0), radians(360), !1), 
    ctx.closePath(), ctx.fill(), ctx.stroke(), ctx.beginPath(), ctx.arc(rp.x, rp.y, 10, radians(0), radians(360), !1), 
    ctx.stroke(), ctx.beginPath(), ctx.moveTo(0, rp.y), ctx.lineTo(this.mask.width, rp.y), 
    ctx.stroke(), ctx.beginPath(), ctx.moveTo(rp.x, 0), ctx.lineTo(rp.x, this.mask.height), 
    ctx.stroke(), this.drawNew(), this.changed();
}, PaintCanvasMorph.prototype.floodfill = function(sourcepoint) {
    var currentpoint, read, sourcecolor, checkpoint, width = this.paper.width, height = this.paper.height, ctx = this.paper.getContext("2d"), img = ctx.getImageData(0, 0, width, height), data = img.data, stack = [ Math.round(sourcepoint.y) * width + sourcepoint.x ];
    if (checkpoint = function(p) {
        return p[0] === sourcecolor[0] && p[1] === sourcecolor[1] && p[2] === sourcecolor[2] && p[3] === sourcecolor[3];
    }, (0 !== (sourcecolor = (read = function(p) {
        var d = 4 * p;
        return [ data[d], data[d + 1], data[d + 2], data[d + 3] ];
    })(stack[0]))[3] || "transparent" !== this.settings.primarycolor) && !(sourcecolor[0] === this.settings.primarycolor.r && sourcecolor[1] === this.settings.primarycolor.g && sourcecolor[2] === this.settings.primarycolor.b && sourcecolor[3] === this.settings.primarycolor.a || 0 === sourcecolor[3] && 0 === this.settings.primarycolor.a)) {
        for (;stack.length > 0; ) checkpoint(read(currentpoint = stack.pop())) && (currentpoint % width > 1 && (stack.push(currentpoint + 1), 
        stack.push(currentpoint - 1)), currentpoint > 0 && currentpoint < height * width && (stack.push(currentpoint + width), 
        stack.push(currentpoint - width))), "transparent" === this.settings.primarycolor ? data[4 * currentpoint + 3] = 0 : (data[4 * currentpoint] = this.settings.primarycolor.r, 
        data[4 * currentpoint + 1] = this.settings.primarycolor.g, data[4 * currentpoint + 2] = this.settings.primarycolor.b, 
        data[4 * currentpoint + 3] = 255 * this.settings.primarycolor.a);
        ctx.putImageData(img, 0, 0), this.drawNew(), this.changed();
    }
}, PaintCanvasMorph.prototype.mouseDownLeft = function(pos) {
    return this.cacheUndo(), this.dragRect.origin = pos.subtract(this.bounds.origin), 
    this.dragRect.corner = pos.subtract(this.bounds.origin), this.previousDragPoint = this.dragRect.corner.copy(), 
    "crosshairs" === this.currentTool ? (this.rotationCenter = pos.subtract(this.bounds.origin), 
    void this.drawcrosshair()) : "paintbucket" === this.currentTool ? this.floodfill(pos.subtract(this.bounds.origin)) : void ("transparent" === this.settings.primarycolor && "crosshairs" !== this.currentTool && (this.erasermask = newCanvas(this.extent()), 
    this.merge(this.paper, this.erasermask)));
}, PaintCanvasMorph.prototype.mouseMove = function(pos) {
    if ("paintbucket" !== this.currentTool) {
        var i, relpos = pos.subtract(this.bounds.origin), mctx = this.mask.getContext("2d"), pctx = this.paper.getContext("2d"), x = this.dragRect.origin.x, y = this.dragRect.origin.y, p = relpos.x, q = relpos.y, w = (p - x) / 2, h = (q - y) / 2, width = this.paper.width;
        switch (mctx.save(), this.brushBuffer.push([ p, q ]), mctx.lineWidth = this.settings.linewidth, 
        mctx.clearRect(0, 0, this.bounds.width(), this.bounds.height()), this.dragRect.corner = relpos.subtract(this.dragRect.origin), 
        "transparent" === this.settings.primarycolor && "crosshairs" !== this.currentTool ? (this.merge(this.erasermask, this.mask), 
        pctx.clearRect(0, 0, this.bounds.width(), this.bounds.height()), mctx.globalCompositeOperation = "destination-out") : (mctx.fillStyle = this.settings.primarycolor.toString(), 
        mctx.strokeStyle = this.settings.primarycolor.toString()), this.currentTool) {
          case "rectangle":
            this.isShiftPressed() ? mctx.strokeRect(x, y, 2 * newW(), 2 * newH()) : mctx.strokeRect(x, y, 2 * w, 2 * h);
            break;

          case "rectangleSolid":
            this.isShiftPressed() ? mctx.fillRect(x, y, 2 * newW(), 2 * newH()) : mctx.fillRect(x, y, 2 * w, 2 * h);
            break;

          case "brush":
            for (mctx.lineCap = "round", mctx.lineJoin = "round", mctx.beginPath(), mctx.moveTo(this.brushBuffer[0][0], this.brushBuffer[0][1]), 
            i = 0; i < this.brushBuffer.length; i += 1) mctx.lineTo(this.brushBuffer[i][0], this.brushBuffer[i][1]);
            mctx.stroke();
            break;

          case "line":
            mctx.beginPath(), mctx.moveTo(x, y), this.isShiftPressed() ? Math.abs(h) > Math.abs(w) ? mctx.lineTo(x, q) : mctx.lineTo(p, y) : mctx.lineTo(p, q), 
            mctx.stroke();
            break;

          case "circle":
          case "circleSolid":
            if (mctx.beginPath(), this.isShiftPressed()) mctx.arc(x, y, new Point(x, y).distanceTo(new Point(p, q)), 0, 2 * Math.PI, !1); else {
                for (i = 0; i < width; i += 1) mctx.lineTo(i, 2 * h * Math.sqrt(2 - Math.pow((i - x) / (2 * w), 2)) + y);
                for (i = width; i > 0; i -= 1) mctx.lineTo(i, 2 * h * -1 * Math.sqrt(2 - Math.pow((i - x) / (2 * w), 2)) + y);
            }
            mctx.closePath(), "circleSolid" === this.currentTool ? mctx.fill() : "circle" === this.currentTool && mctx.stroke();
            break;

          case "crosshairs":
            this.rotationCenter = relpos.copy(), this.drawcrosshair(mctx);
            break;

          case "eraser":
            for (this.merge(this.paper, this.mask), mctx.save(), mctx.globalCompositeOperation = "destination-out", 
            mctx.beginPath(), mctx.moveTo(this.brushBuffer[0][0], this.brushBuffer[0][1]), i = 0; i < this.brushBuffer.length; i += 1) mctx.lineTo(this.brushBuffer[i][0], this.brushBuffer[i][1]);
            mctx.stroke(), mctx.restore(), this.paper = newCanvas(this.extent()), this.merge(this.mask, this.paper);
            break;

          default:
            nop();
        }
        this.previousDragPoint = relpos, this.drawNew(), this.changed(), mctx.restore();
    }
    function newW() {
        return Math.max(Math.abs(w), Math.abs(h)) * (w / Math.abs(w));
    }
    function newH() {
        return Math.max(Math.abs(w), Math.abs(h)) * (h / Math.abs(h));
    }
}, PaintCanvasMorph.prototype.mouseClickLeft = function() {
    "crosshairs" !== this.currentTool && this.merge(this.mask, this.paper), this.brushBuffer = [];
}, PaintCanvasMorph.prototype.mouseLeaveDragging = PaintCanvasMorph.prototype.mouseClickLeft, 
PaintCanvasMorph.prototype.buildContents = function() {
    this.background = newCanvas(this.extent()), this.paper = newCanvas(this.extent()), 
    this.mask = newCanvas(this.extent()), this.erasermask = newCanvas(this.extent());
    var i, j, bkctx = this.background.getContext("2d");
    for (i = 0; i < this.background.width; i += 5) for (j = 0; j < this.background.height; j += 5) bkctx.fillStyle = (i + j) / 5 % 2 == 1 ? "rgba(255, 255, 255, 1)" : "rgba(255, 255, 255, 0.3)", 
    bkctx.fillRect(i, j, 5, 5);
}, PaintCanvasMorph.prototype.drawNew = function() {
    var can = newCanvas(this.extent());
    this.merge(this.background, can), this.merge(this.paper, can), this.merge(this.mask, can), 
    this.image = can, this.drawFrame();
}, PaintCanvasMorph.prototype.drawFrame = function() {
    var context, borderColor;
    context = this.image.getContext("2d"), this.parent ? (this.color = this.parent.color.lighter(.75 * this.contrast), 
    borderColor = this.parent.color) : borderColor = new Color(120, 120, 120), context.fillStyle = this.color.toString(), 
    this.cachedClr = borderColor.toString(), this.cachedClrBright = borderColor.lighter(this.contrast).toString(), 
    this.cachedClrDark = borderColor.darker(this.contrast).toString(), this.drawRectBorder(context);
}, PaintCanvasMorph.prototype.drawRectBorder = InputFieldMorph.prototype.drawRectBorder, 
PaintCanvasMorph.prototype.edge = InputFieldMorph.prototype.edge, PaintCanvasMorph.prototype.fontSize = InputFieldMorph.prototype.fontSize, 
PaintCanvasMorph.prototype.typeInPadding = InputFieldMorph.prototype.typeInPadding, 
PaintCanvasMorph.prototype.contrast = InputFieldMorph.prototype.contrast, modules.lists = "2014-November-20";

var List, ListWatcherMorph;

function List(array) {
    this.contents = array || [], this.first = null, this.rest = null, this.isLinked = !1, 
    this.lastChanged = Date.now();
}

List.prototype.toString = function() {
    return "a List [" + this.asArray() + "]";
}, List.prototype.changed = function() {
    this.lastChanged = Date.now();
}, List.prototype.cons = function(car, cdr) {
    var answer = new List();
    if (!(cdr instanceof List || isNil(cdr))) throw new Error("cdr isn't a list: " + cdr);
    return answer.first = isNil(car) ? null : car, answer.rest = cdr || null, answer.isLinked = !0, 
    answer;
}, List.prototype.cdr = function() {
    var result, i;
    if (this.isLinked) return this.rest || new List();
    if (this.contents.length < 2) return new List();
    for (result = new List(), i = this.contents.length; i > 1; i -= 1) result = this.cons(this.at(i), result);
    return result;
}, List.prototype.add = function(element, index) {
    var idx = index || this.length() + 1, obj = 0 === element ? 0 : !1 !== element && (element || null);
    this.becomeArray(), this.contents.splice(idx - 1, 0, obj), this.changed();
}, List.prototype.put = function(element, index) {
    var data = 0 === element ? 0 : !1 !== element && (element || null);
    this.becomeArray(), this.contents[index - 1] = data, this.changed();
}, List.prototype.remove = function(index) {
    this.becomeArray(), this.contents.splice(index - 1, 1), this.changed();
}, List.prototype.clear = function() {
    this.contents = [], this.first = null, this.rest = null, this.isLinked = !1, this.changed();
}, List.prototype.length = function() {
    if (this.isLinked) {
        for (var pair = this, result = 0; pair && pair.isLinked; ) result += 1, pair = pair.rest;
        return result + (pair ? pair.contents.length : 0);
    }
    return this.contents.length;
}, List.prototype.at = function(index) {
    for (var value, idx = +index, pair = this; pair.isLinked; ) {
        if (!(idx > 1)) return pair.first;
        pair = pair.rest, idx -= 1;
    }
    return isNil(value = pair.contents[idx - 1]) ? "" : value;
}, List.prototype.contains = function(element) {
    for (var pair = this; pair.isLinked; ) {
        if (snapEquals(pair.first, element)) return !0;
        pair = pair.rest;
    }
    return pair.contents.some(function(any) {
        return snapEquals(any, element);
    });
}, List.prototype.asArray = function() {
    return this.becomeArray(), this.contents;
}, List.prototype.asText = function() {
    for (var length, element, i, result = "", pair = this; pair.isLinked; ) (element = pair.first) instanceof List ? result = result.concat(element.asText()) : (element = isNil(element) ? "" : element.toString(), 
    result = result.concat(element)), pair = pair.rest;
    for (length = pair.length(), i = 1; i <= length; i += 1) (element = pair.at(i)) instanceof List ? result = result.concat(element.asText()) : (element = isNil(element) ? "" : element.toString(), 
    result = result.concat(element));
    return result;
}, List.prototype.becomeArray = function() {
    if (this.isLinked) {
        var i, next = this;
        for (this.contents = []; next && next.isLinked; ) this.contents.push(next.first), 
        next = next.rest;
        if (next) for (i = 1; i <= next.contents.length; i += 1) this.contents.push(next.at(i));
        this.isLinked = !1, this.first = null, this.rest = null;
    }
}, List.prototype.becomeLinked = function() {
    var i, stop, tail = this;
    if (!this.isLinked) {
        for (stop = this.length(), i = 0; i < stop; i += 1) tail.first = this.contents[i], 
        tail.rest = new List(), tail.isLinked = !0, tail = tail.rest;
        this.contents = [], this.isLinked = !0;
    }
}, List.prototype.equalTo = function(other) {
    var i, j, loopcount, myself = this, it = other;
    if (!(other instanceof List)) return !1;
    for (;myself.isLinked && it.isLinked; ) {
        if (!snapEquals(myself.first, it.first)) return !1;
        myself = myself.rest, it = it.rest;
    }
    for (it.isLinked && (i = it, it = myself, myself = i), j = 0; myself.isLinked; ) {
        if (!snapEquals(myself.first, it.contents[j])) return !1;
        myself = myself.rest, j += 1;
    }
    if (i = 0, myself.contents.length !== it.contents.length - j) return !1;
    for (loopcount = myself.contents.length; loopcount > 0; ) {
        if (loopcount -= 1, !snapEquals(myself.contents[i], it.contents[j])) return !1;
        i += 1, j += 1;
    }
    return !0;
}, ListWatcherMorph.prototype = new BoxMorph(), ListWatcherMorph.prototype.constructor = ListWatcherMorph, 
ListWatcherMorph.uber = BoxMorph.prototype, ListWatcherMorph.prototype.cellColor = SpriteMorph.prototype.blockColor.lists;

function ListWatcherMorph(list, parentCell) {
    this.init(list, parentCell);
}

ListWatcherMorph.prototype.init = function(list, parentCell) {
    var myself = this;
    this.list = list || new List(), this.start = 1, this.range = 100, this.lastUpdated = Date.now(), 
    this.lastCell = null, this.parentCell = parentCell || null, this.label = new StringMorph(localize("length: ") + this.list.length(), SyntaxElementMorph.prototype.fontSize, null, !1, !1, !1, MorphicPreferences.isFlat ? new Point() : new Point(1, 1), new Color(255, 255, 255)), 
    this.label.mouseClickLeft = function() {
        myself.startIndexMenu();
    }, this.frame = new ScrollFrameMorph(null, 10), this.frame.alpha = 0, this.frame.acceptsDrops = !1, 
    this.frame.contents.acceptsDrops = !1, this.handle = new HandleMorph(this, 80, 70, 3, 3), 
    this.handle.setExtent(new Point(13, 13)), this.arrow = new ArrowMorph("down", SyntaxElementMorph.prototype.fontSize), 
    this.arrow.mouseClickLeft = function() {
        myself.startIndexMenu();
    }, this.arrow.setRight(this.handle.right()), this.arrow.setBottom(this.handle.top()), 
    this.handle.add(this.arrow), this.plusButton = new PushButtonMorph(this.list, "add", "+"), 
    this.plusButton.padding = 0, this.plusButton.edge = 0, this.plusButton.outlineColor = this.color, 
    this.plusButton.drawNew(), this.plusButton.fixLayout(), ListWatcherMorph.uber.init.call(this, SyntaxElementMorph.prototype.rounding, 1.000001, new Color(120, 120, 120)), 
    this.color = new Color(220, 220, 220), this.isDraggable = !0, this.setExtent(new Point(80, 70).multiplyBy(SyntaxElementMorph.prototype.scale)), 
    this.add(this.label), this.add(this.frame), this.add(this.plusButton), this.add(this.handle), 
    this.handle.drawNew(), this.update(), this.fixLayout();
}, ListWatcherMorph.prototype.update = function(anyway) {
    var i, idx, ceil, morphs, cell, cnts, label, button, max, starttime;
    if (this.frame.contents.children.forEach(function(m) {
        m instanceof CellMorph && m.contentsMorph instanceof ListWatcherMorph && m.contentsMorph.update();
    }), this.lastUpdated === this.list.lastChanged && !anyway) return null;
    for (this.updateLength(!0), this.start = Math.max(Math.min(this.start, Math.floor((this.list.length() - 1) / this.range) * this.range + 1), 1), 
    max = Math.min(this.start + this.range - 1, this.list.length()), ceil = Math.min(3 * (max - this.start + 1), this.frame.contents.children.length), 
    i = 0; i < ceil; i += 3) idx = this.start + i / 3, cell = this.frame.contents.children[i], 
    label = this.frame.contents.children[i + 1], button = this.frame.contents.children[i + 2], 
    cnts = this.list.at(idx), cell.contents !== cnts && (cell.contents = cnts, cell.drawNew(), 
    this.lastCell && cell.setLeft(this.lastCell.left())), this.lastCell = cell, label.text !== idx.toString() && (label.text = idx.toString(), 
    label.drawNew()), button.action = idx;
    for (morphs = 3 * (max - this.start + 1); this.frame.contents.children.length > morphs; ) this.frame.contents.children[morphs].destroy();
    if (ceil = morphs, i = this.frame.contents.children.length, starttime = Date.now(), 
    ceil > i + 1) for (;i < ceil; i += 3) {
        if (Date.now() - starttime > 1e3) return this.fixLayout(), this.frame.contents.adjustBounds(), 
        this.frame.contents.setLeft(this.frame.left()), null;
        idx = this.start + i / 3, label = new StringMorph(idx.toString(), SyntaxElementMorph.prototype.fontSize, null, !1, !1, !1, MorphicPreferences.isFlat ? new Point() : new Point(1, 1), new Color(255, 255, 255)), 
        cell = new CellMorph(this.list.at(idx), this.cellColor, idx, this.parentCell), (button = new PushButtonMorph(this.list.remove, idx, "-", this.list)).padding = 1, 
        button.edge = 0, button.corner = 1, button.outlineColor = this.color.darker(), button.drawNew(), 
        button.fixLayout(), this.frame.contents.add(cell), this.lastCell ? cell.setPosition(this.lastCell.bottomLeft()) : cell.setTop(this.frame.contents.top()), 
        this.lastCell = cell, label.setCenter(cell.center()), label.setRight(cell.left() - 2), 
        this.frame.contents.add(label), this.frame.contents.add(button);
    }
    this.lastCell = null, this.fixLayout(), this.frame.contents.adjustBounds(), this.frame.contents.setLeft(this.frame.left()), 
    this.updateLength(), this.lastUpdated = this.list.lastChanged;
}, ListWatcherMorph.prototype.updateLength = function(notDone) {
    this.label.text = localize("length: ") + this.list.length(), this.label.color = new Color(0, 0, notDone ? 100 : 0), 
    this.label.drawNew(), this.label.setCenter(this.center()), this.label.setBottom(this.bottom() - 3);
}, ListWatcherMorph.prototype.startIndexMenu = function() {
    var i, range, myself = this, items = Math.ceil(this.list.length() / this.range), menu = new MenuMorph(function(idx) {
        myself.setStartIndex(idx);
    }, null, myself);
    for (menu.addItem("1...", 1), i = 1; i < items; i += 1) range = 100 * i + 1, menu.addItem(range + "...", range);
    menu.popUpAtHand(this.world());
}, ListWatcherMorph.prototype.setStartIndex = function(index) {
    this.start = index, this.list.changed();
}, ListWatcherMorph.prototype.fixLayout = function() {
    Morph.prototype.trackChanges = !1, this.frame && (this.arrangeCells(), this.frame.silentSetPosition(this.position().add(3)), 
    this.frame.bounds.corner = this.bounds.corner.subtract(new Point(3, 17)), this.frame.drawNew(), 
    this.frame.contents.adjustBounds()), this.label.setCenter(this.center()), this.label.setBottom(this.bottom() - 3), 
    this.plusButton.setLeft(this.left() + 3), this.plusButton.setBottom(this.bottom() - 3), 
    Morph.prototype.trackChanges = !0, this.changed(), this.parent && this.parent.fixLayout && this.parent.fixLayout();
}, ListWatcherMorph.prototype.arrangeCells = function() {
    var i, cell, label, button, lastCell, end = this.frame.contents.children.length;
    for (i = 0; i < end; i += 3) cell = this.frame.contents.children[i], label = this.frame.contents.children[i + 1], 
    button = this.frame.contents.children[i + 2], lastCell && cell.setTop(lastCell.bottom()), 
    label && (label.setTop(cell.center().y - label.height() / 2), label.setRight(cell.left() - 2)), 
    button && (button.setCenter(cell.center()), button.setLeft(cell.right() + 2)), lastCell = cell;
    this.frame.contents.adjustBounds();
}, ListWatcherMorph.prototype.show = function() {
    ListWatcherMorph.uber.show.call(this), this.frame.contents.adjustBounds();
}, ListWatcherMorph.prototype.drawNew = function() {
    WatcherMorph.prototype.drawNew.call(this), this.fixLayout();
}, modules.byob = "2015-January-21";

var CustomBlockDefinition, CustomCommandBlockMorph, CustomReporterBlockMorph, BlockDialogMorph, BlockEditorMorph, PrototypeHatBlockMorph, BlockLabelFragment, BlockLabelFragmentMorph, BlockInputFragmentMorph, BlockLabelPlaceHolderMorph, InputSlotDialogMorph, VariableDialogMorph, JaggedBlockMorph, BlockExportDialogMorph, BlockImportDialogMorph;

function CustomBlockDefinition(spec, receiver) {
    this.body = null, this.scripts = [], this.category = null, this.isGlobal = !1, this.type = "command", 
    this.spec = spec || "", this.declarations = {}, this.comment = null, this.codeMapping = null, 
    this.codeHeader = null, this.receiver = receiver || null;
}

CustomBlockDefinition.prototype.blockInstance = function() {
    var block;
    return (block = "command" === this.type ? new CustomCommandBlockMorph(this) : new CustomReporterBlockMorph(this, "predicate" === this.type)).isDraggable = !0, 
    block;
}, CustomBlockDefinition.prototype.templateInstance = function() {
    var block;
    return (block = this.blockInstance()).refreshDefaults(), block.isDraggable = !1, 
    block.isTemplate = !0, block;
}, CustomBlockDefinition.prototype.prototypeInstance = function() {
    var block, slot, myself = this;
    return (block = "command" === this.type ? new CustomCommandBlockMorph(this, !0) : new CustomReporterBlockMorph(this, "predicate" === this.type, !0)).parts().forEach(function(part) {
        part instanceof BlockInputFragmentMorph && (slot = myself.declarations[part.fragment.labelString]) && (part.fragment.type = slot[0], 
        part.fragment.defaultValue = slot[1], part.fragment.options = slot[2], part.fragment.isReadOnly = slot[3] || !1);
    }), block;
}, CustomBlockDefinition.prototype.copyAndBindTo = function(sprite) {
    var c = copy(this);
    return c.receiver = sprite, c.declarations = copy(this.declarations), c.body && (c.body = Process.prototype.reify.call(null, this.body.expression, new List(this.inputNames())), 
    c.body.outerContext = null), c;
}, CustomBlockDefinition.prototype.blockSpec = function() {
    var spec, myself = this, ans = [];
    return this.parseSpec(this.spec).forEach(function(part) {
        spec = "%" === part[0] && part.length > 1 ? myself.typeOf(part.slice(1)) : part, 
        ans.push(spec), ans.push(" ");
    }), "".concat.apply("", ans).trim();
}, CustomBlockDefinition.prototype.helpSpec = function() {
    var ans = [];
    return this.parseSpec(this.spec).forEach(function(part) {
        "%" !== part[0] && ans.push(part);
    }), "".concat.apply("", ans).replace(/\?/g, "");
}, CustomBlockDefinition.prototype.typeOf = function(inputName) {
    return this.declarations[inputName] ? this.declarations[inputName][0] : "%s";
}, CustomBlockDefinition.prototype.defaultValueOf = function(inputName) {
    return this.declarations[inputName] ? this.declarations[inputName][1] : "";
}, CustomBlockDefinition.prototype.defaultValueOfInputIdx = function(idx) {
    var inputName = this.inputNames()[idx];
    return this.defaultValueOf(inputName);
}, CustomBlockDefinition.prototype.dropDownMenuOfInputIdx = function(idx) {
    var inputName = this.inputNames()[idx];
    return this.dropDownMenuOf(inputName);
}, CustomBlockDefinition.prototype.isReadOnlyInputIdx = function(idx) {
    var inputName = this.inputNames()[idx];
    return this.isReadOnlyInput(inputName);
}, CustomBlockDefinition.prototype.inputOptionsOfIdx = function(idx) {
    var inputName = this.inputNames()[idx];
    return this.inputOptionsOf(inputName);
}, CustomBlockDefinition.prototype.dropDownMenuOf = function(inputName) {
    var dict = {};
    return this.declarations[inputName] && this.declarations[inputName][2] ? (this.declarations[inputName][2].split("\n").forEach(function(line) {
        var pair = line.split("=");
        dict[pair[0]] = isNil(pair[1]) ? pair[0] : pair[1];
    }), dict) : null;
}, CustomBlockDefinition.prototype.isReadOnlyInput = function(inputName) {
    return this.declarations[inputName] && !0 === this.declarations[inputName][3];
}, CustomBlockDefinition.prototype.inputOptionsOf = function(inputName) {
    return [ this.dropDownMenuOf(inputName), this.isReadOnlyInput(inputName) ];
}, CustomBlockDefinition.prototype.inputNames = function() {
    var vNames = [];
    return this.parseSpec(this.spec).forEach(function(part) {
        "%" === part[0] && part.length > 1 && vNames.push(part.slice(1));
    }), vNames;
}, CustomBlockDefinition.prototype.parseSpec = function(spec) {
    var i, c, parts = [], word = "", quoted = !1;
    for (i = 0; i < spec.length; i += 1) "'" === (c = spec[i]) ? quoted = !quoted : " " !== c || quoted ? word = word.concat(c) : (parts.push(word), 
    word = "");
    return parts.push(word), parts;
}, CustomBlockDefinition.prototype.scriptsPicture = function() {
    var scripts, proto, block, comment;
    return (scripts = new ScriptsMorph()).cleanUpMargin = 10, (proto = new PrototypeHatBlockMorph(this)).setPosition(scripts.position().add(10)), 
    null !== this.comment && (comment = this.comment.fullCopy(), proto.comment = comment, 
    comment.block = proto), null !== this.body && proto.nextBlock(this.body.expression.fullCopy()), 
    scripts.add(proto), proto.fixBlockColor(null, !0), this.scripts.forEach(function(element) {
        (block = element.fullCopy()).setPosition(scripts.position().add(element.position())), 
        scripts.add(block), block instanceof BlockMorph && block.allComments().forEach(function(comment) {
            comment.align(block);
        });
    }), proto.allComments().forEach(function(comment) {
        comment.align(proto);
    }), proto.children[0].fixLayout(), scripts.fixMultiArgs(), scripts.scriptsPicture();
}, CustomCommandBlockMorph.prototype = new CommandBlockMorph(), CustomCommandBlockMorph.prototype.constructor = CustomCommandBlockMorph, 
CustomCommandBlockMorph.uber = CommandBlockMorph.prototype;

function CustomCommandBlockMorph(definition, isProto) {
    this.init(definition, isProto);
}

CustomCommandBlockMorph.prototype.init = function(definition, isProto) {
    this.definition = definition, this.isPrototype = isProto || !1, CustomCommandBlockMorph.uber.init.call(this), 
    this.category = definition.category, this.selector = "evaluateCustomBlock", definition && this.refresh();
}, CustomCommandBlockMorph.prototype.refresh = function() {
    var oldInputs, def = this.definition, newSpec = this.isPrototype ? def.spec : def.blockSpec();
    this.setCategory(def.category), this.blockSpec !== newSpec ? (oldInputs = this.inputs(), 
    this.zebraContrast ? this.fixBlockColor() : this.forceNormalColoring(), this.setSpec(newSpec), 
    this.fixLabelColor(), this.restoreInputs(oldInputs)) : this.inputs().forEach(function(inp, i) {
        inp instanceof InputSlotMorph && inp.setChoices.apply(inp, def.inputOptionsOfIdx(i));
    }), this.inputs().forEach(function(inp, idx) {
        inp instanceof TemplateSlotMorph && "↑" === inp.contents() && inp.setContents(def.inputNames()[idx]);
    });
}, CustomCommandBlockMorph.prototype.restoreInputs = function(oldInputs) {
    var old, i = 0, myself = this;
    this.isPrototype || this.inputs().forEach(function(inp) {
        (old = oldInputs[i]) instanceof ReporterBlockMorph && !(inp instanceof TemplateSlotMorph) ? myself.silentReplaceInput(inp, old) : old instanceof InputSlotMorph && inp instanceof InputSlotMorph ? inp.setContents(old.evaluate()) : old instanceof TemplateSlotMorph && inp instanceof TemplateSlotMorph ? inp.setContents(old.evaluate()) : old instanceof CSlotMorph && inp instanceof CSlotMorph && inp.nestedBlock(old.evaluate()), 
        i += 1;
    });
}, CustomCommandBlockMorph.prototype.refreshDefaults = function() {
    var idx = 0, myself = this;
    this.inputs().forEach(function(inp) {
        inp instanceof InputSlotMorph && inp.setContents(myself.definition.defaultValueOfInputIdx(idx)), 
        idx += 1;
    });
}, CustomCommandBlockMorph.prototype.refreshPrototype = function() {
    var hat, protoSpec, newFrag, frags = [], myself = this, i = 0;
    if (!this.isPrototype) return null;
    hat = this.parentThatIsA(PrototypeHatBlockMorph), this.parts().forEach(function(part) {
        part.fragment.isDeleted || (part.fragment.type ? frags.push(part.fragment) : myself.definition.parseSpec(part.fragment.labelString).forEach(function(word) {
            (newFrag = part.fragment.copy()).labelString = word, frags.push(newFrag);
        }));
    }), protoSpec = this.specFromFragments(), this instanceof CustomCommandBlockMorph && ("reporter" === hat.type || "predicate" === hat.type) ? (myself = new CustomReporterBlockMorph(this.definition, "predicate" === hat.type, !0), 
    hat.silentReplaceInput(this, myself)) : this instanceof CustomReporterBlockMorph && ("command" === hat.type ? (myself = new CustomCommandBlockMorph(this.definition, !0), 
    hat.silentReplaceInput(this, myself)) : (this.isPredicate = "predicate" === hat.type, 
    this.drawNew())), myself.setCategory(hat.blockCategory || "other"), hat.fixBlockColor(), 
    myself.setSpec(protoSpec), myself.parts().forEach(function(part) {
        part instanceof BlockLabelPlaceHolderMorph || (frags[i] && (part.fragment = frags[i]), 
        i += 1);
    }), this.refreshPrototypeSlotTypes(), hat.fixLayout();
}, CustomCommandBlockMorph.prototype.refreshPrototypeSlotTypes = function() {
    this.parts().forEach(function(part) {
        part instanceof BlockInputFragmentMorph && (part.template().instantiationSpec = part.contents(), 
        part.setContents(part.fragment.defTemplateSpecFragment()));
    }), this.fixBlockColor(null, !0);
}, CustomCommandBlockMorph.prototype.inputFragmentNames = function() {
    var ans = [];
    return this.parts().forEach(function(part) {
        !part.fragment.isDeleted && part.fragment.type && ans.push(part.fragment.labelString);
    }), ans;
}, CustomCommandBlockMorph.prototype.upvarFragmentNames = function() {
    var ans = [];
    return this.parts().forEach(function(part) {
        part.fragment.isDeleted || "%upvar" !== part.fragment.type || ans.push(part.fragment.labelString);
    }), ans;
}, CustomCommandBlockMorph.prototype.upvarFragmentName = function(idx) {
    return this.upvarFragmentNames()[idx] || "↑";
}, CustomCommandBlockMorph.prototype.specFromFragments = function() {
    var ans = "";
    return this.parts().forEach(function(part) {
        part.fragment.isDeleted || (ans = ans + part.fragment.defSpecFragment() + " ");
    }), ans.trim();
}, CustomCommandBlockMorph.prototype.blockSpecFromFragments = function() {
    var ans = "";
    return this.parts().forEach(function(part) {
        part.fragment.isDeleted || (ans = ans + part.fragment.blockSpecFragment() + " ");
    }), ans.trim();
}, CustomCommandBlockMorph.prototype.declarationsFromFragments = function() {
    var ans = {};
    return this.parts().forEach(function(part) {
        part instanceof BlockInputFragmentMorph && (ans[part.fragment.labelString] = [ part.fragment.type, part.fragment.defaultValue, part.fragment.options, part.fragment.isReadOnly ]);
    }), ans;
}, CustomCommandBlockMorph.prototype.parseSpec = function(spec) {
    return this.isPrototype ? this.definition.parseSpec.call(this, spec) : CustomCommandBlockMorph.uber.parseSpec.call(this, spec);
}, CustomCommandBlockMorph.prototype.mouseClickLeft = function() {
    if (!this.isPrototype) return CustomCommandBlockMorph.uber.mouseClickLeft.call(this);
    this.edit();
}, CustomCommandBlockMorph.prototype.edit = function() {
    var block, hat, myself = this;
    this.isPrototype ? ((block = this.definition.blockInstance()).addShadow(), hat = this.parentThatIsA(PrototypeHatBlockMorph), 
    new BlockDialogMorph(null, function(definition) {
        definition && (hat.blockCategory = definition.category, hat.type = definition.type, 
        myself.refreshPrototype());
    }, myself).openForChange("Change block", hat.blockCategory, hat.type, myself.world(), block.fullImage(), myself.isInUse())) : new BlockEditorMorph(this.definition, this.receiver()).popUp();
}, CustomCommandBlockMorph.prototype.labelPart = function(spec) {
    var part;
    return this.isPrototype ? ("%" === spec[0] && spec.length > 1 ? part = new BlockInputFragmentMorph(spec.replace(/%/g, "")) : ((part = new BlockLabelFragmentMorph(spec)).fontSize = this.fontSize, 
    part.color = new Color(255, 255, 255), part.isBold = !0, part.shadowColor = this.color.darker(this.labelContrast), 
    part.shadowOffset = this.embossing, part.drawNew()), part) : CustomCommandBlockMorph.uber.labelPart.call(this, spec);
}, CustomCommandBlockMorph.prototype.placeHolder = function() {
    var part;
    return (part = new BlockLabelPlaceHolderMorph()).fontSize = 1.4 * this.fontSize, 
    part.color = new Color(45, 45, 45), part.drawNew(), part;
}, CustomCommandBlockMorph.prototype.attachTargets = function() {
    return this.isPrototype ? [] : CustomCommandBlockMorph.uber.attachTargets.call(this);
}, CustomCommandBlockMorph.prototype.isInUse = function() {
    return this.receiver().usesBlockInstance(this.definition);
}, CustomCommandBlockMorph.prototype.userMenu = function() {
    var menu;
    return this.isPrototype ? (menu = new MenuMorph(this)).addItem("script pic...", function() {
        window.open(this.topBlock().fullImage().toDataURL());
    }, "open a new window\nwith a picture of this script") : ((menu = this.constructor.uber.userMenu.call(this)) ? menu.addLine() : menu = new MenuMorph(this), 
    menu.addItem("delete block definition...", "deleteBlockDefinition")), menu.addItem("edit...", "edit"), 
    menu;
}, CustomCommandBlockMorph.prototype.exportBlockDefinition = function() {
    var xml = new SnapSerializer().serialize(this.definition);
    window.open("data:text/xml," + encodeURIComponent(xml));
}, CustomCommandBlockMorph.prototype.deleteBlockDefinition = function() {
    var idx, rcvr, stage, ide, block, myself = this;
    if (this.isPrototype) return null;
    (block = myself.definition.blockInstance()).addShadow(), new DialogBoxMorph(this, function() {
        (rcvr = myself.receiver()).deleteAllBlockInstances(myself.definition), myself.definition.isGlobal ? (stage = rcvr.parentThatIsA(StageMorph), 
        -1 !== (idx = stage.globalBlocks.indexOf(myself.definition)) && stage.globalBlocks.splice(idx, 1)) : -1 !== (idx = rcvr.customBlocks.indexOf(myself.definition)) && rcvr.customBlocks.splice(idx, 1), 
        (ide = rcvr.parentThatIsA(IDE_Morph)) && (ide.flushPaletteCache(), ide.refreshPalette());
    }, this).askYesNo("Delete Custom Block", localize("block deletion dialog text"), myself.world(), block.fullImage());
}, CustomCommandBlockMorph.prototype.mouseEnter = function() {
    var comment, help;
    this.isTemplate && this.definition.comment && ((comment = this.definition.comment.fullCopy()).contents.parse(), 
    help = "", comment.contents.lines.forEach(function(line) {
        help = help + "\n" + line;
    }), this.bubbleHelp(help.substr(1), this.definition.comment.color));
}, CustomCommandBlockMorph.prototype.mouseLeave = function() {
    this.isTemplate && this.definition.comment && this.world().hand.destroyTemporaries();
}, CustomCommandBlockMorph.prototype.bubbleHelp = function(contents, color) {
    var myself = this;
    this.fps = 2, this.step = function() {
        this.bounds.containsPoint(this.world().hand.position()) && myself.popUpbubbleHelp(contents, color), 
        myself.fps = 0, delete myself.step;
    };
}, CustomCommandBlockMorph.prototype.popUpbubbleHelp = function(contents, color) {
    new SpeechBubbleMorph(contents, color, null, 1).popUp(this.world(), this.rightCenter().add(new Point(-8, 0)));
}, CustomCommandBlockMorph.prototype.relabel = function(alternatives) {
    var menu = new MenuMorph(this), oldInputs = this.inputs().map(function(each) {
        return each.fullCopy();
    }), myself = this;
    alternatives.forEach(function(def) {
        var block = def.blockInstance();
        block.restoreInputs(oldInputs), block.fixBlockColor(null, !0), block.addShadow(new Point(3, 3)), 
        menu.addItem(block, function() {
            myself.definition = def, myself.refresh();
        });
    }), menu.popup(this.world(), this.bottomLeft().subtract(new Point(8, this instanceof CommandBlockMorph ? this.corner : 0)));
}, CustomCommandBlockMorph.prototype.alternatives = function() {
    var rcvr = this.receiver(), stage = rcvr.parentThatIsA(StageMorph), myself = this;
    return rcvr.customBlocks.concat(stage.globalBlocks).filter(function(each) {
        return each !== myself.definition && each.type === myself.definition.type;
    });
}, CustomReporterBlockMorph.prototype = new ReporterBlockMorph(), CustomReporterBlockMorph.prototype.constructor = CustomReporterBlockMorph, 
CustomReporterBlockMorph.uber = ReporterBlockMorph.prototype;

function CustomReporterBlockMorph(definition, isPredicate, isProto) {
    this.init(definition, isPredicate, isProto);
}

CustomReporterBlockMorph.prototype.init = function(definition, isPredicate, isProto) {
    this.definition = definition, this.isPrototype = isProto || !1, CustomReporterBlockMorph.uber.init.call(this, isPredicate), 
    this.category = definition.category, this.selector = "evaluateCustomBlock", definition && this.refresh();
}, CustomReporterBlockMorph.prototype.refresh = function() {
    CustomCommandBlockMorph.prototype.refresh.call(this), this.isPrototype || (this.isPredicate = "predicate" === this.definition.type), 
    this.drawNew();
}, CustomReporterBlockMorph.prototype.mouseClickLeft = function() {
    if (!this.isPrototype) return CustomReporterBlockMorph.uber.mouseClickLeft.call(this);
    this.edit();
}, CustomReporterBlockMorph.prototype.placeHolder = CustomCommandBlockMorph.prototype.placeHolder, 
CustomReporterBlockMorph.prototype.parseSpec = CustomCommandBlockMorph.prototype.parseSpec, 
CustomReporterBlockMorph.prototype.edit = CustomCommandBlockMorph.prototype.edit, 
CustomReporterBlockMorph.prototype.labelPart = CustomCommandBlockMorph.prototype.labelPart, 
CustomReporterBlockMorph.prototype.upvarFragmentNames = CustomCommandBlockMorph.prototype.upvarFragmentNames, 
CustomReporterBlockMorph.prototype.upvarFragmentName = CustomCommandBlockMorph.prototype.upvarFragmentName, 
CustomReporterBlockMorph.prototype.inputFragmentNames = CustomCommandBlockMorph.prototype.inputFragmentNames, 
CustomReporterBlockMorph.prototype.specFromFragments = CustomCommandBlockMorph.prototype.specFromFragments, 
CustomReporterBlockMorph.prototype.blockSpecFromFragments = CustomCommandBlockMorph.prototype.blockSpecFromFragments, 
CustomReporterBlockMorph.prototype.declarationsFromFragments = CustomCommandBlockMorph.prototype.declarationsFromFragments, 
CustomReporterBlockMorph.prototype.refreshPrototype = CustomCommandBlockMorph.prototype.refreshPrototype, 
CustomReporterBlockMorph.prototype.refreshPrototypeSlotTypes = CustomCommandBlockMorph.prototype.refreshPrototypeSlotTypes, 
CustomReporterBlockMorph.prototype.restoreInputs = CustomCommandBlockMorph.prototype.restoreInputs, 
CustomReporterBlockMorph.prototype.refreshDefaults = CustomCommandBlockMorph.prototype.refreshDefaults, 
CustomReporterBlockMorph.prototype.isInUse = CustomCommandBlockMorph.prototype.isInUse, 
CustomReporterBlockMorph.prototype.userMenu = CustomCommandBlockMorph.prototype.userMenu, 
CustomReporterBlockMorph.prototype.deleteBlockDefinition = CustomCommandBlockMorph.prototype.deleteBlockDefinition, 
CustomReporterBlockMorph.prototype.mouseEnter = CustomCommandBlockMorph.prototype.mouseEnter, 
CustomReporterBlockMorph.prototype.mouseLeave = CustomCommandBlockMorph.prototype.mouseLeave, 
CustomReporterBlockMorph.prototype.bubbleHelp = CustomCommandBlockMorph.prototype.bubbleHelp, 
CustomReporterBlockMorph.prototype.popUpbubbleHelp = CustomCommandBlockMorph.prototype.popUpbubbleHelp, 
CustomReporterBlockMorph.prototype.relabel = CustomCommandBlockMorph.prototype.relabel, 
CustomReporterBlockMorph.prototype.alternatives = CustomCommandBlockMorph.prototype.alternatives, 
JaggedBlockMorph.prototype = new ReporterBlockMorph(), JaggedBlockMorph.prototype.constructor = JaggedBlockMorph, 
JaggedBlockMorph.uber = ReporterBlockMorph.prototype, JaggedBlockMorph.prototype.jag = 5;

function JaggedBlockMorph(spec) {
    this.init(spec);
}

JaggedBlockMorph.prototype.init = function(spec) {
    JaggedBlockMorph.uber.init.call(this), spec && this.setSpec(spec), "%cs" === spec && (this.minWidth = 25, 
    this.fixLayout());
}, JaggedBlockMorph.prototype.drawNew = function() {
    var context;
    this.cachedClr = this.color.toString(), this.cachedClrBright = this.bright(), this.cachedClrDark = this.dark(), 
    this.image = newCanvas(this.extent()), (context = this.image.getContext("2d")).fillStyle = this.cachedClr, 
    this.drawBackground(context), MorphicPreferences.isFlat || this.drawEdges(context), 
    this.eraseHoles(context);
}, JaggedBlockMorph.prototype.drawBackground = function(context) {
    var i, y, w = this.width(), h = this.height(), jags = Math.round(h / this.jag), delta = h / jags;
    for (context.fillStyle = this.cachedClr, context.beginPath(), context.moveTo(0, 0), 
    context.lineTo(w, 0), y = 0, i = 0; i < jags; i += 1) y += delta / 2, context.lineTo(w - this.jag / 2, y), 
    y += delta / 2, context.lineTo(w, y);
    for (context.lineTo(0, h), y = h, i = 0; i < jags; i += 1) y -= delta / 2, context.lineTo(this.jag / 2, y), 
    y -= delta / 2, context.lineTo(0, y);
    context.closePath(), context.fill();
}, JaggedBlockMorph.prototype.drawEdges = function(context) {
    var gradient, i, y, w = this.width(), h = this.height(), jags = Math.round(h / this.jag), delta = h / jags, shift = this.edge / 2;
    for (context.lineWidth = this.edge, context.lineJoin = "round", context.lineCap = "round", 
    (gradient = context.createLinearGradient(0, 0, 0, this.edge)).addColorStop(0, this.cachedClrBright), 
    gradient.addColorStop(1, this.cachedClr), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(shift, shift), context.lineTo(w - shift, shift), context.stroke(), 
    y = 0, i = 0; i < jags; i += 1) context.strokeStyle = this.cachedClrDark, context.beginPath(), 
    context.moveTo(w - shift, y), y += delta / 2, context.lineTo(w - this.jag / 2 - shift, y), 
    context.stroke(), y += delta / 2;
    for ((gradient = context.createLinearGradient(0, h - this.edge, 0, h)).addColorStop(0, this.cachedClr), 
    gradient.addColorStop(1, this.cachedClrDark), context.strokeStyle = gradient, context.beginPath(), 
    context.moveTo(w - shift, h - shift), context.lineTo(shift, h - shift), context.stroke(), 
    y = h, i = 0; i < jags; i += 1) context.strokeStyle = this.cachedClrBright, context.beginPath(), 
    context.moveTo(shift, y), y -= delta / 2, context.lineTo(this.jag / 2 + shift, y), 
    context.stroke(), y -= delta / 2;
}, BlockDialogMorph.prototype = new DialogBoxMorph(), BlockDialogMorph.prototype.constructor = BlockDialogMorph, 
BlockDialogMorph.uber = DialogBoxMorph.prototype;

function BlockDialogMorph(target, action, environment) {
    this.init(target, action, environment);
}

BlockDialogMorph.prototype.init = function(target, action, environment) {
    this.blockType = "command", this.category = "other", this.isGlobal = !0, this.types = null, 
    this.categories = null, BlockDialogMorph.uber.init.call(this, target, action, environment), 
    this.key = "makeABlock", this.types = new AlignmentMorph("row", this.padding), this.add(this.types), 
    this.scopes = new AlignmentMorph("row", this.padding), this.add(this.scopes), this.categories = new BoxMorph(), 
    this.categories.color = SpriteMorph.prototype.paletteColor.lighter(8), this.categories.borderColor = this.categories.color.lighter(40), 
    this.createCategoryButtons(), this.fixCategoriesLayout(), this.add(this.categories), 
    this.createTypeButtons(), this.createScopeButtons(), this.fixLayout();
}, BlockDialogMorph.prototype.openForChange = function(title, category, type, world, pic, preventTypeChange) {
    var clr = SpriteMorph.prototype.blockColor[category];
    this.key = "changeABlock", this.category = category, this.blockType = type, this.categories.children.forEach(function(each) {
        each.refresh();
    }), this.types.children.forEach(function(each) {
        each.setColor(clr), each.refresh();
    }), this.labelString = title, this.createLabel(), pic && this.setPicture(pic), this.addButton("ok", "OK"), 
    this.addButton("cancel", "Cancel"), preventTypeChange && (this.types.destroy(), 
    this.types = null), this.scopes.destroy(), this.scopes = null, this.fixLayout(), 
    this.drawNew(), this.popUp(world);
}, BlockDialogMorph.prototype.createCategoryButtons = function() {
    var myself = this, oldFlag = Morph.prototype.trackChanges;
    Morph.prototype.trackChanges = !1, SpriteMorph.prototype.categories.forEach(function(cat) {
        myself.addCategoryButton(cat);
    }), Morph.prototype.trackChanges = oldFlag;
}, BlockDialogMorph.prototype.addCategoryButton = function(category) {
    var button, myself = this, colors = [ SpriteMorph.prototype.paletteColor, SpriteMorph.prototype.paletteColor.darker(50), SpriteMorph.prototype.blockColor[category] ];
    return (button = new ToggleButtonMorph(colors, this, function() {
        myself.category = category, myself.categories.children.forEach(function(each) {
            each.refresh();
        }), myself.types && myself.types.children.forEach(function(each) {
            each.setColor(colors[2]);
        }), myself.edit();
    }, category[0].toUpperCase().concat(category.slice(1)), function() {
        return myself.category === category;
    }, null, null, null, 75, !0)).corner = 8, button.padding = 0, button.labelShadowOffset = new Point(-1, -1), 
    button.labelShadowColor = colors[1], button.labelColor = IDE_Morph.prototype.buttonLabelColor, 
    button.contrast = this.buttonContrast, button.fixLayout(), button.refresh(), this.categories.add(button), 
    button;
}, BlockDialogMorph.prototype.fixCategoriesLayout = function() {
    var row, col, buttonWidth = this.categories.children[0].width(), buttonHeight = this.categories.children[0].height(), rows = Math.ceil(this.categories.children.length / 2), l = this.categories.left(), t = this.categories.top(), i = 0, oldFlag = Morph.prototype.trackChanges;
    Morph.prototype.trackChanges = !1, this.categories.children.forEach(function(button) {
        i += 1, row = Math.ceil(i / 2), col = 2 - i % 2, button.setPosition(new Point(l + (15 * col + (col - 1) * buttonWidth), t + (2 * row + (row - 1) * buttonHeight + 10)));
    }), MorphicPreferences.isFlat && (this.categories.corner = 0, this.categories.border = 0, 
    this.categories.edge = 0), this.categories.setExtent(new Point(45 + 2 * buttonWidth, 2 * (rows + 1) + rows * buttonHeight + 20)), 
    Morph.prototype.trackChanges = oldFlag, this.categories.changed();
}, BlockDialogMorph.prototype.createTypeButtons = function() {
    var block, myself = this, clr = SpriteMorph.prototype.blockColor[this.category];
    (block = new CommandBlockMorph()).setColor(clr), block.setSpec(localize("Command")), 
    this.addBlockTypeButton(function() {
        myself.setType("command");
    }, block, function() {
        return "command" === myself.blockType;
    }), (block = new ReporterBlockMorph()).setColor(clr), block.setSpec(localize("Reporter")), 
    this.addBlockTypeButton(function() {
        myself.setType("reporter");
    }, block, function() {
        return "reporter" === myself.blockType;
    }), (block = new ReporterBlockMorph(!0)).setColor(clr), block.setSpec(localize("Predicate")), 
    this.addBlockTypeButton(function() {
        myself.setType("predicate");
    }, block, function() {
        return "predicate" === myself.blockType;
    });
}, BlockDialogMorph.prototype.addBlockTypeButton = function(action, element, query) {
    var button = new ToggleElementMorph(this, action, element, query, null, null, "rebuild");
    return button.refresh(), this.types.add(button), button;
}, BlockDialogMorph.prototype.addTypeButton = function(action, label, query) {
    var button = new ToggleMorph("radiobutton", this, action, label, query);
    return button.edge = this.buttonEdge / 2, button.outline = this.buttonOutline / 2, 
    button.outlineColor = this.buttonOutlineColor, button.outlineGradient = this.buttonOutlineGradient, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), this.types.add(button), 
    button;
}, BlockDialogMorph.prototype.setType = function(blockType) {
    this.blockType = blockType || this.blockType, this.types.children.forEach(function(c) {
        c.refresh();
    }), this.edit();
}, BlockDialogMorph.prototype.createScopeButtons = function() {
    var myself = this;
    this.addScopeButton(function() {
        myself.setScope("gobal");
    }, "for all sprites", function() {
        return myself.isGlobal;
    }), this.addScopeButton(function() {
        myself.setScope("local");
    }, "for this sprite only", function() {
        return !myself.isGlobal;
    });
}, BlockDialogMorph.prototype.addScopeButton = function(action, label, query) {
    var button = new ToggleMorph("radiobutton", this, action, label, query);
    return button.edge = this.buttonEdge / 2, button.outline = this.buttonOutline / 2, 
    button.outlineColor = this.buttonOutlineColor, button.outlineGradient = this.buttonOutlineGradient, 
    button.contrast = this.buttonContrast, button.drawNew(), button.fixLayout(), this.scopes.add(button), 
    button;
}, BlockDialogMorph.prototype.setScope = function(varType) {
    this.isGlobal = "gobal" === varType, this.scopes.children.forEach(function(c) {
        c.refresh();
    }), this.edit();
}, BlockDialogMorph.prototype.getInput = function() {
    var spec, def, body;
    return this.body instanceof InputFieldMorph && (spec = this.normalizeSpaces(this.body.getValue())), 
    (def = new CustomBlockDefinition(spec)).type = this.blockType, def.category = this.category, 
    def.isGlobal = this.isGlobal, "reporter" !== def.type && "predicate" !== def.type || ((body = Process.prototype.reify.call(null, SpriteMorph.prototype.blockForSelector("doReport"), new List(), !0)).outerContext = null, 
    def.body = body), def;
}, BlockDialogMorph.prototype.fixLayout = function() {
    var th = fontHeight(this.titleFontSize) + 2 * this.titlePadding;
    this.body ? (this.body.setPosition(this.position().add(new Point(this.padding, th + this.padding))), 
    this.silentSetWidth(this.body.width() + 2 * this.padding), this.silentSetHeight(this.body.height() + 2 * this.padding + th), 
    this.categories && (this.categories.setCenter(this.body.center()), this.categories.setTop(this.body.top()), 
    this.body.setTop(this.categories.bottom() + this.padding), this.silentSetHeight(this.height() + this.categories.height() + this.padding))) : this.head && (this.types ? (this.types.fixLayout(), 
    this.silentSetWidth(Math.max(this.types.width(), this.head.width()) + 2 * this.padding)) : this.silentSetWidth(Math.max(this.categories.width(), this.head.width()) + 2 * this.padding), 
    this.head.setCenter(this.center()), this.head.setTop(th + this.padding), this.silentSetHeight(this.head.height() + 2 * this.padding + th), 
    this.categories && (this.categories.setCenter(this.center()), this.categories.setTop(this.head.bottom() + this.padding), 
    this.silentSetHeight(this.height() + this.categories.height() + this.padding))), 
    this.label && (this.label.setCenter(this.center()), this.label.setTop(this.top() + (th - this.label.height()) / 2)), 
    this.types && (this.types.fixLayout(), this.silentSetHeight(this.height() + this.types.height() + this.padding), 
    this.silentSetWidth(Math.max(this.width(), this.types.width() + 2 * this.padding)), 
    this.types.setCenter(this.center()), this.body ? this.types.setTop(this.body.bottom() + this.padding) : this.categories && this.types.setTop(this.categories.bottom() + this.padding)), 
    this.scopes && (this.scopes.fixLayout(), this.silentSetHeight(this.height() + this.scopes.height() + this.padding / 3), 
    this.silentSetWidth(Math.max(this.width(), this.scopes.width() + 2 * this.padding)), 
    this.scopes.setCenter(this.center()), this.types && this.scopes.setTop(this.types.bottom() + this.padding / 3)), 
    this.buttons && this.buttons.children.length > 0 && (this.buttons.fixLayout(), this.silentSetHeight(this.height() + this.buttons.height() + this.padding), 
    this.buttons.setCenter(this.center()), this.buttons.setBottom(this.bottom() - this.padding));
}, BlockEditorMorph.prototype = new DialogBoxMorph(), BlockEditorMorph.prototype.constructor = BlockEditorMorph, 
BlockEditorMorph.uber = DialogBoxMorph.prototype;

function BlockEditorMorph(definition, target) {
    this.init(definition, target);
}

BlockEditorMorph.prototype.init = function(definition, target) {
    var scripts, proto, scriptsFrame, block, comment, myself = this;
    this.definition = definition, this.handle = null, BlockEditorMorph.uber.init.call(this, target, function() {
        myself.updateDefinition();
    }, target), this.key = "editBlock" + definition.spec, this.labelString = "Block Editor", 
    this.createLabel(), (scripts = new ScriptsMorph(target)).isDraggable = !1, scripts.color = IDE_Morph.prototype.groupColor, 
    scripts.cachedTexture = IDE_Morph.prototype.scriptsPaneTexture, scripts.cleanUpMargin = 10, 
    (proto = new PrototypeHatBlockMorph(this.definition)).setPosition(scripts.position().add(10)), 
    null !== definition.comment && (comment = definition.comment.fullCopy(), proto.comment = comment, 
    comment.block = proto), null !== definition.body && proto.nextBlock(definition.body.expression.fullCopy()), 
    scripts.add(proto), proto.fixBlockColor(null, !0), this.definition.scripts.forEach(function(element) {
        (block = element.fullCopy()).setPosition(scripts.position().add(element.position())), 
        scripts.add(block), block instanceof BlockMorph && block.allComments().forEach(function(comment) {
            comment.align(block);
        });
    }), proto.allComments().forEach(function(comment) {
        comment.align(proto);
    }), (scriptsFrame = new ScrollFrameMorph(scripts)).padding = 10, scriptsFrame.growth = 50, 
    scriptsFrame.isDraggable = !1, scriptsFrame.acceptsDrops = !1, scriptsFrame.contents.acceptsDrops = !0, 
    scripts.scrollFrame = scriptsFrame, this.addBody(scriptsFrame), this.addButton("ok", "OK"), 
    this.addButton("updateDefinition", "Apply"), this.addButton("cancel", "Cancel"), 
    this.setExtent(new Point(375, 300)), this.fixLayout(), proto.children[0].fixLayout(), 
    scripts.fixMultiArgs();
}, BlockEditorMorph.prototype.popUp = function() {
    var world = this.target.world();
    world && (BlockEditorMorph.uber.popUp.call(this, world), this.handle = new HandleMorph(this, 280, 220, this.corner, this.corner));
}, BlockEditorMorph.prototype.accept = function() {
    this.action && ("function" == typeof this.target ? "function" == typeof this.action ? this.target.call(this.environment, this.action.call()) : this.target.call(this.environment, this.action) : "function" == typeof this.action ? this.action.call(this.target, this.getInput()) : this.target[this.action](this.getInput())), 
    this.close();
}, BlockEditorMorph.prototype.cancel = function() {
    this.close();
}, BlockEditorMorph.prototype.close = function() {
    var doubles, block;
    return this.definition.isGlobal && (block = detect(this.body.contents.allChildren(), function(morph) {
        return morph.definition && !morph.definition.isGlobal;
    })) ? ((block = block.definition.blockInstance()).addShadow(), void new DialogBoxMorph().inform("Local Block(s) in Global Definition", "This global block definition contains one or more\nlocal custom blocks which must be removed first.", this.world(), block.fullImage())) : (doubles = this.target.doubleDefinitionsFor(this.definition)).length > 0 ? ((block = doubles[0].blockInstance()).addShadow(), 
    void new DialogBoxMorph(this, "consolidateDoubles", this).askYesNo("Same Named Blocks", "Another custom block with this name exists.\nWould you like to replace it?", this.world(), block.fullImage())) : void this.destroy();
}, BlockEditorMorph.prototype.consolidateDoubles = function() {
    this.target.replaceDoubleDefinitionsFor(this.definition), this.destroy();
}, BlockEditorMorph.prototype.refreshAllBlockInstances = function() {
    var template = this.target.paletteBlockInstance(this.definition);
    this.target.allBlockInstances(this.definition).forEach(function(block) {
        block.refresh();
    }), template && template.refreshDefaults();
}, BlockEditorMorph.prototype.updateDefinition = function() {
    var head, ide, element, pos = this.body.contents.position(), myself = this;
    this.definition.receiver = this.target, this.definition.spec = this.prototypeSpec(), 
    this.definition.declarations = this.prototypeSlots(), this.definition.scripts = [], 
    this.body.contents.children.forEach(function(morph) {
        morph instanceof PrototypeHatBlockMorph ? head = morph : (morph instanceof BlockMorph || morph instanceof CommentMorph && !morph.block) && ((element = morph.fullCopy()).parent = null, 
        element.setPosition(morph.position().subtract(pos)), myself.definition.scripts.push(element));
    }), head && (this.definition.category = head.blockCategory, this.definition.type = head.type, 
    head.comment ? (this.definition.comment = head.comment.fullCopy(), this.definition.comment.block = !0) : this.definition.comment = null), 
    this.definition.body = this.context(head), this.refreshAllBlockInstances(), (ide = this.target.parentThatIsA(IDE_Morph)).flushPaletteCache(), 
    ide.refreshPalette();
}, BlockEditorMorph.prototype.context = function(prototypeHat) {
    var topBlock, stackFrame;
    return null === (topBlock = (prototypeHat || detect(this.body.contents.children, function(c) {
        return c instanceof PrototypeHatBlockMorph;
    })).nextBlock()) ? null : ((stackFrame = Process.prototype.reify.call(null, topBlock, new List(this.definition.inputNames()), !0)).outerContext = null, 
    stackFrame);
}, BlockEditorMorph.prototype.prototypeSpec = function() {
    return detect(this.body.contents.children, function(c) {
        return c instanceof PrototypeHatBlockMorph;
    }).parts()[0].specFromFragments();
}, BlockEditorMorph.prototype.prototypeSlots = function() {
    return detect(this.body.contents.children, function(c) {
        return c instanceof PrototypeHatBlockMorph;
    }).parts()[0].declarationsFromFragments();
}, BlockEditorMorph.prototype.fixLayout = function() {
    var th = fontHeight(this.titleFontSize) + 2 * this.titlePadding;
    this.buttons && this.buttons.children.length > 0 && this.buttons.fixLayout(), this.body && (this.body.setPosition(this.position().add(new Point(this.padding, th + this.padding))), 
    this.body.setExtent(new Point(this.width() - 2 * this.padding, this.height() - 3 * this.padding - th - this.buttons.height()))), 
    this.label && (this.label.setCenter(this.center()), this.label.setTop(this.top() + (th - this.label.height()) / 2)), 
    this.buttons && this.buttons.children.length > 0 && (this.buttons.setCenter(this.center()), 
    this.buttons.setBottom(this.bottom() - this.padding));
}, PrototypeHatBlockMorph.prototype = new HatBlockMorph(), PrototypeHatBlockMorph.prototype.constructor = PrototypeHatBlockMorph, 
PrototypeHatBlockMorph.uber = HatBlockMorph.prototype;

function PrototypeHatBlockMorph(definition) {
    this.init(definition);
}

PrototypeHatBlockMorph.prototype.init = function(definition) {
    var proto = definition.prototypeInstance();
    this.definition = definition, this.blockCategory = definition ? definition.category : null, 
    this.type = definition ? definition.type : null, HatBlockMorph.uber.init.call(this), 
    this.color = SpriteMorph.prototype.blockColor.control, this.category = "control", 
    this.add(proto), proto.refreshPrototypeSlotTypes(), this.fixLayout();
}, PrototypeHatBlockMorph.prototype.mouseClickLeft = function() {
    this.children[0].mouseClickLeft();
}, PrototypeHatBlockMorph.prototype.userMenu = function() {
    return this.children[0].userMenu();
}, PrototypeHatBlockMorph.prototype.fixBlockColor = function(nearestBlock, isForced) {
    var nearest = this.children[0] || nearestBlock;
    if (this.zebraContrast || isForced) {
        if (!this.zebraContrast && isForced) return this.forceNormalColoring();
        nearest.category === this.category ? nearest.color.eq(this.color) && this.alternateBlockColor() : this.category && !this.color.eq(SpriteMorph.prototype.blockColor[this.category]) && this.alternateBlockColor(), 
        isForced && this.fixChildrensBlockColor(!0);
    }
};

function BlockLabelFragment(labelString) {
    this.labelString = labelString || "", this.type = "%s", this.defaultValue = "", 
    this.options = "", this.isReadOnly = !1, this.isDeleted = !1;
}

BlockLabelFragment.prototype.defSpecFragment = function() {
    var pref = this.type ? "%'" : "";
    return this.isDeleted ? "" : pref + this.labelString + (this.type ? "'" : "");
}, BlockLabelFragment.prototype.defTemplateSpecFragment = function() {
    var suff = "";
    return this.type ? (this.isUpvar() ? suff = " ↑" : this.isMultipleInput() ? suff = "..." : "%cs" === this.type ? suff = " λ" : "%b" === this.type ? suff = " ?" : "%l" === this.type ? suff = " ︙" : "%obj" === this.type ? suff = " %turtleOutline" : contains([ "%cmdRing", "%repRing", "%predRing", "%anyUE", "%boolUE" ], this.type) ? suff = " λ" : this.defaultValue && (suff = " = " + this.defaultValue.toString()), 
    this.labelString + suff) : this.defSpecFragment();
}, BlockLabelFragment.prototype.blockSpecFragment = function() {
    return this.isDeleted ? "" : this.type || this.labelString;
}, BlockLabelFragment.prototype.copy = function() {
    var ans = new BlockLabelFragment(this.labelString);
    return ans.type = this.type, ans.defaultValue = this.defaultValue, ans.options = this.options, 
    ans.isReadOnly = this.isReadOnly, ans;
}, BlockLabelFragment.prototype.isSingleInput = function() {
    return !this.isMultipleInput() && "%upvar" !== this.type;
}, BlockLabelFragment.prototype.isMultipleInput = function() {
    return !!this.type && this.type.indexOf("%mult") > -1;
}, BlockLabelFragment.prototype.isUpvar = function() {
    return !!this.type && "%upvar" === this.type;
}, BlockLabelFragment.prototype.setToSingleInput = function() {
    if (!this.type) return null;
    "%upvar" === this.type ? this.type = "%s" : this.type = this.singleInputType();
}, BlockLabelFragment.prototype.setToMultipleInput = function() {
    if (!this.type) return null;
    "%upvar" === this.type && (this.type = "%s"), this.type = "%mult".concat(this.singleInputType());
}, BlockLabelFragment.prototype.setToUpvar = function() {
    if (!this.type) return null;
    this.type = "%upvar";
}, BlockLabelFragment.prototype.singleInputType = function() {
    return this.type ? this.isMultipleInput() ? this.type.substr(5) : this.type : null;
}, BlockLabelFragment.prototype.setSingleInputType = function(type) {
    this.type && this.isMultipleInput() ? this.type = "%mult".concat(type) : this.type = type;
}, BlockLabelFragmentMorph.prototype = new StringMorph(), BlockLabelFragmentMorph.prototype.constructor = BlockLabelFragmentMorph, 
BlockLabelFragmentMorph.uber = StringMorph.prototype;

function BlockLabelFragmentMorph(text) {
    this.init(text);
}

BlockLabelFragmentMorph.prototype.init = function(text) {
    this.fragment = new BlockLabelFragment(text), this.fragment.type = null, this.sO = null, 
    BlockLabelFragmentMorph.uber.init.call(this, text, null, SyntaxElementMorph.prototype.labelFontStyle, null, null, null, null, null, null, SyntaxElementMorph.prototype.labelFontName);
}, BlockLabelFragmentMorph.prototype.mouseEnter = function() {
    this.sO = this.shadowOffset, this.shadowOffset = this.sO.neg(), this.drawNew(), 
    this.changed();
}, BlockLabelFragmentMorph.prototype.mouseLeave = function() {
    this.shadowOffset = this.sO, this.drawNew(), this.changed();
}, BlockLabelFragmentMorph.prototype.mouseClickLeft = function() {
    var frag = this.fragment.copy(), myself = this, isPlaceHolder = this instanceof BlockLabelPlaceHolderMorph, isOnlyElement = this.parent.parseSpec(this.parent.blockSpec).length < 2;
    new InputSlotDialogMorph(frag, null, function() {
        myself.updateBlockLabel(frag);
    }, this, this.parent.definition.category).open(this instanceof BlockLabelFragmentMorph ? "Edit label fragment" : isPlaceHolder ? "Create input name" : "Edit input name", frag.labelString, this.world(), null, isPlaceHolder || isOnlyElement);
}, BlockLabelFragmentMorph.prototype.updateBlockLabel = function(newFragment) {
    var prot = this.parentThatIsA(BlockMorph);
    this.fragment = newFragment, prot && prot.refreshPrototype();
}, BlockLabelFragmentMorph.prototype.userMenu = function() {
    var myself = this, symbolColor = new Color(100, 100, 130), menu = new MenuMorph(function(string) {
        var tuple = myself.text.split("-");
        myself.changed(), tuple[0] = "$" + string, myself.text = tuple.join("-"), myself.fragment.labelString = myself.text, 
        myself.drawNew(), myself.changed();
    }, null, this, this.fontSize);
    return SymbolMorph.prototype.names.forEach(function(name) {
        menu.addItem([ new SymbolMorph(name, menu.fontSize, symbolColor), name ], name);
    }), menu;
}, BlockLabelPlaceHolderMorph.prototype = new StringMorph(), BlockLabelPlaceHolderMorph.prototype.constructor = BlockLabelPlaceHolderMorph, 
BlockLabelPlaceHolderMorph.uber = StringMorph.prototype, BlockLabelPlaceHolderMorph.prototype.plainLabel = !1;

function BlockLabelPlaceHolderMorph() {
    this.init();
}

BlockLabelPlaceHolderMorph.prototype.init = function() {
    this.fragment = new BlockLabelFragment(""), this.fragment.type = "%s", this.fragment.isDeleted = !0, 
    this.isHighlighted = !1, this.isProtectedLabel = !0, BlockLabelFragmentMorph.uber.init.call(this, "+");
}, BlockLabelPlaceHolderMorph.prototype.drawNew = function() {
    var context, width, x, y, cx, cy;
    this.plainLabel && (this.text = this.isHighlighted ? " + " : ""), this.image = newCanvas(), 
    (context = this.image.getContext("2d")).font = this.font(), width = Math.max(context.measureText(this.text).width + Math.abs(this.shadowOffset.x), 1), 
    this.bounds.corner = this.bounds.origin.add(new Point(width, fontHeight(this.fontSize) + Math.abs(this.shadowOffset.y))), 
    this.image.width = width, this.image.height = this.height(), this.isHighlighted && (cx = Math.floor(width / 2), 
    cy = Math.floor(this.height() / 2), context.fillStyle = this.color.toString(), context.beginPath(), 
    context.arc(cx, 1.2 * cy, Math.min(cx, cy), radians(0), radians(360), !1), context.closePath(), 
    context.fill()), context.font = this.font(), context.textAlign = "left", context.textBaseline = "bottom", 
    this.shadowColor && (x = Math.max(this.shadowOffset.x, 0), y = Math.max(this.shadowOffset.y, 0), 
    context.fillStyle = this.shadowColor.toString(), context.fillText(this.text, x, fontHeight(this.fontSize) + y)), 
    x = Math.abs(Math.min(this.shadowOffset.x, 0)), y = Math.abs(Math.min(this.shadowOffset.y, 0)), 
    context.fillStyle = this.isHighlighted ? "white" : this.color.toString(), context.fillText(this.text, x, fontHeight(this.fontSize) + y), 
    this.parent && this.parent.fixLayout && this.parent.fixLayout();
}, BlockLabelPlaceHolderMorph.prototype.mouseEnter = function() {
    this.isHighlighted = !0, this.drawNew(), this.changed();
}, BlockLabelPlaceHolderMorph.prototype.mouseLeave = function() {
    this.isHighlighted = !1, this.drawNew(), this.changed();
}, BlockLabelPlaceHolderMorph.prototype.mouseClickLeft = BlockLabelFragmentMorph.prototype.mouseClickLeft, 
BlockLabelPlaceHolderMorph.prototype.updateBlockLabel = BlockLabelFragmentMorph.prototype.updateBlockLabel, 
BlockInputFragmentMorph.prototype = new TemplateSlotMorph(), BlockInputFragmentMorph.prototype.constructor = BlockInputFragmentMorph, 
BlockInputFragmentMorph.uber = TemplateSlotMorph.prototype;

function BlockInputFragmentMorph(text) {
    this.init(text);
}

BlockInputFragmentMorph.prototype.init = function(text) {
    this.fragment = new BlockLabelFragment(text), this.fragment.type = "%s", BlockInputFragmentMorph.uber.init.call(this, text);
}, BlockInputFragmentMorph.prototype.mouseClickLeft = BlockLabelFragmentMorph.prototype.mouseClickLeft, 
BlockInputFragmentMorph.prototype.updateBlockLabel = BlockLabelFragmentMorph.prototype.updateBlockLabel, 
InputSlotDialogMorph.prototype = new DialogBoxMorph(), InputSlotDialogMorph.prototype.constructor = InputSlotDialogMorph, 
InputSlotDialogMorph.uber = DialogBoxMorph.prototype, InputSlotDialogMorph.prototype.isLaunchingExpanded = !1;

function InputSlotDialogMorph(fragment, target, action, environment, category) {
    this.init(fragment, target, action, environment, category);
}

InputSlotDialogMorph.prototype.init = function(fragment, target, action, environment, category) {
    var scale = SyntaxElementMorph.prototype.scale, fh = fontHeight(10) / 1.2 * scale;
    this.fragment = fragment || new BlockLabelFragment(), this.textfield = null, this.types = null, 
    this.slots = null, this.isExpanded = !1, this.category = category || "other", this.cachedRadioButton = null, 
    BlockDialogMorph.uber.init.call(this, target, action, environment), this.types = new AlignmentMorph("row", this.padding), 
    this.types.respectHiddens = !0, this.add(this.types), this.slots = new BoxMorph(), 
    this.slots.color = new Color(55, 55, 55), this.slots.borderColor = this.slots.color.lighter(50), 
    this.slots.setExtent(new Point(24 * (fh + 10), 10.4 * (fh + 10 * scale))), this.add(this.slots), 
    this.createSlotTypeButtons(), this.fixSlotsLayout(), this.addSlotsMenu(), this.createTypeButtons(), 
    this.fixLayout();
}, InputSlotDialogMorph.prototype.createTypeButtons = function() {
    var block, arrow, myself = this, clr = SpriteMorph.prototype.blockColor[this.category];
    (block = new JaggedBlockMorph(localize("Title text"))).setColor(clr), this.addBlockTypeButton(function() {
        myself.setType(null);
    }, block, function() {
        return null === myself.fragment.type;
    }), (block = new JaggedBlockMorph("%inputName")).setColor(clr), this.addBlockTypeButton(function() {
        myself.setType("%s");
    }, block, function() {
        return null !== myself.fragment.type;
    }), (arrow = new ArrowMorph("right", PushButtonMorph.prototype.fontSize + 4, 2)).noticesTransparentClick = !0, 
    this.types.add(arrow), this.types.fixLayout(), arrow.refresh = function() {
        null === myself.fragment.type ? (myself.isExpanded = !1, arrow.hide(), myself.drawNew()) : (arrow.show(), 
        myself.isExpanded ? arrow.direction = "down" : arrow.direction = "right", arrow.drawNew(), 
        arrow.changed());
    }, arrow.mouseClickLeft = function() {
        arrow.isVisible && (myself.isExpanded = !myself.isExpanded, myself.types.children.forEach(function(c) {
            c.refresh();
        }), myself.drawNew(), myself.edit());
    }, arrow.refresh();
}, InputSlotDialogMorph.prototype.addTypeButton = BlockDialogMorph.prototype.addTypeButton, 
InputSlotDialogMorph.prototype.addBlockTypeButton = BlockDialogMorph.prototype.addBlockTypeButton, 
InputSlotDialogMorph.prototype.setType = function(fragmentType) {
    this.textfield.choices = fragmentType ? null : this.symbolMenu, this.textfield.drawNew(), 
    this.fragment.type = fragmentType || null, this.types.children.forEach(function(c) {
        c.refresh();
    }), this.slots.children.forEach(function(c) {
        c.refresh();
    }), this.edit();
}, InputSlotDialogMorph.prototype.getInput = function() {
    var lbl;
    return this.body instanceof InputFieldMorph && (lbl = this.normalizeSpaces(this.body.getValue())), 
    lbl ? (this.fragment.labelString = lbl, this.fragment.defaultValue = this.slots.defaultInputField.getValue(), 
    lbl) : (this.fragment.isDeleted = !0, null);
}, InputSlotDialogMorph.prototype.fixLayout = function() {
    var maxWidth, left = this.left(), th = fontHeight(this.titleFontSize) + 2 * this.titlePadding;
    if (!this.isExpanded) return this.slots && this.slots.hide(), BlockDialogMorph.prototype.fixLayout.call(this);
    this.slots.show(), maxWidth = this.slots.width(), this.body.setPosition(this.position().add(new Point(this.padding + (maxWidth - this.body.width()) / 2, th + this.padding))), 
    this.label.setLeft(left + this.padding + (maxWidth - this.label.width()) / 2), this.label.setTop(this.top() + (th - this.label.height()) / 2), 
    this.types.fixLayout(), this.types.setTop(this.body.bottom() + this.padding), this.types.setLeft(left + this.padding + (maxWidth - this.types.width()) / 2), 
    this.slots.setPosition(new Point(this.left() + this.padding, this.types.bottom() + this.padding)), 
    this.slots.children.forEach(function(c) {
        c.refresh();
    }), this.buttons.fixLayout(), this.buttons.setTop(this.slots.bottom() + this.padding), 
    this.buttons.setLeft(left + this.padding + (maxWidth - this.buttons.width()) / 2), 
    this.silentSetHeight(this.buttons.bottom() - this.top() + this.padding), this.silentSetWidth(this.slots.right() - this.left() + this.padding);
}, InputSlotDialogMorph.prototype.open = function(title, defaultString, world, pic, noDeleteButton) {
    var txt = new InputFieldMorph(defaultString), oldFlag = Morph.prototype.trackChanges;
    this.fragment.type || (txt.choices = this.symbolMenu), Morph.prototype.trackChanges = !1, 
    this.isExpanded = this.isLaunchingExpanded, txt.setWidth(250), this.labelString = title, 
    this.createLabel(), pic && this.setPicture(pic), this.addBody(txt), txt.drawNew(), 
    this.textfield = txt, this.addButton("ok", "OK"), noDeleteButton || this.addButton("deleteFragment", "Delete"), 
    this.addButton("cancel", "Cancel"), this.fixLayout(), this.drawNew(), this.fixLayout(), 
    this.popUp(world), this.add(this.types), Morph.prototype.trackChanges = oldFlag, 
    this.changed();
}, InputSlotDialogMorph.prototype.symbolMenu = function() {
    var symbols = [], symbolColor = new Color(100, 100, 130), myself = this;
    return SymbolMorph.prototype.names.forEach(function(symbol) {
        symbols.push([ [ new SymbolMorph(symbol, myself.fontSize, symbolColor), localize(symbol) ], "$" + symbol ]);
    }), symbols;
}, InputSlotDialogMorph.prototype.deleteFragment = function() {
    this.fragment.isDeleted = !0, this.accept();
}, InputSlotDialogMorph.prototype.createSlotTypeButtons = function() {
    var defLabel, defInput, myself = this, oldFlag = Morph.prototype.trackChanges;
    Morph.prototype.trackChanges = !1, this.addSlotTypeButton("Object", "%obj"), this.addSlotTypeButton("Text", "%txt"), 
    this.addSlotTypeButton("List", "%l"), this.addSlotTypeButton("Number", "%n"), this.addSlotTypeButton("Any type", "%s"), 
    this.addSlotTypeButton("Boolean (T/F)", "%b"), this.addSlotTypeButton("Command\n(inline)", "%cmdRing"), 
    this.addSlotTypeButton("Reporter", "%repRing"), this.addSlotTypeButton("Predicate", "%predRing"), 
    this.addSlotTypeButton("Command\n(C-shape)", "%cs"), this.addSlotTypeButton("Any\n(unevaluated)", "%anyUE"), 
    this.addSlotTypeButton("Boolean\n(unevaluated)", "%boolUE"), this.slots.radioButtonSingle = this.addSlotArityButton(function() {
        myself.setSlotArity("single");
    }, "Single input.", function() {
        return myself.fragment.isSingleInput();
    }), this.addSlotArityButton(function() {
        myself.setSlotArity("multiple");
    }, "Multiple inputs (value is list of inputs)", function() {
        return myself.fragment.isMultipleInput();
    }), this.addSlotArityButton(function() {
        myself.setSlotArity("upvar");
    }, "Upvar - make internal variable visible to caller", function() {
        return myself.fragment.isUpvar();
    }), (defLabel = new StringMorph(localize("Default Value:"))).fontSize = this.slots.radioButtonSingle.fontSize, 
    defLabel.setColor(new Color(255, 255, 255)), defLabel.refresh = function() {
        myself.isExpanded && contains([ "%s", "%n", "%txt", "%anyUE" ], myself.fragment.type) ? defLabel.show() : defLabel.hide();
    }, this.slots.defaultInputLabel = defLabel, this.slots.add(defLabel), (defInput = new InputFieldMorph(this.fragment.defaultValue)).contents().fontSize = defLabel.fontSize, 
    defInput.contrast = 90, defInput.contents().drawNew(), defInput.setWidth(50), defInput.refresh = function() {
        defLabel.isVisible ? (defInput.show(), "%n" === myself.fragment.type ? defInput.setIsNumeric(!0) : defInput.setIsNumeric(!1)) : defInput.hide();
    }, this.slots.defaultInputField = defInput, this.slots.add(defInput), defInput.drawNew(), 
    Morph.prototype.trackChanges = oldFlag;
}, InputSlotDialogMorph.prototype.setSlotType = function(type) {
    this.fragment.setSingleInputType(type), this.slots.children.forEach(function(c) {
        c.refresh();
    }), this.edit();
}, InputSlotDialogMorph.prototype.setSlotArity = function(arity) {
    "single" === arity ? this.fragment.setToSingleInput() : "multiple" === arity ? this.fragment.setToMultipleInput() : "upvar" === arity && this.fragment.setToUpvar(), 
    this.slots.children.forEach(function(c) {
        c.refresh();
    }), this.edit();
}, InputSlotDialogMorph.prototype.addSlotTypeButton = function(label, spec) {
    var query, button, myself = this, element = new JaggedBlockMorph(spec);
    return query = function() {
        return myself.fragment.singleInputType() === spec;
    }, element.setCategory(this.category), element.rebuild(), (button = new ToggleMorph("radiobutton", this, function() {
        myself.setSlotType(spec);
    }, label, query, null, null, this.cachedRadioButton, element.fullImage(), "rebuild")).edge = this.buttonEdge / 2, 
    button.outline = this.buttonOutline / 2, button.outlineColor = this.buttonOutlineColor, 
    button.outlineGradient = this.buttonOutlineGradient, button.drawNew(), button.fixLayout(), 
    button.label.isBold = !1, button.label.setColor(new Color(255, 255, 255)), this.cachedRadioButton || (this.cachedRadioButton = button), 
    this.slots.add(button), button;
}, InputSlotDialogMorph.prototype.addSlotArityButton = function(action, label, query) {
    var button = new ToggleMorph("radiobutton", this, action, label, query, null, null, this.cachedRadioButton);
    return button.edge = this.buttonEdge / 2, button.outline = this.buttonOutline / 2, 
    button.outlineColor = this.buttonOutlineColor, button.outlineGradient = this.buttonOutlineGradient, 
    button.drawNew(), button.fixLayout(), button.label.setColor(new Color(255, 255, 255)), 
    this.slots.add(button), this.cachedRadioButton || (this.cachedRadioButton = button), 
    button;
}, InputSlotDialogMorph.prototype.fixSlotsLayout = function() {
    var idx, col, slots = this.slots, scale = SyntaxElementMorph.prototype.scale, xPadding = 10 * scale, ypadding = 14 * scale, bh = (fontHeight(10) / 1.2 + 15) * scale, ah = (fontHeight(10) / 1.2 + 10) * scale, cols = [ slots.left() + xPadding, slots.left() + slots.width() / 3, slots.left() + 2 * slots.width() / 3 ], rows = [ slots.top() + ypadding, slots.top() + ypadding + bh, slots.top() + ypadding + 2 * bh, slots.top() + ypadding + 3 * bh, slots.top() + ypadding + 4 * bh, slots.top() + ypadding + 5 * bh, slots.top() + ypadding + 5 * bh + ah, slots.top() + ypadding + 5 * bh + 2 * ah ], row = -1, oldFlag = Morph.prototype.trackChanges;
    for (Morph.prototype.trackChanges = !1, idx = 0; idx < 12; idx += 1) col = idx % 3, 
    idx % 3 == 0 && (row += 1), slots.children[idx].setPosition(new Point(cols[col], rows[row]));
    for (col = 0, row = 5, idx = 12; idx < 15; idx += 1) slots.children[idx].setPosition(new Point(cols[col], rows[row + idx - 12]));
    this.slots.defaultInputLabel.setPosition(this.slots.radioButtonSingle.label.topRight().add(new Point(5, 0))), 
    this.slots.defaultInputField.setCenter(this.slots.defaultInputLabel.center().add(new Point(this.slots.defaultInputField.width() / 2 + this.slots.defaultInputLabel.width() / 2 + 5, 0))), 
    Morph.prototype.trackChanges = oldFlag, this.slots.changed();
}, InputSlotDialogMorph.prototype.addSlotsMenu = function() {
    var myself = this;
    this.slots.userMenu = function() {
        if (contains([ "%s", "%n", "%txt", "%anyUE" ], myself.fragment.type)) {
            var menu = new MenuMorph(myself);
            return menu.addItem("options...", "editSlotOptions"), menu.addItem((myself.fragment.isReadOnly ? "☑ " : "☐ ") + localize("read-only"), function() {
                myself.fragment.isReadOnly = !myself.fragment.isReadOnly;
            }), menu;
        }
        return Morph.prototype.userMenu.call(myself);
    };
}, InputSlotDialogMorph.prototype.editSlotOptions = function() {
    var myself = this;
    new DialogBoxMorph(myself, function(options) {
        myself.fragment.options = options;
    }, myself).promptCode("Input Slot Options", myself.fragment.options, myself.world(), null, localize('Enter one option per line.Optionally use "=" as key/value delimiter\ne.g.\n   the answer=42'));
}, InputSlotDialogMorph.prototype.hide = function() {
    this.isVisible = !1, this.changed();
}, InputSlotDialogMorph.prototype.show = function() {
    this.isVisible = !0, this.changed();
}, VariableDialogMorph.prototype = new DialogBoxMorph(), VariableDialogMorph.prototype.constructor = VariableDialogMorph, 
VariableDialogMorph.uber = DialogBoxMorph.prototype;

function VariableDialogMorph(target, action, environment) {
    this.init(target, action, environment);
}

VariableDialogMorph.prototype.init = function(target, action, environment) {
    this.types = null, this.isGlobal = !0, BlockDialogMorph.uber.init.call(this, target, action, environment), 
    this.types = new AlignmentMorph("row", this.padding), this.add(this.types), this.createTypeButtons();
}, VariableDialogMorph.prototype.createTypeButtons = function() {
    var myself = this;
    this.addTypeButton(function() {
        myself.setType("gobal");
    }, "for all sprites", function() {
        return myself.isGlobal;
    }), this.addTypeButton(function() {
        myself.setType("local");
    }, "for this sprite only", function() {
        return !myself.isGlobal;
    });
}, VariableDialogMorph.prototype.addTypeButton = BlockDialogMorph.prototype.addTypeButton, 
VariableDialogMorph.prototype.setType = function(varType) {
    this.isGlobal = "gobal" === varType, this.types.children.forEach(function(c) {
        c.refresh();
    }), this.edit();
}, VariableDialogMorph.prototype.getInput = function() {
    var name = this.normalizeSpaces(this.body.getValue());
    return name ? [ name, this.isGlobal ] : null;
}, VariableDialogMorph.prototype.fixLayout = function() {
    var th = fontHeight(this.titleFontSize) + 2 * this.titlePadding;
    this.body && (this.body.setPosition(this.position().add(new Point(this.padding, th + this.padding))), 
    this.silentSetWidth(this.body.width() + 2 * this.padding), this.silentSetHeight(this.body.height() + 2 * this.padding + th)), 
    this.label && (this.label.setCenter(this.center()), this.label.setTop(this.top() + (th - this.label.height()) / 2)), 
    this.types && (this.types.fixLayout(), this.silentSetHeight(this.height() + this.types.height() + this.padding), 
    this.silentSetWidth(Math.max(this.width(), this.types.width() + 2 * this.padding)), 
    this.types.setCenter(this.center()), this.body ? this.types.setTop(this.body.bottom() + this.padding) : this.categories && this.types.setTop(this.categories.bottom() + this.padding)), 
    this.buttons && this.buttons.children.length > 0 && (this.buttons.fixLayout(), this.silentSetHeight(this.height() + this.buttons.height() + this.padding), 
    this.buttons.setCenter(this.center()), this.buttons.setBottom(this.bottom() - this.padding));
}, BlockExportDialogMorph.prototype = new DialogBoxMorph(), BlockExportDialogMorph.prototype.constructor = BlockExportDialogMorph, 
BlockExportDialogMorph.uber = DialogBoxMorph.prototype, BlockExportDialogMorph.prototype.key = "blockExport";

function BlockExportDialogMorph(serializer, blocks) {
    this.init(serializer, blocks);
}

BlockExportDialogMorph.prototype.init = function(serializer, blocks) {
    var myself = this;
    this.serializer = serializer, this.blocks = blocks.slice(0), this.handle = null, 
    BlockExportDialogMorph.uber.init.call(this, null, function() {
        myself.exportBlocks();
    }, null), this.labelString = "Export blocks", this.createLabel(), this.buildContents();
}, BlockExportDialogMorph.prototype.buildContents = function() {
    var palette, x, y, block, checkBox, lastCat, myself = this;
    (palette = new ScrollFrameMorph(null, null, SpriteMorph.prototype.sliderColor)).color = SpriteMorph.prototype.paletteColor, 
    palette.padding = 4, palette.isDraggable = !1, palette.acceptsDrops = !1, palette.contents.acceptsDrops = !1, 
    x = palette.left() + 4, y = palette.top() + 4, SpriteMorph.prototype.categories.forEach(function(category) {
        myself.blocks.forEach(function(definition) {
            definition.category === category && (lastCat && category !== lastCat && (y += 4), 
            lastCat = category, block = definition.templateInstance(), (checkBox = new ToggleMorph("checkbox", myself, function() {
                var idx = myself.blocks.indexOf(definition);
                idx > -1 ? myself.blocks.splice(idx, 1) : myself.blocks.push(definition);
            }, null, function() {
                return contains(myself.blocks, definition);
            }, null, null, null, block.fullImage())).setPosition(new Point(x, y + (checkBox.top() - checkBox.toggleElement.top()))), 
            palette.addContents(checkBox), y += checkBox.fullBounds().height() + 4);
        });
    }), palette.scrollX(4), palette.scrollY(4), this.addBody(palette), this.addButton("ok", "OK"), 
    this.addButton("cancel", "Cancel"), this.setExtent(new Point(220, 300)), this.fixLayout();
}, BlockExportDialogMorph.prototype.popUp = function(wrrld) {
    var world = wrrld || this.target.world();
    world && (BlockExportDialogMorph.uber.popUp.call(this, world), this.handle = new HandleMorph(this, 200, 220, this.corner, this.corner));
}, BlockExportDialogMorph.prototype.userMenu = function() {
    var menu = new MenuMorph(this, "select");
    return menu.addItem("all", "selectAll"), menu.addItem("none", "selectNone"), menu;
}, BlockExportDialogMorph.prototype.selectAll = function() {
    this.body.contents.children.forEach(function(checkBox) {
        checkBox.state || checkBox.trigger();
    });
}, BlockExportDialogMorph.prototype.selectNone = function() {
    this.blocks = [], this.body.contents.children.forEach(function(checkBox) {
        checkBox.refresh();
    });
}, BlockExportDialogMorph.prototype.exportBlocks = function() {
    var str = this.serializer.serialize(this.blocks);
    this.blocks.length > 0 ? window.open(encodeURI('data:text/xml,<blocks app="' + this.serializer.app + '" version="' + this.serializer.version + '">' + str + "</blocks>")) : new DialogBoxMorph().inform("Export blocks", "no blocks were selected", this.world());
}, BlockExportDialogMorph.prototype.fixLayout = BlockEditorMorph.prototype.fixLayout, 
BlockImportDialogMorph.prototype = new DialogBoxMorph(), BlockImportDialogMorph.prototype.constructor = BlockImportDialogMorph, 
BlockImportDialogMorph.uber = DialogBoxMorph.prototype, BlockImportDialogMorph.prototype.key = "blockImport";

function BlockImportDialogMorph(blocks, target, name) {
    this.init(blocks, target, name);
}

BlockImportDialogMorph.prototype.init = function(blocks, target, name) {
    var myself = this;
    this.blocks = blocks.slice(0), this.handle = null, BlockExportDialogMorph.uber.init.call(this, target, function() {
        myself.importBlocks(name);
    }, null), this.labelString = localize("Import blocks") + (name ? ": " : "") + name || "", 
    this.createLabel(), this.buildContents();
}, BlockImportDialogMorph.prototype.buildContents = BlockExportDialogMorph.prototype.buildContents, 
BlockImportDialogMorph.prototype.popUp = BlockExportDialogMorph.prototype.popUp, 
BlockImportDialogMorph.prototype.userMenu = BlockExportDialogMorph.prototype.userMenu, 
BlockImportDialogMorph.prototype.selectAll = BlockExportDialogMorph.prototype.selectAll, 
BlockImportDialogMorph.prototype.selectNone = BlockExportDialogMorph.prototype.selectNone, 
BlockImportDialogMorph.prototype.importBlocks = function(name) {
    var ide = this.target.parentThatIsA(IDE_Morph);
    ide && (this.blocks.length > 0 ? (this.blocks.forEach(function(def) {
        def.receiver = ide.stage, ide.stage.globalBlocks.push(def), ide.stage.replaceDoubleDefinitionsFor(def);
    }), ide.flushPaletteCache(), ide.refreshPalette(), ide.showMessage("Imported Blocks Module" + (name ? ": " + name : "") + ".", 2)) : new DialogBoxMorph().inform("Import blocks", "no blocks were selected", this.world()));
}, BlockImportDialogMorph.prototype.fixLayout = BlockEditorMorph.prototype.fixLayout, 
modules.xml = "2014-January-09";

var ReadStream, XML_Element;

function ReadStream(arrayOrString) {
    this.contents = arrayOrString || "", this.index = 0;
}

ReadStream.prototype.space = /[\s]/, ReadStream.prototype.next = function(count) {
    var element, start;
    return void 0 === count ? (element = this.contents[this.index], this.index += 1, 
    element) : (start = this.index, this.index += count, this.contents.slice(start, this.index));
}, ReadStream.prototype.peek = function() {
    return this.contents[this.index];
}, ReadStream.prototype.skip = function(count) {
    this.index += count || 1;
}, ReadStream.prototype.atEnd = function() {
    return this.index > this.contents.length - 1;
}, ReadStream.prototype.upTo = function(regex) {
    var i, start;
    return isString(this.contents) ? -1 === (i = this.contents.substr(this.index).search(regex)) ? "" : (start = this.index, 
    this.index += i, this.contents.substring(start, this.index)) : "";
}, ReadStream.prototype.peekUpTo = function(regex) {
    if (!isString(this.contents)) return "";
    var i = this.contents.substr(this.index).search(regex);
    return -1 === i ? "" : this.contents.substring(this.index, this.index + i);
}, ReadStream.prototype.skipSpace = function() {
    if (!isString(this.contents)) return "";
    for (var ch = this.peek(); this.space.test(ch) && "" !== ch; ) this.skip(), ch = this.peek();
}, ReadStream.prototype.word = function() {
    var i, start;
    return isString(this.contents) ? -1 === (i = this.contents.substr(this.index).search(/[\s\>\/\=]|$/)) ? "" : (start = this.index, 
    this.index += i, this.contents.substring(start, this.index)) : "";
}, XML_Element.prototype = new Node(), XML_Element.prototype.constructor = XML_Element, 
XML_Element.uber = Node.prototype, XML_Element.prototype.indentation = "  ";

function XML_Element(tag, contents, parent) {
    this.init(tag, contents, parent);
}

XML_Element.prototype.init = function(tag, contents, parent) {
    this.tag = tag || "unnamed", this.attributes = {}, this.contents = contents || "", 
    XML_Element.uber.init.call(this), parent instanceof XML_Element && parent.addChild(this);
}, XML_Element.prototype.require = function(tagName) {
    var child = this.childNamed(tagName);
    if (!child) throw new Error("Missing required element <" + tagName + ">!");
    return child;
}, XML_Element.prototype.childNamed = function(tagName) {
    return detect(this.children, function(child) {
        return child.tag === tagName;
    });
}, XML_Element.prototype.childrenNamed = function(tagName) {
    return this.children.filter(function(child) {
        return child.tag === tagName;
    });
}, XML_Element.prototype.parentNamed = function(tagName) {
    return this.tag === tagName ? this : this.parent ? this.parent.parentNamed(tagName) : null;
}, XML_Element.prototype.toString = function(isFormatted, indentationLevel) {
    var key, i, result = "", indent = "", level = indentationLevel || 0;
    if (isFormatted) {
        for (i = 0; i < level; i += 1) indent += this.indentation;
        result += indent;
    }
    result += "<" + this.tag;
    for (key in this.attributes) Object.prototype.hasOwnProperty.call(this.attributes, key) && this.attributes[key] && (result += " " + key + '="' + this.attributes[key] + '"');
    return this.contents.length || this.children.length ? (result += ">", result += this.contents, 
    this.children.forEach(function(element) {
        isFormatted && (result += "\n"), result += element.toString(isFormatted, level + 1);
    }), isFormatted && this.children.length && (result += "\n" + indent), result += "</" + this.tag + ">") : result += "/>", 
    result;
}, XML_Element.prototype.escape = function(string, ignoreQuotes) {
    var i, ch, src = isNil(string) ? "" : string.toString(), result = "";
    for (i = 0; i < src.length; i += 1) switch (ch = src[i]) {
      case "'":
        result += "&apos;";
        break;

      case '"':
        result += ignoreQuotes ? ch : "&quot;";
        break;

      case "<":
        result += "&lt;";
        break;

      case ">":
        result += "&gt;";
        break;

      case "&":
        result += "&amp;";
        break;

      case "\n":
        result += "&#xD;";
        break;

      case "~":
        result += "&#126;";
        break;

      default:
        result += ch;
    }
    return result;
}, XML_Element.prototype.unescape = function(string) {
    var ch, stream = new ReadStream(string), result = "";
    function nextPut(str) {
        result += str, stream.upTo(";"), stream.skip();
    }
    for (;!stream.atEnd(); ) if ("&" === (ch = stream.next())) switch (stream.peekUpTo(";")) {
      case "apos":
        nextPut("'");
        break;

      case "quot":
        nextPut('"');
        break;

      case "lt":
        nextPut("<");
        break;

      case "gt":
        nextPut(">");
        break;

      case "amp":
        nextPut("&");
        break;

      case "#xD":
        nextPut("\n");
        break;

      case "#126":
        nextPut("~");
        break;

      default:
        result += ch;
    } else result += ch;
    return result;
}, XML_Element.prototype.parseString = function(string) {
    var stream = new ReadStream(string);
    stream.upTo("<"), stream.skip(), this.parseStream(stream);
}, XML_Element.prototype.parseStream = function(stream) {
    var key, value, ch;
    for (this.tag = stream.word(), stream.skipSpace(), ch = stream.peek(); ">" !== ch && "/" !== ch; ) {
        if (key = stream.word(), stream.skipSpace(), "=" !== stream.next()) throw new Error('Expected "=" after attribute name');
        if (stream.skipSpace(), '"' !== (ch = stream.next()) && "'" !== ch) throw new Error("Expected single- or double-quoted attribute value");
        value = stream.upTo(ch), stream.skip(1), stream.skipSpace(), this.attributes[key] = this.unescape(value), 
        ch = stream.peek();
    }
    if ("/" !== stream.peek()) {
        if (">" !== stream.next()) throw new Error('Expected ">" after tag name and attributes');
        for (;!stream.atEnd(); ) if ("<" === (ch = stream.next())) {
            if ("/" === stream.peek()) {
                if (stream.skip(), stream.word() !== this.tag) throw new Error("Expected to close " + this.tag);
                return stream.upTo(">"), stream.skip(), void (this.contents = this.unescape(this.contents));
            }
            new XML_Element(null, null, this).parseStream(stream);
        } else this.contents += ch;
    } else if (stream.skip(), ">" !== stream.next()) throw new Error('Expected ">" after "/" in empty tag');
}, modules.store = "2015-January-21";

function XML_Serializer() {
    this.contents = [], this.media = [], this.isCollectingMedia = !1;
}

XML_Serializer.prototype.idProperty = "serializationID", XML_Serializer.prototype.mediaIdProperty = "serializationMediaID", 
XML_Serializer.prototype.mediaDetectionProperty = "isMedia", XML_Serializer.prototype.version = 1, 
XML_Serializer.prototype.serialize = function(object) {
    var xml;
    return this.flush(), this.flushMedia(), xml = this.store(object), this.flush(), 
    xml;
}, XML_Serializer.prototype.store = function(object, mediaID) {
    return isNil(object) || !object.toXML ? "" : this.isCollectingMedia && object[this.mediaDetectionProperty] ? (this.addMedia(object, mediaID), 
    this.format('<ref mediaID="@"></ref>', object[this.mediaIdProperty])) : object[this.idProperty] ? this.format('<ref id="@"></ref>', object[this.idProperty]) : (this.add(object), 
    object.toXML(this, mediaID).replace("~", this.format('id="@"', object[this.idProperty])));
}, XML_Serializer.prototype.mediaXML = function() {
    var xml = "<media>", myself = this;
    return this.media.forEach(function(object) {
        var str = object.toXML(myself).replace("~", myself.format('mediaID="@"', object[myself.mediaIdProperty]));
        xml += str;
    }), xml + "</media>";
}, XML_Serializer.prototype.add = function(object) {
    return object[this.idProperty] ? -1 : (this.contents.push(object), object[this.idProperty] = this.contents.length, 
    this.contents.length);
}, XML_Serializer.prototype.addMedia = function(object, mediaID) {
    return object[this.mediaIdProperty] ? -1 : (this.media.push(object), object[this.mediaIdProperty] = mediaID ? mediaID + "_" + object.name : this.media.length, 
    this.media.length);
}, XML_Serializer.prototype.at = function(integer) {
    return this.contents[integer - 1];
}, XML_Serializer.prototype.flush = function() {
    var myself = this;
    this.contents.forEach(function(obj) {
        delete obj[myself.idProperty];
    }), this.contents = [];
}, XML_Serializer.prototype.flushMedia = function() {
    var myself = this;
    this.media instanceof Array && this.media.forEach(function(obj) {
        delete obj[myself.mediaIdProperty];
    }), this.media = [];
}, XML_Serializer.prototype.escape = XML_Element.prototype.escape, XML_Serializer.prototype.unescape = XML_Element.prototype.unescape, 
XML_Serializer.prototype.format = function(string) {
    var value, myself = this, i = -1, values = arguments;
    return string.replace(/[@$%]([\d]+)?/g, function(spec, index) {
        return index = parseInt(index, 10), value = isNaN(index) ? values[(i += 1) + 1] : values[index + 1], 
        "@" === spec ? myself.escape(value) : "$" === spec ? myself.escape(value, !0) : value;
    });
}, XML_Serializer.prototype.load = function(xmlString) {
    throw nop(xmlString), new Error("loading should be implemented in heir of XML_Serializer");
}, XML_Serializer.prototype.parse = function(xmlString) {
    var element = new XML_Element();
    return element.parseString(xmlString), element;
};

var SnapSerializer;

SnapSerializer.prototype = new XML_Serializer(), SnapSerializer.prototype.constructor = SnapSerializer, 
SnapSerializer.uber = XML_Serializer.prototype, SnapSerializer.prototype.app = "Snap! 4.0, http://snap.berkeley.edu", 
SnapSerializer.prototype.thumbnailSize = new Point(160, 120), SnapSerializer.prototype.watcherLabels = {
    xPosition: "x position",
    yPosition: "y position",
    direction: "direction",
    getScale: "size",
    getTempo: "tempo",
    getLastAnswer: "answer",
    getLastMessage: "message",
    getTimer: "timer",
    getCostumeIdx: "costume #",
    reportMouseX: "mouse x",
    reportMouseY: "mouse y",
    reportThreadCount: "processes"
};

function SnapSerializer() {
    this.init();
}

SnapSerializer.prototype.init = function() {
    this.project = {}, this.objects = {}, this.mediaDict = {};
}, XML_Serializer.prototype.mediaXML = function(name) {
    var xml = '<media name="' + (name || "untitled") + '" app="' + this.app + '" version="' + this.version + '">', myself = this;
    return this.media.forEach(function(object) {
        var str = object.toXML(myself).replace("~", myself.format('mediaID="@"', object[myself.mediaIdProperty]));
        xml += str;
    }), xml + "</media>";
}, SnapSerializer.prototype.load = function(xmlString, ide) {
    return this.loadProjectModel(this.parse(xmlString), ide);
}, SnapSerializer.prototype.loadProjectModel = function(xmlNode, ide) {
    var appInfo = xmlNode.attributes.app, app = appInfo ? appInfo.split(" ")[0] : null;
    return ide && app !== this.app.split(" ")[0] && ide.inform(app + " Project", "This project has been created by a different app:\n\n" + app + "\n\nand may be incompatible or fail to load here."), 
    this.rawLoadProjectModel(xmlNode);
}, SnapSerializer.prototype.rawLoadProjectModel = function(xmlNode) {
    var model, nameID, myself = this, project = {
        sprites: {}
    };
    if (this.project = project, model = {
        project: xmlNode
    }, +xmlNode.attributes.version > this.version) throw "Project uses newer version of Serializer";
    if (this.objects = {}, project.name = model.project.attributes.name, !project.name) {
        for (nameID = 1; Object.prototype.hasOwnProperty.call(localStorage, "-snap-project-Untitled " + nameID); ) nameID += 1;
        project.name = "Untitled " + nameID;
    }
    return model.notes = model.project.childNamed("notes"), model.notes && (project.notes = model.notes.contents), 
    model.globalVariables = model.project.childNamed("variables"), project.globalVariables = new VariableFrame(), 
    model.stage = model.project.require("stage"), StageMorph.prototype.frameRate = 0, 
    project.stage = new StageMorph(project.globalVariables), Object.prototype.hasOwnProperty.call(model.stage.attributes, "id") && (this.objects[model.stage.attributes.id] = project.stage), 
    model.stage.attributes.name && (project.stage.name = model.stage.attributes.name), 
    "true" === model.stage.attributes.scheduled && (project.stage.fps = 30, StageMorph.prototype.frameRate = 30), 
    model.pentrails = model.stage.childNamed("pentrails"), model.pentrails && (project.pentrails = new Image(), 
    project.pentrails.onload = function() {
        project.stage.trailsCanvas.getContext("2d").drawImage(project.pentrails, 0, 0), 
        project.stage.changed();
    }, project.pentrails.src = model.pentrails.contents), project.stage.setTempo(model.stage.attributes.tempo), 
    StageMorph.prototype.dimensions = new Point(480, 360), model.stage.attributes.width && (StageMorph.prototype.dimensions.x = Math.max(+model.stage.attributes.width, 480)), 
    model.stage.attributes.height && (StageMorph.prototype.dimensions.y = Math.max(+model.stage.attributes.height, 180)), 
    project.stage.setExtent(StageMorph.prototype.dimensions), SpriteMorph.prototype.useFlatLineEnds = "flat" === model.stage.attributes.lines, 
    project.stage.isThreadSafe = "true" === model.stage.attributes.threadsafe, StageMorph.prototype.enableCodeMapping = "true" === model.stage.attributes.codify, 
    model.hiddenPrimitives = model.project.childNamed("hidden"), model.hiddenPrimitives && model.hiddenPrimitives.contents.split(" ").forEach(function(sel) {
        sel && (StageMorph.prototype.hiddenPrimitives[sel] = !0);
    }), model.codeHeaders = model.project.childNamed("headers"), model.codeHeaders && model.codeHeaders.children.forEach(function(xml) {
        StageMorph.prototype.codeHeaders[xml.tag] = xml.contents;
    }), model.codeMappings = model.project.childNamed("code"), model.codeMappings && model.codeMappings.children.forEach(function(xml) {
        StageMorph.prototype.codeMappings[xml.tag] = xml.contents;
    }), model.globalBlocks = model.project.childNamed("blocks"), model.globalBlocks && (this.loadCustomBlocks(project.stage, model.globalBlocks, !0), 
    this.populateCustomBlocks(project.stage, model.globalBlocks, !0)), this.loadObject(project.stage, model.stage), 
    model.sprites = model.stage.require("sprites"), project.sprites[project.stage.name] = project.stage, 
    model.sprites.childrenNamed("sprite").forEach(function(model) {
        myself.loadValue(model);
    }), myself.project.stage.children.forEach(function(sprite) {
        var anchor;
        sprite.nestingInfo && ((anchor = myself.project.sprites[sprite.nestingInfo.anchor]) && anchor.attachPart(sprite), 
        sprite.rotatesWithAnchor = "true" === sprite.nestingInfo.synch);
    }), myself.project.stage.children.forEach(function(sprite) {
        sprite.nestingInfo && (sprite.nestingScale = +(sprite.nestingInfo.scale || sprite.scale), 
        delete sprite.nestingInfo);
    }), model.globalVariables && this.loadVariables(project.globalVariables, model.globalVariables), 
    this.objects = {}, model.sprites.childrenNamed("watcher").forEach(function(model) {
        var watcher, color, target, hidden, extX, extY;
        color = myself.loadColor(model.attributes.color), target = Object.prototype.hasOwnProperty.call(model.attributes, "scope") ? project.sprites[model.attributes.scope] : null, 
        hidden = Object.prototype.hasOwnProperty.call(model.attributes, "hidden") && "false" !== model.attributes.hidden, 
        (watcher = Object.prototype.hasOwnProperty.call(model.attributes, "var") ? new WatcherMorph(model.attributes.var, color, isNil(target) ? project.globalVariables : target.variables, model.attributes.var, hidden) : new WatcherMorph(localize(myself.watcherLabels[model.attributes.s]), color, target, model.attributes.s, hidden)).setStyle(model.attributes.style || "normal"), 
        "slider" === watcher.style && (watcher.setSliderMin(model.attributes.min || "1"), 
        watcher.setSliderMax(model.attributes.max || "100")), watcher.setPosition(project.stage.topLeft().add(new Point(+model.attributes.x || 0, +model.attributes.y || 0))), 
        project.stage.add(watcher), watcher.onNextStep = function() {
            this.currentValue = null;
        }, watcher.currentValue instanceof List && ((extX = model.attributes.extX) && watcher.cellMorph.contentsMorph.setWidth(+extX), 
        (extY = model.attributes.extY) && watcher.cellMorph.contentsMorph.setHeight(+extY), 
        watcher.cellMorph.contentsMorph.handle.drawNew());
    }), this.objects = {}, project;
}, SnapSerializer.prototype.loadBlocks = function(xmlString, targetStage) {
    var model, stage = new StageMorph();
    if (this.project = {
        stage: stage,
        sprites: {},
        targetStage: targetStage
    }, +(model = this.parse(xmlString)).attributes.version > this.version) throw "Module uses newer version of Serializer";
    return this.loadCustomBlocks(stage, model, !0), this.populateCustomBlocks(stage, model, !0), 
    this.objects = {}, stage.globalBlocks.forEach(function(def) {
        def.receiver = null;
    }), this.objects = {}, this.project = {}, this.mediaDict = {}, stage.globalBlocks;
}, SnapSerializer.prototype.loadSprites = function(xmlString, ide) {
    var model, project, myself = this;
    if ((project = this.project = {
        globalVariables: ide.globalVariables,
        stage: ide.stage,
        sprites: {}
    }).sprites[project.stage.name] = project.stage, +(model = this.parse(xmlString)).attributes.version > this.version) throw "Module uses newer version of Serializer";
    model.childrenNamed("sprite").forEach(function(model) {
        var sprite = new SpriteMorph(project.globalVariables);
        model.attributes.id && (myself.objects[model.attributes.id] = sprite), model.attributes.name && (sprite.name = model.attributes.name, 
        project.sprites[model.attributes.name] = sprite), model.attributes.color && (sprite.color = myself.loadColor(model.attributes.color)), 
        model.attributes.pen && (sprite.penPoint = model.attributes.pen), project.stage.add(sprite), 
        ide.sprites.add(sprite), sprite.scale = parseFloat(model.attributes.scale || "1"), 
        sprite.rotationStyle = parseFloat(model.attributes.rotation || "1"), sprite.isDraggable = "false" !== model.attributes.draggable, 
        sprite.isVisible = "true" !== model.attributes.hidden, sprite.heading = parseFloat(model.attributes.heading) || 0, 
        sprite.drawNew(), sprite.gotoXY(+model.attributes.x || 0, +model.attributes.y || 0), 
        myself.loadObject(sprite, model);
    }), project.stage.children.forEach(function(sprite) {
        var anchor;
        sprite.nestingInfo && ((anchor = project.sprites[sprite.nestingInfo.anchor]) && anchor.attachPart(sprite), 
        sprite.rotatesWithAnchor = "true" === sprite.nestingInfo.synch);
    }), project.stage.children.forEach(function(sprite) {
        sprite.nestingInfo && (sprite.nestingScale = +(sprite.nestingInfo.scale || sprite.scale), 
        delete sprite.nestingInfo);
    }), this.objects = {}, this.project = {}, this.mediaDict = {}, ide.createCorral(), 
    ide.fixLayout();
}, SnapSerializer.prototype.loadMedia = function(xmlString) {
    return this.loadMediaModel(this.parse(xmlString));
}, SnapSerializer.prototype.loadMediaModel = function(xmlNode) {
    var myself = this, model = xmlNode;
    if (this.mediaDict = {}, +model.attributes.version > this.version) throw "Module uses newer version of Serializer";
    return model.children.forEach(function(model) {
        myself.loadValue(model);
    }), this.mediaDict;
}, SnapSerializer.prototype.loadObject = function(object, model) {
    var blocks = model.require("blocks");
    this.loadNestingInfo(object, model), this.loadCostumes(object, model), this.loadSounds(object, model), 
    this.loadCustomBlocks(object, blocks), this.populateCustomBlocks(object, blocks), 
    this.loadVariables(object.variables, model.require("variables")), this.loadScripts(object.scripts, model.require("scripts"));
}, SnapSerializer.prototype.loadNestingInfo = function(object, model) {
    var info = model.childNamed("nest");
    info && (object.nestingInfo = info.attributes);
}, SnapSerializer.prototype.loadCostumes = function(object, model) {
    var costume, costumes = model.childNamed("costumes");
    costumes && (object.costumes = this.loadValue(costumes.require("list"))), Object.prototype.hasOwnProperty.call(model.attributes, "costume") && (costume = object.costumes.asArray()[model.attributes.costume - 1]) && (costume.loaded ? object.wearCostume(costume) : costume.loaded = function() {
        object.wearCostume(costume), this.loaded = !0;
    });
}, SnapSerializer.prototype.loadSounds = function(object, model) {
    var sounds = model.childNamed("sounds");
    sounds && (object.sounds = this.loadValue(sounds.require("list")));
}, SnapSerializer.prototype.loadVariables = function(varFrame, element) {
    var myself = this;
    element.children.forEach(function(child) {
        var value;
        "variable" === child.tag && (value = child.children[0], varFrame.vars[child.attributes.name] = new Variable(value ? myself.loadValue(value) : 0));
    });
}, SnapSerializer.prototype.loadCustomBlocks = function(object, element, isGlobal) {
    var myself = this;
    element.children.forEach(function(child) {
        var definition, names, inputs, header, code, comment, i;
        "block-definition" === child.tag && ((definition = new CustomBlockDefinition(child.attributes.s || "", object)).category = child.attributes.category || "other", 
        definition.type = child.attributes.type || "command", definition.isGlobal = !0 === isGlobal, 
        definition.isGlobal ? object.globalBlocks.push(definition) : object.customBlocks.push(definition), 
        names = definition.parseSpec(definition.spec).filter(function(str) {
            return "%" === str.charAt(0);
        }).map(function(str) {
            return str.substr(1);
        }), definition.names = names, (inputs = child.childNamed("inputs")) && (i = -1, 
        inputs.children.forEach(function(child) {
            var options = child.childNamed("options");
            "input" === child.tag && (i += 1, definition.declarations[names[i]] = [ child.attributes.type, child.contents, options ? options.contents : void 0, "true" === child.attributes.readonly ]);
        })), (header = child.childNamed("header")) && (definition.codeHeader = header.contents), 
        (code = child.childNamed("code")) && (definition.codeMapping = code.contents), (comment = child.childNamed("comment")) && (definition.comment = myself.loadComment(comment)));
    });
}, SnapSerializer.prototype.populateCustomBlocks = function(object, element, isGlobal) {
    var myself = this;
    element.children.forEach(function(child, index) {
        var definition, script, scripts;
        "block-definition" === child.tag && (definition = isGlobal ? object.globalBlocks[index] : object.customBlocks[index], 
        (script = child.childNamed("script")) && (definition.body = new Context(null, script ? myself.loadScript(script) : null, null, object), 
        definition.body.inputs = definition.names.slice(0)), (scripts = child.childNamed("scripts")) && (definition.scripts = myself.loadScriptsArray(scripts)), 
        delete definition.names);
    });
}, SnapSerializer.prototype.loadScripts = function(scripts, model) {
    var myself = this, scale = SyntaxElementMorph.prototype.scale;
    scripts.cachedTexture = IDE_Morph.prototype.scriptsPaneTexture, model.children.forEach(function(child) {
        var element;
        if ("script" === child.tag) {
            if (!(element = myself.loadScript(child))) return;
            element.setPosition(new Point((+child.attributes.x || 0) * scale, (+child.attributes.y || 0) * scale).add(scripts.topLeft())), 
            scripts.add(element), element.fixBlockColor(null, !0), element.allComments().forEach(function(comment) {
                comment.align(element);
            });
        } else if ("comment" === child.tag) {
            if (!(element = myself.loadComment(child))) return;
            element.setPosition(new Point((+child.attributes.x || 0) * scale, (+child.attributes.y || 0) * scale).add(scripts.topLeft())), 
            scripts.add(element);
        }
    });
}, SnapSerializer.prototype.loadScriptsArray = function(model) {
    var myself = this, scale = SyntaxElementMorph.prototype.scale, scripts = [];
    return model.children.forEach(function(child) {
        var element;
        if ("script" === child.tag) {
            if (!(element = myself.loadScript(child))) return;
            element.setPosition(new Point((+child.attributes.x || 0) * scale, (+child.attributes.y || 0) * scale)), 
            scripts.push(element), element.fixBlockColor(null, !0);
        } else if ("comment" === child.tag) {
            if (!(element = myself.loadComment(child))) return;
            element.setPosition(new Point((+child.attributes.x || 0) * scale, (+child.attributes.y || 0) * scale)), 
            scripts.push(element);
        }
    }), scripts;
}, SnapSerializer.prototype.loadScript = function(model) {
    var topBlock, block, nextBlock, myself = this;
    return model.children.forEach(function(child) {
        (nextBlock = myself.loadBlock(child)) && (block ? block.nextBlock(nextBlock) : topBlock = nextBlock, 
        block = nextBlock);
    }), topBlock;
}, SnapSerializer.prototype.loadComment = function(model) {
    var comment = new CommentMorph(model.contents), scale = SyntaxElementMorph.prototype.scale;
    return comment.isCollapsed = "true" === model.attributes.collapsed, comment.setTextWidth(+model.attributes.w * scale), 
    comment;
}, SnapSerializer.prototype.loadBlock = function(model, isReporter) {
    var block, info, inputs, isGlobal, rm, receiver;
    if ("block" === model.tag) {
        if (Object.prototype.hasOwnProperty.call(model.attributes, "var")) return SpriteMorph.prototype.variableBlock(model.attributes.var);
        block = SpriteMorph.prototype.blockForSelector(model.attributes.s);
    } else if ("custom-block" === model.tag) {
        if (receiver = (isGlobal = !model.attributes.scope) ? this.project.stage : this.project.sprites[model.attributes.scope], 
        (rm = model.childNamed("receiver")) && rm.children[0] && (receiver = this.loadValue(model.childNamed("receiver").children[0])), 
        !receiver) return this.obsoleteBlock(isReporter);
        if (isGlobal ? !(info = detect(receiver.globalBlocks, function(block) {
            return block.blockSpec() === model.attributes.s;
        })) && this.project.targetStage && (info = detect(this.project.targetStage.globalBlocks, function(block) {
            return block.blockSpec() === model.attributes.s;
        })) : info = detect(receiver.customBlocks, function(block) {
            return block.blockSpec() === model.attributes.s;
        }), !info) return this.obsoleteBlock(isReporter);
        block = "command" === info.type ? new CustomCommandBlockMorph(info, !1) : new CustomReporterBlockMorph(info, "predicate" === info.type, !1);
    }
    return null === block && (block = this.obsoleteBlock(isReporter)), block.isDraggable = !0, 
    inputs = block.inputs(), model.children.forEach(function(child, i) {
        "comment" === child.tag ? (block.comment = this.loadComment(child), block.comment.block = block) : "receiver" === child.tag ? nop() : this.loadInput(child, inputs[i], block);
    }, this), block;
}, SnapSerializer.prototype.obsoleteBlock = function(isReporter) {
    var block = isReporter ? new ReporterBlockMorph() : new CommandBlockMorph();
    return block.selector = "nop", block.color = new Color(200, 0, 20), block.setSpec("Obsolete!"), 
    block.isDraggable = !0, block;
}, SnapSerializer.prototype.loadInput = function(model, input, block) {
    var inp, myself = this;
    if ("script" === model.tag) (inp = this.loadScript(model)) && (input.add(inp), input.fixLayout()); else if ("autolambda" === model.tag && model.children[0]) (inp = this.loadBlock(model.children[0], !0)) && (input.silentReplaceInput(input.children[0], inp), 
    input.fixLayout()); else if ("list" === model.tag) {
        for (;input.inputs().length > 0; ) input.removeInput();
        model.children.forEach(function(item) {
            input.addInput(), myself.loadInput(item, input.children[input.children.length - 2], input);
        }), input.fixLayout();
    } else "block" === model.tag || "custom-block" === model.tag ? block.silentReplaceInput(input, this.loadBlock(model, !0)) : "color" === model.tag ? input.setColor(this.loadColor(model.contents)) : !isNil(this.loadValue(model)) && input.setContents && input.setContents(this.loadValue(model));
}, SnapSerializer.prototype.loadValue = function(model) {
    var v, items, el, center, image, name, audio, option, myself = this;
    function record() {
        Object.prototype.hasOwnProperty.call(model.attributes, "id") && (myself.objects[model.attributes.id] = v), 
        Object.prototype.hasOwnProperty.call(model.attributes, "mediaID") && (myself.mediaDict[model.attributes.mediaID] = v);
    }
    switch (model.tag) {
      case "ref":
        if (Object.prototype.hasOwnProperty.call(model.attributes, "id")) return this.objects[model.attributes.id];
        if (Object.prototype.hasOwnProperty.call(model.attributes, "mediaID")) return this.mediaDict[model.attributes.mediaID];
        throw new Error("expecting a reference id");

      case "l":
        return (option = model.childNamed("option")) ? [ option.contents ] : model.contents;

      case "bool":
        return "true" === model.contents;

      case "list":
        return model.attributes.hasOwnProperty("linked") ? 0 === (items = model.childrenNamed("item")).length ? (v = new List(), 
        record(), v) : (items.forEach(function(item) {
            var value = item.children[0];
            void 0 === v ? (v = new List(), record()) : v = v.rest = new List(), v.isLinked = !0, 
            v.first = value ? myself.loadValue(value) : 0;
        }), v) : (v = new List(), record(), v.contents = model.childrenNamed("item").map(function(item) {
            var value = item.children[0];
            return value ? myself.loadValue(value) : 0;
        }), v);

      case "sprite":
        return v = new SpriteMorph(myself.project.globalVariables), model.attributes.id && (myself.objects[model.attributes.id] = v), 
        model.attributes.name && (v.name = model.attributes.name, myself.project.sprites[model.attributes.name] = v), 
        model.attributes.idx && (v.idx = +model.attributes.idx), model.attributes.color && (v.color = myself.loadColor(model.attributes.color)), 
        model.attributes.pen && (v.penPoint = model.attributes.pen), myself.project.stage.add(v), 
        v.scale = parseFloat(model.attributes.scale || "1"), v.rotationStyle = parseFloat(model.attributes.rotation || "1"), 
        v.isDraggable = "false" !== model.attributes.draggable, v.isVisible = "true" !== model.attributes.hidden, 
        v.heading = parseFloat(model.attributes.heading) || 0, v.drawNew(), v.gotoXY(+model.attributes.x || 0, +model.attributes.y || 0), 
        myself.loadObject(v, model), v;

      case "context":
        return v = new Context(null), record(), (el = model.childNamed("script")) ? v.expression = this.loadScript(el) : (el = model.childNamed("block") || model.childNamed("custom-block")) ? v.expression = this.loadBlock(el) : (el = model.childNamed("l")) && (v.expression = new InputSlotMorph(el.contents)), 
        (el = model.childNamed("receiver")) && (el = el.childNamed("ref") || el.childNamed("sprite")) && (v.receiver = this.loadValue(el)), 
        (el = model.childNamed("inputs")) && el.children.forEach(function(item) {
            "input" === item.tag && v.inputs.push(item.contents);
        }), (el = model.childNamed("variables")) && this.loadVariables(v.variables, el), 
        (el = model.childNamed("context")) && (v.outerContext = this.loadValue(el)), v.outerContext && v.receiver && !v.outerContext.variables.parentFrame && (v.outerContext.variables.parentFrame = v.receiver.variables), 
        v;

      case "costume":
        return center = new Point(), Object.prototype.hasOwnProperty.call(model.attributes, "center-x") && (center.x = parseFloat(model.attributes["center-x"])), 
        Object.prototype.hasOwnProperty.call(model.attributes, "center-y") && (center.y = parseFloat(model.attributes["center-y"])), 
        Object.prototype.hasOwnProperty.call(model.attributes, "name") && (name = model.attributes.name), 
        Object.prototype.hasOwnProperty.call(model.attributes, "image") && (image = new Image(), 
        0 !== model.attributes.image.indexOf("data:image/svg+xml") || MorphicPreferences.rasterizeSVGs ? (v = new Costume(null, name, center), 
        image.onload = function() {
            var canvas = newCanvas(new Point(image.width, image.height));
            canvas.getContext("2d").drawImage(image, 0, 0), v.contents = canvas, v.version = +new Date(), 
            "function" == typeof v.loaded ? v.loaded() : v.loaded = !0;
        }) : (v = new SVG_Costume(null, name, center), image.onload = function() {
            v.contents = image, v.version = +new Date(), "function" == typeof v.loaded ? v.loaded() : v.loaded = !0;
        }), image.src = model.attributes.image), record(), v;

      case "sound":
        return (audio = new Audio()).src = model.attributes.sound, v = new Sound(audio, model.attributes.name), 
        Object.prototype.hasOwnProperty.call(model.attributes, "mediaID") && (myself.mediaDict[model.attributes.mediaID] = v), 
        v;
    }
}, SnapSerializer.prototype.loadColor = function(colorString) {
    var c = (colorString || "").split(",");
    return new Color(parseFloat(c[0]), parseFloat(c[1]), parseFloat(c[2]), parseFloat(c[3]));
}, SnapSerializer.prototype.openProject = function(project, ide) {
    var sprite, stage = ide.stage, sprites = [];
    project && project.stage && (ide.projectName = project.name, ide.projectNotes = project.notes || "", 
    ide.globalVariables && (ide.globalVariables = project.globalVariables), stage && stage.destroy(), 
    ide.add(project.stage), ide.stage = project.stage, (sprites = ide.stage.children.filter(function(child) {
        return child instanceof SpriteMorph;
    })).sort(function(x, y) {
        return x.idx - y.idx;
    }), ide.sprites = new List(sprites), sprite = sprites[0] || project.stage, sizeOf(this.mediaDict) > 0 ? (ide.hasChangedMedia = !1, 
    this.mediaDict = {}) : ide.hasChangedMedia = !0, project.stage.drawNew(), ide.createCorral(), 
    ide.selectSprite(sprite), ide.fixLayout(), ide.world().keyboardReceiver = project.stage);
}, Array.prototype.toXML = function(serializer) {
    return this.reduce(function(xml, item) {
        return xml + serializer.store(item);
    }, "");
}, StageMorph.prototype.toXML = function(serializer) {
    var thumbdata, thumbnail = this.thumbnail(SnapSerializer.prototype.thumbnailSize), ide = this.parentThatIsA(IDE_Morph);
    try {
        thumbdata = thumbnail.toDataURL("image/png");
    } catch (error) {
        thumbdata = null;
    }
    function code(key) {
        var str = "";
        return Object.keys(StageMorph.prototype[key]).forEach(function(selector) {
            str += "<" + selector + ">" + XML_Element.prototype.escape(StageMorph.prototype[key][selector]) + "</" + selector + ">";
        }), str;
    }
    return this.removeAllClones(), serializer.format('<project name="@" app="@" version="@"><notes>$</notes><thumbnail>$</thumbnail><stage name="@" width="@" height="@" costume="@" tempo="@" threadsafe="@" lines="@" codify="@" scheduled="@" ~><pentrails>$</pentrails><costumes>%</costumes><sounds>%</sounds><variables>%</variables><blocks>%</blocks><scripts>%</scripts><sprites>%</sprites></stage><hidden>$</hidden><headers>%</headers><code>%</code><blocks>%</blocks><variables>%</variables></project>', ide && ide.projectName ? ide.projectName : localize("Untitled"), serializer.app, serializer.version, ide && ide.projectNotes ? ide.projectNotes : "", thumbdata, this.name, StageMorph.prototype.dimensions.x, StageMorph.prototype.dimensions.y, this.getCostumeIdx(), this.getTempo(), this.isThreadSafe, SpriteMorph.prototype.useFlatLineEnds ? "flat" : "round", this.enableCodeMapping, 0 !== StageMorph.prototype.frameRate, this.trailsCanvas.toDataURL("image/png"), serializer.store(this.costumes, this.name + "_cst"), serializer.store(this.sounds, this.name + "_snd"), serializer.store(this.variables), serializer.store(this.customBlocks), serializer.store(this.scripts), serializer.store(this.children), Object.keys(StageMorph.prototype.hiddenPrimitives).reduce(function(a, b) {
        return a + " " + b;
    }, ""), code("codeHeaders"), code("codeMappings"), serializer.store(this.globalBlocks), ide && ide.globalVariables ? serializer.store(ide.globalVariables) : "");
}, SpriteMorph.prototype.toXML = function(serializer) {
    var stage = this.parentThatIsA(StageMorph), ide = stage ? stage.parentThatIsA(IDE_Morph) : null, idx = ide ? ide.sprites.asArray().indexOf(this) + 1 : 0;
    return serializer.format('<sprite name="@" idx="@" x="@" y="@" heading="@" scale="@" rotation="@" draggable="@"% costume="@" color="@,@,@" pen="@" ~>%<costumes>%</costumes><sounds>%</sounds><variables>%</variables><blocks>%</blocks><scripts>%</scripts></sprite>', this.name, idx, this.xPosition(), this.yPosition(), this.heading, this.scale, this.rotationStyle, this.isDraggable, this.isVisible ? "" : ' hidden="true"', this.getCostumeIdx(), this.color.r, this.color.g, this.color.b, this.penPoint, this.anchor ? '<nest anchor="' + this.anchor.name + '" synch="' + this.rotatesWithAnchor + (this.scale === this.nestingScale ? "" : '" scale="' + this.nestingScale) + '"/>' : "", serializer.store(this.costumes, this.name + "_cst"), serializer.store(this.sounds, this.name + "_snd"), serializer.store(this.variables), this.customBlocks ? serializer.store(this.customBlocks) : "", serializer.store(this.scripts));
}, Costume.prototype[XML_Serializer.prototype.mediaDetectionProperty] = !0, Costume.prototype.toXML = function(serializer) {
    return serializer.format('<costume name="@" center-x="@" center-y="@" image="@" ~/>', this.name, this.rotationCenter.x, this.rotationCenter.y, this instanceof SVG_Costume ? this.contents.src : this.contents.toDataURL("image/png"));
}, Sound.prototype[XML_Serializer.prototype.mediaDetectionProperty] = !0, Sound.prototype.toXML = function(serializer) {
    return serializer.format('<sound name="@" sound="@" ~/>', this.name, this.toDataURL());
}, VariableFrame.prototype.toXML = function(serializer) {
    var myself = this;
    return Object.keys(this.vars).reduce(function(vars, v) {
        var val = myself.vars[v].value;
        return vars + (void 0 === val || null === val ? serializer.format('<variable name="@"/>', v) : serializer.format('<variable name="@">%</variable>', v, "object" == typeof val ? serializer.store(val) : "boolean" == typeof val ? serializer.format("<bool>$</bool>", val) : serializer.format("<l>$</l>", val)));
    }, "");
}, WatcherMorph.prototype.toXML = function(serializer) {
    var isVar = this.target instanceof VariableFrame, isList = this.currentValue instanceof List, color = this.readoutColor, position = this.parent ? this.topLeft().subtract(this.parent.topLeft()) : this.topLeft();
    return serializer.format('<watcher% % style="@"% x="@" y="@" color="@,@,@"%%/>', isVar && this.target.owner || !isVar && this.target ? serializer.format(' scope="@"', isVar ? this.target.owner.name : this.target.name) : "", serializer.format(isVar ? 'var="@"' : 's="@"', this.getter), this.style, isVar && "slider" === this.style ? serializer.format(' min="@" max="@"', this.sliderMorph.start, this.sliderMorph.stop) : "", position.x, position.y, color.r, color.g, color.b, isList ? serializer.format(' extX="@" extY="@"', this.cellMorph.contentsMorph.width(), this.cellMorph.contentsMorph.height()) : "", this.isVisible ? "" : ' hidden="true"');
}, ScriptsMorph.prototype.toXML = function(serializer) {
    return this.children.reduce(function(xml, child) {
        return child instanceof BlockMorph ? xml + child.toScriptXML(serializer, !0) : child instanceof CommentMorph && !child.block ? xml + child.toXML(serializer) : xml;
    }, "");
}, BlockMorph.prototype.toXML = BlockMorph.prototype.toScriptXML = function(serializer, savePosition) {
    var position, xml, scale = SyntaxElementMorph.prototype.scale, block = this;
    position = this.parent ? this.topLeft().subtract(this.parent.topLeft()) : this.topLeft(), 
    xml = savePosition ? serializer.format('<script x="@" y="@">', position.x / scale, position.y / scale) : "<script>";
    do {
        xml += block.toBlockXML(serializer), block = block.nextBlock();
    } while (block);
    return xml += "<\/script>";
}, BlockMorph.prototype.toBlockXML = function(serializer) {
    return serializer.format('<block s="@">%%</block>', this.selector, serializer.store(this.inputs()), this.comment ? this.comment.toXML(serializer) : "");
}, ReporterBlockMorph.prototype.toXML = function(serializer) {
    return "reportGetVar" === this.selector ? serializer.format('<block var="@"/>', this.blockSpec) : this.toBlockXML(serializer);
}, ReporterBlockMorph.prototype.toScriptXML = function(serializer, savePosition) {
    var position, scale = SyntaxElementMorph.prototype.scale;
    return position = this.parent ? this.topLeft().subtract(this.parent.topLeft()) : this.topLeft(), 
    savePosition ? serializer.format('<script x="@" y="@">%<\/script>', position.x / scale, position.y / scale, this.toXML(serializer)) : serializer.format("<script>%<\/script>", this.toXML(serializer));
}, CustomCommandBlockMorph.prototype.toBlockXML = function(serializer) {
    var scope = this.definition.isGlobal ? void 0 : this.definition.receiver.name;
    return serializer.format('<custom-block s="@"%>%%%</custom-block>', this.blockSpec, this.definition.isGlobal ? "" : serializer.format(' scope="@"', scope), serializer.store(this.inputs()), this.comment ? this.comment.toXML(serializer) : "", scope && !this.definition.receiver[serializer.idProperty] ? "<receiver>" + serializer.store(this.definition.receiver) + "</receiver>" : "");
}, CustomReporterBlockMorph.prototype.toBlockXML = CustomCommandBlockMorph.prototype.toBlockXML, 
CustomBlockDefinition.prototype.toXML = function(serializer) {
    var myself = this;
    return serializer.format('<block-definition s="@" type="@" category="@">%<header>@</header><code>@</code><inputs>%</inputs>%%</block-definition>', this.spec, this.type, this.category || "other", this.comment ? this.comment.toXML(serializer) : "", this.codeHeader || "", this.codeMapping || "", Object.keys(this.declarations).reduce(function(xml, decl) {
        return xml + serializer.format('<input type="@"$>$%</input>', myself.declarations[decl][0], myself.declarations[decl][3] ? ' readonly="true"' : "", myself.declarations[decl][1], myself.declarations[decl][2] ? "<options>" + myself.declarations[decl][2] + "</options>" : "");
    }, ""), this.body ? serializer.store(this.body.expression) : "", this.scripts.length > 0 ? "<scripts>" + (array = this.scripts, 
    array.reduce(function(xml, element) {
        return element instanceof BlockMorph ? xml + element.toScriptXML(serializer, !0) : element instanceof CommentMorph && !element.block ? xml + element.toXML(serializer) : xml;
    }, "")) + "</scripts>" : "");
    var array;
}, ArgMorph.prototype.toXML = function() {
    return "<l/>";
}, InputSlotMorph.prototype.toXML = function(serializer) {
    return this.constant ? serializer.format("<l><option>$</option></l>", this.constant) : serializer.format("<l>$</l>", this.contents().text);
}, TemplateSlotMorph.prototype.toXML = function(serializer) {
    return serializer.format("<l>$</l>", this.contents());
}, CommandSlotMorph.prototype.toXML = function(serializer) {
    var block = this.children[0];
    return block instanceof BlockMorph ? block instanceof ReporterBlockMorph ? serializer.format("<autolambda>%</autolambda>", serializer.store(block)) : serializer.store(block) : "<script><\/script>";
}, FunctionSlotMorph.prototype.toXML = CommandSlotMorph.prototype.toXML, MultiArgMorph.prototype.toXML = function(serializer) {
    return serializer.format("<list>%</list>", serializer.store(this.inputs()));
}, ArgLabelMorph.prototype.toXML = function(serializer) {
    return serializer.format("%", serializer.store(this.inputs()[0]));
}, ColorSlotMorph.prototype.toXML = function(serializer) {
    return serializer.format("<color>$,$,$,$</color>", this.color.r, this.color.g, this.color.b, this.color.a);
}, List.prototype.toXML = function(serializer, mediaContext) {
    var xml, item;
    if (this.isLinked) {
        xml = '<list linked="linked" ~>', item = this;
        do {
            xml += serializer.format("<item>%</item>", serializer.store(item.first)), item = item.rest;
        } while (void 0 !== item && null !== item);
        return xml + "</list>";
    }
    return serializer.format("<list ~>%</list>", this.contents.reduce(function(xml, item) {
        return xml + serializer.format("<item>%</item>", "object" == typeof item ? serializer.store(item, mediaContext) : "boolean" == typeof item ? serializer.format("<bool>$</bool>", item) : serializer.format("<l>$</l>", item));
    }, ""));
}, Context.prototype.toXML = function(serializer) {
    return this.isContinuation ? "" : serializer.format("<context ~><inputs>%</inputs><variables>%</variables>%<receiver>%</receiver>%</context>", this.inputs.reduce(function(xml, input) {
        return xml + serializer.format("<input>$</input>", input);
    }, ""), this.variables ? serializer.store(this.variables) : "", this.expression ? serializer.store(this.expression) : "", this.receiver ? serializer.store(this.receiver) : "", this.outerContext ? serializer.store(this.outerContext) : "");
}, CommentMorph.prototype.toXML = function(serializer) {
    var position, scale = SyntaxElementMorph.prototype.scale;
    return this.block ? serializer.format('<comment w="@" collapsed="@">%</comment>', this.textWidth() / scale, this.isCollapsed, serializer.escape(this.text())) : (position = this.parent ? this.topLeft().subtract(this.parent.topLeft()) : this.topLeft(), 
    serializer.format('<comment x="@" y="@" w="@" collapsed="@">%</comment>', position.x / scale, position.y / scale, this.textWidth() / scale, this.isCollapsed, serializer.escape(this.text())));
}, modules.cloud = "2015-January-12";

var Cloud, SnapCloud = new Cloud("https://snap.apps.miosoft.com/SnapCloud");

function Cloud(url) {
    this.username = null, this.password = null, this.url = url, this.session = null, 
    this.limo = null, this.route = null, this.api = {};
}

Cloud.prototype.clear = function() {
    this.username = null, this.password = null, this.session = null, this.limo = null, 
    this.route = null, this.api = {};
}, Cloud.prototype.hasProtocol = function() {
    return 0 === this.url.toLowerCase().indexOf("http");
}, Cloud.prototype.setRoute = function(username) {
    var i, userNum = 0;
    for (i = 0; i < username.length; i += 1) userNum += username.charCodeAt(i);
    userNum = userNum % 10 + 1, this.route = ".sc1m" + (userNum < 10 ? "0" : "") + userNum;
}, Cloud.prototype.signup = function(username, email, callBack, errorCall) {
    var request = new XMLHttpRequest(), myself = this;
    try {
        request.open("GET", (this.hasProtocol() ? "" : "http://") + this.url + "SignUp?Username=" + encodeURIComponent(username) + "&Email=" + encodeURIComponent(email), !0), 
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), request.withCredentials = !0, 
        request.onreadystatechange = function() {
            4 === request.readyState && (request.responseText ? 0 === request.responseText.indexOf("ERROR") ? errorCall.call(this, request.responseText, "Signup") : callBack.call(null, request.responseText, "Signup") : errorCall.call(null, myself.url + "SignUp", localize("could not connect to:")));
        }, request.send(null);
    } catch (err) {
        errorCall.call(this, err.toString(), "Snap!Cloud");
    }
}, Cloud.prototype.getPublicProject = function(id, callBack, errorCall) {
    var responseList, request = new XMLHttpRequest(), myself = this;
    try {
        request.open("GET", (this.hasProtocol() ? "" : "http://") + this.url + "Public?" + id, !0), 
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), request.withCredentials = !0, 
        request.onreadystatechange = function() {
            4 === request.readyState && (request.responseText ? 0 === request.responseText.indexOf("ERROR") ? errorCall.call(this, request.responseText) : (responseList = myself.parseResponse(request.responseText), 
            callBack.call(null, responseList[0].SourceCode)) : errorCall.call(null, myself.url + "Public", localize("could not connect to:")));
        }, request.send(null);
    } catch (err) {
        errorCall.call(this, err.toString(), "Snap!Cloud");
    }
}, Cloud.prototype.resetPassword = function(username, callBack, errorCall) {
    var request = new XMLHttpRequest(), myself = this;
    try {
        request.open("GET", (this.hasProtocol() ? "" : "http://") + this.url + "ResetPW?Username=" + encodeURIComponent(username), !0), 
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), request.withCredentials = !0, 
        request.onreadystatechange = function() {
            4 === request.readyState && (request.responseText ? 0 === request.responseText.indexOf("ERROR") ? errorCall.call(this, request.responseText, "Reset Password") : callBack.call(null, request.responseText, "Reset Password") : errorCall.call(null, myself.url + "ResetPW", localize("could not connect to:")));
        }, request.send(null);
    } catch (err) {
        errorCall.call(this, err.toString(), "Snap!Cloud");
    }
}, Cloud.prototype.login = function(username, password, callBack, errorCall) {
    var request = new XMLHttpRequest(), usr = JSON.stringify({
        __h: password,
        __u: username
    }), myself = this;
    this.setRoute(username);
    try {
        request.open("POST", (this.hasProtocol() ? "" : "http://") + this.url + "?SESSIONGLUE=" + this.route, !0), 
        request.setRequestHeader("Content-Type", "application/json; charset=utf-8"), request.setRequestHeader("SESSIONGLUE", this.route), 
        request.withCredentials = !0, request.onreadystatechange = function() {
            4 === request.readyState && (request.responseText ? (myself.api = myself.parseAPI(request.responseText), 
            myself.session = request.getResponseHeader("MioCracker").split(";")[0], myself.limo = this.getResponseHeader("miocracker").substring(9, this.getResponseHeader("miocracker").indexOf("=")), 
            myself.api.logout ? (myself.username = username, myself.password = password, callBack.call(null, myself.api, "Snap!Cloud")) : errorCall.call(null, request.responseText, "connection failed")) : errorCall.call(null, myself.url, localize("could not connect to:")));
        }, request.send(usr);
    } catch (err) {
        errorCall.call(this, err.toString(), "Snap!Cloud");
    }
}, Cloud.prototype.reconnect = function(callBack, errorCall) {
    this.username && this.password ? this.login(this.username, this.password, callBack, errorCall) : this.message("You are not logged in");
}, Cloud.prototype.saveProject = function(ide, callBack, errorCall) {
    var pdata, media, myself = this;
    ide.serializer.isCollectingMedia = !0, pdata = ide.serializer.serialize(ide.stage), 
    media = ide.hasChangedMedia ? ide.serializer.mediaXML(ide.projectName) : null, ide.serializer.isCollectingMedia = !1, 
    ide.serializer.flushMedia();
    try {
        ide.serializer.parse(pdata);
    } catch (err) {
        throw ide.showMessage("Serialization of program data failed:\n" + err), new Error("Serialization of program data failed:\n" + err);
    }
    if (null !== media) try {
        ide.serializer.parse(media);
    } catch (err) {
        throw ide.showMessage("Serialization of media failed:\n" + err), new Error("Serialization of media failed:\n" + err);
    }
    ide.serializer.isCollectingMedia = !1, ide.serializer.flushMedia(), myself.reconnect(function() {
        myself.callService("saveProject", function(response, url) {
            callBack.call(null, response, url), myself.disconnect(), ide.hasChangedMedia = !1;
        }, errorCall, [ ide.projectName, pdata, media, pdata.length, media ? media.length : 0 ]);
    }, errorCall);
}, Cloud.prototype.getProjectList = function(callBack, errorCall) {
    var myself = this;
    this.reconnect(function() {
        myself.callService("getProjectList", function(response, url) {
            callBack.call(null, response, url), myself.disconnect();
        }, errorCall);
    }, errorCall);
}, Cloud.prototype.changePassword = function(oldPW, newPW, callBack, errorCall) {
    var myself = this;
    this.reconnect(function() {
        myself.callService("changePassword", function(response, url) {
            callBack.call(null, response, url), myself.disconnect();
        }, errorCall, [ hex_sha512(oldPW), hex_sha512(newPW) ]);
    }, errorCall);
}, Cloud.prototype.logout = function(callBack, errorCall) {
    this.clear(), this.callService("logout", callBack, errorCall);
}, Cloud.prototype.disconnect = function() {
    this.callService("logout", nop, nop);
}, Cloud.prototype.callURL = function(url, callBack, errorCall) {
    var stickyUrl, request = new XMLHttpRequest(), myself = this;
    try {
        stickyUrl = url + "&SESSIONGLUE=" + this.route + "&_Limo=" + this.limo, request.open("GET", stickyUrl, !0), 
        request.withCredentials = !0, request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), 
        request.setRequestHeader("MioCracker", this.session), request.setRequestHeader("SESSIONGLUE", this.route), 
        request.onreadystatechange = function() {
            if (4 === request.readyState) if (request.responseText) {
                var responseList = myself.parseResponse(request.responseText);
                callBack.call(null, responseList, url);
            } else errorCall.call(null, url, "no response from:");
        }, request.send(null);
    } catch (err) {
        errorCall.call(this, err.toString(), url);
    }
}, Cloud.prototype.callService = function(serviceName, callBack, errorCall, args) {
    var stickyUrl, postDict, request = new XMLHttpRequest(), service = this.api[serviceName], myself = this;
    if (this.session) if (service) {
        args && args.length > 0 && (postDict = {}, service.parameters.forEach(function(parm, idx) {
            postDict[parm] = args[idx];
        }));
        try {
            stickyUrl = this.url + "/" + service.url + "&SESSIONGLUE=" + this.route + "&_Limo=" + this.limo, 
            request.open(service.method, stickyUrl, !0), request.withCredentials = !0, request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), 
            request.setRequestHeader("MioCracker", this.session), request.setRequestHeader("SESSIONGLUE", this.route), 
            request.onreadystatechange = function() {
                if (4 === request.readyState) {
                    var responseList = [];
                    if (request.responseText && 0 === request.responseText.indexOf("ERROR")) return void errorCall.call(this, request.responseText, localize("Service:") + " " + localize(serviceName));
                    "login" === serviceName && (myself.api = myself.parseAPI(request.responseText)), 
                    responseList = myself.parseResponse(request.responseText), callBack.call(null, responseList, service.url);
                }
            }, request.send(this.encodeDict(postDict));
        } catch (err) {
            errorCall.call(this, err.toString(), service.url);
        }
    } else errorCall.call(null, "service " + serviceName + " is not available", "API"); else errorCall.call(null, "You are not connected", "Cloud");
}, Cloud.prototype.parseAPI = function(src) {
    var api = {};
    return src.split(" ").forEach(function(service) {
        var parms, serviceDescription = {};
        service.split("&").forEach(function(entry) {
            var pair = entry.split("="), key = decodeURIComponent(pair[0]).toLowerCase(), val = decodeURIComponent(pair[1]);
            "service" === key ? api[val] = serviceDescription : "parameters" === key ? (1 !== (parms = val.split(",")).length || parms[0]) && (serviceDescription.parameters = parms) : serviceDescription[key] = val;
        });
    }), api;
}, Cloud.prototype.parseResponse = function(src) {
    var ans = [];
    return src ? (src.split(" ").forEach(function(service) {
        var dict = {};
        service.split("&").forEach(function(entry) {
            var pair = entry.split("="), key = decodeURIComponent(pair[0]), val = decodeURIComponent(pair[1]);
            dict[key] = val;
        }), ans.push(dict);
    }), ans) : ans;
}, Cloud.prototype.parseDict = function(src) {
    var dict = {};
    return src ? (src.split("&").forEach(function(entry) {
        var pair = entry.split("="), key = decodeURIComponent(pair[0]), val = decodeURIComponent(pair[1]);
        dict[key] = val;
    }), dict) : dict;
}, Cloud.prototype.encodeDict = function(dict) {
    var pair, key, str = "";
    if (!dict) return null;
    for (key in dict) dict.hasOwnProperty(key) && (pair = encodeURIComponent(key) + "=" + encodeURIComponent(dict[key]), 
    str.length > 0 && (str += "&"), str += pair);
    return str;
}, Cloud.prototype.message = function(string) {
    alert(string);
};

var hex_sha512 = function(hex_sha512) {
    function hex_sha512(s) {
        return CryptoJS.SHA512(function(input) {
            var x, y, output = "", i = -1;
            for (;++i < input.length; ) x = input.charCodeAt(i), y = i + 1 < input.length ? input.charCodeAt(i + 1) : 0, 
            55296 <= x && x <= 56319 && 56320 <= y && y <= 57343 && (x = 65536 + ((1023 & x) << 10) + (1023 & y), 
            i++), x <= 127 ? output += String.fromCharCode(x) : x <= 2047 ? output += String.fromCharCode(192 | x >>> 6 & 31, 128 | 63 & x) : x <= 65535 ? output += String.fromCharCode(224 | x >>> 12 & 15, 128 | x >>> 6 & 63, 128 | 63 & x) : x <= 2097151 && (output += String.fromCharCode(240 | x >>> 18 & 7, 128 | x >>> 12 & 63, 128 | x >>> 6 & 63, 128 | 63 & x));
            return output;
        }(s)).toString(CryptoJS.enc.Hex);
    }
    var CryptoJS = CryptoJS || function(a, g) {
        var m = {}, e = m.lib = {}, q = e.Base = function() {
            function a() {}
            return {
                extend: function(b) {
                    a.prototype = this;
                    var d = new a();
                    return b && d.mixIn(b), d.$super = this, d;
                },
                create: function() {
                    var a = this.extend();
                    return a.init.apply(a, arguments), a;
                },
                init: function() {},
                mixIn: function(a) {
                    for (var k in a) a.hasOwnProperty(k) && (this[k] = a[k]);
                    a.hasOwnProperty("toString") && (this.toString = a.toString);
                },
                clone: function() {
                    return this.$super.extend(this);
                }
            };
        }(), r = e.WordArray = q.extend({
            init: function(a, b) {
                a = this.words = a || [], this.sigBytes = void 0 != b ? b : 4 * a.length;
            },
            toString: function(a) {
                return (a || n).stringify(this);
            },
            concat: function(a) {
                var b = this.words, d = a.words, c = this.sigBytes;
                a = a.sigBytes;
                if (this.clamp(), c % 4) for (var i = 0; i < a; i++) b[c + i >>> 2] |= (d[i >>> 2] >>> 24 - i % 4 * 8 & 255) << 24 - (c + i) % 4 * 8; else if (65535 < d.length) for (i = 0; i < a; i += 4) b[c + i >>> 2] = d[i >>> 2]; else b.push.apply(b, d);
                return this.sigBytes += a, this;
            },
            clamp: function() {
                var k = this.words, b = this.sigBytes;
                k[b >>> 2] &= 4294967295 << 32 - b % 4 * 8, k.length = a.ceil(b / 4);
            },
            clone: function() {
                var a = q.clone.call(this);
                return a.words = this.words.slice(0), a;
            },
            random: function(k) {
                for (var b = [], d = 0; d < k; d += 4) b.push(4294967296 * a.random() | 0);
                return r.create(b, k);
            }
        }), y = m.enc = {}, n = y.Hex = {
            stringify: function(a) {
                for (var b = a.words, d = (a = a.sigBytes, []), c = 0; c < a; c++) {
                    var i = b[c >>> 2] >>> 24 - c % 4 * 8 & 255;
                    d.push((i >>> 4).toString(16)), d.push((15 & i).toString(16));
                }
                return d.join("");
            },
            parse: function(a) {
                for (var b = a.length, d = [], c = 0; c < b; c += 2) d[c >>> 3] |= parseInt(a.substr(c, 2), 16) << 24 - c % 8 * 4;
                return r.create(d, b / 2);
            }
        }, l = y.Latin1 = {
            stringify: function(a) {
                for (var b = a.words, d = (a = a.sigBytes, []), c = 0; c < a; c++) d.push(String.fromCharCode(b[c >>> 2] >>> 24 - c % 4 * 8 & 255));
                return d.join("");
            },
            parse: function(a) {
                for (var b = a.length, d = [], c = 0; c < b; c++) d[c >>> 2] |= (255 & a.charCodeAt(c)) << 24 - c % 4 * 8;
                return r.create(d, b);
            }
        }, da = y.Utf8 = {
            stringify: function(a) {
                try {
                    return decodeURIComponent(escape(l.stringify(a)));
                } catch (b) {
                    throw Error("Malformed UTF-8 data");
                }
            },
            parse: function(a) {
                return l.parse(unescape(encodeURIComponent(a)));
            }
        }, h = e.BufferedBlockAlgorithm = q.extend({
            reset: function() {
                this._data = r.create(), this._nDataBytes = 0;
            },
            _append: function(a) {
                "string" == typeof a && (a = da.parse(a)), this._data.concat(a), this._nDataBytes += a.sigBytes;
            },
            _process: function(k) {
                var b = this._data, d = b.words, c = b.sigBytes, i = this.blockSize, l = c / (4 * i);
                k = (l = k ? a.ceil(l) : a.max((0 | l) - this._minBufferSize, 0)) * i, c = a.min(4 * k, c);
                if (k) {
                    for (var h = 0; h < k; h += i) this._doProcessBlock(d, h);
                    h = d.splice(0, k), b.sigBytes -= c;
                }
                return r.create(h, c);
            },
            clone: function() {
                var a = q.clone.call(this);
                return a._data = this._data.clone(), a;
            },
            _minBufferSize: 0
        });
        e.Hasher = h.extend({
            init: function() {
                this.reset();
            },
            reset: function() {
                h.reset.call(this), this._doReset();
            },
            update: function(a) {
                return this._append(a), this._process(), this;
            },
            finalize: function(a) {
                return a && this._append(a), this._doFinalize(), this._hash;
            },
            clone: function() {
                var a = h.clone.call(this);
                return a._hash = this._hash.clone(), a;
            },
            blockSize: 16,
            _createHelper: function(a) {
                return function(b, d) {
                    return a.create(d).finalize(b);
                };
            },
            _createHmacHelper: function(a) {
                return function(b, d) {
                    return ea.HMAC.create(a, d).finalize(b);
                };
            }
        });
        var ea = m.algo = {};
        return m;
    }(Math);
    !function(a) {
        var g, m = (g = CryptoJS).lib, e = m.Base, q = m.WordArray;
        (g = g.x64 = {}).Word = e.extend({
            init: function(a, e) {
                this.high = a, this.low = e;
            }
        }), g.WordArray = e.extend({
            init: function(e, y) {
                e = this.words = e || [], this.sigBytes = void 0 != y ? y : 8 * e.length;
            },
            toX32: function() {
                for (var a = this.words, e = a.length, n = [], l = 0; l < e; l++) {
                    var g = a[l];
                    n.push(g.high), n.push(g.low);
                }
                return q.create(n, this.sigBytes);
            },
            clone: function() {
                for (var a = e.clone.call(this), g = a.words = this.words.slice(0), n = g.length, l = 0; l < n; l++) g[l] = g[l].clone();
                return a;
            }
        });
    }(), function() {
        function a() {
            return q.create.apply(q, arguments);
        }
        var g = CryptoJS, m = g.lib.Hasher, q = (e = g.x64).Word, r = e.WordArray, e = g.algo, y = [ a(1116352408, 3609767458), a(1899447441, 602891725), a(3049323471, 3964484399), a(3921009573, 2173295548), a(961987163, 4081628472), a(1508970993, 3053834265), a(2453635748, 2937671579), a(2870763221, 3664609560), a(3624381080, 2734883394), a(310598401, 1164996542), a(607225278, 1323610764), a(1426881987, 3590304994), a(1925078388, 4068182383), a(2162078206, 991336113), a(2614888103, 633803317), a(3248222580, 3479774868), a(3835390401, 2666613458), a(4022224774, 944711139), a(264347078, 2341262773), a(604807628, 2007800933), a(770255983, 1495990901), a(1249150122, 1856431235), a(1555081692, 3175218132), a(1996064986, 2198950837), a(2554220882, 3999719339), a(2821834349, 766784016), a(2952996808, 2566594879), a(3210313671, 3203337956), a(3336571891, 1034457026), a(3584528711, 2466948901), a(113926993, 3758326383), a(338241895, 168717936), a(666307205, 1188179964), a(773529912, 1546045734), a(1294757372, 1522805485), a(1396182291, 2643833823), a(1695183700, 2343527390), a(1986661051, 1014477480), a(2177026350, 1206759142), a(2456956037, 344077627), a(2730485921, 1290863460), a(2820302411, 3158454273), a(3259730800, 3505952657), a(3345764771, 106217008), a(3516065817, 3606008344), a(3600352804, 1432725776), a(4094571909, 1467031594), a(275423344, 851169720), a(430227734, 3100823752), a(506948616, 1363258195), a(659060556, 3750685593), a(883997877, 3785050280), a(958139571, 3318307427), a(1322822218, 3812723403), a(1537002063, 2003034995), a(1747873779, 3602036899), a(1955562222, 1575990012), a(2024104815, 1125592928), a(2227730452, 2716904306), a(2361852424, 442776044), a(2428436474, 593698344), a(2756734187, 3733110249), a(3204031479, 2999351573), a(3329325298, 3815920427), a(3391569614, 3928383900), a(3515267271, 566280711), a(3940187606, 3454069534), a(4118630271, 4000239992), a(116418474, 1914138554), a(174292421, 2731055270), a(289380356, 3203993006), a(460393269, 320620315), a(685471733, 587496836), a(852142971, 1086792851), a(1017036298, 365543100), a(1126000580, 2618297676), a(1288033470, 3409855158), a(1501505948, 4234509866), a(1607167915, 987167468), a(1816402316, 1246189591) ], n = [];
        !function() {
            for (var l = 0; 80 > l; l++) n[l] = a();
        }(), e = e.SHA512 = m.extend({
            _doReset: function() {
                this._hash = r.create([ a(1779033703, 4089235720), a(3144134277, 2227873595), a(1013904242, 4271175723), a(2773480762, 1595750129), a(1359893119, 2917565137), a(2600822924, 725511199), a(528734635, 4215389547), a(1541459225, 327033209) ]);
            },
            _doProcessBlock: function(a, e) {
                for (var g = (h = this._hash.words)[0], k = h[1], b = h[2], d = h[3], c = h[4], i = h[5], m = h[6], h = h[7], q = g.high, r = g.low, W = k.high, K = k.low, X = b.high, L = b.low, Y = d.high, M = d.low, Z = c.high, N = c.low, $ = i.high, O = i.low, aa = m.high, P = m.low, ba = h.high, Q = h.low, t = q, o = r, E = W, C = K, F = X, D = L, T = Y, G = M, u = Z, p = N, R = $, H = O, S = aa, I = P, U = ba, J = Q, v = 0; 80 > v; v++) {
                    var z = n[v];
                    if (16 > v) var s = z.high = 0 | a[e + 2 * v], f = z.low = 0 | a[e + 2 * v + 1]; else {
                        f = (s = n[v - 15]).high, s = ((w = s.low) << 31 | f >>> 1) ^ (w << 24 | f >>> 8) ^ f >>> 7;
                        var w = (f << 31 | w >>> 1) ^ (f << 24 | w >>> 8) ^ (f << 25 | w >>> 7), B = (f = (B = n[v - 2]).high, 
                        ((j = B.low) << 13 | f >>> 19) ^ (f << 3 | j >>> 29) ^ f >>> 6), j = (f << 13 | j >>> 19) ^ (j << 3 | f >>> 29) ^ (f << 26 | j >>> 6), V = (f = n[v - 7]).high, x = (A = n[v - 16]).high, A = A.low;
                        s = (s = (s = s + V + ((f = w + f.low) >>> 0 < w >>> 0 ? 1 : 0)) + B + ((f = f + j) >>> 0 < j >>> 0 ? 1 : 0)) + x + ((f = f + A) >>> 0 < A >>> 0 ? 1 : 0);
                        z.high = s, z.low = f;
                    }
                    V = u & R ^ ~u & S, A = p & H ^ ~p & I, z = t & E ^ t & F ^ E & F;
                    var fa = o & C ^ o & D ^ C & D, ga = (w = (o << 4 | t >>> 28) ^ (t << 30 | o >>> 2) ^ (t << 25 | o >>> 7), 
                    B = (t << 4 | o >>> 28) ^ (o << 30 | t >>> 2) ^ (o << 25 | t >>> 7), (j = y[v]).high), ca = j.low;
                    x = (x = (x = (x = U + ((p << 18 | u >>> 14) ^ (p << 14 | u >>> 18) ^ (u << 23 | p >>> 9)) + ((j = J + ((u << 18 | p >>> 14) ^ (u << 14 | p >>> 18) ^ (p << 23 | u >>> 9))) >>> 0 < J >>> 0 ? 1 : 0)) + V + ((j = j + A) >>> 0 < A >>> 0 ? 1 : 0)) + ga + ((j = j + ca) >>> 0 < ca >>> 0 ? 1 : 0)) + s + ((j = j + f) >>> 0 < f >>> 0 ? 1 : 0), 
                    z = w + z + ((f = B + fa) >>> 0 < B >>> 0 ? 1 : 0), U = S, J = I, S = R, I = H, 
                    R = u, H = p, u = T + x + ((p = G + j | 0) >>> 0 < G >>> 0 ? 1 : 0) | 0, T = F, 
                    G = D, F = E, D = C, E = t, C = o, t = x + z + ((o = j + f | 0) >>> 0 < j >>> 0 ? 1 : 0) | 0;
                }
                r = g.low = r + o | 0, g.high = q + t + (r >>> 0 < o >>> 0 ? 1 : 0) | 0, K = k.low = K + C | 0, 
                k.high = W + E + (K >>> 0 < C >>> 0 ? 1 : 0) | 0, L = b.low = L + D | 0, b.high = X + F + (L >>> 0 < D >>> 0 ? 1 : 0) | 0, 
                M = d.low = M + G | 0, d.high = Y + T + (M >>> 0 < G >>> 0 ? 1 : 0) | 0, N = c.low = N + p | 0, 
                c.high = Z + u + (N >>> 0 < p >>> 0 ? 1 : 0) | 0, O = i.low = O + H | 0, i.high = $ + R + (O >>> 0 < H >>> 0 ? 1 : 0) | 0, 
                P = m.low = P + I | 0, m.high = aa + S + (P >>> 0 < I >>> 0 ? 1 : 0) | 0, Q = h.low = Q + J | 0, 
                h.high = ba + U + (Q >>> 0 < J >>> 0 ? 1 : 0) | 0;
            },
            _doFinalize: function() {
                var a = this._data, e = a.words, h = 8 * this._nDataBytes, g = 8 * a.sigBytes;
                e[g >>> 5] |= 128 << 24 - g % 32, e[31 + (g + 128 >>> 10 << 5)] = h, a.sigBytes = 4 * e.length, 
                this._process(), this._hash = this._hash.toX32();
            },
            blockSize: 32
        }), g.SHA512 = m._createHelper(e), g.HmacSHA512 = m._createHmacHelper(e);
    }();
    return hex_sha512;
}({});

SpriteMorph.prototype.categories.push("mearm"), SpriteMorph.prototype.blockColor.mearm = new Color(255, 0, 0), 
Process.prototype.mearmOpenGrip = function() {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.openGrip(function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
}, Process.prototype.mearmCloseGrip = function() {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.closeGrip(function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
}, Process.prototype.mearmMoveBaseTo = function(angle) {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.moveBaseTo(angle, function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
}, Process.prototype.mearmMoveLowerTo = function(angle) {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.moveLowerTo(angle, function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
}, Process.prototype.mearmMoveUpperTo = function(angle) {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.moveUpperTo(angle, function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
}, Process.prototype.mearmMoveGripTo = function(angle) {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.moveGripTo(angle, function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
}, Process.prototype.mearmStop = function() {
    if (mearm.ready()) {
        if (void 0 === this.context.proceed) {
            var self = this;
            this.context.proceed = !1, mearm.stop(function(state, msg) {
                "complete" === state && self.context && (self.context.proceed = !0);
            });
        }
        if (this.context.proceed) return null;
        this.pushContext("doYield"), this.pushContext();
    }
};

var init = function() {
    loadFile("/a/remote.css", "css", function(res) {
        qs("#app").innerHTML = '<canvas id="world" tabindex="1" style="position: absolute;" />';
        var world;
        window.mirobot;
        IDE_Morph.prototype.reactToWorldResize = function(rect) {
            this.isAutoFill && (rect.origin.y = document.getElementById("header").getBoundingClientRect().height, 
            this.setPosition(rect.origin), this.setExtent(rect.extent())), this.filePicker && (document.body.removeChild(this.filePicker), 
            this.filePicker = null);
        }, (world = new WorldMorph(document.getElementById("world"))).worldCanvas.focus();
        var IDE = new IDE_Morph(!1);
        if (IDE.loadNewProject = !1, IDE.userLanguage = String.locale, IDE.openIn(world), 
        IDE.toggleStageSize(!0), hasLocalStorage()) new SaveMenu("#menu", {
            saveHandler: function(name) {
                return IDE.setProjectName(name), IDE.serializer.serialize(IDE.stage);
            },
            loadHandler: function(prog) {
                return IDE.rawOpenProjectString(prog);
            },
            clearHandler: function() {
                return IDE.newProject();
            },
            namespace: "snap",
            fileType: "js"
        });
        IDE.setLanguage(String.locale), setInterval(function() {
            world.doOneCycle();
        }, 1);
    });
};